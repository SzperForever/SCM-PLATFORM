
CREATE  PROCEDURE [dbo].[SP_KIT_AddNewSplitOrder]

		--@WorkCell varchar(20),
		@FatherOrderID varchar(13),
		@Kits_Qty FLOAT,
		@BuildPlanTime datetime,
		@ReasonFlag int,
		@ReasonCode nchar(10),
		@SplitReason varchar(1000)
		
		--@Priority varchar(10)
		
AS
	begin		
		declare @OrderID Varchar(13),@KittingPartNum nvarchar(30),@ProgressCode int
		DECLARE @dt CHAR(6),@CreateBy varchar(15)
		SELECT @dt=dt FROM v_GetDate	
		
		Select @KittingPartNum= kittingpartnum 
					,@ProgressCode = ProgressCode
								from TB_KIT_ORDER_HEADER 
								where OrderID = @FatherOrderID 
		set @CreateBy = (Select Order_ReleasedBy  
								from TB_KIT_ORDER_HEADER 
								where OrderID = @FatherOrderID )
								
		set @orderid = (SELECT 'K'+ @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(orderid),6),0),6) 
						FROM TB_KIT_ORDER_HEADER  WITH(XLOCK,PAGLOCK) 
						WHERE orderid like 'K' + @dt+'%')
		--print @orderid
		
		if @ProgressCode > 301
			begin
				raiserror ('You are not allowed to split order when progress code is over 301.',16,1)
				return
			end

		INSERT INTO dbo.TB_KIT_ORDER_HEADER
           ([OrderID]
           ,[OrderStatus]
           ,[KittingPartNum]
           ,[BuildPlanTime]
           ,[Kits_Qty]
           ,Order_ReleasedBy
           ,Order_ReleasedTime
           ,ProgressCode  
           ,[CurrentPlace]
           ,Flag 
		   ,[Station]
		   ,IsChildOrder
           ,[UserDefinedColumn1]
           ,[ReasonCode]
           ,[OrderNotes])           
			VALUES (@orderid			
				--dbo.f_NextBH(@Model,@Batch)--自定义函数，相同MODEL,相同套数,相同BATCH用同一个orderID.
				,'OPEN'
				,@KittingPartNum
				,@BuildPlanTime
				,@Kits_Qty
				,@CreateBy
				,GETDATE()
				,300
				,'KIT'
				,@ReasonFlag
				,0
				,1
				,@FatherOrderID 
				,@ReasonCode
				, '//This is a child order. It was splited from order:' + @FatherOrderID + '.Split Reason:' + @SplitReason )		
		
		if @@ERROR <> 0 
		begin
			raiserror ('Unknown error occured while inserting child order. Insert failed.',16,1)
			return
		end
		
		update dbo.TB_KIT_ORDER_HEADER 
		set Kits_Qty = Kits_Qty - @Kits_Qty 
			,OrderNotes = OrderNotes + '//Please be noted this order has child order(s)'  
		where OrderID = @FatherOrderID 
end

GO
