-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create TRIGGER [dbo].[Tri_Disible_kit_Upload]
   ON  [dbo].[Tb_Kitting_Order_Header]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--如果需要定时停止服务，则启用如下代码：

        declare @DatePeriod smalldatetime
	 
	if  getdate() < '2017-01-20 10:00:00' return
    if  getdate() < '2017-02-01 06:00:00' 
	begin		
		rollback tran
		RAISERROR ('You are not allowed to upload build plan during this period. ePull is out of service between 2017-01-20 10:00:00 and 2017-02-01 06:00:00. Any unclear please contact with Dai lisong.', 16, 1)
		return
     end

	return
END
GO
