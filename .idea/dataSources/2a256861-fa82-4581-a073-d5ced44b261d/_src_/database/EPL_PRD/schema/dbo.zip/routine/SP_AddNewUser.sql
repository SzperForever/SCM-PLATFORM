
CREATE PROCEDURE [dbo].[SP_AddNewUser]
	-- Add the parameters for the stored procedure here
		 @UserID nvarchar(10)
		,@UserRole nvarchar(20) 
		,@UserName nvarchar(20)
		,@Password nvarchar(20)
		,@UserLevel nvarchar(20)
		,@EnglishName nvarchar(20)
		,@Shift nvarchar(10)
		,@WorkStation nvarchar(30)
		,@Contacts nvarchar(20)
		,@AddBy nvarchar(10)
		,@Addtime smalldatetime	
AS INSERT INTO [dbo].[Bas_User]
           ([UserID]
           ,[UserRole]
           ,[UserName]
           ,[Password]
           ,[UserLevel]
           ,[EnglishName]
           ,[Shift]
           ,[WorkStation]
           ,[Contacts]
           ,[AddBy]
           ,[AddTime])
     VALUES
           (@UserID
			,@UserRole 
			,@UserName
			,@Password
			,@UserLevel
			,@EnglishName
			,@Shift
			,@WorkStation
			,@Contacts
			,@AddBy
			,@AddTime)
GO
