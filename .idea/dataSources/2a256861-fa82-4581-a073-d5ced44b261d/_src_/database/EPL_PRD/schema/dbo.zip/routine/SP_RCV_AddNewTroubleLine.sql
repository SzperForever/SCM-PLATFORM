-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-2-16>
-- Description:	<Add New Trouble Shelf Item and send an alert msg.>
-- =============================================
CREATE PROCEDURE [dbo].[SP_RCV_AddNewTroubleLine]
	-- Add the parameters for the stored procedure here
			--@RegDate date
            @Plant nchar(4)
           ,@WorkCell nvarchar(20)
           ,@PartNumber nvarchar(20)
           ,@PO nvarchar(20)
           ,@Qty float
           ,@Vendor nvarchar(20)
           ,@FromWhere nvarchar(20)
           ,@HAWB nvarchar(20)
           ,@Buyer nvarchar(100)
           ,@BuyerMailAddress nvarchar(100)
           ,@Reason nvarchar(max)
           ,@AddWho nvarchar(20)
           ,@AddPC nvarchar(20)
           ,@SN nvarchar(11)
           ,@Flag nvarchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare  @TrackingNumber varchar(12)
			,@dt CHAR(6)
			,@Rcount int
			,@RecAddressList nvarchar(250)
			,@CopyList nvarchar(2000)
			,@MailSubj nvarchar(200)
			,@Msg nvarchar(max)
			,@tableHTML  NVARCHAR(MAX) 
	
	SELECT @dt=dt FROM v_GetDate		
	select @Rcount = (select COUNT(*) 
					  from TB_RCV_TroubleShelf 
					  where WorkCell = @WorkCell and Partnumber =@PartNumber and qty =@Qty and vendor = @Vendor and buyer = @buyer and HAWB = @HAWB and Reason = @reason and sn = @SN )

	if @Rcount = 0
		begin
			set @TrackingNumber =(SELECT @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(TrackingNumber),6),0),6) 
								  FROM TB_RCV_TroubleShelf WITH(XLOCK,PAGLOCK) 
								  WHERE TrackingNumber like @dt+'%')
		end   
	else begin
		raiserror('You are trying to insert an item which already exsit in epull system.Please double confirm.',16,1)	
	end  
	
	select @RecAddressList = @BuyerMailAddress 
	set @CopyList = (select CopyList  from Cfg_DBmail where AlertName = 'AddNewHoldItem')
	set @MailSubj = (select Subject   from Cfg_DBmail where AlertName = 'AddNewHoldItem')
	--Steed_gu@jabil.com;qiudi_wang@jabil.com;zhu_jifeng@jabil.com
	select @Msg = 'Dear ' + @Buyer + ',' + CHAR(10) + 
			 'You have a new hold item as below and a soonest reply is required.Otherwise your supervisor will get an alert message after 24 hours.' 
	
	INSERT INTO [dbo].[TB_RCV_TroubleShelf]
           ([RegDate]
           ,[Plant]
           ,[WorkCell]
           ,[TrackingNumber]
           ,[PartNumber]
           ,[PO]
           ,[Qty]
           ,[Vendor]
           ,[FromWhere]
           ,[HAWB]
           ,[Buyer]
           ,[BuyerMailAddress]
           ,[Reason]
           ,[AddTime]
           ,[AddWho]
           ,[AddPC]
           ,[SN]
           ,[ItemStatus]
           ,[Flag])
     VALUES(CONVERT(varchar(100), GETDATE(), 23) 
           ,@Plant 
           ,@WorkCell 
           ,@TrackingNumber 
           ,@PartNumber 
           ,@PO 
           ,@Qty 
           ,@Vendor 
           ,@FromWhere
           ,@HAWB
           ,@Buyer 
           ,@BuyerMailAddress
           ,@Reason 
           ,GETDATE() 
           ,@AddWho 
           ,@AddPC
           ,@SN
           ,'Open'
           ,@Flag)
     
     IF @@ROWCOUNT = 0 BEGIN
		raiserror('System error occured. Please contact with system administrator.',16,1)	
		RETURN
     END
	
	SET @tableHTML = @Msg +
		N'<H1>New Hold Item on Trouble Shelf </H1>' +
		N'<table border="1">' +
		N'<tr><th>Date</th><th>Plant</th><th>WorkCell</th><th>TrackingNumber</th><th>PartNumber</th><th>PO</th>' +
		N'<th>Qty</th><th>Vendor</th><th>Source</th><th>HAWB</th><th>Reason</th><th>Buyer_Or_Planner</th><th>CreateBy</th><th>CreateTime</th><th>SN</th><th>RaiseByArea</th></tr>' +
		CAST ( ( SELECT td = a.RegDate,       '',
						td = a.Plant, '',
						td = a.WorkCell, '',
						td = a.TrackingNumber, '',
						td = a.PartNumber, '',
						td = a.PO , '',
						td = a.Qty, '',
						td = a.Vendor, '',
						td = a.FromWhere, '',
						td = a.HAWB,'',
						td = a.Reason, '',
						td = a.Buyer, '',
						td = a.Addwho, '',
						td = a.AddTime, '',
						td = a.SN,'',
						td = b.WorkStation ,''
				  from TB_RCV_TroubleShelf as a join Bas_User as b on a.AddWho = b.UserName 
				  where TrackingNumber = @TrackingNumber
				  --WorkCell = @WorkCell and Partnumber =@PartNumber and qty =@Qty and vendor = @Vendor and buyer = @buyer and sn = @SN and ItemStatus = 'Open'
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		'It is very important.Please reply and get support from RCV team as soon as possible.
		                                                                                                    Form# : 25-IC30-GEN-010-06A';
     
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name ='EpullSqlMail',
	@recipients = @RecAddressList,
	@copy_recipients = @CopyList,
	@subject =@MailSubj ,
	@body = @tableHTML,
    @body_format = 'HTML' ;
END
GO
