CREATE VIEW dbo.View_FG_SR_Headers
AS
SELECT        h.SRid, h.SRno, c.English_DESC AS Status, c1.English_DESC AS Order_Status, c2.English_DESC AS SP_Status, h.Project, h.Requestor, RTRIM(f.ForwarderName) 
                         AS ForwarderName, h.ReasonCodeID, h.PlaceWhere, h.Plan_Pick_Time, u.UserName AS CreateBy, h.ActivateTime, COUNT(DISTINCT d.PartNum) AS SR_Part_Cnt, 
                         COUNT(DISTINCT m.MPno) AS MP_Cnt, SUM(ISNULL(m.MP_Items_Cnt, 0)) AS MP_Items_Cnt, ca.DocCnt AS TotalDocCnt, ca.TotalGrossWeight, ca.TotalNetWeight, 
                         h.PackingTime, h.PGI_Time, h.Load_Truck_Time, h.Truck_No, h.SoldToCode, h.ShipToCode, h.TradeTerms, h.Actual_Pick_Time, u2.UserName AS ActivatedBy, 
                         RTRIM(h.SoldToAddress) AS SoldToAddress, RTRIM(h.ShipToAddress) AS ShipToAddress, h.CancelTime, h.CloseTime, h.SR_Status, h.SR_OrderStatus, 
                         h.SR_SP_Status, h.CreateBy AS SRCreateBy, h.Flag, c3.Chinese_DESC AS AbnormalReason, h.AWB, h.OrderNotes, h.EstimatePkgCnt, h.IsPlt, P.TotalCtnCnt, 
                         (CASE WHEN h.isplt = 1 THEN h.EstimatePkgCnt ELSE 0 END) AS TotalPltCnt, h.AllowUpdate
FROM            dbo.TB_FG_SR_Header AS h LEFT OUTER JOIN
                         dbo.TB_FG_MP_Details AS m ON m.SRid = h.SRid LEFT OUTER JOIN
                             (SELECT        SRid, COUNT(BoxID) AS TotalCtnCnt
                               FROM            dbo.TB_FG_PKG_Details
                               GROUP BY SRid) AS P ON P.SRid = h.SRid LEFT OUTER JOIN
                         dbo.View_FG_Calc AS ca ON h.SRid = ca.SRid LEFT OUTER JOIN
                         dbo.Bas_Code AS c3 ON h.ReasonCodeID = c3.CodeID LEFT OUTER JOIN
                         dbo.Bas_Code AS c1 ON h.SR_OrderStatus = c1.Code LEFT OUTER JOIN
                         dbo.Bas_Code AS c2 ON h.SR_SP_Status = c2.Code LEFT OUTER JOIN
                         dbo.View_Users AS u ON u.UserID = h.CreateBy LEFT OUTER JOIN
                         dbo.View_Users AS u1 ON h.ScanBy = u1.UserID LEFT OUTER JOIN
                         dbo.View_Users AS u2 ON h.ActivateBy = u2.UserID LEFT OUTER JOIN
                         dbo.Bas_FG_Forwarders AS f ON h.ForwarderID = f.ID LEFT OUTER JOIN
                         dbo.TB_FG_SR_Details AS d ON h.SRid = d.SRid LEFT OUTER JOIN
                         dbo.Bas_Code AS c ON h.SR_Status = c.Code
GROUP BY h.SRid, h.SRno, c.English_DESC, c1.English_DESC, c2.English_DESC, h.Project, h.Requestor, h.Plan_Pick_Time, h.Actual_Pick_Time, u.UserName, u.UserName, 
                         h.PGI_Time, h.Load_Truck_Time, h.Truck_No, h.CancelTime, h.CloseTime, h.SoldToCode, h.ShipToCode, RTRIM(h.SoldToAddress), RTRIM(h.ShipToAddress), 
                         h.TradeTerms, u2.UserName, h.OrderNotes, RTRIM(f.ForwarderName), h.SR_Status, h.SR_OrderStatus, h.SR_SP_Status, h.CreateBy, h.Flag, h.PlaceWhere, 
                         h.ReasonCodeID, c3.Chinese_DESC, ca.DocCnt, ca.TotalGrossWeight, ca.TotalNetWeight, h.AWB, h.EstimatePkgCnt, h.IsPlt, h.PackingTime, h.AllowUpdate, 
                         P.TotalCtnCnt, h.ActivateTime
GO
