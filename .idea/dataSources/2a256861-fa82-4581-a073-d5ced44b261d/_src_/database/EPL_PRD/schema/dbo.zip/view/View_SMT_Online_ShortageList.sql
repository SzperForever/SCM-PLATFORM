CREATE VIEW dbo.View_SMT_Online_ShortageList
AS
SELECT     TOP (100) PERCENT a.OrderID, u.WorkCell, u.BuildPlanTime, u.CreateBy, u.BayNum, u.Model, u.FinishRate, a.Component, a.needqty, a.Actualqty, 
                      a.diffqty
FROM         dbo.View_MultiMdoel_SMT_KittingStatus AS a LEFT OUTER JOIN
                      dbo.Tb_Order_Details AS u ON a.OrderID = u.OrderID
WHERE     (a.diffqty < 0) AND (a.OrderID IN
                          (SELECT DISTINCT OrderID
                            FROM          dbo.Tb_Order_Details
                            WHERE      (OrderStatus = 'Open') AND (PullStatus = 'Close') AND (ConditionalFormat = 'Inprogress') AND (CurrentPlace = 'Online')))
GROUP BY a.OrderID, a.Component, a.needqty, a.Actualqty, a.diffqty, u.WorkCell, u.BuildPlanTime, u.CreateBy, u.BayNum, u.Model, u.FinishRate
ORDER BY a.OrderID, a.Component
GO
