/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.[V_Kanban_STOCK&LVHM_Count_Source]
AS
SELECT     DocYear, ShortDate_Rec, LongDate_Rec, BP_WEEK, STOCK_WEEK, LVHM_WEEK, BP_DAY, STOCK_DAY, LVHM_DAY, COUNT(*) AS QTY
FROM         (SELECT     OrderID, OrderType, OrderStatus, PullStatus, LVHMsts, Model, PullListNo, BuildPlanTime, StockReceivedTime, StockCompleteTime, LVHMrequestTime, LVHMReceivedTime, 
                                              LVHMcompleteTime, SendLineTime, DATEPART(year, BuildPlanTime) AS DocYear, CONVERT(VARCHAR(6), BuildPlanTime, 6) AS ShortDate_Rec, CONVERT(date, BuildPlanTime) 
                                              AS LongDate_Rec, DATEPART(WEEK, BuildPlanTime) AS BP_WEEK, DATEPART(WEEK, StockCompleteTime) AS STOCK_WEEK, DATEPART(WEEK, LVHMcompleteTime) AS LVHM_WEEK, 
                                              DATEPART(DAY, BuildPlanTime) AS BP_DAY, DATEPART(DAY, StockCompleteTime) AS STOCK_DAY, DATEPART(DAY, LVHMcompleteTime) AS LVHM_DAY
                       FROM          dbo.Tb_Order_Details
                       WHERE      (OrderType = 'AutoPull') AND (OrderStatus = 'Close') AND (PullStatus = 'Close')) AS t
GROUP BY DocYear, ShortDate_Rec, LongDate_Rec, BP_WEEK, STOCK_WEEK, LVHM_WEEK, BP_DAY, STOCK_DAY, LVHM_DAY
GO
