-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-08-20,>
-- Description:	<Comapre Inventory between SAP and LVHM SMT by sloc>
-- =============================================
CREATE PROCEDURE [dbo].[SP_View_SAP_VS_LVHM_SMT_INV]
	-- Add the parameters for the stored procedure here
	@Sloc nchar(4),
	@OrderID nchar(20),
	@Flag nchar(4)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if @Flag = 'Auto' begin
    -- Insert statements for procedure here
    SELECT *
		FROM(SELECT     a.Sloc As S_sloc , b_1.Sloc AS E_sloc, a.Material AS SAPPartNo, b_1.PartNo, a.Mtrl_Desc, a.Mtrl_Grp, ISNULL(a.StandPrice, 0.00) AS Stand_Price, ISNULL(a.Unrestricted, 0) 
			  AS SAPqty, SUM(ISNULL(b_1.Qty, 0)) AS LV_Qty, SUM(ISNULL(b_1.Qty, 0)) - ISNULL(a.Unrestricted, 0) AS VarianceQty, (SUM(ISNULL(b_1.Qty, 0)) - ISNULL(a.Unrestricted, 
			  0)) * ISNULL(a.StandPrice, 0.00) AS VarianceValue
			FROM         (SELECT     Sloc, Material, Mtrl_Grp, Mtrl_Type, StandPrice, Unrestricted, Unrestr_Cnsgt, Stock_In_Tfr, In_Qual_Insp, Cnsgt_Qual_In, Blocked, Blocked_Cnsgt, 
									  Total_Value, MRP, Mtrl_Desc, LastUpdateTime
			   FROM          dbo.TB_SAP_INV_FINAL
			   WHERE      (Sloc = @Sloc )) AS a FULL OUTER JOIN
				  (SELECT     OrderID, PartNo, Qty, GRN, ScanTime, PreparedBy, Remark, PreparedID, RegDate, WorkCell, BayNum, Sloc, Model, Sets, UploadBy, UploadTime, 
										   CheckFlag, CheckTime, CheckBy, QtyUpdateRmk, FlagGroup, DoneMark
					FROM          dbo.Tb_PreparedList
					WHERE      (OrderID = @OrderID )) AS b_1 ON a.Material = b_1.PartNo				
		GROUP BY a.Sloc, b_1.Sloc, a.Material, b_1.PartNo, a.Mtrl_Desc, a.Mtrl_Grp, a.StandPrice, a.Unrestricted)as tt
        where VarianceQty <>0
	end
	else begin
		SELECT     a.Sloc as S_Sloc, b_1.Sloc AS E_sloc, a.Material AS SAPPartNo, b_1.PartNo, a.[Material description], a.[Matl grp], ISNULL(a.[Stand Price], 0.00) AS Stand_Price, ISNULL(a.Unrestricted, 0) 
				  AS SAP_Qty, SUM(ISNULL(b_1.Qty, 0)) AS LV_Qty, SUM(ISNULL(b_1.Qty, 0)) - ISNULL(a.Unrestricted, 0) AS VarianceQty, (SUM(ISNULL(b_1.Qty, 0)) - ISNULL(a.Unrestricted, 
				  0)) * ISNULL(a.[Stand Price], 0.00) AS VarianceValue
		FROM        (SELECT     * 
				   FROM          dbo.tmp_Sap_Inventory 
				   WHERE      (Sloc = @Sloc )) AS a FULL OUTER JOIN
					  (SELECT     OrderID, PartNo, Qty, GRN, ScanTime, PreparedBy, Remark, PreparedID, RegDate, WorkCell, BayNum, Sloc, Model, Sets, UploadBy, UploadTime, 
											   CheckFlag, CheckTime, CheckBy, QtyUpdateRmk, FlagGroup, DoneMark
						FROM          dbo.Tb_PreparedList
						WHERE      (OrderID = @OrderID )) AS b_1 ON a.Material = b_1.PartNo
		GROUP BY a.Sloc, b_1.Sloc, a.Material, b_1.PartNo, a.[Material description], a.[Matl grp] , a.[Stand Price] , a.Unrestricted	
	end
END
GO
