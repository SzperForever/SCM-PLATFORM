
-- =============================================
-- Author:		<HANSON_Zhang>
-- Create date: <2012-12-9>
-- Description:	<Insert new pull item into kitting order>
-- =============================================
CREATE PROCEDURE [dbo].[SP_KIT_AddNewPull] 
	-- Add the parameters for the stored procedure here
	@PullListNo nvarchar(13),	
	@AddBy	nchar(10)	
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    
    
    
    
    --	针对库存不足的子订单，在有可用库存时在第一时间开料单时自动将需求时间推后72小时
    --	针对无图纸的订单，在第一时间开料单时自动将需求时间推后72小时
	Update dbo.TB_KIT_ORDER_HEADER 
	set PullListNo = @PullListNo
		,BuildPlanTime = DATEADD(hh,72,getdate())
		,Pull_ReleasedBy = @AddBy 
		,Pull_ReleasedTime = GETDATE()
		,Stock_sts = 'NotStarted'
		--,Stock_ReceivedTime = GETDATE()
		,CurrentPlace = 'STK'
		,ProgressCode = 301
	     --OrderNotes = OrderNotes + @StrNote
	where OrderID in (Select distinct OrderID 
						from dbo.TB_KIT_ORDER_HEADER 
						where Selective = 1 and OrderStatus = 'OPEN' AND (LEN(ISNULL(PullListNo, '')) = 0) and Flag > 0)
	
	if @@ERROR <> 0  raiserror ('Child order update failed.',16,1) 
	
	
   -- declare @StrNote nvarchar(100)
    --set @StrNote = convert(nvarchar,Getdate()) + 'Appended a pulllist by ' + @AddBy + '. PulllistNo:' + @PullListNo
	Update dbo.TB_KIT_ORDER_HEADER 
	set PullListNo = @PullListNo
		,BuildPlanTime = DATEADD(hh,72,getdate())
		,Pull_ReleasedBy = @AddBy 
		,Pull_ReleasedTime = GETDATE()
		,Stock_sts = 'NotStarted'
		--,Stock_ReceivedTime = GETDATE()
		,CurrentPlace = 'STK'
		,ProgressCode = 301
	     --OrderNotes = OrderNotes + @StrNote
	where OrderID in (Select distinct OrderID 
						from dbo.TB_KIT_ORDER_HEADER 
						where Selective = 1 and OrderStatus = 'OPEN' AND (LEN(ISNULL(PullListNo, '')) = 0))
		
	
												
END


GO
