CREATE VIEW dbo.V_KIT_RAW_Details
AS
SELECT        TOP (100) PERCENT h.OrderID, h.KittingPartNum, h.Kits_Qty, h.FinalQty, s.Component, s.[Qty Per], (CASE WHEN h.FinalQty IS NULL 
                         THEN s.[Qty Per] * h.Kits_Qty ELSE s.[Qty Per] * h.FinalQty END) AS RawQntySuppose, h.OrderCreateBy, h.OrderStatus, h.[Processing Status], h.ProcessingType,
                             (SELECT        ISNULL(SUM(Qnty), 0) AS Expr1
                               FROM            dbo.TB_KIT_RAW_HISTORY
                               WHERE        (OrderID = h.OrderID) AND (RawPartNum = s.Component)) AS ActualQnty
FROM            dbo.V_KIT_ORDER_HEADER AS h LEFT OUTER JOIN
                         dbo.Bas_SAPbom AS s ON h.KittingPartNum = s.[Assembly Name]
GO
