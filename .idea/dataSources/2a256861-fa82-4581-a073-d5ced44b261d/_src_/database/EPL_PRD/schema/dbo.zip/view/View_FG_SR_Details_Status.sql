CREATE VIEW dbo.View_FG_SR_Details_Status
AS
SELECT        d.SRid, h.SRno, d.PartNum, SUM(d.TotalQty) AS TotalQty, ISNULL
                             ((SELECT        SUM(ISNULL(Qty, 0)) AS Expr1
                                 FROM            dbo.TB_FG_PKG_Details AS d2
                                 WHERE        (SRid = d.SRid) AND (PartNum = d.PartNum)), 0) AS DoneQty, ISNULL
                             ((SELECT        SUM(ISNULL(Qty, 0)) AS Expr1
                                 FROM            dbo.TB_FG_PKG_Details AS d2
                                 WHERE        (SRid = d.SRid) AND (PartNum = d.PartNum)), 0) - SUM(d.TotalQty) AS Difference,
                             (SELECT        COUNT(DISTINCT BoxID) AS Expr1
                               FROM            dbo.TB_FG_PKG_Details AS d3
                               WHERE        (SRid = d.SRid) AND (PartNum = d.PartNum)) AS PkgCnt
FROM            dbo.TB_FG_SR_Details AS d LEFT OUTER JOIN
                         dbo.TB_FG_SR_Header AS h ON d.SRid = h.SRid
GROUP BY d.SRid, d.PartNum, h.SRno
GO
