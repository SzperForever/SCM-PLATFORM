CREATE VIEW dbo.V_M_Bom_NotIn_SAPBOM
AS
SELECT     View_T2.OrderID, View_T2.WorkCell, View_T2.PPLModelName, View_T1.Model, View_T2.Rev, View_T2.BayNum, View_T1.CreateBy, View_T2.CurrentPlace, View_T2.pkgInfoTapeWidth, 
                      View_T2.fsPartNum, View_T1.Component
FROM         (SELECT     OrderID, WorkCell, PPLModelName, Rev, BayNum, CurrentPlace, fsPartNum, pkgInfoTapeWidth
                       FROM          (SELECT DISTINCT a1.OrderID, a1.WorkCell, a1.PPLModelName, a1.Rev, a1.BayNum, a1.CurrentPlace, m.fsPartNum, m.pkgInfoTapeWidth
                                               FROM          dbo.Tb_Order_Details AS a1 INNER JOIN
                                                                      dbo.Bas_Machine_Feeder_Report AS m ON a1.Rev = m.Rev AND a1.BayNum = m.MAText AND a1.PPLModelName = m.Number
                                               WHERE      (a1.OrderStatus = 'Open') AND (a1.FlagGroup = 'SMT')) AS T2) AS View_T2 LEFT OUTER JOIN
                          (SELECT     OrderID, WorkCell, Model, Rev, BayNum, CurrentPlace, CreateBy, Component
                            FROM          (SELECT DISTINCT A2.OrderID, A2.WorkCell, A2.Model, A2.Rev, A2.BayNum, A2.CurrentPlace, N.Component, A2.CreateBy
                                                    FROM          dbo.Tb_Order_Details AS A2 INNER JOIN
                                                                           dbo.Bas_SAPbom AS N ON A2.Model = N.[Assembly Name]
                                                    WHERE      (A2.OrderStatus = 'Open') AND (A2.FlagGroup = 'SMT')) AS T1) AS View_T1 ON View_T2.OrderID = View_T1.OrderID AND View_T2.fsPartNum = View_T1.Component
WHERE     (View_T1.Component IS NULL) AND (View_T2.WorkCell NOT LIKE '%CN07%')
GO
