
CREATE PROCEDURE [dbo].[SP_UserPermission_Assignment]
	@UserRole varchar(20),
	@UserID varchar(10)
AS
	if @UserRole = 'IA'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 1
					  ,[IA_Pull_OrderCancel_1] = 1
					  ,[IA_Pull_OrderClosure_2] = 1
					  ,[IA_Pull_OrderMixClosure_3] = 1
					  ,[IA_Sup_Data_Maintaince_4] = 1
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 0
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 0
					  ,[LV_Pull_3PLReceiption_11] = 0
					  ,[LV_Sup_StoreIn_12] = 0
					  ,[LV_Sup_StoreOut_13] = 0
					  ,[LV_Sup_PickList_14] = 0
					  ,[LV_Sup_Inv_Inquire_15] = 1
					  ,[LV_Sup_Tra_Inquire_16] = 1
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 0
					  ,[LV_Sup_Sap_Comparesion_21] = 0
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 1
				 WHERE WorkStation = 'IA' and UserID = @UserID
 
		END
	if @UserRole = 'LVHM-All'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 1
					  ,[LV_Pull_PrepareListUpload_6] = 1
					  ,[LV_Pull_PrepareListEdit_7] = 1
					  ,[LV_Pull_SendToLine_8] = 1
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 1
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 1
					  ,[LV_Pull_3PLReceiption_11] = 1
					  ,[LV_Sup_StoreIn_12] = 1
					  ,[LV_Sup_StoreOut_13] = 1
					  ,[LV_Sup_PickList_14] = 1
					  ,[LV_Sup_Inv_Inquire_15] = 1
					  ,[LV_Sup_Tra_Inquire_16] = 1
					  ,[LV_Sup_Inv_Adj_17] = 1
					  ,[LV_Sup_Map_Setting_18] = 1
					  ,[LV_Sup_Bin_Setting_19] = 1
					  ,[LV_Sup_PullOrderPlace_20] = 1
					  ,[LV_Sup_Sap_Comparesion_21] = 1
					  ,[LV_Rts_ScanBefore_22] = 1
					  ,[LV_Rts_ScanAfter_23] = 1
					  ,[LV_Rts_LCZZ_24] = 1
					  ,[LV_Rts_AllowDelete_25] =1
					  ,[LV_Tool_CountingRecord_26] = 1
					  ,[LV_Tool_Sup_BinPrinter_27] = 1
					  ,[LV_Tool_LB_Printer_28] =1
					  ,[LV_Tool_BayLoc_Printer_29] = 1
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE WorkStation = 'LVHM-All' and UserID = @UserID
 
		END
	if @UserRole = 'LVHM-BoxBuild'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 1
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 1
					  ,[LV_Pull_3PLReceiption_11] = 1
					  ,[LV_Sup_StoreIn_12] = 1
					  ,[LV_Sup_StoreOut_13] = 1
					  ,[LV_Sup_PickList_14] = 1
					  ,[LV_Sup_Inv_Inquire_15] = 1
					  ,[LV_Sup_Tra_Inquire_16] = 1
					  ,[LV_Sup_Inv_Adj_17] = 1
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 1
					  ,[LV_Sup_Sap_Comparesion_21] = 1
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE WorkStation = 'LVHM-BoxBuild' and UserID = @UserID
 
		END
	if @UserRole = 'LVHM-Cisco SMT' or @UserRole = 'LVHM-NonCiscoSMT'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 1
					  ,[LV_Pull_PrepareListUpload_6] = 1
					  ,[LV_Pull_PrepareListEdit_7] = 1
					  ,[LV_Pull_SendToLine_8] = 1
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 0
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 1
					  ,[LV_Pull_3PLReceiption_11] = 1
					  ,[LV_Sup_StoreIn_12] = 0
					  ,[LV_Sup_StoreOut_13] = 0
					  ,[LV_Sup_PickList_14] = 0
					  ,[LV_Sup_Inv_Inquire_15] = 0
					  ,[LV_Sup_Tra_Inquire_16] = 0
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 0
					  ,[LV_Sup_Sap_Comparesion_21] = 0
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 1
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =1
					  ,[LV_Tool_BayLoc_Printer_29] = 1
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE (WorkStation = 'LVHM-Cisco SMT' or WorkStation = 'LVHM-NonCiscoSMT') and UserID = @UserID
 
		END
	if @UserRole = 'LVHM-MI'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 1
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 0
					  ,[LV_Pull_3PLReceiption_11] = 1
					  ,[LV_Sup_StoreIn_12] = 0
					  ,[LV_Sup_StoreOut_13] = 0
					  ,[LV_Sup_PickList_14] = 0
					  ,[LV_Sup_Inv_Inquire_15] = 0
					  ,[LV_Sup_Tra_Inquire_16] = 0
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 0
					  ,[LV_Sup_Sap_Comparesion_21] = 0
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE WorkStation = 'LVHM-MI' and UserID = @UserID
 
		END		
	if @UserRole = 'LVHM-RTS'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 0
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 0
					  ,[LV_Pull_3PLReceiption_11] = 0
					  ,[LV_Sup_StoreIn_12] = 0
					  ,[LV_Sup_StoreOut_13] = 0
					  ,[LV_Sup_PickList_14] = 0
					  ,[LV_Sup_Inv_Inquire_15] = 0
					  ,[LV_Sup_Tra_Inquire_16] = 0
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 0
					  ,[LV_Sup_Sap_Comparesion_21] = 0
					  ,[LV_Rts_ScanBefore_22] = 1
					  ,[LV_Rts_ScanAfter_23] = 1
					  ,[LV_Rts_LCZZ_24] = 1
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE WorkStation = 'LVHM-RTS' and UserID = @UserID
 
		END		
	if @UserRole = 'LVHM-SuperMarket'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 1
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 0
					  ,[LV_Pull_3PLReceiption_11] = 0
					  ,[LV_Sup_StoreIn_12] = 1
					  ,[LV_Sup_StoreOut_13] = 1
					  ,[LV_Sup_PickList_14] = 1
					  ,[LV_Sup_Inv_Inquire_15] = 1
					  ,[LV_Sup_Tra_Inquire_16] = 1
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 1
					  ,[LV_Sup_Sap_Comparesion_21] = 1
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE WorkStation = 'LVHM-SuperMarket' and UserID = @UserID
 
		END	
	if @UserRole = '3rd PL'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 0
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 0
					  ,[LV_Pull_3PLReceiption_11] = 0
					  ,[LV_Sup_StoreIn_12] = 0
					  ,[LV_Sup_StoreOut_13] = 0
					  ,[LV_Sup_PickList_14] = 0
					  ,[LV_Sup_Inv_Inquire_15] = 0
					  ,[LV_Sup_Tra_Inquire_16] = 0
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 0
					  ,[LV_Sup_Sap_Comparesion_21] = 0
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 1
					  ,[PL_Pull_MI_35] = 1
					  ,[PL_Pull_NonMI_36] = 1
					  ,[PL_Pull_201_37] =1
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE WorkStation = '3rd PL'  and UserID = @UserID
 
		END	
	if @UserRole = 'Shipping'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 0
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 0
					  ,[LV_Pull_3PLReceiption_11] = 0
					  ,[LV_Sup_StoreIn_12] = 0
					  ,[LV_Sup_StoreOut_13] = 0
					  ,[LV_Sup_PickList_14] = 0
					  ,[LV_Sup_Inv_Inquire_15] = 0
					  ,[LV_Sup_Tra_Inquire_16] = 0
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 0
					  ,[LV_Sup_Sap_Comparesion_21] = 0
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 1
					  ,[FG_StoreOut_39] = 1
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE WorkStation = 'Shipping'   and UserID = @UserID
		END	
	if @UserRole = 'All'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 1
					  ,[IA_Pull_OrderCancel_1] = 1
					  ,[IA_Pull_OrderClosure_2] = 1
					  ,[IA_Pull_OrderMixClosure_3] = 1
					  ,[IA_Sup_Data_Maintaince_4] = 1
					  ,[LV_Pull_Receiption_5] = 1
					  ,[LV_Pull_PrepareListUpload_6] = 1
					  ,[LV_Pull_PrepareListEdit_7] = 1
					  ,[LV_Pull_SendToLine_8] = 1
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 1
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 1
					  ,[LV_Pull_3PLReceiption_11] = 0
					  ,[LV_Sup_StoreIn_12] = 1
					  ,[LV_Sup_StoreOut_13] = 1
					  ,[LV_Sup_PickList_14] = 1
					  ,[LV_Sup_Inv_Inquire_15] = 1
					  ,[LV_Sup_Tra_Inquire_16] = 1
					  ,[LV_Sup_Inv_Adj_17] = 1
					  ,[LV_Sup_Map_Setting_18] = 1
					  ,[LV_Sup_Bin_Setting_19] = 1
					  ,[LV_Sup_PullOrderPlace_20] = 1
					  ,[LV_Sup_Sap_Comparesion_21] = 1
					  ,[LV_Rts_ScanBefore_22] = 1
					  ,[LV_Rts_ScanAfter_23] = 1
					  ,[LV_Rts_LCZZ_24] = 1
					  ,[LV_Rts_AllowDelete_25] =1
					  ,[LV_Tool_CountingRecord_26] = 1
					  ,[LV_Tool_Sup_BinPrinter_27] = 1
					  ,[LV_Tool_LB_Printer_28] =1
					  ,[LV_Tool_BayLoc_Printer_29] = 1
					  ,[Stk_Pull_AssignPicker_30] = 1
					  ,[Stk_Pull_201_OrderPlace_31] = 1
					  ,[Stk_Pull_201_Receiption_32] = 1
					  ,[Stk_Rts_Inquire_33] = 1
					  ,[PL_Pull_AssignPicker_34] = 1
					  ,[PL_Pull_MI_35] = 1
					  ,[PL_Pull_NonMI_36] = 1
					  ,[PL_Pull_201_37] =1
					  ,[FG_StoreIn_38] = 1
					  ,[FG_StoreOut_39] = 1
					  ,[Sys_User_40] = 1
					  ,[Sys_Log_41] = 1
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 1
				 WHERE WorkStation = 'All'   and UserID = @UserID
		END	
	if @UserRole = 'SMT Stock'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 0
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 0
					  ,[LV_Pull_3PLReceiption_11] = 0
					  ,[LV_Sup_StoreIn_12] = 0
					  ,[LV_Sup_StoreOut_13] = 0
					  ,[LV_Sup_PickList_14] = 0
					  ,[LV_Sup_Inv_Inquire_15] = 0
					  ,[LV_Sup_Tra_Inquire_16] = 0
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 0
					  ,[LV_Sup_Sap_Comparesion_21] = 0
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 1
					  ,[Stk_Pull_201_OrderPlace_31] = 1
					  ,[Stk_Pull_201_Receiption_32] = 1
					  ,[Stk_Rts_Inquire_33] = 1
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE WorkStation = 'SMT Stock' and UserID = @UserID
 
		END
	if @UserRole = 'LVHM-MA' 
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 0
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 0
					  ,[LV_Pull_3PLReceiption_11] = 0
					  ,[LV_Sup_StoreIn_12] = 0
					  ,[LV_Sup_StoreOut_13] = 0
					  ,[LV_Sup_PickList_14] = 0
					  ,[LV_Sup_Inv_Inquire_15] = 0
					  ,[LV_Sup_Tra_Inquire_16] = 0
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 0
					  ,[LV_Sup_Sap_Comparesion_21] = 0
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 1
				 WHERE WorkStation = 'LVHM-MA' and UserID = @UserID
 
		END	
	if @UserRole = 'Pkg 3PL'
		begin
			UPDATE [dbo].[Bas_User]
				   SET [IA_Pull_OrderUpload_0] = 0
					  ,[IA_Pull_OrderCancel_1] = 0
					  ,[IA_Pull_OrderClosure_2] = 0
					  ,[IA_Pull_OrderMixClosure_3] = 0
					  ,[IA_Sup_Data_Maintaince_4] = 0
					  ,[LV_Pull_Receiption_5] = 0
					  ,[LV_Pull_PrepareListUpload_6] = 0
					  ,[LV_Pull_PrepareListEdit_7] = 0
					  ,[LV_Pull_SendToLine_8] = 0
					  ,[LV_Pull_MI_MP_PlaceOrder_9] = 0
					  ,[LV_Pull_NonMI_MP_PlaceOrder_10] = 0
					  ,[LV_Pull_3PLReceiption_11] = 0
					  ,[LV_Sup_StoreIn_12] = 0
					  ,[LV_Sup_StoreOut_13] = 0
					  ,[LV_Sup_PickList_14] = 0
					  ,[LV_Sup_Inv_Inquire_15] = 0
					  ,[LV_Sup_Tra_Inquire_16] = 0
					  ,[LV_Sup_Inv_Adj_17] = 0
					  ,[LV_Sup_Map_Setting_18] = 0
					  ,[LV_Sup_Bin_Setting_19] = 0
					  ,[LV_Sup_PullOrderPlace_20] = 0
					  ,[LV_Sup_Sap_Comparesion_21] = 0
					  ,[LV_Rts_ScanBefore_22] = 0
					  ,[LV_Rts_ScanAfter_23] = 0
					  ,[LV_Rts_LCZZ_24] = 0
					  ,[LV_Rts_AllowDelete_25] =0
					  ,[LV_Tool_CountingRecord_26] = 0
					  ,[LV_Tool_Sup_BinPrinter_27] = 0
					  ,[LV_Tool_LB_Printer_28] =0
					  ,[LV_Tool_BayLoc_Printer_29] = 0
					  ,[Stk_Pull_AssignPicker_30] = 0
					  ,[Stk_Pull_201_OrderPlace_31] = 0
					  ,[Stk_Pull_201_Receiption_32] = 0
					  ,[Stk_Rts_Inquire_33] = 0
					  ,[PL_Pull_AssignPicker_34] = 0
					  ,[PL_Pull_MI_35] = 0
					  ,[PL_Pull_NonMI_36] = 0
					  ,[PL_Pull_201_37] =0
					  ,[FG_StoreIn_38] = 0
					  ,[FG_StoreOut_39] = 0
					  ,[Sys_User_40] = 0
					  ,[Sys_Log_41] = 0
					  ,[Fun_lockuser] =0
					  ,[Fun_EndSession_43] = 0
					  ,[Fun_Pw_Change_44] = 1
					  ,[IA_RTS_Analysis_45] = 0
				 WHERE WorkStation = 'Pkg 3PL' and UserID = @UserID
		end
	if @UserRole not in(select distinct workstation from Bas_User)
		begin
			rollback tran
			raiserror('Out of user role definition',16,1)			
		end
GO
