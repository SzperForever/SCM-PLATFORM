
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_KIT_AssignPeople]
	-- Add the parameters for the stored procedure here
	@AssignedTo nchar(10),
	@AssignedBy nchar(10),
	@PullListNo nchar(13)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE TB_KIT_ORDER_HEADER 
	SET Stock_Sts  = 'InProgress'
	  ,Stock_PickingTime = GETDATE()
      ,Stock_AssignedBy = @AssignedBy
      ,Stock_AssignedTo = @AssignedTo
	  ,ProgressCode = 302
	WHERE Pulllistno = @PullListNo and OrderStatus = 'Open'	

END

GO
