CREATE VIEW dbo.View_SR_WorkLoad
AS
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '06:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '04:30:00:000' AND '06:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '08:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '06:30:00:000' AND '08:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '10:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '08:30:00:000' AND '10:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '12:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '10:30:00:000' AND '12:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '14:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '12:30:00:000' AND '14:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '16:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '14:30:00:000' AND '16:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '18:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '16:30:00:000' AND '18:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '20:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '18:30:00:000' AND '20:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '22:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '20:30:00:000' AND '22:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '00:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '22:30:00:000' AND '00:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '02:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '00:30:00:000' AND '02:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
UNION
SELECT     COUNT(SRNo) AS TotalSRcnt,sum(MPItems) AS TotalMPItems, '04:30' AS HourPeriod, CONVERT(date, SRReceivedTime, 120) AS SR_Date
FROM         Tb_SR_Details a
WHERE     CONVERT(varchar(12), SRReceivedTime, 114) BETWEEN '02:30:00:000' AND '04:30:00:000'
GROUP BY CONVERT(date, SRReceivedTime, 120)
GO
