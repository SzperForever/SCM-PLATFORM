
CREATE VIEW [dbo].[V_KIT_BOM_TREE]
AS
SELECT DISTINCT h.KittingPartNum, s.Component, s.[Qty Per]
FROM            dbo.Bas_SAPbom AS s RIGHT OUTER JOIN
                         dbo.TB_KIT_ORDER_HEADER AS h ON s.[Assembly Name] = h.KittingPartNum

GO
