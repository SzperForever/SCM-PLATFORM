CREATE VIEW dbo.V_Kanban_Rec_ArriveRate_Monthly_LY
AS
SELECT        TOP (100) PERCENT 0.95 AS Goal, DocYear, ShortDate_Rec, LongDate_Rec,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.TB_RCV_InboundTracking
                               WHERE        (CONVERT(date, AddTime) = v.LongDate_Rec)) AS TotalDocCnt,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                               WHERE        (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls24Gt12' OR
                                                         PeriodType = 'Ls12')) AS DocCnt_LS24
FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v
WHERE        (LongDate_Rec BETWEEN DATEADD(dd, - 31, GETDATE()) AND GETDATE() - 1)
GROUP BY LongDate_Rec, ShortDate_Rec, DocYear
ORDER BY LongDate_Rec DESC
GO
