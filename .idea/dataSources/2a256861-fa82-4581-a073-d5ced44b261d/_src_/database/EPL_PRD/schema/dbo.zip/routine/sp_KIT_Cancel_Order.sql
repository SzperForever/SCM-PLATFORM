

CREATE PROCEDURE [dbo].[sp_KIT_Cancel_Order]
	@OrderID nvarchar(13)
AS
BEGIN
	SET NOCOUNT ON;

	Update TB_KIT_ORDER_HEADER 
	set orderstatus = 'CANCEL' 
		,ProgressCode = 314
		,CancelTime = GETDATE()
		,CanceledBy = Order_ReleasedBy
	where OrderID = @OrderID

END


GO
