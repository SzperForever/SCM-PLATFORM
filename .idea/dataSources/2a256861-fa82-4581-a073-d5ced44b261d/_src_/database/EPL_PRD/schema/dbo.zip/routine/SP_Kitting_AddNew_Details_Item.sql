

CREATE  PROCEDURE [dbo].[SP_Kitting_AddNew_Details_Item]
		@BatchID varchar(13),
		@PartNo varchar(25),
		@Qty numeric(18, 0),
		@GRN varchar(18),	
		@AddBy varchar(15),
		@ReturnCode varchar(200)		output
AS	
	begin
	
		Declare @OrderID VARCHAR(13),@Rcnt int,@DiffQty float,@ActualQty float
		
		set @Rcnt = (Select COUNT(0) from Tb_Kitting_Order_Header where KittingPartNum = @PartNo and OrderStatus = 'Open')
		if @Rcnt = 0 begin
			set @ReturnCode = 'Error:999,There is no demand avaliable for this kittingPartNum currently.'
			RAISERROR (@ReturnCode, 16, 1)
			return
		end
								
		--set @ActualQty = (select dbo.f_Kitting_getactualqty(@PartNo))
		--if @ActualQty = 0 set @BatchID = dbo.f_Kitting_NextBatchID()	
					
		exec [Ep_SP_addNewPreparedRecord] @batchid,@partno,@qty,@grn,@addby,'','KOM','','','0143','',0,'Kitting'
		
		--update Tb_Kitting_Order_Header 
		--set batchid = @BatchID 
		--where OrderID in(Select OrderID from view_kitting_batchlist where OrderStatus = 'Open' and BatchID = @BatchID) 
		
				INSERT INTO [dbo].[TB_Kitting_BatchList]
						   ([OrderID]
						   ,[BatchID]
						   ,grn
						   ,[AddBy]
						   ,[AddTime]
						   ,[PrintFlag]
						   ,IsCalculable)						   
				select orderid,@BatchID,@grn,@AddBy,getdate(),0,1
				from View_Kitting_Order_Headers 
				where KittingPartNum =@PartNo 		
		
		--set @DiffQty =(Select DiffQty 
		--				from View_Kitting_OverallStatus
		--				where [KittingPartNum] = @PartNo)
				
						
		--if @DiffQty  > = 0  BEGIN


		
		--		update Tb_Kitting_Order_Header 
		--		set OrderStatus = 'CLOSED',
		--		closedtime = getdate(),
		--		ClosedBy = @AddBy 
		--		where [KittingPartNum] = @PartNo 			
		--END
		

		set @ReturnCode = 'Kitting Details Records Inserted.'
		return
					
end


GO
