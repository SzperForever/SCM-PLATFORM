
CREATE PROCEDURE [dbo].[sp_BuildOrderCancel]
	@OrderID varchar(12),
	@CancelBy varchar(10),
	@Reason varchar(100),
	@MailAlertSwitch bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	declare @Msg varchar(200),@MailSubj  varchar(100),@RecList varchar(2000)
	
	update Tb_Order_Details set remark= remark + @reason,OrderStatus = 'Cancel',PullStatus = 'Cancel',CancelTime =GETDATE() where OrderID = @OrderID
	select @Msg= 'OrderID:' + @OrderID + ' was canceled By:' + @CancelBy + '! The reason marked is :' + @reason + ',Total ' + ltrim(STR(@@ROWCOUNT)) + ' Items affected. Please be noticed.'
	set @MailSubj = (Select Subject  from Cfg_DBmail where AlertName = 'SMTOrderCancelation')
	set @RecList=(Select recipients  from Cfg_DBmail where AlertName = 'SMTOrderCancelation')
	
	if @MailAlertSwitch = 1 begin
		EXEC msdb.dbo.sp_send_dbmail 
		@profile_name ='EpullSqlMail',
		@recipients = @RecList,
		@subject = @MailSubj,
		@body =@Msg
	end
END
GO
