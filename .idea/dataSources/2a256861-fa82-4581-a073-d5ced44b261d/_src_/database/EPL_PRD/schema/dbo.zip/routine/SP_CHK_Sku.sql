
CREATE PROCEDURE [dbo].[SP_CHK_Sku]
	@Material varchar(20),
	@ErrFlag int output,
	@ProjectName varchar(25) output
AS
BEGIN
	SET NOCOUNT ON;
	if exists(SELECT [Material]  FROM [dbo].[BAS_SKU] where Material = @Material AND Plant = 'CN04')
		begin
			SELECT @ProjectName = (Select Matlgroup FROM BAS_SKU WHERE Material = @Material AND Plant = 'CN04')
			select @ErrFlag = 0
		end
	else begin
		set @ProjectName = 'Unknown'
		select @ErrFlag = 1
	end
END


--SELECT * FROM BAS_SKU WHERE Material = 'GMHDW001336B'
GO
