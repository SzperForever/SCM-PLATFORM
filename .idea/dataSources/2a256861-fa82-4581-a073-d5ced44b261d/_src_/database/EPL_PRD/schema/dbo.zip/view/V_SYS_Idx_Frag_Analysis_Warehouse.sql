/*查看指定表的索引情况*/
CREATE VIEW dbo.V_SYS_Idx_Frag_Analysis_LVHM
AS
SELECT        TOP (100) PERCENT t.object_id, t.name AS TableName, i.index_id, i.name AS IdxName, s.avg_fragmentation_in_percent
FROM            sys.tables AS t INNER JOIN
                         sys.indexes AS i ON i.object_id = t.object_id INNER JOIN
                         sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('EPL_PRD'), NULL, NULL, 'limited') AS s ON s.object_id = i.object_id AND s.index_id = i.index_id
WHERE        (i.index_id > 0) AND (s.avg_fragmentation_in_percent > 15.0) AND (s.object_id IN (996914623, 780581869, 391008474, 1042154808, 1769109393, 1244583522, 
                         504388866, 1793441463, 253959981, 194151787, 914154352, 1767729400, 1474156347, 1342679881, 2114158627, 123199539, 1163203244, 167723700, 
                         2103730597, 919726379, 951726493, 999726664, 2071730483, 357628367, 631725353, 503724897, 1013630704, 2039014345, 1527012521, 1575012692, 
                         1433108196, 354100302, 807725980, 2151103, 1849109678, 1614680850, 943394480))
ORDER BY s.avg_fragmentation_in_percent DESC
GO
