
-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-11-14,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Kitting_ProlongDeliveryTime] 
	-- Add the parameters for the stored procedure here
	@OrderID nvarchar(13)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	Update Tb_Kitting_Order_Header 
	set BuildPlanTime = '2099-1-1 12:00:00',Flag = 1,OrderNotes = OrderNotes + '/This order has been prolonged the delivery time by kitting operator which means will delay the delivery time.'
	where OrderID = @OrderID 
	
	if @@ERROR <>  0 begin
		raiserror ('Failed to prolong the delivery time for this order.',16,1)
	end
END

GO
