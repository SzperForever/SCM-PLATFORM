-- =============================================
-- Author:		HANSON
-- Create date: 2014-11-4
-- Description:	<Description,,>
-- =============================================
Create PROCEDURE [dbo].[SP_Alert_Stk_Pull_HourlyReport]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
		
	set @AlertName = 'StockPullStatusHourlyReport'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	set @Rcnt = 0
	--set @Rcnt =(select COUNT(distinct PullListNo) from Tb_Order_Details 
	--			where OrderStatus = 'Open' and DATEDIFF(Minute,BuildPlanTime, GETDATE()) > '-120' 
	--				and DATEDIFF(Minute,BuildPlanTime, GETDATE()) < 0 
	--				AND FlagGroup = 'SMT' and LVHMsts <> 'Prepared' and LVHMsts <> 'SentToBuild' and StoreArea = '0100')	
	--if @Rcnt > 0
	
	--if @Rcnt = 0 or @@ERROR <> 0 begin
	--	return
	--end
	
	SET @tableHTML =
    N'<H1>StockRoom Hourly Order Status </H1>' +
    N'<table border="1">' +
    N'<tr><th>Order Date</th><th>Hour Period</th>' +
    N'<th>Open Pulls</th><th>Closed Pulls</th><th>Closed Hourly</th><th>OpenPartCount</th><th>ClosedPartCount</th><th>ClosedHourlyPartCount</th></tr>' +
    CAST ( ( SELECT td = PullDate,       '',
                    td = convert(varchar(8),TimePeriod,8), '',
                    td = OpenPulls, '',
                    td = ClosedPulls, '',
                    td = ClosedHourly, '',
                    td = OpenPartCount, '',
                    td = ClosedPartCount, '',
                    td = ClosedHourlyPartCount, ''
              FROM dbo.tb_Chart_StkPull
              WHERE  pulldate = convert(date,getdate()) order by TimePeriod asc                       
              FOR XML PATH('tr'), TYPE 
    ) AS NVARCHAR(MAX) ) +
    N'</table>' +    
    'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';

    
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END
GO
