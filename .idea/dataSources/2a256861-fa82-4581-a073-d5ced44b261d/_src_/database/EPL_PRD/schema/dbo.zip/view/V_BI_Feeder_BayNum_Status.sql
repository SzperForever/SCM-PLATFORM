CREATE VIEW dbo.V_BI_Feeder_BayNum_Status
AS
SELECT     TOP (100) PERCENT a.OrderID, a.Workcell, a.BayNum, a.ModelName, a.PlanBuildTime, a.PlanCompleteTime, a.Sets, a.Progress, a.RouteStep, b.Num AS BaySeq
FROM         (SELECT     OrderID, Workcell, BayNum, ModelName, PlanBuildTime, PlanCompleteTime, Sets, Bottom_Progress AS Progress, 'Bottom' AS RouteStep, ID
                       FROM          dbo.TB_Feeder_Setup_History
                       WHERE      (SetupStatus = 'open')
                       GROUP BY OrderID, Workcell, BayNum, ModelName, PlanBuildTime, PlanCompleteTime, Sets, Bottom_Progress, ID
                       UNION
                       SELECT     OrderID, Workcell, BayNum, ModelName, PlanBuildTime, PlanCompleteTime, Sets, Top_Progress AS Progress, 'TOP' AS RouteStep, ID
                       FROM         dbo.TB_Feeder_Setup_History AS TB_Feeder_Setup_History_1
                       WHERE     (SetupStatus = 'open')
                       GROUP BY OrderID, Workcell, BayNum, ModelName, PlanBuildTime, PlanCompleteTime, Sets, Top_Progress, ID) AS a INNER JOIN
                      dbo.Bas_LineNo AS b ON a.BayNum = b.BayNum
WHERE     (a.Progress IN ('Building', 'LoadingCompleted'))
ORDER BY BaySeq
GO
