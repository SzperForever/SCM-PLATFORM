CREATE  PROCEDURE [dbo].[SP_ADD_PI_BY_BIN]
	@PI_ID varchar(12) = 'New',
	@Sloc nchar(4),
	@BinLoc nchar(20),
	@PartNo nchar(30),
	@Qty float,
	@GRN NCHAR(18),
	@ReturnMsg nvarchar(500),
	@AddBy nchar(10),
	@Remark varchar(50),
	@ReturnID varchar(12) OUTPUT
           
AS
begin
	SET NOCOUNT ON;	
	DECLARE @dt CHAR(6)
	
	-- Add the T-SQL statements to compute the return value here
	
	SELECT @dt=dt FROM v_GetDate	
	if @PI_ID = 'New'
		BEGIN
			set @PI_ID = (SELECT 'P' + @dt+RIGHT(100001+ISNULL(RIGHT(MAX(PI_ID),5),0),5) 
					FROM [Tb_PI_By_Bin] WITH(XLOCK,PAGLOCK) 
					WHERE PI_ID like '%P' + @dt+'%')
			set @ReturnID = @PI_ID
		END
		
					
	INSERT INTO [EPL_PRD].[dbo].[Tb_PI_By_Bin]
           ([PI_ID]
           ,[Sloc]
           ,[BinLoc]
           ,[PartNum]
           ,[Qty]
           ,[GRN]
           ,[SledInfo]
           ,[AddBy]
           ,[Remark])
     VALUES(@PI_ID,@Sloc,@BinLoc,@PartNo,@Qty,@GRN,@ReturnMsg,@AddBy,@Remark)
     
end
GO
