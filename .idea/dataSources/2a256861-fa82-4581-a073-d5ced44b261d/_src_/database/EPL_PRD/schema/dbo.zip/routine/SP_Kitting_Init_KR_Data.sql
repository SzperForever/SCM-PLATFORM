


CREATE procedure [dbo].[SP_Kitting_Init_KR_Data]

as begin

if exists (Select * from tempdb.dbo.sysobjects Where name='##eP_tmp_KR' and  Xtype='U') drop table [##eP_tmp_KR]

CREATE TABLE ##eP_tmp_KR(
	[BuildPlanTime] [smalldatetime] NOT NULL,
	[AssemblyName] [nchar](30) NOT NULL,
	[DemandQty] float NOT NULL,
	[DmdType] int  -- 1 means normal, 0 means shortage
	--[QtyPer] varchar(20)
 CONSTRAINT [PK_tmp_KR] PRIMARY KEY CLUSTERED 
(
	[AssemblyName],[BuildPlanTime] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

	--ALTER TABLE ##eP_tmp_KR ALTER COLUMN [QtyPer] varchar(20)COLLATE Chinese_PRC_CI_AS 
	--ALTER TABLE ##eP_tmp_KR ALTER COLUMN [WorkCell] [nchar](25)COLLATE Chinese_PRC_CI_AS 
	--ALTER TABLE ##eP_tmp_KR ALTER COLUMN [AssemblyName] [nchar](25) COLLATE Chinese_PRC_CI_AS 

--Cannot resolve the collation conflict between "Chinese_PRC_CI_AS" and "SQL_Latin1_General_CP1_CI_AS" in the equal to operation.

end

GO
