CREATE VIEW dbo.View_Shipping_MergeBox
AS
SELECT     b.Mtrl_Grp, b.Material, b.[Available stock], a.STD_QTY, b.[Available stock] / a.STD_QTY AS BOXcout
FROM         dbo.Bas_Shipping_PCBA_STDQTY AS a RIGHT OUTER JOIN
                      dbo.View_Shipping_PCBA_BulkBIN_SUMavailablestock AS b ON a.Material = b.Material
WHERE     (b.[Available stock] / a.STD_QTY >= 1)
GO
