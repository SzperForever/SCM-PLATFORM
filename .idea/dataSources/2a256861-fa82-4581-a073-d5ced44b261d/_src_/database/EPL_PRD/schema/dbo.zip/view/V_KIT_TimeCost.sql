
CREATE VIEW [dbo].[V_KIT_TimeCost]
AS
SELECT        ID, OrderID, KittingPartNum, Kits_Qty, Station, ScheduledStartTime, ScheduledEndTime,
                             (SELECT        ProcessingType
                               FROM            dbo.TB_KIT_DOC
                               WHERE        (KittingPartNum = h.KittingPartNum)) AS ProcessingTyp,
                             (SELECT        [UPH(Hr)]
                               FROM            dbo.TB_KIT_DOC AS TB_KIT_DOC_2
                               WHERE        (KittingPartNum = h.KittingPartNum)) AS UPH, CONVERT(decimal(18, 2), Kits_Qty /
                             (SELECT        [UPH(Hr)]
                               FROM            dbo.TB_KIT_DOC AS TB_KIT_DOC_1
                               WHERE        (KittingPartNum = h.KittingPartNum))) AS TimeCost, BuildPlanTime
FROM            dbo.TB_KIT_ORDER_HEADER AS h
WHERE        (Station = 0) AND (ProgressCode BETWEEN 304 AND 306)

GO
