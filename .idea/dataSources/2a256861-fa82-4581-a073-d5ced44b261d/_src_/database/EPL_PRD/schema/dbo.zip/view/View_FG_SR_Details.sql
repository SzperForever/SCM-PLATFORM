CREATE VIEW dbo.View_FG_SR_Details
AS
SELECT     d.SRid, h.SRno, d.Item, RTRIM(d.PartNum) AS PartNum, RTRIM(d.PO) AS PO, RTRIM(d.SO) AS SO, d.DN AS [Delivery Number], d.TotalQty, s.StandPrice AS Standard_price, 
                      s.StandPrice * d.TotalQty AS TotalAmount, d.Currency, d.CDF_Number, s.Total_OH, s.Mtrl_Desc AS Material_description, u.UserName AS AddBy, d.AddTime, d.Remark, d.SR_Item_id, 
                      d.UnitNetWeight
FROM         dbo.TB_FG_SR_Header AS h INNER JOIN
                      dbo.TB_FG_SR_Details AS d ON h.SRid = d.SRid LEFT OUTER JOIN
                          (SELECT     Material, StandPrice, Mtrl_Desc, SUM(Unrestricted) AS Total_OH
                            FROM          dbo.TB_SAP_INV_FINAL
                            WHERE      (Sloc = '0100') AND (Plant = 'cn04')
                            GROUP BY Material, StandPrice, Mtrl_Desc) AS s ON s.Material = d.PartNum INNER JOIN
                      dbo.View_Users AS u ON u.UserID = d.AddBy
GO
