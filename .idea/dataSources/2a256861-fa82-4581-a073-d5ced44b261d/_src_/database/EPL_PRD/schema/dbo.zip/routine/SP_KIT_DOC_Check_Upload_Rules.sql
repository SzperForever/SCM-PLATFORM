-- =============================================
-- Author:		<Hanson Zhang)
-- Create date: <2014/6/20>
-- Description:	<Rules to check the upload item >
-- =============================================
CREATE PROCEDURE [dbo].[SP_KIT_DOC_Check_Upload_Rules]
	-- Add the parameters for the stored procedure here
		@KittingPartNum nvarchar(40),
		@DocIndex nchar(50),
		@MvmtTyp nchar(3),
		@ProcessingType nchar(20),
		@UPH FLOAT,
		 @ReturnCode   varchar(1000) = '' output ,
		 @BreakRuleID int = 0 output,
		 @ErrCode int = 0 output
AS BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;		
				
		if @KittingPartNum is null or LEN(@KittingPartNum)= 0
			begin
				set @ErrCode = 1
				set @BreakRuleID= 1
				set @ReturnCode = 'KittingPartNum is invalid. '
				--RAISERROR (@ReturnCode, 16, 1)
				return				
			end
		IF EXISTS(Select kittingpartnum from tb_kit_doc where KittingPartNum = @KittingPartNum) begin
				set @ErrCode = 2
				set @BreakRuleID= 2
				set @ReturnCode = 'KittingPartNum is already exist. '
				--RAISERROR (@ReturnCode, 16, 1)
				return		
			end
		IF NOT EXISTS(SELECT [Assembly Name] FROM Bas_SAPbom WHERE [Assembly Name] = @KittingPartNum) BEGIN
				set @ErrCode = 3
				set @BreakRuleID= 3
				set @ReturnCode = 'KittingPartNum is not exist in SAP BOM. '
				--RAISERROR (@ReturnCode, 16, 1)
				return	
		END
		if @DocIndex is null or LEN(@DocIndex)= 0
			begin
				set @ErrCode = 4
				set @BreakRuleID= 4
				set @ReturnCode = 'DocIndex is invalid. '
				--RAISERROR (@ReturnCode, 16, 1)
				return		
			end	
		if @MvmtTyp not in (301,131,309) begin
				set @ErrCode = 5
				set @BreakRuleID= 5
				set @ReturnCode = 'MvmtTyp is invalid. '
				--RAISERROR (@ReturnCode, 16, 1)
				return		
			end	
		if @ProcessingType is null or @ProcessingType = '' begin
				set @ErrCode = 6
				set @BreakRuleID= 6
				set @ReturnCode = 'ProcessingType cannot be empty. '
				--RAISERROR (@ReturnCode, 16, 1)
				return		
			end	
		if @UPH <=0 begin
				set @ErrCode = 7
				set @BreakRuleID= 7
				set @ReturnCode = 'UPH is invalid. '
				--RAISERROR (@ReturnCode, 16, 1)
				return		
			end	

		set @ErrCode = 0
		set @BreakRuleID = 0	
		set @ReturnCode = ''
		return
END
GO
