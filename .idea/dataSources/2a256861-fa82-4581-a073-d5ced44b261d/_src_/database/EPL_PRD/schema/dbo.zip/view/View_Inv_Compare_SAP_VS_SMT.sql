CREATE VIEW dbo.View_Inv_Compare_SAP_VS_SMT
AS
SELECT     b_1.OrderID, a.SLoc, a.Material AS SAPPartNo, b_1.PartNo, a.[Material description], a.[Matl grp], ISNULL(a.[Stand Price], 0.00) AS Stand_Price, ISNULL(a.Unrestricted, 
                      0) AS SAPqty, SUM(ISNULL(b_1.Qty, 0)) AS lvqty, SUM(ISNULL(b_1.Qty, 0)) - ISNULL(a.Unrestricted, 0) AS VarianceQty, (SUM(ISNULL(b_1.Qty, 0)) 
                      - ISNULL(a.Unrestricted, 0)) * ISNULL(a.[Stand Price], 0.00) AS VarianceValue
FROM         dbo.tmp_Sap_Inventory AS a FULL OUTER JOIN
                          (SELECT     OrderID, PartNo, Qty, GRN, Sloc, FlagGroup
                            FROM          dbo.Tb_PreparedList AS a
                            WHERE      (OrderID IN
                                                       (SELECT DISTINCT OrderID
                                                         FROM          dbo.Tb_Order_Details AS b
                                                         WHERE      (OrderStatus = 'Open') AND (CurrentPlace = 'LVHM') AND (FlagGroup = 'SMT')))) AS b_1 ON a.Material = b_1.PartNo AND 
                      a.SLoc = b_1.Sloc
WHERE     (b_1.FlagGroup = 'SMT')
GROUP BY b_1.OrderID, a.SLoc, a.Material, b_1.PartNo, a.[Material description], a.[Matl grp], a.[Stand Price], a.Unrestricted
GO
