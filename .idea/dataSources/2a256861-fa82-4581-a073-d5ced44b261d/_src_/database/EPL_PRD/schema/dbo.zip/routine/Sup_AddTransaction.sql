CREATE PROCEDURE [dbo].[Sup_AddTransaction]
	-- Add the parameters for the stored procedure here
	   @RegDate date,
	   @TransactionTime datetime2(3),
	   @Movement nchar(10) ,
	   @MaterialGroup nchar(20),
	   @Sku nchar(20),
	   @MtrlDescription nchar(100),
	   @FQty float,@TQty float,
	   @RestQty int,
	   @FBinLoc nchar(10),
	   @TBinLoc nchar(10),
	   @FGRN nchar(18),
	   @TGRN nchar(18),
	   @FStgType nchar(2),
	   @TStgType nchar(2),
	   @AddWho nchar(10),
	   @UserName nchar(10),
	   @ReferenceNo nchar(15),
	   @TransferID nchar(15),
	   @ComputerName nchar(15),
	   @SAPDocNo nchar(20),
	   @ZRTfromSloc NCHAR(4),
	   @Remark nvarchar(50)
	   
AS 
	begin
		declare @Qty float,@Sloc nvarchar(4),@msg varchar(max)
		
		if @Movement = '' or @Movement is null 
		begin			
			raiserror('读取交易类型失败导致存储过程执行失败。',16,1)	
			goto ExitPro
		end	
							
		select @Qty = isnull((Select AvailableQty from Sup_Inventory where Material = @Sku and BinLoc = @TBinLoc ),0)
		if @@ROWCOUNT = 1 
			begin
				Set @FQty = @Qty
			end
		else begin 
				set @FQty = 0
			end
			
		if @Movement = '101' or @Movement = 'ZRT' 
			BEGIN
				SET @RestQty = @FQty + @TQty 
				set @Sloc = ''
				
			END
		else if @movement = '311'
			begin
				SET @RestQty = @FQty - @TQty 
				set @Sloc = (Select Sloc from dbo.SUP_PullListHistory where DocNo = @ReferenceNo and PartNum = @sku)
			end
			
			insert into Sup_Transaction
						([RegDate],
						[TransactionTime],
						[Movement],
						[MaterialGroup],
						[Sku],
						[MtrlDescription],
						[FQty],
						[TQty],
						[RestQty],
						[FBinLoc],
						[TBinLoc],
						[FGRN],
						[TGRN],
						[FStgType],
						[TStgType],
						[AddWho],
						[UserName],
						[ReferenceNo],
						[TransferID],
						[ComputerName],
						[SAPDocNo],
						[ZRTfromSloc],
						[Remark],
						[sloc])
			values
				(@RegDate,GETDATE(),@Movement,@MaterialGroup,@Sku,@MtrlDescription,@FQty,@TQty,@RestQty,@FBinLoc,@TBinLoc,@FGRN,
				@TGRN,@FStgType,@TStgType,@AddWho,@UserName,@ReferenceNo,@TransferID,@ComputerName,@SAPDocNo,@ZRTfromSloc,@Remark,@Sloc)
		
ExitPro:
	
	end
GO
