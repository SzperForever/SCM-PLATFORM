-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kanban_Insert_PullsData]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	

	insert into [dbo].[Tb_Kanban_Pull_FinishRate] 
		   (Pulldate--
           ,[TimePeriod]--
           ,[TotalOpenPulls]--
           --,[TotalClosedPulls]--
           ,[StkClosedHourly]
           ,[LVClosedHourly]
           --,[StkDelayPulls]
           --,[LVDelayPulls]
           ,[StkOpenPulls]
           ,[StkClosedPulls]
           ,[LVOpenPulls]
           ,[LVClosedPulls]
           ,[StkOpenPartCount]
           ,[StkClosedPartCount]
           ,[StkClosedHourlyPartCount]
           ,[LVOpenPartCount]
           ,[LVClosedPartCount]
           ,[LVClosedHourlyPartCount]
           ,[FlagGroup])
	values(
	 (select left(CONVERT(date,getdate()),10)) --Pulldate
	,(select left(CONVERT(time,getdate()),8))  --[TimePeriod]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and PullStatus = 'Open'  and FlagGroup = 'SMT') --[TotalOpenPulls]
	--,(SELECT COUNT(0) FROM tb_order_Details where PullStatus = 'Close'  and FlagGroup = 'SMT') --[TotalClosedPulls]
	,(select count(0) from tb_order_Details where PullStatus = 'Close'  and FlagGroup = 'SMT' and DATEDIFF(hh, StockCompleteTime,GETDATE())=1)--[StkClosedHourly]
	,(select count(0) from tb_order_Details where PullStatus = 'Close'  and FlagGroup = 'SMT' and DATEDIFF(hh, LVHMcompleteTime,GETDATE())=1)--[LVClosedHourly]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and lvhmsts in ('NotReceived','Prepared')  and FlagGroup = 'SMT' and LVHMrequestTime <= dateadd(hour,4,getdate())) --[StkOpenPulls]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and lvhmsts in ('NotReceived','Prepared') and StockCompleteTime IS NOT NULL  and FlagGroup = 'SMT' and LVHMrequestTime <= dateadd(hour,4,getdate())) --[StkClosedPulls]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and CurrentPlace = 'LVHM'  and FlagGroup = 'SMT' and BuildPlanTime <= dateadd(hour,4,getdate())) --[LVOpenPulls]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and CurrentPlace = 'LVHM' and LVHMcompleteTime IS NOT NULL and FlagGroup = 'SMT'  and BuildPlanTime <= dateadd(hour,4,getdate())) --[[LVClosedPulls]]
	,(SELECT sum(PartAmount) FROM tb_order_Details where OrderStatus = 'Open' and PullStatus = 'Open' and FlagGroup = 'SMT' and LVHMrequestTime <= dateadd(hour,4,getdate()))--[StkOpenPartCount]
	,(select sum(PartAmount) from tb_order_Details where OrderStatus = 'Open' and PullStatus = 'Close'  and FlagGroup = 'SMT' and LVHMrequestTime <= dateadd(hour,4,getdate())) --[StkClosedPartCount]
	,(select sum(PartAmount) from tb_order_Details where OrderStatus = 'Open' and PullStatus = 'Close'  and FlagGroup = 'SMT' and DATEDIFF(hh, StockCompleteTime,GETDATE())=1) --[StkClosedHourlyPartCount]	
	,(SELECT sum(PartAmount) FROM tb_order_Details where OrderStatus = 'Open' and FlagGroup = 'SMT' and BuildPlanTime <= dateadd(hour,4,getdate()))--[LVOpenPartCount]
	,(select sum(PartAmount) from tb_order_Details where OrderStatus = 'Open' and FlagGroup = 'SMT' and LVHMcompleteTime  > (select CONVERT(date,getdate()))) --[LVClosedPartCount]
	,(select sum(PartAmount) from tb_order_Details where OrderStatus = 'Open' and FlagGroup = 'SMT' and DATEDIFF(hh, LVHMcompleteTime,GETDATE())=1) --[LVClosedHourlyPartCount]
	,'SMT')

	
	insert into [dbo].[Tb_Kanban_Pull_FinishRate] 
		   (Pulldate--
           ,[TimePeriod]--
           ,[TotalOpenPulls]--
           --,[TotalClosedPulls]--
           ,[StkClosedHourly]
           ,[LVClosedHourly]
           --,[StkDelayPulls]
           --,[LVDelayPulls]
           ,[StkOpenPulls]
           ,[StkClosedPulls]
           ,[LVOpenPulls]
           ,[LVClosedPulls]
           ,[StkOpenPartCount]
           ,[StkClosedPartCount]
           ,[StkClosedHourlyPartCount]
           ,[LVOpenPartCount]
           ,[LVClosedPartCount]
           ,[LVClosedHourlyPartCount]
           ,[FlagGroup])
	values(
	 (select left(CONVERT(date,getdate()),10)) --Pulldate
	,(select left(CONVERT(time,getdate()),8))  --[TimePeriod]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and PullStatus = 'Open'  and FlagGroup = 'MI') --[TotalOpenPulls]
	--,(SELECT COUNT(0) FROM tb_order_Details where PullStatus = 'Close'  and FlagGroup = 'MI') --[TotalClosedPulls]
	,(select count(0) from tb_order_Details where PullStatus = 'Close'  and FlagGroup = 'MI' and DATEDIFF(hh, StockCompleteTime,GETDATE())=1)--[StkClosedHourly]
	,(select count(0) from tb_order_Details where PullStatus = 'Close'  and FlagGroup = 'MI' and DATEDIFF(hh, LVHMcompleteTime,GETDATE())=1)--[LVClosedHourly]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and lvhmsts in ('NotReceived','Prepared')  and FlagGroup = 'MI' and LVHMrequestTime <= dateadd(hour,4,getdate())) --[StkOpenPulls]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and lvhmsts in ('NotReceived','Prepared') and StockCompleteTime IS NOT NULL  and FlagGroup = 'MI' and LVHMrequestTime <= dateadd(hour,4,getdate())) --[StkClosedPulls]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and CurrentPlace = 'LVHM'  and FlagGroup = 'MI' and BuildPlanTime <= dateadd(hour,4,getdate())) --[LVOpenPulls]
	,(SELECT COUNT(0) FROM tb_order_Details where OrderStatus = 'Open' and CurrentPlace = 'LVHM' and LVHMcompleteTime IS NOT NULL and FlagGroup = 'MI'  and BuildPlanTime <= dateadd(hour,4,getdate())) --[[LVClosedPulls]]
	,(SELECT sum(PartAmount) FROM tb_order_Details where OrderStatus = 'Open' and PullStatus = 'Open' and FlagGroup = 'MI' and LVHMrequestTime <= dateadd(hour,4,getdate()))--[StkOpenPartCount]
	,(select sum(PartAmount) from tb_order_Details where OrderStatus = 'Open' and PullStatus = 'Close'  and FlagGroup = 'MI' and LVHMrequestTime <= dateadd(hour,4,getdate())) --[StkClosedPartCount]
	,(select sum(PartAmount) from tb_order_Details where OrderStatus = 'Open' and PullStatus = 'Close'  and FlagGroup = 'MI' and DATEDIFF(hh, StockCompleteTime,GETDATE())=1) --[StkClosedHourlyPartCount]	
	,(SELECT sum(PartAmount) FROM tb_order_Details where OrderStatus = 'Open' and FlagGroup = 'MI' and BuildPlanTime <= dateadd(hour,4,getdate()))--[LVOpenPartCount]
	,(select sum(PartAmount) from tb_order_Details where OrderStatus = 'Open' and FlagGroup = 'MI' and LVHMcompleteTime  > (select CONVERT(date,getdate()))) --[LVClosedPartCount]
	,(select sum(PartAmount) from tb_order_Details where OrderStatus = 'Open' and FlagGroup = 'MI' and DATEDIFF(hh, LVHMcompleteTime,GETDATE())=1) --[LVClosedHourlyPartCount]
	,'MI')

	--SELECT * FROM [Tb_Kanban_Pull_FinishRate]
END


GO
