CREATE VIEW dbo.sumOutOutPerPickerToday
AS
SELECT     Picker, SUM(PartAmount) AS PartAmount
FROM         dbo.Tb_Order_Details
WHERE     (DATEDIFF(day, StockReceivedTime, GETDATE()) = 0)
GROUP BY Picker
GO
