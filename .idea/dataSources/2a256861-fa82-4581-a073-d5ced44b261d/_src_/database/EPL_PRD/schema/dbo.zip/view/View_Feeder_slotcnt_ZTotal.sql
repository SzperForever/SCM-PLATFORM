CREATE VIEW dbo.View_Feeder_slotcnt_ZTotal
AS
SELECT     TOP 1000 [Workcell_2017], [Jan], [Feb], [Mar], [Apr], [May], [Jun], [Jul], [Aug], [Sep], [Oct], [Nov], [Dec]
FROM         [EPL_PRD].[dbo].[View_Feeder_slotcntStatus]
UNION
SELECT     'ZTotal',
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '1' AND YEAR = '2017') AS Jan,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '2' AND YEAR = '2017') AS Feb,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '3' AND YEAR = '2017') AS Mar,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '4' AND YEAR = '2017') AS Apr,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '5' AND YEAR = '2017') AS May,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '6' AND YEAR = '2017') AS Jun,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '7' AND YEAR = '2017') AS Jul,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '8' AND YEAR = '2017') AS Aug,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '9' AND YEAR = '2017') AS Sep,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '10' AND YEAR = '2017') AS Oct,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '11' AND YEAR = '2017') AS Nov,
                          (SELECT     SUM(QTY) AS Expr1
                            FROM          [EPL_PRD].[dbo].[View_Feeder_slotcnt]
                            WHERE      [Month] = '12' AND YEAR = '2017') AS Dec
GO
