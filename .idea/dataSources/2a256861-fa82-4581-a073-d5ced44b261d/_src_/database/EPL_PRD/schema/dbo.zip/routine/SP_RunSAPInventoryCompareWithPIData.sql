CREATE PROCEDURE [dbo].[SP_RunSAPInventoryCompareWithPIData]
	@Area varchar(10),
	@PIYear varchar(4)
AS
BEGIN
	SET NOCOUNT ON;
	if @Area = 'LVHM'
		begin
			select * from View_PI_DataComparison
			--where piyear = @PIYear OR piyear2 = @PIYear
		end
	else if @Area = 'MFG'
		begin
			SELECT a.PIYear,
					A.[SLoc],
					b.[Storage Location],
					A.[Material] as SAPPartNo,
					b.[Material Number]as PIPartNo,
					a.[Material description],
					A.[Matl grp],
					A.[Stand Price],
					isnull(A.[Unrestricted],0) as SAPqty,
					isnull(sum(B.Quantity),0) as PIqty ,
					count(b.Quantity) as TagCount,
					(isnull(sum(B.Quantity),0)- isnull(A.[Unrestricted],0)) AS VarianceQty, 
					(a.[stand price] * (isnull(sum(B.Quantity),0)-isnull(A.[Unrestricted],0))) as VarianceValue 
			FROM dbo.TB_PI_MFG_SAP_INVENTORY A full JOIN 
				 dbo.Tb_PI_Inventory B ON A.MATERIAL = B.[Material Number] and a.sloc = B.[Storage Location] and A.PIYear = b.piyear
			where A.PIYear = @PIYear or b.PIYear = @PIYear and b.Area = @Area 
			group by a.piyear,A.[SLoc],A.[Material],b.[Storage Location],B.[Material Number],a.[Material description],A.[Matl grp],A.[Stand Price],A.[Unrestricted]
			order by A.[SLoc],A.[Material] asc
		end
	else if @Area = 'Warehouse'
		begin
			raiserror('Opps!Warehouse is not supported for this PI Module yet.',16,1)	
		end
END
GO
