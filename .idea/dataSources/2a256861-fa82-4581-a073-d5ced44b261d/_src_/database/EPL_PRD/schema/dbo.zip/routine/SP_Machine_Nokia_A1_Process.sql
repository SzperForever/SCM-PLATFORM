	
	
	
	--[SP_Machine_Nokia_A1_Process] 'E:\xml\Resource\Bay28_088411A.102B_102_B-P160803_16-08-05','E\XML'
	
	
	CREATE PROCEDURE [dbo].[SP_Machine_Nokia_A1_Process] 
	-- Add the parameters for the stored procedure here
	@DIR varchar(2000),         
	@ResultPath nvarchar(100),                               --XML放置的文件路径	
	@ParentDirTree varchar(1000) = 'E:\XML\Resource'           --根目录名
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @XMLDIR varchar(2000),                       --XML放置的文件全路径
			@FileFullName varchar(8000),                  --游标用,文件名称(全路径)
			@Str varchar(2000),                          --文本日志内容
			@ParentFolderName varchar(200) ,             --新建的文件夹名
			@NewFolderPath varchar(1000),
			@CmdCreateNewFolder varchar(1000),
			@CmdMoveToCopyFolder varchar(1000),
			@LogFileName varchar(1000)
			
	Declare @FileTable TABLE(x varchar(MAX))             --临时表,存储 文件夹所有XML文件名称

--		set @DIR = 'E:\xml\Resource\Bay28_088411A.102B_102_B-P160803_16-08-05'		
		set @ParentFolderName = '_A1'  
-- convert(varchar(4),RAND()) +
	
		SET @XMLDIR=N'DIR '+ @DIR + '\*.xml'             --*.xml 只读取是XML的扩展名的文件
		set @LogFileName = @ResultPath + '\ResultLog.txt'
				
				
		INSERT @FileTable
		exec xp_cmdshell @XMLDIR                        --将文件夹的内容读取插入临时表中		

		
		delete from  @FileTable where x not like '%.xml' or x is null	
		update @FileTable set x=@DIR+'\'+SUBSTRING(x,40,120)
		
		
		declare @Rcnt_A1 INT
		set @Rcnt_A1 = (select COUNT(*) from @FileTable Where x like '%NOKIA_A1%')
		--PRINT @Rcnt_A1
		select * from @FileTable 
		if @@ROWCOUNT > 15 and @Rcnt_A1 > 5
		begin
		
			set @CmdCreateNewFolder = 'mkdir ' + @ParentDirTree  + '\' + @ParentFolderName  --调用DOS命令创建project文件夹
			set @CmdMoveToCopyFolder = 'Move  ' + @DIR + '\NOKIA_A1*.xml'   + SPACE(1) + @ParentDirTree + '\' + @ParentFolderName
			set @NewFolderPath =  @ParentDirTree  + '\' + @ParentFolderName
			SELECT @CmdCreateNewFolder,@CmdMoveToCopyFolder,@NewFolderPath
			exec xp_cmdshell @CmdCreateNewFolder  
			exec xp_cmdshell @CmdMoveToCopyFolder  
			
			EXEC dbo.SP_Machine_Feeder_Calc_BrdNum_FromXML @NewFolderPath,@ResultPath		
			set @Str = '[SP_Machine_Nokia_A1_Process]:(Found NOKIA_A1 Model):' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Create new folder and move all NOKIA_A1* files into it:' + rtrim(@NewFolderPath)
			EXEC p_Writefile @LogFileName, @Str
				
		end
		
end

  GO
