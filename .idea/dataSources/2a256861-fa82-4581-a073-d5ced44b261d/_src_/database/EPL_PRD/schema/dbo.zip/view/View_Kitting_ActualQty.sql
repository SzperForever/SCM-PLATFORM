


CREATE VIEW [dbo].[View_Kitting_ActualQty]
AS
SELECT DISTINCT KittingPartNum, ISNULL(SUM(Qty), 0) AS Qty, ISNULL(COUNT(DISTINCT GRN), 0) AS PkgCnt
FROM         dbo.View_Kitting_PreparedList AS h with (nolock)
WHERE     ((BatchID + KittingPartNum + GRN) IN
                          (SELECT     BatchID + PartNo + GRN AS Expr1
                            FROM          dbo.View_Kitting_BatchDetails with (nolock)
                            WHERE      (OrderStatus = 'OPEN')))
GROUP BY KittingPartNum


GO
