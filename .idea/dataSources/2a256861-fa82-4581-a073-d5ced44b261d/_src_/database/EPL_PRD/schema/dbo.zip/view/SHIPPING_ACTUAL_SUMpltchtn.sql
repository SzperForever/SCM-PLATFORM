CREATE VIEW dbo.SHIPPING_ACTUAL_SUMpltchtn
AS
SELECT     TOP (100) PERCENT Actual_Pick_Time_DocYear, Actual_Pick_Time_HH, SUM(Pltcntnew) AS OUTQTY
FROM         (SELECT     CONVERT(VARCHAR(19), Actual_Pick_Time, 112) AS Actual_Pick_Time_DocYear, DATEPART(HH, Actual_Pick_Time) AS Actual_Pick_Time_HH, 
                                              (CASE WHEN [TotalPltCnt] = 0 THEN ([TotalCtnCnt] / 5) ELSE [TotalPltCnt] END) AS Pltcntnew
                       FROM          dbo.View_FG_SR_Headers
                       WHERE      (Order_Status NOT IN ('Cance', 'Hold')) AND (Actual_Pick_Time IS NOT NULL)) AS T
GROUP BY Actual_Pick_Time_DocYear, Actual_Pick_Time_HH
ORDER BY Actual_Pick_Time_DocYear, Actual_Pick_Time_HH
GO
