CREATE VIEW dbo.View_FG_MP_Details
AS
SELECT        dbo.TB_FG_SR_Header.SRid, dbo.TB_FG_SR_Header.SRno, dbo.TB_FG_MP_Details.MPno, dbo.Bas_Code.English_DESC AS MP_Status, 
                         dbo.TB_FG_MP_Details.MP_Prepared_By, dbo.TB_FG_MP_Details.MP_Prepare_Time, dbo.TB_FG_MP_Details.MP_Complete_Time, 
                         dbo.TB_FG_MP_Details.MP_Create_Time, dbo.View_Users.UserName AS AddBy
FROM            dbo.TB_FG_MP_Details LEFT OUTER JOIN
                         dbo.TB_FG_SR_Header ON dbo.TB_FG_MP_Details.SRid = dbo.TB_FG_SR_Header.SRid LEFT OUTER JOIN
                         dbo.Bas_Code ON dbo.TB_FG_MP_Details.SR_MP_Status = dbo.Bas_Code.Code LEFT OUTER JOIN
                         dbo.View_Users ON dbo.TB_FG_MP_Details.AddWho = dbo.View_Users.UserID
GO
