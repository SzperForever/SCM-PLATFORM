CREATE TRIGGER [dbo].[Tri_CheckRuleWhenInsert]   ON  [dbo].[Sup_SKuMap]    AFTER insert AS 

	declare @Sku varchar(20),
			@BinLoc varchar(6),
			@Pass1 int,@Pass2 int,
			@Errmsg VARCHAR(255),
			@BinCount int,
			@mix_attr varchar(1)	,
			@MaxPartCount int,
			@BinPartCount int,
			@WorkCell varchar(10),
			@Material_description varchar(50),
			@InsertCount int,
			@MinUnit int,
			@MaxUnit int,
			@UP2H int
			
	set @insertcount = (select count(*) from inserted)		
	if @insertcount >1 
			begin
				rollback tran
				set @Errmsg = '插入临时表中存在多行，不能正确定位。'
				raiserror(@ErrMsg,16,1)		
			end	
	if @insertcount	 =1
	begin
		set @sku = (select distinct Material from inserted)
		set @Binloc =(select distinct binloc from inserted)
		set @Pass1 = (select count(*) from bas_sku where material =@sku and Plant = 'CN04')
		set @Pass2 = (select count(*) from dbo.Bas_Sup_BinLoc where binloc = @binloc and BinSts <> 'X')
		set @mix_attr =(select mix_attr from dbo.Bas_Sup_BinLoc where binloc = @binloc and BinSts <> 'X')
		set @BinCount =(select count(binloc) from sup_skumap where binloc = @binloc)
		set @MaxPartCount =(SELECT MAXPARTCOUNT FROM Bas_Sup_BinLoc WHERE binloc = @binloc )
		set @BinPartCount = (select count(material ) from sup_skumap where binloc = @binloc)
		set @Workcell =(select Matlgroup from bas_sku where material = @sku and Plant = 'CN04')
		set @Material_description=(select Material_description from bas_sku where material = @sku and Plant = 'CN04')
		set @UP2H =(select UP2H from inserted)
		set @MinUnit = @UP2H * 2 
		set @MaxUnit = @UP2H * 4 

		begin	
			SET NOCOUNT ON
			update [Sup_SKuMap] 
				set workcell = @workcell,Material_description =@Material_description,MinUnit = @MinUnit,MaxUnit = @MaxUnit,SAPMPNO = '' 
				where material = @sku
			
			if @Pass1 = 0	
				begin	
					rollback tran
					set @Errmsg = 'EPULL不承认错误的料号' + @sku + rtrim(str(@Pass1)) +'，请确认SAP是否存在此料号，若存在请更新EPULL BAS_SKU数据库。'
					raiserror(@ErrMsg,16,1)	
				end
		end
				IF @Pass2 = 0 
					begin
						rollback tran
						set @Errmsg = @Binloc + rtrim(str(@Pass2)) + '这个储位不合法，EPULL中没有维护。或也有可能这个储位被设禁用。'
						raiserror(@ErrMsg,16,1)		
					end 
				if @mix_attr = 'N'
					begin
						if @BinCount > 1
							begin
								rollback tran
								set @Errmsg = @Binloc + '这个储位epull中已经设置为不允许批次混放,所以系统只允许存放一个物料。请检查EPULL中对这个储位的mix_attr属性设置.'
								raiserror(@ErrMsg,16,1)	
							end
					end		
				if @BinPartCount > @MaxPartCount
					begin
						rollback tran
						set @Errmsg =  @Binloc + '这个储位超出最大存储物料数量限制。系统设置该BIN最大允许存放物料数量：' + rtrim(str(@MaxPartCount)) + ',地图尝试存放:' + rtrim(str(@BinPartCount))
						raiserror(@ErrMsg,16,1)					
					end
			end
		IF UPDATE(UP2H)
			BEGIN
				update [Sup_SKuMap] 
					set MinUnit = @MinUnit,MaxUnit = @MaxUnit 
					where material = @sku
			END
GO
