-- =============================================
-- Author:		DAILS
-- Create date: 2017-06-08
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[OPEN_PullList_PNQTY]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@tableHTML2 nvarchar(max)
			,@tableHTML3 nvarchar(max)	
			,@tableHTML4 nvarchar(max)		
			,@Msg nvarchar(300)
			,@Rcnt int
			,@Rcnt2 int
			,@Rcnt3 int
			,@Rcnt4 int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
			
	set @AlertName = '0100&0300_OPEN_PullList_PNQTY_重要提示'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	
	
	
			set @Rcnt =  (SELECT COUNT(0)    
					     FROM [EPL_PRD].[dbo].[Tb_Order_Details]
					     WHERE     (OrderType = 'miPull')  AND (OrderStatus='OPEN') AND [BuildPlanTime]>'2017-01-01 00:00:00.000' and StockSts in('Picking','NotStarted'))
			set @Rcnt2 = (SELECT COUNT(0)
						 FROM         dbo.Tb_Order_Details AS A INNER JOIN
                                      dbo.Bas_Machine_Feeder_Report AS B ON A.BayNum = B.MAText AND A.PPLModelName = B.Number AND A.Rev = B.Rev
						 WHERE     (A.OrderType = 'AutoPull') AND (A.StoreArea = '0100') AND (A.OrderStatus='open') and a.CurrentPlace ='StockRoom' )
			set @Rcnt3 = (SELECT COUNT(0)
						 FROM         dbo.Tb_Order_Details AS A INNER JOIN
                                      dbo.Bas_Machine_Feeder_Report AS B ON A.BayNum = B.MAText AND A.PPLModelName = B.Number AND A.Rev = B.Rev
   					    WHERE     (A.OrderType = 'AutoPull') AND (A.StoreArea = '0100') AND (A.CreateTime > '2017-05-01 00:00:00.000'))
			set @Rcnt4 = (SELECT COUNT(0)
						FROM [EPL_PRD].[dbo].[Tb_Order_Details]
						WHERE     (OrderType = 'miPull')   AND CreateTime>'2017-05-01 00:00:00.000')	
	
	
	set @tableHTML2 = ''	
	set @tableHTML3 = ''	
	set @tableHTML4 = ''	
	SET @tableHTML =
	    N'<H1> 0100&0300_OPEN_PullList_PNQTY_重要提示 </H1>' +
		N'<table border="1">' +
		N'<font color=#FF0000><H1> 0300_open_OPEN_PullList_PNQTY(IA_BOM)</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[DAY]</th><th>PNQTY</th></tr>' +
	CAST ( (  SELECT    td = DocYear,'',
						td = QTY,''
  FROM(
    SELECT  DocYear,sum([PartAmount]) as QTY
FROM(
SELECT [OrderID]
      ,[OrderType]
      ,[OrderStatus]
      ,[WorkCell]
      ,[Model]
      ,[BayNum]      
      ,[PartAmount]     
      ,[BuildPlanTime] 
      ,[StockSts]  
      , CONVERT(VARCHAR(19), [BuildPlanTime], 112) AS DocYear
		 ,DATEPART(m,[BuildPlanTime]) AS WeekName
  FROM [EPL_PRD].[dbo].[Tb_Order_Details]
  WHERE     (OrderType = 'miPull')  AND (OrderStatus='OPEN') AND [BuildPlanTime]>'2017-01-01 00:00:00.000'
 and StockSts in('Picking','NotStarted')
group by [OrderID]
      ,[OrderType]
      ,[OrderStatus]
      ,[WorkCell]
      ,[Model]
      ,[BayNum]      
      ,[PartAmount]     
      ,[BuildPlanTime] 
      ,[StockSts]  ) AS T
      GROUP BY DocYear
       ) AS E
       ORDER BY DocYear
            
	FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX))+
		N'</table>'   
		

		
set @tableHTML2 = 
	
		N'<font color=#FF0000><H1> 0100_open_OPEN_PullList_PNQTY(Feeder_BOM)</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[DAY]</th><th>PNQTY</th></tr>' +
		
	CAST ( (	SELECT 
		  td = DocYear,'',
          td = QTY,''
        
		
FROM(
SELECT  DocYear,SUM(QTY) AS QTY
FROM(
SELECT    A.OrderID
		, A.WorkCell
		, A.Rev
		, A.BayNum
		, A.[BuildPlanTime]
		--,DATEADD(DD,+1,A.[CreateTime]) AS DocYear
		, CONVERT(VARCHAR(19), A.[BuildPlanTime], 112) AS DocYear
		 ,DATEPART(m,A.[BuildPlanTime]) AS WeekName
		, A.Model
		, A.PPLModelName
		, COUNT(B.fsPartNum) AS QTY
FROM         dbo.Tb_Order_Details AS A INNER JOIN
                      dbo.Bas_Machine_Feeder_Report AS B ON A.BayNum = B.MAText AND A.PPLModelName = B.Number AND A.Rev = B.Rev
WHERE     (A.OrderType = 'AutoPull') AND (A.StoreArea = '0100') AND (A.OrderStatus='open') and a.CurrentPlace ='StockRoom' 
GROUP BY A.OrderID, A.WorkCell, A.Model, A.Rev, A.BayNum, A.[BuildPlanTime], A.PPLModelName ) AS T

GROUP BY DocYear) as e
ORDER BY DocYear 
				FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' 
				
set @tableHTML3 = 
		
     	N'<font color=#FF0000><H1>0100_IA每天下的SMT料号数量(feeder站位计算)</H1></font>' +
		N'<table border="1">' +		
	    N'<tr><th>[DAY]</th><th>[week]</th><th>PNQTY</th></tr>' +
		
	CAST ( (	SELECT 
		  td = DocYear2,'',
		  td = [week],'',
          td = QTY,''
FROM(
SELECT  DocYear2,[week],SUM(QTY) AS QTY
FROM(
SELECT    A.OrderID
		, A.WorkCell
		, A.Rev
		, A.BayNum
		, A.CreateTime
		,Datename(weekday, A.CreateTime)as [week]
		--,DATEADD(DD,+1,A.[CreateTime]) AS DocYear
		, CONVERT(VARCHAR(19), A.CreateTime, 112) AS DocYear2
		,DATEPART(m,A.CreateTime) AS WeekName
		, A.Model
		, A.PPLModelName
		, COUNT(B.fsPartNum) AS QTY
FROM         dbo.Tb_Order_Details AS A INNER JOIN
                      dbo.Bas_Machine_Feeder_Report AS B ON A.BayNum = B.MAText AND A.PPLModelName = B.Number AND A.Rev = B.Rev
WHERE     (A.OrderType = 'AutoPull') AND (A.StoreArea = '0100') AND (A.CreateTime > '2017-05-01 00:00:00.000')
GROUP BY A.OrderID, A.WorkCell, A.Model, A.Rev, A.BayNum, A.CreateTime, A.PPLModelName ) AS T

GROUP BY DocYear2 ,[week]) as e
ORDER BY DocYear2 DESC          
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
			N'</table>' 
				
set @tableHTML4 = 
		
     	N'<font color=#FF0000><H1>0300_IA每天下的MI料号数量(IA_BOM)</H1></font>' +
		N'<table border="1">' +		
	    N'<tr><th>[DAY]</th><th>[week]</th><th>PNQTY</th></tr>' +
	CAST ( (	SELECT 
		  td = DocYear,'',
		  td = [week],'',
          td = QTY,''
FROM(	
SELECT  DocYear,week,sum([PartAmount]) as QTY
FROM(
SELECT [OrderID]
      ,[OrderType]
      ,[OrderStatus]
      ,[WorkCell]
      ,[Model]
      ,[BayNum]      
      ,[PartAmount]     
      ,CreateTime 
      ,[StockSts]  
      , CONVERT(VARCHAR(19), CreateTime, 112) AS DocYear
	  ,DATEPART(m,CreateTime) AS WeekName
	  ,Datename(weekday, CreateTime)as week
  FROM [EPL_PRD].[dbo].[Tb_Order_Details]
  WHERE     (OrderType = 'miPull')  
				 AND CreateTime>'2017-05-01 00:00:00.000'

group by [OrderID]
      ,[OrderType]
      ,[OrderStatus]
      ,[WorkCell]
      ,[Model]
      ,[BayNum]      
      ,[PartAmount]     
      ,CreateTime 
      ,[StockSts]  ) AS T
      GROUP BY DocYear,week) AS E
      ORDER BY DocYear desc
		          FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
		        
		        
		N'</table>' +    

    
		'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';
    if @Rcnt =0 and @Rcnt2 =0 and @Rcnt3 =0 and @Rcnt4 =0 return

	if @Rcnt > 0 and @Rcnt2 = 0 and @Rcnt3 = 0 and @Rcnt4 =0 begin
		set @tableHTML=@tableHTML
	end	
	if @Rcnt > 0 and @Rcnt2 > 0 and @Rcnt3 = 0 and @Rcnt4 =0 begin
		set @tableHTML=@tableHTML+ @tableHTML2
	end	
	if @Rcnt > 0 and @Rcnt2 > 0 and @Rcnt3 > 0 and @Rcnt4 =0 begin
		set @tableHTML=@tableHTML+ @tableHTML2+ @tableHTML3
	end		
	if @Rcnt > 0 and @Rcnt2 = 0 and @Rcnt3 > 0  and @Rcnt4 =0 begin
		set @tableHTML=@tableHTML+ @tableHTML3
	end	
	if @Rcnt > 0 and @Rcnt2 = 0 and @Rcnt3 > 0  and @Rcnt4 >0 begin
		set @tableHTML=@tableHTML+ @tableHTML3+ @tableHTML4
	end	
	if @Rcnt > 0 and @Rcnt2 = 0 and @Rcnt3 = 0  and @Rcnt4 >0 begin
		set @tableHTML=@tableHTML+ @tableHTML4
	end		
	if @Rcnt = 0 and @Rcnt2 > 0 and @Rcnt3 = 0 and @Rcnt4 =0 begin
		set @tableHTML=@tableHTML2
	end
	if @Rcnt = 0 and @Rcnt2 > 0 and @Rcnt3 > 0  and @Rcnt4 =0 begin
		set @tableHTML=@tableHTML2+@tableHTML3
	end
	if @Rcnt = 0 and @Rcnt2 > 0 and @Rcnt3 > 0  and @Rcnt4 >0 begin
		set @tableHTML=@tableHTML2+@tableHTML3+ @tableHTML4
	end	
	if @Rcnt = 0 and @Rcnt2 > 0 and @Rcnt3 = 0  and @Rcnt4 >0 begin
		set @tableHTML=@tableHTML2+ @tableHTML4
	end		
	if @Rcnt = 0 and @Rcnt2 = 0 and @Rcnt3 > 0 and @Rcnt4 =0 begin
		set @tableHTML=@tableHTML3
	end	
	if @Rcnt = 0 and @Rcnt2 = 0 and @Rcnt3 > 0 and @Rcnt4 >0 begin
		set @tableHTML=@tableHTML3 + @tableHTML4
	end		
	if @Rcnt > 0 and @Rcnt2 > 0 and @Rcnt3 > 0  and @Rcnt4 >0 begin
		set @tableHTML=@tableHTML + @tableHTML2 + @tableHTML3+ @tableHTML4
	end
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END

GO
