-- =============================================
-- Author:		<Hanson>
-- Create date: <2012-07-04>
-- Description:	<To update the finish rate of each open orders>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Pull_UpdateFinishRateByOrder]
	@OrderID varchar(12),
	@FlagGroup nchar(10),
	@Model nchar(500) = 'Default'
AS
BEGIN
	SET NOCOUNT ON;
	Declare @BomRowCount int,
			@FinishStatus varchar(15),
			@ActualPartCount float,
			@MeetRowCount int,
			@Progress varchar(100)
	if @flaggroup = 'SMT' 
			BEGIN
				set @BomRowCount = (SELECT  ltrim(str(COUNT(distinct Component))) 
									FROM  dbo.View_SMT_KittingStatus AS b 
									WHERE (b.OrderID = @OrderID))		
									
          --      set @MeetRowCount = (SELECT  ltrim(str(COUNT(distinct Component)))  
										--FROM  dbo.View_MultiMdoel_SMT_KittingStatus 
										--WHERE(DiffQty >= 0) AND (OrderID = @OrderID))					
			
				set @MeetRowCount = (SELECT  ltrim(str(COUNT(distinct Component)))  
										FROM  dbo.View_MultiMdoel_SMT_KittingStatus 
										WHERE(DiffQty >= 0) AND (OrderID = @OrderID))									
				if @MeetRowCount = 0
					begin
						set @Progress = 'NotStarted'
					end
				else if @MeetRowCount =  ltrim(str(@BomRowCount))
					begin
						set @Progress = 'Completed'
					end
				else
					begin
						set @Progress = 'InProgress'
					end
																
				set @FinishStatus = Ltrim(str(@MeetRowCount)) + '/' +  ltrim(str(@BomRowCount))						
				
				update tb_order_details 
				set FinishRate = @finishstatus,ConditionalFormat = @Progress
				where orderid = @orderid and flaggroup = 'SMT'	
				
			end
		Else if @flaggroup = 'MI'  
			BEGIN	
				IF @Model = 'Default' SET @Model = (Select top 1 model from Tb_Order_Details where orderid = @orderid and FlagGroup = 'MI')
				set @BomRowCount = (Select count(partnum) 
									from bas_bom 
									where model = @Model)
				PRINT @BomRowCount
				SET @MeetRowCount =(SELECT  ltrim(str(COUNT(distinct PartNum)))  
									FROM  dbo.View_MI_KittingStatus AS b 
									WHERE(b.DiffQty >= 0) and (b.model = @model) AND (b.OrderID = @OrderID))
					PRINT @MeetRowCount				
				set @FinishStatus = ltrim(str(@MeetRowCount)) + '/' +  ltrim(str(@BomRowCount))
						PRINT @FinishStatus
					if @MeetRowCount =  ltrim(str(@BomRowCount))
						begin
							update tb_order_details 
							set FinishRate = @finishstatus,ConditionalFormat = 'Completed'
							where orderid = @orderid and model = @model	and flaggroup = 'MI'							
						end
					else begin
						update tb_order_details 
						set FinishRate = @finishstatus,ConditionalFormat = 'InProgress'
						where orderid = @orderid and model = @model	and flaggroup = 'MI'	
					end
		end
end
GO
