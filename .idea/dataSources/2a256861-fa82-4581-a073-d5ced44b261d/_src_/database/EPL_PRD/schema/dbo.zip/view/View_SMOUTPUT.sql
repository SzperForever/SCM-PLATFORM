CREATE VIEW dbo.View_SMOUTPUT
AS
SELECT     TOP (100) PERCENT RegDate, COUNT(Movement) AS Items
FROM         dbo.Sup_Transaction
GROUP BY RegDate
ORDER BY RegDate
GO
