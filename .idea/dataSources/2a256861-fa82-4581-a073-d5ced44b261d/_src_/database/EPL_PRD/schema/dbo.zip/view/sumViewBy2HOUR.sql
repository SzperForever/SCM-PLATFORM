CREATE VIEW dbo.sumViewBy2HOUR
AS
SELECT     COUNT(RTSNO) AS sumcount, '06:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '04:30:00:000' AND '06:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '08:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '06:30:00:000' AND '08:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '10:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '08:30:00:000' AND '10:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '12:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '10:30:00:000' AND '12:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '14:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '12:30:00:000' AND '14:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '16:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '14:30:00:000' AND '16:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '18:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '16:30:00:000' AND '18:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '20:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '18:30:00:000' AND '20:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '22:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '20:30:00:000' AND '22:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '00:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '22:30:00:000' AND '00:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '02:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '00:30:00:000' AND '02:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
UNION
SELECT     COUNT(RTSNO) AS sumcount, '04:30' AS times, CONVERT(date, ScanTime, 120) AS dates
FROM         Tb_RTS a
WHERE     CONVERT(varchar(12), ScanTime, 114) BETWEEN '02:30:00:000' AND '04:30:00:000'
GROUP BY CONVERT(date, ScanTime, 120)
GO
