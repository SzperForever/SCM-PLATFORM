
CREATE VIEW [dbo].[View_Kitting_OutofStock_OrderList]
AS
SELECT DISTINCT OrderID, 'Y' AS OutOfStock
FROM         dbo.View_Kitting_Raw_Inventory_Compare with (nolock) 
WHERE     (DiffQty < 0)

GO
