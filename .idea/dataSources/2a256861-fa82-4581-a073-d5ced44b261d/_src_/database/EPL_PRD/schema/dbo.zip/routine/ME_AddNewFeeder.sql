CREATE PROCEDURE [dbo].[ME_AddNewFeeder]
           @FeederID	varchar(20)
           ,@WorkCell	varchar(20)
           ,@FeederStatus varchar(10)
           ,@LastPMDate date
           ,@NextPMDate date
           ,@LastPMBy varchar(10)
           ,@LastPMTime smalldatetime
           ,@LastPMNotes varchar(50)
           ,@RepairDate date
           ,@RepariNotes varchar(50)
           ,@LastRepairedBy varchar(10)
           ,@LastRepairTime smalldatetime
           ,@Remark varchar(100)
AS
BEGIN

	SET NOCOUNT ON;
	
INSERT INTO [dbo].[ME_Feeders]
           ([FeederID]
           ,[WorkCell]
           ,[FeederStatus]
           ,[LastPMDate]
           ,[NextPMDate]
           ,[LastPMBy]
           ,[LastPMTime]
           ,[LastPMNotes]
           ,[RepairDate]
           ,[RepariNotes]
           ,[LastRepairedBy]
           ,[LastRepairTime]
           ,[Remark])
     VALUES
			(@FeederID
           ,@WorkCell
           ,@FeederStatus 
           ,@LastPMDate 
           ,@NextPMDate 
           ,@LastPMBy 
           ,@LastPMTime 
           ,@LastPMNotes 
           ,@RepairDate 
           ,@RepariNotes 
           ,@LastRepairedBy 
           ,@LastRepairTime 
           ,@Remark )
END
GO
