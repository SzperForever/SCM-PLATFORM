
CREATE VIEW [dbo].[V_KIT_RIPE_HISTORY]
AS
SELECT        r.BatchID, r.OrderID, h.KittingPartNum, h.Kits_Qty AS DemandQty, h.FinalQty, r.LineID, r.Qnty AS ActualQty, r.GRN, d.MvmtTyp, r.AddWho, r.AddTime
FROM            dbo.TB_KIT_RIPE_HISTORY AS r INNER JOIN
                         dbo.V_KIT_ORDER_HEADER AS h ON r.OrderID = h.OrderID INNER JOIN
                         dbo.TB_KIT_DOC AS d ON h.KittingPartNum = d.KittingPartNum

GO
