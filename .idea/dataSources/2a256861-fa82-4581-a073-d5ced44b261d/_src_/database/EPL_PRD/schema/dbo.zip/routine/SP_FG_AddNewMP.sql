-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_FG_AddNewMP]
	-- Add the parameters for the stored procedure here

	@SRid bigint,
	@MPno nchar(13),
	@MP_Items_Cnt int,
	@AddBy nchar(13)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	Declare @SRStatus nchar(3),@OrderStatus nchar(3),@ErrMsg varchar(300),@Rcnt int,@SPStatus nchar(3)
	--truncate table [TB_FG_MP_Details]
	set @Rcnt = (Select count(*) from [dbo].[TB_FG_MP_Details] where [SRid] = @SRid and MPno =@MPno )

	if @Rcnt <> 0 begin
	set @ErrMsg = 'This pulllist is already exsit.（拣货单已经存在，不允许重复下单。）'
			raiserror (@ErrMsg,16,1)
			return
	end

	set @OrderStatus = (Select SR_OrderStatus  from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
		if @OrderStatus <> '200' begin
			set @ErrMsg = 'Process denied since SR Order status is not open. （由于SR订单状态未开启，拒绝进行下一步操作。）'
			raiserror (@ErrMsg,16,1)
			return
		end

	set @SRStatus = (Select [SR_Status] from [dbo].[TB_FG_SR_Header] where [SRid] = @SRid)
	if @SRStatus <> '901' begin
		set @ErrMsg = 'Process denied since this SR is not activated. （由于SR订单状态未被激活，拒绝进行下一步操作。）'
		raiserror (@ErrMsg,16,1)
		return
	end

	set @SPStatus = (Select [SR_SP_Status] from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
	if @SPStatus not in('902','903') begin
		set @ErrMsg = 'Invalid shipping status. (该SR只有当前处于拣货单未创建或是正在创建时才可以进行此操作。)'
		raiserror (@ErrMsg,16,1)
		return
	end

	INSERT INTO [dbo].[TB_FG_MP_Details]
           ([SRid]
           ,[MPno]
           ,[SR_MP_Status]
           ,[MP_Items_Cnt]
           ,[MP_Create_Time]
           ,[AddWho])

     VALUES
			(@SRid 
			,@MPno 
			,'903'
			,@MP_Items_Cnt 
			,GETDATE()
			,@AddBy)

	if @@ERROR = 0 begin
		update [TB_FG_SR_Header]
		set SR_SP_Status = '903'
		where SRid = @SRid 
		return
	end



END


--CodeGroup	Code	Chinese_DESC	English_DESC	CodeGroup_Desc
--57	9         	900       	创建订单	SRNotActivated	SR_Status
--58	9         	901       	激活订单	SRActivated	SR_Status
--59	9         	902       	未创建拣货单	MPNotCreated	SR_SP_Status
--60	9         	903       	拣货单创建	MPCreated	SR_SP_Status
--61	9         	904       	拣货中	MPPicking	SR_SP_Status
--62	9         	905       	打印唛头中	PrintShippingMark	SR_SP_Status
--63	9         	906       	等待PGI中	PGI NotStarted	SR_SP_Status
--64	9         	907       	扣PGI中	PGI InProgress	SR_SP_Status
--65	9         	908       	待装车	TruckNotLoaded	SR_SP_Status
--66	9         	909       	发货中	TruckLoading	SR_SP_Status
--67	9         	910       	已发货	ShippedOut	SR_SP_Status

--200  open
--201  closed
--202  cancel
--203  hold
--204  activated
GO
