CREATE VIEW dbo.View_FG_Pkg_Size
AS
SELECT        TOP (100) PERCENT s.SRid, h.SRno, s.Lbid, RTRIM(h.SRno) + '-' + RTRIM(LTRIM(STR(s.Lbid))) AS SMLabelID, 
                         (CASE WHEN s.SMtype = 0 THEN 'Ctn' WHEN s.SMtype = 1 THEN 'Plt' END) AS PkgType, p.PartNum, SUM(ISNULL(p.Qty, 0)) AS PkgQty, 
                         RTRIM(LTRIM(STR(s.Length))) + '*' + RTRIM(LTRIM(STR(s.Width))) + '*' + RTRIM(LTRIM(STR(s.Height))) + '*' + RTRIM(LTRIM(STR(s.GrossWeight))) 
                         + 'kg*' + RTRIM(LTRIM(STR(s.NetWeight))) + 'kg' AS SizeInfo, s.Length, s.Width, s.Height, s.GrossWeight, s.NetWeight, COUNT(DISTINCT s.SMid) AS Copies, 
                         COUNT(p.BoxID) AS BoxCnt
FROM            dbo.TB_FG_SR_Header AS h INNER JOIN
                         dbo.TB_FG_PKG_Details AS p ON h.SRid = p.SRid RIGHT OUTER JOIN
                         dbo.TB_FG_SM_Details AS s ON p.PKGid = s.Lbid AND p.SRid = s.SRid
GROUP BY s.Length, s.Width, s.Height, s.GrossWeight, s.NetWeight, s.SMtype, s.SRid, h.SRno, p.PartNum, s.Lbid
ORDER BY s.SRid, h.SRno, s.Lbid
GO
