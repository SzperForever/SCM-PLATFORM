CREATE VIEW dbo.View_0100_HMP_Expired
AS
SELECT
                     [MaterialGroup]
                     ,count([GRN]) as GRN_QTY
                     ,convert(varchar(30),cast(sum(TotalPrice) as money),1) as TotalPrice
FROM(                     
SELECT [Plant]
      ,[SLoc]
      ,[StorageBin]
      ,[Material]
      ,[MaterialGroup]      
      ,[GRN]
      ,[Quantity]
      ,[UnitPrice]
      ,[UnitPrice]*[Quantity] AS TotalPrice
      ,[SLED]
      ,DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )as Expired
     
      FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1' 
  and [SLoc]='0100'
  and  DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )<='0'
  )AS A 
  group by [MaterialGroup] 
 UNION    
 SELECT     'ZTotal',   (SELECT COUNT(*)						   
						  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
						  WHERE [Active]='1' 
						  and [SLoc]='0100'
						  and  DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )<='0') ,
						 (SELECT convert(varchar(30),cast(sum(UnitPrice*Quantity) as money),1)
							  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
							  WHERE [Active]='1' 
							  and [SLoc]='0100'
							  and  DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )<='0')
GO
