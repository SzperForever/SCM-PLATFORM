-- =============================================
-- Author:		<Hanson >
-- Create date: <2014-10-21,>
-- Description:	<Batch Close Kitting Orders base on closable items>
-- Command example:exec [SP_Kitting_Close_All_Closable_Items] 'HANSON',''
-- =============================================
CREATE  PROCEDURE [dbo].[SP_Kitting_Close_All_Closable_Items]
	-- Add the parameters for the stored procedure here
		@CloseBy varchar(15),
		@ReturnCode varchar(200) output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;  
--temp talbe
	Declare @Rowcnt int,@i int,@KittingPartNum Varchar(30)
	declare @TmpActualQty table
	(	
		ID				int identity(1,1) primary key,
		KittingPartNum	varchar(30) not null
	)
	
	insert into @TmpActualQty (KittingPartNum)
	SELECT DISTINCT KittingPartNum
	FROM         dbo.View_Kitting_PreparedList AS h with (nolock)
	WHERE     ((BatchID + KittingPartNum + GRN) IN
							  (SELECT     BatchID + PartNo + GRN AS Expr1
								FROM          dbo.View_Kitting_BatchDetails
								WHERE      (OrderStatus = 'OPEN')))
	GROUP BY KittingPartNum
	
	--SELECT * FROM @TmpActualQty 
	SET @Rowcnt = (Select COUNT(0) from @TmpActualQty )
	
IF @Rowcnt =0 
	begin
		set @ReturnCode = '001.There are no closable items currently available.' 
		print @ReturnCode
		RETURN
	end

	set @I= 0 
	
	while @I < @Rowcnt 
		begin
			set @I= @I +1
			select @KittingPartNum = kittingpartnum from @TmpActualQty  where ID = @i 
			SET @ReturnCode ='Closing Part:' + @KittingPartNum
			PRINT @ReturnCode
			exec dbo.SP_Kitting_Close_Order_By_KittingPartNum  @KittingPartNum,@closeby,''
			if @@ERROR <> 0 
				begin
					set @ReturnCode = '888. Error occured while closing kitting part:' + @KittingPartNum + '. Please check!'
				end
			else begin
					set @ReturnCode = 'Total Items Count:' + STR(@Rowcnt) + ',Item Index:' + STR(@i) + ' Operation proceed.'
			end				
		end
	print @ReturnCode	
	Return		
		
end

GO
