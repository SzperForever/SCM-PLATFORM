
CREATE FUNCTION [dbo].[F_GetKittingRawPartCount](@KittingPartNum varchar(100)) 
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @PartCount int

	-- Add the T-SQL statements to compute the return value here
	SELECT @PartCount = (select count(distinct Component) from bas_sapbom where [Assembly Name] = @KittingPartNum)

	-- Return the result of the function
	RETURN @PartCount

END
GO
