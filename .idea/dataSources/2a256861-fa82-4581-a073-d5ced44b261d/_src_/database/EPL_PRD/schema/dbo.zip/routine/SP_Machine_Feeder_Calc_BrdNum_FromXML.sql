-- =============================================
-- Author:		<Hanson Zhnag>
-- Create date: <2013/10/18>
-- Description:	<Load XML feeder report to ePullDB>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Machine_Feeder_Calc_BrdNum_FromXML] 
	-- Add the parameters for the stored procedure here
	@DIR varchar(2000),
	@ResultPath varchar(2000)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @XMLDIR varchar(2000),                       --XML放置的文件全路径
			@FileFullName varchar(8000),                  --游标用,文件名称(全路径)
			@Str varchar(2000),                          --文本日志内容
			@LogFileName varchar(1000),                   --日志路径
			@MoveFileName_WhenFailure varchar(2000),
			@MoveFileName_WhenSucceed varchar(2000)			
	
	Declare @FileTable TABLE(x varchar(MAX))             --临时表,存储 文件夹所有XML文件名称
	Declare @seqBrdNum varchar(20)		                 --计算拼板数量用的参数
		
		set @seqBrdNum = 0 --初始值为0
		
		SET @XMLDIR=N'DIR '+ @DIR + '\*.xml'             --*.xml 只读取是XML的扩展名的文件
		set @LogFileName = @ResultPath + '\ResultLog.txt'--日志文件路径
				
		INSERT @FileTable
		exec xp_cmdshell @XMLDIR                        --将文件夹的内容读取插入临时表中		
		

		delete from  @FileTable where x not like '%PartReportUnit%.xml' or x is null			
		update @FileTable set x=@DIR+'\'+SUBSTRING(x,40,120)
		
		declare fCursor_BrdNum cursor for  
				select x from  @FileTable
		open fCursor_BrdNum                   
		fetch next from fCursor_BrdNum  into @FileFullName
		while(@@fetch_status=0)
				

		
		BEGIN
				Declare @xml varchar(Max),                --XML转换成列的内容
						@Pointer INT                   --指向位置的变量

						
				Declare	@Table TABLE(x varchar(MAX))
				Declare	@InsOrderUnitTable TABLE(seqBrdNum varchar(20))
						
				
				
				insert into @table EXEC ('(SELECT *
											FROM OPENROWSET(BULK '''+@FileFullName+''',SINGLE_CLOB) as x)')							
				select @xml=x from @table

						set @Str =  '[SP_Machine_Feeder_Calc_BrdNum_FromXML]:Preparing Documents:'
						EXEC p_Writefile @LogFileName, @STR
				
				EXECUTE sp_xml_PReparedocument @Pointer OUTPUT,@xml
				if @@ERROR <> 0 
					begin
						EXEC xp_cmdshell @MoveFileName_WhenFailure
						set @Str =  CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Folder:' + rtrim(@DIR) + ',Error occured during preparing the documents.'
						EXEC p_Writefile @LogFileName, @STR
					end
					
						set @Str =  '[SP_Machine_Feeder_Calc_BrdNum_FromXML]:Prepared OK. Loading Documents:' + @FileFullName + '.'
						EXEC p_Writefile @LogFileName, @STR
				
				insert into @InsOrderUnitTable 
				SELECT * FROM OPENXML (@Pointer,'/PartReportUnit/Unit',2)
				WITH(seqBrdNum nvarchar(20))				      
				where seqBrdNum <> 'seqBrdNum'	
							 		
				BEGIN							
						set @Str =  '[SP_Machine_Feeder_Calc_BrdNum_FromXML]:Loading Completed. Calculating the SeqBrdNum...'
						EXEC p_Writefile @LogFileName, @STR
			
					EXEC sp_xml_removedocument @Pointer						
					if @@ERROR <> 0 
						begin
							set @Str =  'Error:' + error_message()
							EXEC p_Writefile @LogFileName, @STR		
						end
						else begin
							set @seqBrdNum = (select max(convert(int,seqBrdNum)) from @InsOrderUnitTable )
							EXEC xp_cmdshell @MoveFileName_WhenSucceed
							set @Str =  '[SP_Machine_Feeder_Calc_BrdNum_FromXML]:BrdNum has been succefully caculated. BrdNum:' + str(@seqBrdNum )
							EXEC p_Writefile @LogFileName, @STR	
						end	
			    END
			    
				fetch next from fCursor_BrdNum into @FileFullName
			END
			
		close  fCursor_BrdNum  	
		DEALLOCATE	fCursor_BrdNum
		
		--传拼板数量至另一外存储过程，以写入BOM表。
		--PRINT @seqBrdNum
		
		IF @seqBrdNum = 0 begin
			set @seqBrdNum = 1
			set @Str =  '[SP_Machine_Feeder_Calc_BrdNum_FromXML](Warning):Failed to get the SeqBrdNum, maybe PartUnitxml file been removed or invalid file. Now the SeqBrdNum will be set as default value which is 1.'
			EXEC p_Writefile @LogFileName, @STR	
		end
				
		set @Str =  '[SP_Machine_Feeder_Calc_BrdNum_FromXML]:Loading From header xml File.'
		EXEC p_Writefile @LogFileName, @STR	
		exec dbo.SP_Machine_Feeder_LoadFromXML @dir,@resultpath,@seqBrdNum 
		
END
GO
