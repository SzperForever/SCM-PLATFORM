
CREATE VIEW [dbo].[View_Kitting_Pulls]
AS
SELECT     WorkCell, PullListNo, AddPullBy, CreatePullTime, Stocksts, Stock_AssignedBy, Stock_AssignedTo, Stock_ReceivedTime, Stock_PickingTime, Stock_CompleteTime, 
                      Stock_LeadTime, OrderStatus, Kitting_CompleteTime, Kitting_LeadTime, PullLeadTime, SendToWho, SendByWho, DocIndex, KittingType, SUBSTRING(PullListNo, 9, 4)
                       AS StoreArea
FROM         dbo.View_Kitting_Order_Headers with (nolock) 
WHERE     (LEN(ISNULL(PullListNo, '')) <> 0)
GROUP BY WorkCell, PullListNo, AddPullBy, CreatePullTime, Stocksts, Stock_ReceivedTime, OrderStatus, Stock_CompleteTime, Stock_LeadTime, Kitting_CompleteTime, 
                      Kitting_LeadTime, PullLeadTime, SendToWho, SendByWho, Stock_AssignedBy, Stock_AssignedTo, Stock_PickingTime, DocIndex, KittingType

GO
