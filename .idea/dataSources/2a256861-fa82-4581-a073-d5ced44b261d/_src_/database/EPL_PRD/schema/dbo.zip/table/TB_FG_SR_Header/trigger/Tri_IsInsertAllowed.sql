-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <20160223>
-- Description:	<Enable the command of allowing order placement,>
-- =============================================
CREATE TRIGGER [dbo].[Tri_IsInsertAllowed]
   ON  [dbo].[TB_FG_SR_Header]
   AFTER INSERT
   
   AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	declare @DatePeriod smalldatetime,@msg varchar(1000),
	        @Plan_Pick_Time smalldatetime
	        ,@Project nvarchar(35)
    set @DatePeriod = getdate()
    set @Plan_Pick_Time  = (select Plan_Pick_Time from inserted)
    set @Project = (Select Project from inserted)
    
  --  if @Plan_Pick_Time between '2017-03-02 8:00:00' and '2018-03-04 00:00:00' return
    if @DatePeriod between '2017-09-07 10:10:00' and '2017-09-11 15:30:00' 
  
    --AND RTRIM(UPPER(@Project)) NOT in ('NOKIA')
   
    --if @DatePeriod < '2015-09-08 20:00:00' goto normal
	begin		
		rollback tran
		set @msg = 'You are not allowed to place new SR orders during this period. 
		ePull is out of service due to coming holidays concerns during (2017-09-06 17:00:00--2017-09-11 15:30:00). 
		Any unclear please contact with Dai lisong-65141.'
		RAISERROR (@msg, 16, 1)
		return
     end
    
END
GO
