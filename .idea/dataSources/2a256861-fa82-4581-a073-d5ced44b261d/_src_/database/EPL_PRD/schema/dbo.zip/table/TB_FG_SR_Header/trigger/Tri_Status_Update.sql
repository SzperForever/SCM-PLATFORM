-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE trigger [dbo].[Tri_Status_Update]
   ON  dbo.TB_FG_SR_Header
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    if @@rowcount > 1 return    
    
 
	if update([SR_SP_Status])  Goto CheckStatus
	Return

CheckStatus:
		Declare @rcnt int,@LstSPStatus nchar(3),@NewSPStatus nchar(3),@SRid bigint,@ErrMsg NVARCHAR(1000),@OrderStatus nchar(3),@SRStatus nchar(3)
		
		select @SRid= SRid,@NewSPStatus= SR_SP_Status from Inserted 
		select @LstSPStatus= SR_SP_Status from Deleted 
		
		set @OrderStatus = (Select SR_OrderStatus  from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
		if @OrderStatus <> '200' begin
			set @ErrMsg = 'Process denied since SR Order status is not open. (由于SR订单状态未开启，拒绝进行下一步操作。)'
			raiserror (@ErrMsg,16,1)
			return
		end
		set @SRStatus = (Select SR_Status from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
		if @SRStatus <> '901' begin
			set @ErrMsg = 'SR is not activated. (该SR订单状态未被激活。)'
			raiserror (@ErrMsg,16,1)
			return
		end
	
		if @NewSPStatus < '902' begin
			set @ErrMsg = 'Invalid SP Status.（订单作业状态更新失败.不允许的状态值尝试更新。）'
			raiserror (@ErrMsg,16,1)
			rollback TRAN
		end
		else if @NewSPStatus = '902' begin
			if @LstSPStatus <> '901' goto RollbackChange
		end
		else if @NewSPStatus = '903' begin
			if @LstSPStatus <> '902' goto RollbackChange
		end
		else if @NewSPStatus = '904' begin
			if @LstSPStatus <> '903' goto RollbackChange
		end
		--else if @NewSPStatus = '905' begin
		--	if @LstSPStatus <> '904' goto RollbackChange
		--end
		else if @NewSPStatus = '906' begin
			if @LstSPStatus <> '905' goto RollbackChange
		end
		else if @NewSPStatus = '907' begin
			if @LstSPStatus <> '906' goto RollbackChange
		end
		else if @NewSPStatus = '908' begin
			if @LstSPStatus <> '907' goto RollbackChange
		end			
		else if @NewSPStatus = '909' begin
			if @LstSPStatus <> '908' goto RollbackChange
		end		
		else if @NewSPStatus = '910' begin
			if @LstSPStatus <> '909' goto RollbackChange
		end																	

		commit tran		
		return
		
RollbackChange:
		set @ErrMsg = 'SP_SR_Status update fail. Check last working status.（订单作业状态更新失败,步骤无法跳跃和返回。）'
		raiserror (@ErrMsg,16,1)
		rollback TRAN
		return

END
GO
DISABLE TRIGGER Tri_Status_Update ON TB_FG_SR_Header
GO
