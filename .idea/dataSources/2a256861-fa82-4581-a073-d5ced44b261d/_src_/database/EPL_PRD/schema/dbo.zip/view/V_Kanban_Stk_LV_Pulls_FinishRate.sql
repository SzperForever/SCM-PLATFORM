CREATE VIEW dbo.V_Kanban_Stk_LV_Pulls_FinishRate
AS
SELECT        TOP (100) PERCENT FlagGroup, DATEPART(year, PullDate) AS LogYear, PullDate, TimePeriod, StkOpenPulls, LVOpenPulls, StkOpenPartCount, LVOpenPartCount, 
                         StkClosedPulls, LVClosedPulls, StkClosedPartCount, LVClosedPartCount, CONVERT(DECIMAL(18, 2), CAST(StkClosedPulls AS float) / CAST(StkOpenPulls AS float)) 
                         * 100 AS StkPullsFinishRate, CONVERT(DECIMAL(18, 2), CAST(LVClosedPulls AS float) / CAST(LVOpenPulls AS float)) * 100 AS LvPullsFinishRate, 
                         CONVERT(DECIMAL(18, 2), CAST(StkClosedPartCount AS float) / CAST(StkOpenPartCount AS float)) * 100 AS StkPartCntFinishRate, CONVERT(DECIMAL(18, 2), 
                         CAST(LVClosedPartCount AS float) / CAST(LVOpenPartCount AS float)) * 100 AS LvPartCntFinishRate
FROM            dbo.Tb_Kanban_Pull_FinishRate
WHERE        (StkOpenPulls > 0)
GO
