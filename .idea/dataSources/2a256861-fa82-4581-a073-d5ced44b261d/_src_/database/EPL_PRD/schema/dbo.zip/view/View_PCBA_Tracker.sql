CREATE VIEW dbo.View_PCBA_Tracker
AS
SELECT     TOP (100) PERCENT Model, SN, Station, HMPPartNo, HMPGRN, AddTime, AddWho, Remark, DATEDIFF(day, AddTime, GETDATE()) AS Agingday, 
                      DATEDIFF(dd, DATEADD(wk, CONVERT(int, SUBSTRING(LTRIM(SN), 6, 2)), CONVERT(datetime, LTRIM(STR(CONVERT(int, '20' + SUBSTRING(LTRIM(SN), 
                      4, 2)) - 4)) + '-01-01')), GETDATE()) AS SNagedDay
FROM         dbo.PRO_PCBA_Tracking
ORDER BY AddTime
GO
