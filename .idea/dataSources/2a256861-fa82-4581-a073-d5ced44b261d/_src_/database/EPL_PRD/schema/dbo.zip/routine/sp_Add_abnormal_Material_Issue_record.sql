CREATE PROCEDURE [dbo].[sp_Add_abnormal_Material_Issue_record]
	-- Add the parameters for the stored procedure here
	@BU nchar(10),
	@SMPullListNo varchar(50),
	@Sloc nchar(4),
	@Model nchar(20),
	@BuildDate date,
	@PlanQty int,
	@Material nchar(20),
	@UP2H numeric(18,3),
	@OnlineInventory numeric(18,3),
	@ActualIssuedQty numeric(18,3),
	@IssuedBy nchar(10),
	@Reason nvarchar(100),
	@ReasonCode nchar(2)
AS begin
	SET NOCOUNT ON;
	if @ReasonCode = 1 begin
		INSERT INTO [dbo].[SUP_Abnormal_Mateiral_Issue]
				   ([AlertFlag]
				   ,[SMPullListNo]
				   ,[BU]
				   ,[Sloc]
				   ,[Model]
				   ,[BuildDate]
				   ,[PlanQty]
				   ,[Material]
				   ,UP2H
				   ,[OnlineInventory]
				   ,[ActualIssuedQty]
				   ,[IssuedBy]
				   ,ReasonCode
				   ,[Reason],AbnormalQty,
				   AddTime)
			 VALUES
				('Y',
					@SMPullListNo,
					@BU,@Sloc,
					@Model,
					@BuildDate,
					@PlanQty,
					@Material,
					@up2h,
					@OnlineInventory,
					@ActualIssuedQty,
					@IssuedBy,
					@ReasonCode,@Reason,@ActualIssuedQty,GETDATE())
			end
	else begin
		INSERT INTO [dbo].[SUP_Abnormal_Mateiral_Issue]
				   ([AlertFlag]
				   ,[SMPullListNo]
				   ,[BU]
				   ,[Sloc]
				   ,[Model]
				   ,[BuildDate]
				   ,[PlanQty]
				   ,[Material]
				   ,UP2H
				   ,[OnlineInventory]
				   ,[ActualIssuedQty]
				   ,[IssuedBy]
				   ,ReasonCode
				   ,[Reason],AbnormalQty,
				   AddTime)
			 VALUES
				('Y',
					@SMPullListNo,
					@BU,@Sloc,
					@Model,
					@BuildDate,
					@PlanQty,
					@Material,
					@up2h,
					@OnlineInventory,
					@ActualIssuedQty,
					@IssuedBy,
					@ReasonCode,@Reason,@ActualIssuedQty-@UP2H,GETDATE())
	
	end
END
GO
