CREATE PROCEDURE [dbo].[ME_Add_FeederPMHistory]
		@FeederID varchar(10)
		,@WorkCell varchar(20)
		,@PMDate date
		,@PMBy varchar(20)
		,@PMTime smalldatetime
		,@PMNotes varchar(50)
		,@NextPMDate date
		,@RepairDate date
		,@RepariNotes varchar(50)
		,@RepairedBy varchar(10)
		,@RepairTime smalldatetime
		,@Remark varchar(100)
AS
BEGIN
		INSERT INTO [dbo].[ME_Feeder_History]
				   ([FeederID]
				   ,[WorkCell] 
				   ,[PMDate]
				   ,[PMBy]
				   ,[PMTime]
				   ,[PMNotes]
				   ,[NextPMDate]
				   ,[RepairDate]
				   ,[RepariNotes]
				   ,[RepairedBy]
				   ,[RepairTime]
				   ,[Remark])
			 VALUES
					(@FeederID
					,@WorkCell
					,@PMDate
					,@PMBy
					,@PMTime
					,@PMNotes
					,@NextPMDate
					,@RepairDate
					,@RepariNotes
					,@RepairedBy
					,@RepairTime
					,@Remark)
END
GO
