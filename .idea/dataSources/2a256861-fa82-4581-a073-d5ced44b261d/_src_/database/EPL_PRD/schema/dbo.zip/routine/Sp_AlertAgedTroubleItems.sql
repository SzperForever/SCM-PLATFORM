-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2011-02-18>
-- Description:	<Mailling Trouble Items those aged over 24 hours.>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AlertAgedTroubleItems]
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @tableHTML  NVARCHAR(MAX) 
			,@Msg nvarchar(max)
			,@RecList nvarchar(max)
			,@CCList nvarchar(max)
			,@SpvList nvarchar(max)
			,@BuyerMailAddress nvarchar(max)
			,@SupervisorMailAddress  nvarchar(max)
			,@CCto nvarchar(max)
			,@BlindCopyList nvarchar(max)
			,@MailSubj nvarchar(200)
			,@RowCnt int	
    -- Insert statements for procedure here
	--定义游标
		set @RowCnt =0
		set @RowCnt =(select COUNT(*) from dbo.TB_RCV_TroubleShelf
				where DATEDIFF(HOUR,AddTime, GETDATE())> 24 AND ItemStatus = 'Open')
		if @RowCnt >0 		
			 begin			
				DECLARE Mycursor cursor 
				Read_only FOR 
					Select  rtrim(ltrim(BuyerMailAddress)) as Rec, rtrim(ltrim(SupervisorMailAddress)) as Spv,rtrim(ltrim(isnull(CCto,''))) as CC
					from dbo.Bas_BuyerInfo 
					where Buyer in 
						(select distinct ltrim(rtrim(Buyer)) from dbo.TB_RCV_TroubleShelf
						where DATEDIFF(HOUR,AddTime, GETDATE())> 24 AND ItemStatus = 'Open')
					
				
				set @RecList = (Select [recipients]  from Cfg_DBmail where AlertName = 'AgedTroubleItemsOver24H')
				set @CCList = (Select [CopyList]  from Cfg_DBmail where AlertName = 'AgedTroubleItemsOver24H')
				set @BlindCopyList=(Select Blind_recipients from Cfg_DBmail where AlertName = 'AgedTroubleItemsOver24H')

				set @SpvList = ''

				set @MailSubj = (Select Subject  from Cfg_DBmail where AlertName = 'AgedTroubleItemsOver24H')
				
				
				--打开游标Mycursor
				OPEN Mycursor; 
				FETCH NEXT FROM Mycursor
					INTO @BuyerMailAddress,@SupervisorMailAddress,@CCto 	
				WHILE (@@FETCH_STATUS = 0) --       0-FETCH statement was successful.		
					BEGIN
						select @RecList =ltrim(rtrim( @RecList)) + isnull(@BuyerMailAddress,'') + ';'				
						select @SpvList=ltrim(rtrim(@CCList))+ isnull(@SupervisorMailAddress,'') + ';'						
						--select @CCList=ltrim(rtrim(@CCList)) + isnull(@CCto,'') 

						FETCH NEXT  FROM Mycursor 
						INTO @BuyerMailAddress,@SupervisorMailAddress,@CCto			
					END		
				--关闭游标
				CLOSE Mycursor
				DEALLOCATE Mycursor		
			
				--开始定义和发邮件
				set @Msg = 'All Buyers/Planners,' + CHAR(10)+ CHAR(13) + 'You are required to close these Hold items immediately. ' + char(10) + CHAR(13)+ 'Please Supervisors in the CC list kindly drive this.' + CHAR(10)+ CHAR(13)
				SET @tableHTML = @Msg +		
				N'<H1>Hold Items on Trouble Shelf Aged Over 24 Hours </H1>' +
				N'<table border="1">' +
				N'<tr><th>Date</th><th>Plant</th><th>WorkCell</th><th>TrackingNumber</th><th>PartNumber</th><th>PO</th>' +
				N'<th>Qty</th><th>Vendor</th><th>Reason</th><th>Owner</th><th>CreateBy</th><th>CreateTime</th><th>AgedDay</th></tr>' +
				CAST ( ( SELECT td = RegDate,       '',
								td = Plant, '',
								td = WorkCell, '',
								td = TrackingNumber, '',
								td = PartNumber, '',
								td = PO , '',
								td = Qty, '',
								td = Vendor, '',
								td = Reason, '',
								td = Buyer, '',
								td = Addwho, '',
								td = AddTime, '',
								td = datediff(d,addtime,getdate()), ''
						  from TB_RCV_TroubleShelf
						  where DATEDIFF(HOUR,AddTime, GETDATE())> 24 AND ItemStatus = 'Open'    
						  FOR XML PATH('tr'), TYPE 
				) AS NVARCHAR(MAX) ) +
				N'</table>' +    
				'It is very important.Please do not reply to this mail. When you reply to this mail please remove this mail address and get support from RCV team as soon as possible. Any unclear or wrong owner definition concerns please feel free to reach RCV team to maintain in time.';
		     
			 --raiserror (@RecList,16,1)
			 --raiserror (@CCList,16,1)
			 --raiserror (@BlindCopyList,16,1)
			 --return
			 declare @RecAll nvarchar(max)
			 set  @RecAll = @reclist + ';' + @CCList

			EXEC msdb.dbo.sp_send_dbmail 
			@profile_name ='EpullSqlMail',
			@recipients =@reclist,
			@copy_recipients =@CCList ,
			--@Blind_Copy_recipients = @BlindCopyList ,
			@subject = @mailsubj,
			@body = @tableHTML,
			@body_format = 'HTML' ;
		end
		
END


GO
