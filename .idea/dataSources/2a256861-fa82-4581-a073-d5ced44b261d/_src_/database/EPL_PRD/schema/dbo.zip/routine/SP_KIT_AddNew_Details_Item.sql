

CREATE  PROCEDURE [dbo].[SP_KIT_AddNew_Details_Item]
		@IsNew bit,
		@OrderID  nchar(13),
		@PartNo varchar(25),
		@Qty numeric(18, 3),
		@GRN varchar(18),	
		@AddBy varchar(15),
		@BatchID NCHAR(13) = 'XXXXXXXXXXXXX' OUTPUT,
		@ReturnCode varchar(400)	= '' output

AS	
	begin

		Declare @KittingPartNum VARCHAR(40),@OrderStatus varchar(10),@OrderProgress varchar(20),@FinalQty float,@NextDiffQty float
		Declare @Rcnt int,@DiffQty float,@ActualQty float
		
		IF NOT EXISTS(Select orderid from TB_KIT_ORDER_HEADER where orderid = @orderid ) begin
				set @ReturnCode = 'Error:001,This order does not exist.'
				RAISERROR (@ReturnCode, 16, 1)
				return
		end 

		SELECT @KittingPartNum = [KittingPartNum]
					,@OrderStatus = [OrderStatus]
					,@OrderProgress = ProgressCode
					,@FinalQty = FinalQty
					,@ActualQty = (Select sum([Qnty]) from [TB_KIT_RIPE_HISTORY] where orderid = @OrderID)
					,@DiffQty = @ActualQty-@FinalQty
					,@NextDiffQty = (@ActualQty +@Qty)-@FinalQty
		from TB_KIT_ORDER_HEADER
		where orderid = @OrderID

		IF @iSNEW = 1
			BEGIN
				SET @BatchID = NULL		
				DECLARE @dt CHAR(6)
				SELECT @dt=dt FROM v_GetDate		
				SET @BatchID =(SELECT 'B' + @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(BatchID),6),0),6) 
											FROM TB_KIT_RIPE_HISTORY WITH(XLOCK,PAGLOCK)
											WHERE BatchID like 'B' + @dt+'%')				
			END
		--ELSE BEGIN
		--		Select @BatchID = BatchID
		--		from TB_KIT_RIPE_HISTORY
		--		where id = (select max(id) from TB_KIT_RIPE_HISTORY where AddWho = @AddBy)
		--END

		if @OrderStatus <> 'OPEN' 
			begin
				set @ReturnCode = 'Error:002,Invalid order status. You are not allowed to append items while order status does not show open.'
				RAISERROR (@ReturnCode, 16, 1)
				return
			end

		if @OrderProgress not in (310,311)
			begin
				set @ReturnCode = 'Error:003,Invalid order progress. You are not allowed to append items at this time. Process Code has to be 310 or 311.'
				RAISERROR (@ReturnCode, 16, 1)
				return
			end

		if @KittingPartNum <> @PartNo
			begin
				set @ReturnCode = 'Error:004,Invalid  part number. It does not match with orginal order part number.'
				RAISERROR (@ReturnCode, 16, 1)
				return
			end
		--if @NextDiffQty > 0 
		--	begin
		--		set @ReturnCode = 'Error:005, The quantity you just trying to insert is not match with final qty. With this quantity, actual quantity will greater than the final qty which is not allowed. You need ensure the qty inserted exact match with the final qty. Please confirm and try again.'
		--		RAISERROR (@ReturnCode, 16, 1)
		--		return
		--	end
		if @DiffQty >= 0 
			begin
				set @ReturnCode = 'Error:006,This order has been full kitted thus no further appendent is being accepted..'
				RAISERROR (@ReturnCode, 16, 1)
				return
			end
		if (rtrim(@BatchID) = '') or (@BatchID is null)
			begin
				set @ReturnCode = 'Error:007,@BatchID is not valid. It cannot be empty.'
				RAISERROR (@ReturnCode, 16, 1)
				return
			end			
		--IF @Qty > @FinalQty 
		--	BEGIN
		--		set @ReturnCode = 'Error:008,The quantity you just trying to insert is not accept because it is greater than the final qty.'
		--		RAISERROR (@ReturnCode, 16, 1)
		--		return
		--	END
		SET @Rcnt = (Select count(0) from TB_KIT_RIPE_HISTORY where OrderID = @OrderID)
								
		INSERT INTO [dbo].[TB_KIT_RIPE_HISTORY]
				   ([BatchID]
				   ,[OrderID]
				   ,[KittingPartNum]
				   ,[Qnty]
				   ,[GRN]
				   ,[LineID]
				   ,[AddWho]
				   ,[AddTime])
			 VALUES
					(@BatchID
					,@OrderID
					,@PartNo
					,@Qty
					,@GRN
					,@Rcnt+1
					,@AddBy
					,GETDATE())

		set @ReturnCode = 'Part process record inserted.'

		if @Rcnt = 0 begin
			update TB_KIT_ORDER_HEADER 
			set  ProgressCode = 311
			where OrderID = @OrderID
		end

		SELECT @KittingPartNum = [KittingPartNum]
					,@OrderStatus = [OrderStatus]
					,@OrderProgress = ProgressCode
					,@FinalQty = FinalQty
					,@ActualQty = (Select sum([Qnty]) from [TB_KIT_RIPE_HISTORY] where orderid = @OrderID)
					,@DiffQty = @ActualQty-@FinalQty
		from TB_KIT_ORDER_HEADER
		where orderid = @OrderID

		if @DiffQty >= 0 begin

			update TB_KIT_ORDER_HEADER 
			set Order_ClosedBy = @AddBy
				,Order_ClosedTime = getdate()
				,Processing_FinishedBy = @AddBy
				,Processing_FinishTime = getdate()
				,ProgressCode = 312
			where OrderID = @OrderID

			set @ReturnCode = 'This order is fulfilled.'
		end

		return
					
end


GO
