CREATE PROCEDURE [dbo].[sp_AddPI_Record]
	@Workcell varchar(20),
	@PIYear varchar(4),
	@Bay varchar(20),
	@CountBy varchar(20),
	@AuditBy	varchar(10),
	@EntryBy varchar(10),
	@StoreArea varchar(10),
	@TagNo varchar(20),
	@Material varchar(20),
	@Batch varchar(18),
	@Qty float,
	@AddWho varchar(10),
	@Remark varchar(255),
	@TagFlag varchar(10)
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [dbo].[tb_LVHM_PI]
           ([WorkCell]
           ,[PIYear]
           ,[Bay]
           ,[CountBy]
           ,[AuditBy]
           ,[EntryBy]
           ,[StoreArea]
           ,[TagNo]
           ,[Material]
           ,[Batch]
           ,[Qty]
           ,[AddTime]
           ,[AddWho]
           ,[Remark]
           ,[Tagflag])
     VALUES
			(@Workcell ,@PIYear ,@Bay,@CountBy ,@AuditBy ,@EntryBy,@StoreArea ,@TagNo,@Material ,@Batch,@Qty,GETDATE(),@AddWho,@Remark,@tagflag)
	
	
END
GO
