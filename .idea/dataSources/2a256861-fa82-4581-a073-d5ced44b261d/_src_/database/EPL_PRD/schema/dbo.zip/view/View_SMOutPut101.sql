CREATE VIEW dbo.View_SMOutPut101
AS
SELECT     TOP (100) PERCENT RegDate, COUNT(Movement) AS StoreIn
FROM         dbo.Sup_Transaction
WHERE     (Movement = '101')
GROUP BY RegDate
ORDER BY RegDate
GO
