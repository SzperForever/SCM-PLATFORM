CREATE VIEW dbo.V_Kanban_Rec_ArriveRate_Weekly
AS
SELECT        TOP (12) DocYear, ClosedDay_WkNo, COUNT(DocNo) AS ClosedDocCnt,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.TB_RCV_InboundTracking
                               WHERE        (DATEPART(WEEK, ClosedTime) = v.ClosedDay_WkNo)) AS TotalDocCnt,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v1
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Ls12')) AS DocCnt_LS12,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Ls24Gt12')) AS DocCnt_LS24,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v3
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Ls48Gt24')) AS DocCnt_LS48,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v4
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Gt48')) AS DocCnt_GT48, CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v1
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Ls12')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_8
                                 WHERE        (DATEPART(WEEK, ClosedTime) = v.ClosedDay_WkNo)), 0), 1) AS FLOAT) * 100) AS V_LS12, CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Ls24Gt12')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_7
                                 WHERE        (DATEPART(WEEK, ClosedTime) = v.ClosedDay_WkNo)), 0), 1) AS FLOAT) * 100) AS V_LS24, CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v3
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Ls48Gt24')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_6
                                 WHERE        (DATEPART(WEEK, ClosedTime) = v.ClosedDay_WkNo)), 0), 1) AS FLOAT) * 100) AS V_LS48, CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v4
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Gt48')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_5
                                 WHERE        (DATEPART(WEEK, ClosedTime) = v.ClosedDay_WkNo)), 0), 1) AS FLOAT) * 100) AS V_GT48, CAST(CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v1
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Ls12')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_4
                                 WHERE        (DATEPART(WEEK, ClosedTime) = v.ClosedDay_WkNo)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_LS12, CAST(CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Ls24Gt12')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_3
                                 WHERE        (DATEPART(WEEK, ClosedTime) = v.ClosedDay_WkNo)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_LS24, CAST(CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v3
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Ls48Gt24')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_2
                                 WHERE        (DATEPART(WEEK, ClosedTime) = v.ClosedDay_WkNo)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_LS48, CAST(CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v4
                               WHERE        (ClosedDay_WkNo = v.ClosedDay_WkNo) AND (PeriodType = 'Gt48')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_1
                                 WHERE        (DATEPART(WEEK, ClosedTime) = v.ClosedDay_WkNo)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_GT48
FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v
GROUP BY ClosedDay_WkNo, DocYear
ORDER BY ClosedDay_WkNo DESC
GO
