
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_KIT_CLOSE_Pull]
	-- Add the parameters for the stored procedure here
	@PullListNo nchar(13)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @Rcnt int
	
	set @rcnt = (select COUNT(*) from TB_KIT_ORDER_HEADER  where PullListNo = @PullListNo and OrderStatus = 'OPEN' and Stock_Sts = 'InProgress')
	
	if @rcnt = 0 
	begin
		raiserror ('No pulllist been found or Invalid pull status.',16,1)
		return
	end 
	else begin	
		UPDATE TB_KIT_ORDER_HEADER
		SET Stock_sts  = 'Completed'
			,Pull_FinishedTime =GETDATE()
			--,Kitting_ReceivedTime =GETDATE()
			,ProgressCode = 303
			,CurrentPlace = 'KIT'
		    --,Stock_LeadTime=(select dbo.f_second_Time(datediff(ss,Stock_ReceivedTime ,GETDATE())))
		WHERE Pulllistno = @PullListNo and OrderStatus = 'OPEN'-- and Stock_sts ='INPROGRESS'
	end

END

GO
