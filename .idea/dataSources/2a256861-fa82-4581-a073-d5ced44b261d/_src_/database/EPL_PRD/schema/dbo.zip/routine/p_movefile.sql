
CREATE proc [dbo].[p_movefile]
	@s_file varchar(1000), --源文件
	@d_file varchar(1000) --目标文件
	as
		BEGIN
			declare @err int,@src varchar(255),@desc varchar(255)
			declare @obj int

			exec @err=sp_oacreate 'Scripting.FileSystemObject',@obj out
			if @err<>0 goto lberr

			exec @err=sp_oamethod @obj,'MoveFile',null,@s_file,@d_file
			if @err<>0 goto lberr

			exec @err=sp_oadestroy @obj
			return

lberr:
			 exec sp_oageterrorinfo 0,@src out,@desc out
			 select cast(@err as varbinary(4)) as ErrNo
			  ,@src as ErrSource,@desc as ErrDesc
		END
GO
