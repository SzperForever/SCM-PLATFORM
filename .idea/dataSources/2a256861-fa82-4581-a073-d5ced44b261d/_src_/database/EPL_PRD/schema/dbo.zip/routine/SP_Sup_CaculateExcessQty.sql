-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2011-11-29 14:16>
-- Description:	<用游标算法计算Cisco 物料的ExcessInventory>
-- =============================================

CREATE PROCEDURE [dbo].[SP_Sup_CaculateExcessQty]
	-- Add the parameters for the stored procedure here
	@PartNo varchar(20),
	@BU varchar(20)
AS
BEGIN
	SET NOCOUNT ON;

	--先清空表等待游标数据写入
	delete from [dbo].[Sup_ExcessInventory]
	--定义变量
		DECLARE @item numeric(18, 0),
		@Sloc varchar(4),
		@Model varchar(40),
		@PlanQty int,
		@BuildDate date,
		@BPDemand numeric(18,3),
		@OnlineInventory numeric(18,3),
		@WIPDemand numeric(18,3),
		@ExcessQty numeric(18,3),
		@RemaingQty numeric(18,3),
		@SMInventory numeric(18,3),
		@UP2H numeric(18,3)
		
		insert into [dbo].[Sup_ExcessInventory] 
					([BU]
				   ,[Sloc]
				   ,[Assy#]
				   ,[Plan Qty]
				   ,[Build Date]
				   ,[Material]
				   ,[BPDemand]
				   ,[OnlineInventory]
				   ,[WIPDemand]
				   ,[ExcessQty]
				   ,[RemaingQty]
				   ,[SMInventory]
				   ,[UP2H])
           SELECT		 a.BU,
						 H.SLoc,
						 a.Assy#,
						 a.[Plan Qty], 
						 a.[Build Date], 
						 b.[Component P/N] AS Material, 
						 ISNULL(b.[Qty Per] * a.[Plan Qty], 0.000) AS BPDemand,
						 ISNULL(SUM(c.Unrestricted), 0.000) AS OnlineInventory, 
						 ISNULL(b.[Qty Per] * d.WIP_Qty, 0.000) AS WIPDemand, 
						 ISNULL(SUM(c.Unrestricted) - b.[Qty Per] * d.WIP_Qty, 0.000) AS ExcessQty, 
						 ISNULL(isnull(SUM(c.Unrestricted),0.000) - 
								isnull(b.[Qty Per] * d.WIP_Qty,0.000)-
								isnull(b.[Qty Per] * a.[Plan Qty],0.000),
								(0-ISNULL(b.[Qty Per] * a.[Plan Qty], 0.000))) AS RemaingQty,
						 isnull(f.AvailableQty,0.000) AS SMInventory,g.[UPH*2(material)] 
						 
			FROM         dbo.Sup_BuildPlan AS a LEFT JOIN
						 dbo.Sup_BOM AS b ON a.[Assy#] = b.[Parent P/N] LEFT OUTER JOIN
						 
						 dbo.Sup_WIP AS d ON d.[Assy#] = a.[Assy#] AND d.[Assy#] = b.[Parent P/N] AND d.BU = a.BU LEFT JOIN 
						Sup_Inventory f on f.Material =b.[Component P/N] join 
						Sup_Bas_UPH g on g.[Parent P/N] = a.Assy# and g.[Component P/N] = b.[Component P/N] LEFT JOIN
						Sup_Bas_Sloc H ON  H.BU = A.BU 	FULL OUTER JOIN	
						dbo.Sup_OnlineInventory AS c ON c.Material = b.[Component P/N] AND C.SLOC = H.SLOC 					 
			where (b.[Component P/N] = @PartNo and a.BU = @BU)				 		
			--where (b.[Component P/N] = '29-6040-02' and a.BU = 'NPI' )  							
			GROUP BY a.BU, H.sloc,a.Assy#, a.[Build Date], a.[Plan Qty], b.[Component P/N], b.[Qty Per],d.WIP_Qty,f.AvailableQty ,g.[UPH*2(material)]		
			ORDER BY Material,a.[Build Date] asc
	

		--定义游标
		DECLARE Mycursor cursor scroll dynamic FOR --非SCROLL
		select * from [dbo].[Sup_ExcessInventory] order by ITEM  asc
		--定义这个游标是可以读写的
		for update
		
		--打开游标Mycursor
		OPEN Mycursor; 
		FETCH NEXT FROM Mycursor
			INTO @BU,@Sloc,@Model ,@PlanQty ,@BuildDate,@PartNo,@BPDemand,@OnlineInventory,@WIPDemand,@ExcessQty,@RemaingQty,@SMInventory,@UP2H,@ITEM
		
		FETCH NEXT FROM Mycursor
		
		WHILE @@FETCH_STATUS = 0 --        0-FETCH statement was successful.
		BEGIN
				   		   
		   update [Sup_ExcessInventory] set 
				OnlineInventory =@RemaingQty,
				ExcessQty=@RemaingQty-WIPDemand,
				RemaingQty=@RemaingQty-BPDemand-WIPDemand
		   WHERE
				CURRENT OF Mycursor;	
			--游标指向下一行数据并重新为变量赋值		
			FETCH NEXT  FROM Mycursor
				INTO @BU,@Sloc,@Model ,@PlanQty ,@BuildDate,@PartNo,@BPDemand,@OnlineInventory,@WIPDemand,@ExcessQty,@RemaingQty,@SMInventory,@UP2H,@ITEM
			 --读取上一行计算到的remaingqty			 
			 set @RemaingQty = (Select RemaingQty from [dbo].[Sup_ExcessInventory] where item = @item -1)
		END
		
		--关闭游标
		CLOSE Mycursor
		DEALLOCATE Mycursor
		
		--配合执行后进行检索，返回计算后的列表。
		select * from [dbo].[Sup_ExcessInventory] order by ITEM  asc
		
end

--exec SP_Sup_CaculateExcessQty '700-19058-01','sbu'
GO
