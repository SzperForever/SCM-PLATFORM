create proc dbo.SP_User_Login
(
@userName VARCHAR(25)
,@password VARCHAR(100) 
,@PassLogin int output
)
AS
BEGIN
SET NOCOUNT ON	

	set @PassLogin = 1

IF EXISTS(        
            SELECT *
            FROM dbo.Bas_user WITH (NOLOCK)
            WHERE UserID=@userName
               AND password= sys.fn_VarBinToHexStr(hashbytes('MD5',@password))
        )
    BEGIN
		set @PassLogin = 0
    END
ELSE BEGIN
		set @PassLogin = 1 
		--select sys.fn_SqlVarBaseToStr(hashbytes('MD5',@password)),*,right(sys.fn_VarBinToHexStr(hashbytes('MD5',@password)),32) from BAS_USER WHERE UserID = '135435'
		--RAISERROR('User does not exsit or password is incorrect!Please try again.',16,1)WITH NOWAIT
    END
END
GO
