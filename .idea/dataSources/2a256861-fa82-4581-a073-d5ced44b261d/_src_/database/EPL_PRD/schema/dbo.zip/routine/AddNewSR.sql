CREATE  PROCEDURE [dbo].[AddNewSR]

            @RegDate date
           ,@WorkCell nchar(15)
           ,@SRNo nchar(7)
           ,@SRReceivedTime smalldatetime
           ,@SRStatus nchar(10)
           ,@Remark nvarchar(50)
           ,@AddTime smalldatetime
           ,@AddWho nchar(10)
           
AS
begin
	SET NOCOUNT ON;
		INSERT INTO [dbo].[Tb_SR_Details]
           ([RegDate]
           ,[WorkCell]
           ,[SRNo]
           ,[SRReceivedTime]
           ,[SRStatus]
           ,[Remark]
           ,[AddTime]
           ,[AddWho])
           
     VALUES(@RegDate 
           ,@WorkCell 
           ,@SRNo 
           ,@SRReceivedTime 
           ,@SRStatus 
           ,@Remark 
           ,@AddTime 
           ,@AddWho)
END
GO
