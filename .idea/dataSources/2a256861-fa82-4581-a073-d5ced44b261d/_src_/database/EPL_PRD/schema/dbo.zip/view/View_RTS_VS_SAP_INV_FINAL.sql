CREATE VIEW dbo.View_RTS_VS_SAP_INV_FINAL
AS
SELECT     a.RTSNO, a.StoreLocation AS E_SLOC, b.Sloc AS S_SLOC, a.ScanPartNo AS E_PartNol, SUM(a.ScanQty) AS RTS_Qty, COUNT(a.ScanQty) AS RTS_PNQTY, b.Unrestricted AS S_Qty, 
                      b.Unrestricted - SUM(a.ScanQty) AS Difference, b.StandPrice, SUM(a.ScanQty) - b.Unrestricted AS DiffQty, (SUM(a.ScanQty) - b.Unrestricted) * b.StandPrice AS Total_Price
FROM         dbo.Tb_RTS AS a LEFT OUTER JOIN
                      dbo.TB_SAP_INV_FINAL AS b ON a.StoreLocation = b.Sloc AND a.ScanPartNo = b.Material
GROUP BY a.RTSNO, a.StoreLocation, b.Sloc, a.ScanPartNo, b.Material, b.Unrestricted, b.StandPrice
GO
