CREATE VIEW dbo.V_KIT_RAW_Calc
AS
SELECT     TOP (100) PERCENT h.OrderID, h.KittingPartNum, h.Kits_Qty, s.Component AS RawPartNum, s.[Qty Per], h.Kits_Qty * s.[Qty Per] AS DemandQty, ISNULL(SUM(r.Qnty), 0) AS ActualQty, COUNT(r.GRN) 
                      AS PkgCnt, ISNULL(SUM(r.Qnty), 0) - h.Kits_Qty * s.[Qty Per] AS DiffQty, h.OrderStatus, h.ProgressCode, h.PullListNo,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) + ISNULL(SUM(Unrestr_Cnsgt), 0) + ISNULL(SUM(In_Qual_Insp), 0) + ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_Total
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1
                            WHERE      (Material = s.Component) AND (Sloc IN ('0100', '0300', '0500', '0600', '0143', '01SH', '01TR', '01RB', 'O1RI', '03RI', '03RB'))) AS CurrentStock, (CASE WHEN
                          (SELECT     ISNULL(SUM(Unrestricted), 0) + ISNULL(SUM(Unrestr_Cnsgt), 0) + ISNULL(SUM(In_Qual_Insp), 0) + ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_Total
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1
                            WHERE      (Material = s.Component) AND (Sloc IN ('0100', '0300', '0500', '0600', '0143', '01SH', '01TR', '01RB', 'O1RI', '03RI', '03RB'))) >= (h.Kits_Qty * s.[Qty Per]) THEN 'Y' ELSE 'N' END) 
                      AS IsStockAvl
FROM         dbo.TB_KIT_ORDER_HEADER AS h LEFT OUTER JOIN
                      dbo.Bas_SAPbom AS s ON h.KittingPartNum = s.[Assembly Name] LEFT OUTER JOIN
                      dbo.TB_KIT_RAW_HISTORY AS r ON r.OrderID = h.OrderID AND r.RawPartNum = s.Component
GROUP BY h.OrderID, h.KittingPartNum, h.Kits_Qty, s.Component, s.[Qty Per], h.OrderStatus, h.ProgressCode, h.PullListNo
ORDER BY h.OrderID DESC
GO
