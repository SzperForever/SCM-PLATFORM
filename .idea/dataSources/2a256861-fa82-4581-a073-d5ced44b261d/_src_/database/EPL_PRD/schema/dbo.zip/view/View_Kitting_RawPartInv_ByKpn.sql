
CREATE VIEW [dbo].[View_Kitting_RawPartInv_ByKpn]
AS
SELECT     b.OrderID, b.KittingPartNum, b.RawPartNum, b.[Qty Per], b.RawPartsDemandQty, a.Shortage, a.Inv_Total, a.DiffQty, a.Inv_0100, a.Inv_0300, a.Inv_0500, a.Inv_0143, 
                      b.OrderStatus
FROM         dbo.View_Kitting_RawPart_Inv AS a  with (nolock) INNER JOIN
                      dbo.View_Kitting_RawPartsDemandList AS b  with (nolock) ON a.RawPartNum = b.RawPartNum

GO
