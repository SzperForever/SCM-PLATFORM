CREATE VIEW dbo.View_Feeder_slotcnt
AS
SELECT     TOP (100) PERCENT Workcell, DATEPART(YY, OccuredTime) AS Year, DATEPART(MM, OccuredTime) AS Month, SUM(SlotCnt) AS QTY
FROM         (SELECT     Workcell, BayNum, ModelName, Sets, Step, Rev, Op_Text, SlotCnt, OccuredTime
                       FROM          dbo.View_Feeder_Logs
                       WHERE      (Op_Text = 'Start Loading Feeders.') AND (OccuredTime BETWEEN '2017-1-1 00:00:00' AND '2018-1-1 00:00:00')) AS M
GROUP BY DATEPART(YY, OccuredTime), DATEPART(MM, OccuredTime), Workcell
ORDER BY Workcell, Year, Month
GO
