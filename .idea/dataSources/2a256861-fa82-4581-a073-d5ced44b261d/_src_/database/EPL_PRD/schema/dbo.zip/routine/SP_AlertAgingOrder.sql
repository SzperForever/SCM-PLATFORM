
CREATE PROCEDURE [dbo].[SP_AlertAgingOrder]
	-- Add the parameters for the stored procedure here
	@UserName varchar(20),
	@FlagGroup varchar(20),
	@SMT_Flag INT OUTPUT,
	@MI_Flag int output,
	@MFG_Flag int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @iRecordCount int,@Errmsg varchar(200)
	if @FlagGroup = 'SMT' 
		begin
			set @iRecordCount = (select COUNT(distinct MODEL) 
								from Tb_Order_Details 
								where datediff(hour,(RTScompletedTime),getdate()) > 24 and OrderStatus = 'Open' and CurrentPlace ='IA' and CreateBy = @UserName )
								--group by b.WorkCell,a.RTSNO,b.Sloc,b.Model,b.Sets,b.BAYNUM,b.SendLineTime,b.BuildPlanTime,b.CreateBy )
			if @iRecordCount > 0
				BEGIN
					set @SMT_Flag = 1
				END
			else
				BEGIN
					set @SMT_Flag = 0				
				END
		end
	else if @FlagGroup = 'MI' 
		begin
			set @iRecordCount = (select COUNT(distinct PullListNo) 
								 from Tb_Order_Details 
								 where DATEDIFF(Minute,BuildPlanTime, GETDATE())> 2880 and OrderStatus = 'Open' and ConditionalFormat = 'Completed' and FlagGroup = 'MI' and CreateBy = @UserName )
			if @iRecordCount > 0
				BEGIN
					set @MI_Flag = 1	
				END
			else
				BEGIN
					set @MI_Flag = 0
				END
		end
	else if @FlagGroup = 'MFG'  		
		begin
			set @iRecordCount = (select COUNT(distinct PullListNo) 
									from Tb_Order_Details 
									where DATEDIFF(Minute,sendlinetime, GETDATE())> 1440 and OrderStatus = 'Open' and CurrentPlace = 'Online' and FlagGroup = 'SMT' and CreateBy = @UserName )
			if @iRecordCount > 0
				BEGIN
					set @MFG_Flag = 1	
				END
			else
				BEGIN
					set @MFG_Flag = 0
				END
		end
	
	else begin
			SET @MI_Flag = 2
			SET @SMT_Flag = 2
			set @MFG_Flag = 2
			set @Errmsg = 'Opps! MY dear, @Flaggroup is invaild.'
			raiserror(@ErrMsg,16,1)	
		end

END
GO
