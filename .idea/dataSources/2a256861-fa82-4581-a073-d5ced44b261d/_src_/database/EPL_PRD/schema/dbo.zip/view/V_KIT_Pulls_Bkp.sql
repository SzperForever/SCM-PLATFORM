
CREATE VIEW [dbo].[V_KIT_Pulls_Bkp]
AS
SELECT        PullListNo, Pull_ReleasedBy, Pull_ReleasedTime, Stock_Sts, Stock_AssignedBy, Stock_AssignedTo, Stock_PickingTime, Pull_FinishedTime, OrderStatus, 
                         SUBSTRING(PullListNo, 9, 4) AS StoreArea, Workcell
FROM            dbo.V_KIT_ORDER_HEADER AS h
WHERE        (LEN(ISNULL(PullListNo, '')) <> 0)
GROUP BY PullListNo, Pull_ReleasedBy, Pull_ReleasedTime, Stock_Sts, Stock_AssignedBy, Stock_AssignedTo, Stock_PickingTime, Pull_FinishedTime, OrderStatus, Workcell

GO
