

CREATE   FUNCTION [dbo].[GetStrPara]
   (@SourceString nvarchar(4000),--要分割的原字串。
    @SN int,    --要取第几个
    @Deli varchar(1))--分隔符
    
    RETURNS varchar(1000)--返回值
AS
BEGIN
	declare @first int,@last int,@result varchar(1000),@sn0 int
	select @sn0=0,@first=0,@LAST=1,@SourceString=@SourceString+REPLICATE(@DELI,5)
	while @sn0!=@sn
	  begin
	  select @sn0=@sn0+1,@first=@LAST,@last=charindex(@DELI,@SourceString,@LAST)+1
	  end
	SET @RESULT=SUBSTRING(@SourceString,@FIRST,@LAST-@FIRST-1)
	RETURN ( @RESULT )
END


GO
