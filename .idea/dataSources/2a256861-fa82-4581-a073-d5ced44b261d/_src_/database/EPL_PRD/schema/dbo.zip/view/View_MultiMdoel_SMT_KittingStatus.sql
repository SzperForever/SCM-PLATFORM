CREATE VIEW dbo.View_MultiMdoel_SMT_KittingStatus
AS
SELECT     TOP (100) PERCENT Component, Actualqty, SUM(NeedQty) AS needqty, PkgCount, Actualqty - SUM(NeedQty) AS diffqty, OrderID
FROM         dbo.View_SMT_KittingStatus
WHERE     (OrderStatus <> 'Cancel')
GROUP BY Actualqty, Component, PkgCount, OrderID
ORDER BY DiffQty, Component
GO
