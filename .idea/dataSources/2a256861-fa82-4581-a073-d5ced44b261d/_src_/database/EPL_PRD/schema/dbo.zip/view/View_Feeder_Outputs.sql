CREATE VIEW dbo.View_Feeder_Outputs
AS
SELECT     CONVERT(varchar(13), CONVERT(varchar, OccuredTime, 120), 120) + ':00:00' AS TimePeriod, COUNT(DISTINCT OrderID) AS OrderCnt, Op_Text, 
                      COUNT(Op_Text) AS LogItemsCnt, SUM(SlotCnt) AS SlotCnt, COUNT(UserID) AS OperatorCnt
FROM         dbo.Tb_Feeder_Logs
GROUP BY CONVERT(varchar(13), CONVERT(varchar, OccuredTime, 120), 120) + ':00:00', Op_Text
GO
