-- =============================================
-- Author:		Hanson Zhang	
-- Create date: 2016-10-28
-- Description:	Check availibility of RMA SN
-- =============================================
CREATE PROCEDURE SP_RMA_Check_Availibility
	-- Add the parameters for the stored procedure here
	@SN nvarchar(100),
	@IsAvailable bit = 0 output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	declare @ReturnRow int
	
	Set @ReturnRow = (Select count(0) from [dbo].[tb_RMA_Tracking] where Serialnumber = @SN and status = 'Open')
	if @ReturnRow = 0 
		begin
			set @IsAvailable = 1
			return @IsAvailable
		end

END
GO
