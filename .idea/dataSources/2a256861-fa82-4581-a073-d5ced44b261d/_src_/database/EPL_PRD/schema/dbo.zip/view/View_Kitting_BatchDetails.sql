CREATE VIEW dbo.View_Kitting_BatchDetails
AS
SELECT     b.Sloc, b.OrderID AS BatchID, a.OrderID, a.WorkCell, b.PartNo, b.Qty, b.GRN, b.PreparedBy AS ScanBy, b.ScanTime, a.OrderStatus
FROM         dbo.Tb_PreparedList AS b WITH (nolock) INNER JOIN
                      dbo.TB_Kitting_BatchList AS c WITH (nolock) ON b.OrderID = c.BatchID AND b.GRN = c.GRN INNER JOIN
                      dbo.View_Kitting_Order_Headers AS a WITH (nolock) ON c.OrderID = a.OrderID
WHERE     (b.FlagGroup = 'Kitting') AND (c.IsCalculable = 1) AND (b.PreparedID = 'KOM')
GO
