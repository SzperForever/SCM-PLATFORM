-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-11-12>
-- Description:	<SMT Preparation base on the buffer setting>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_SeeSMTBuffer]
	-- Add the parameters for the stored procedure here
	@BufferQty float,
	@BufferPercent float,
	@BaseQty float,
	@OrderID varchar(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Insert statements for procedure here
	SELECT     c.OrderID, c.WorkCell, c.Model, c.BayNum, c.Sloc, c.CreateBy, a.Component, a.[Qty Per], c.Sets, c.OrderStatus, d.ABC_Type, 
                      c.Sets * a.[Qty Per] AS BOMQty, 
                (CASE WHEN ((d .ABC_Type = 'C') AND (c.Sets * a.[Qty Per]) < @BaseQty) THEN (c.Sets * a.[Qty Per] + @BufferQty) 
                      WHEN ((d .ABC_Type = 'C') AND (c.Sets * a.[Qty Per]) >= @BaseQty) THEN (c.Sets * a.[Qty Per] + (c.Sets * a.[Qty Per]) * @BufferPercent)         
					   END) AS Needqty,
                          (SELECT     ISNULL(SUM(Qty), 0) AS Actualqty
                            FROM          dbo.Tb_PreparedList AS h
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Component) AND (FlagGroup = 'SMT')) AS Actualqty,
                          (SELECT     ISNULL(SUM(Qty), 0) AS Expr1
                            FROM          dbo.Tb_PreparedList AS h
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Component) AND (FlagGroup = 'SMT')) - (CASE WHEN ((d .ABC_Type = 'C') AND (c.Sets * a.[Qty Per]) 
                      < @BaseQty) THEN (c.Sets * a.[Qty Per] + @BufferQty) WHEN ((d .ABC_Type = 'C') AND (c.Sets * a.[Qty Per]) > @BaseQty) THEN (c.Sets * a.[Qty Per] + (c.Sets * a.[Qty Per]) 
                      * @BufferPercent) ELSE (c.Sets * a.[Qty Per]) END) AS DiffQty,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Tb_PreparedList AS g
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Component)) AS PkgCount, c.FinishRate
FROM      dbo.Bas_SAPbom AS a LEFT OUTER JOIN
		  dbo.Tb_Order_Details AS c ON c.Model = a.[Assembly Name] LEFT OUTER JOIN
		  dbo.Tb_PreparedList AS b ON a.[Assembly Name] = c.Model AND a.Component = b.PartNo AND b.OrderID = c.OrderID AND 
		  c.FlagGroup = 'SMT' INNER JOIN
		  dbo.BAS_SKU AS d ON b.PartNo = d.Material
WHERE     (c.FlagGroup = 'SMT') AND (c.OrderID = @OrderID) AND (c.OrderStatus = 'Open')
GROUP BY c.OrderID, c.WorkCell, c.Model, c.BayNum, c.Sloc, c.CreateBy, a.Component, a.[Qty Per], c.Sets, c.FinishRate, c.OrderStatus, d.ABC_Type
ORDER BY a.Component


END
GO
