CREATE VIEW dbo.VIEW_RTS_VS_SAPbom
AS
SELECT     TOP (100) PERCENT S.OrderID, S.Component, S.NeedQty, S.Actualqty, S.PkgCount, S.DiffQty, SUM(ISNULL(R.ScanQty, 0)) AS RTS_Qty, COUNT(R.GRNno) AS GRN_Cnt, 
                      M.Standard_price AS Std_Price, M.Standard_price * (SUM(ISNULL(R.ScanQty, 0)) - S.DiffQty) AS V_Value, SUM(ISNULL(R.ScanQty, 0)) - S.DiffQty AS V_Qty
FROM         dbo.View_SMT_KittingStatus AS S WITH (nolock) LEFT OUTER JOIN
                      dbo.Tb_RTS AS R WITH (nolock) ON R.RTSNO = S.OrderID AND R.ScanPartNo = S.Component RIGHT OUTER JOIN
                      dbo.BAS_SKU AS M WITH (nolock) ON M.Material = S.Component
GROUP BY S.OrderID, S.Component, S.NeedQty, S.Actualqty, S.PkgCount, S.DiffQty, S.Component, M.Standard_price
ORDER BY S.Component
GO
