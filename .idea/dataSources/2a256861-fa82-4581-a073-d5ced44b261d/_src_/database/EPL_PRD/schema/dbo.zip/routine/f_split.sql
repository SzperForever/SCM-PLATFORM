
create  function  [dbo].[f_split](@s  Nvarchar(2000),@pos  int)  
returns  nvarchar(2000)  
as  
begin  
           declare  @i  int  
           set  @i=charindex('/',@s)  
           while  @i>0  and  @pos>1  
                       select  @i=charindex('/',@s,@i+1),@pos=@pos-1  
           return(case  @pos  when  1  then  case  when  @i>0  then  left(@s,@i)  else  @s  end  else  ''  end)  
end

GO
