

CREATE VIEW [dbo].[View_Kitting_RawPartsDemandList]
AS
SELECT     a.OrderID, a.KittingPartNum, SUM(a.Kits_Qty) AS DemandQty, b.Component AS RawPartNum, b.[Qty Per], b.[Qty Per] * SUM(a.Kits_Qty) AS RawPartsDemandQty, 
                      a.PullListNo, a.DocIndex,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) + ISNULL(SUM(Unrestr_Cnsgt), 0) + ISNULL(SUM(In_Qual_Insp), 0) + ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_Total
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1
                            WHERE      (Material = b.Component) AND (Sloc IN ('0100', '0300', '0500', '0600', '0143', '01SH', '01TR', '01RB', 'O1RI', '03RI', '03RB'))) AS CurrentStock, 
                      a.KittingType, a.OrderStatus
FROM         dbo.Bas_SAPbom AS b  with (nolock) INNER JOIN
                      dbo.View_Kitting_Order_Headers AS a  with (nolock) ON b.[Assembly Name] = a.KittingPartNum
GROUP BY a.KittingPartNum, b.Component, b.[Qty Per], a.OrderID, a.PullListNo, a.DocIndex, a.KittingType, a.OrderStatus


GO
