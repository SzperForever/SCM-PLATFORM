CREATE VIEW dbo.View_Feeder_slotcntStatus
AS
SELECT DISTINCT Workcell AS Workcell_2017, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '1') AND (Year = '2017')), 0)) AS Jan, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '2') AND (Year = '2017')), 0)) AS Feb, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '3') AND (Year = '2017')), 0)) AS Mar, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '4') AND (Year = '2017')), 0)) AS Apr, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '5') AND (Year = '2017')), 0)) AS May, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '6') AND (Year = '2017')), 0)) AS Jun, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '7') AND (Year = '2017')), 0)) AS Jul, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '8') AND (Year = '2017')), 0)) AS Aug, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '9') AND (Year = '2017')), 0)) AS Sep, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '10') AND (Year = '2017')), 0)) AS Oct, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '11') AND (Year = '2017')), 0)) AS Nov, CONVERT(float, ISNULL
                          ((SELECT     SUM(QTY) AS Expr1
                              FROM         dbo.View_Feeder_slotcnt AS v1
                              WHERE     (Workcell = V.Workcell) AND (Month = '12') AND (Year = '2017')), 0)) AS Dec
FROM         dbo.View_Feeder_slotcnt AS V
GO
