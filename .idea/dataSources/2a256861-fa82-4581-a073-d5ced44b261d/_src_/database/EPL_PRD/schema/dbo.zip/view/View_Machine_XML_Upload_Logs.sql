CREATE VIEW dbo.View_Machine_XML_Upload_Logs
AS
SELECT     MAText, Number, Rev, BoardSide, JobRevision, COUNT(fsPartNum) AS PartCnt, LstUpdateTime, PrgName
FROM         dbo.Bas_Machine_Feeder_Report
GROUP BY MAText, Number, Rev, BoardSide, JobRevision, LstUpdateTime, PrgName
GO
