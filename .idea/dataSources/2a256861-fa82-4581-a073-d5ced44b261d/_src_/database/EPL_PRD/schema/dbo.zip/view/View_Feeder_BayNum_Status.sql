CREATE VIEW dbo.View_Feeder_BayNum_Status
AS
SELECT     BayNum, Workcell, Bottom_Progress, ModelName, BayNum + Workcell + ModelName + Bottom_Progress AS Progress, 1 AS Expr1
FROM         dbo.TB_Feeder_Setup_History
WHERE     (SetupStatus = 'open') AND (Bottom_Progress IN ('OnLoading', 'LoadingCompleted', 'Building'))
GROUP BY Workcell, BayNum, Bottom_Progress, ModelName
GO
