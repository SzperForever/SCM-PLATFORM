-- =============================================
-- Author:		HANSON
-- Create date: 2016-08-08
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Alert_RTS_SLED_Report] 
	@DaysRange int = -180
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
		
	set @AlertName = 'RTS_SLEDAlert'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	set @Rcnt = (SELECT COUNT(*)FROM
					(SELECT *
					  ,LifeDays = datediff(d, replace( replace(dbo.GetStrPara([MAremark],3,':'),'"',''),'}]',''),getdate())
					  	FROM [EPL_PRD].[dbo].[Tb_RTS]
						WHERE [MAremark] LIKE '%RECODE":0%' 
						and [RTSNO] not LIKE 'r%' AND ScanTime BETWEEN DATEADD(dd,-1,getdate()) AND getdate()) as v
  
					WHERE LifeDays >= @DaysRange )	
	if @Rcnt =0 return	
	SET @tableHTML =
    N'<H1>Hi, All: </H1>' +
    N'<H1>Please pay more attention to below items which the material shelf life will be expired within 180 days </H1>' +
    N'<table border="1">' +
    N'<tr><th>RTSNO</th><th>WorkCell</th>' +
    N'<th>StoreLocation</th><th>ScanPartNo</th><th>ScanQty</th><th>SLED</th><th>GRNno</th><th>LifeDays</th></tr>' +
    CAST ( ( SELECT td = RTSNO,       '',
                    td = WorkCell, '',
                    td = StoreLocation, '',
                    td = ScanPartNo, '',
                    td = ScanQty, '',
                    td = SLED,'',
                    td = GRNno, '',
                    td = LifeDays, ''
              from 
					(SELECT [RTSNO]
					  ,[WorkCell]
					  ,[StoreLocation]
					  ,[ScanPartNo]
					  ,[ScanQty]
					  ,[GRNno]
					  ,[ScanTime]
					  ,[MAremark]
					  ,SLED = (replace( replace(dbo.GetStrPara([MAremark],3,':'),'"',''),'}]',''))
					  ,LifeDays = datediff(d, replace( replace(dbo.GetStrPara([MAremark],3,':'),'"',''),'}]',''),getdate())
					  ,TodayDate = getdate()
						FROM [EPL_PRD].[dbo].[Tb_RTS]
						WHERE [MAremark] LIKE '%RECODE":0%' and [RTSNO] not LIKE 'r%' AND ScanTime BETWEEN DATEADD(dd,-1,getdate()) AND getdate()) as v
  
			WHERE LifeDays >= @DaysRange                   
              FOR XML PATH('tr'), TYPE 
				) AS NVARCHAR(MAX) ) +
    N'</table>' +    
    'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';

    
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,--'Hanson_zhang@jabil.com',--
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END
GO
