CREATE VIEW dbo.View_Inv_Compare_SAP_VS_MI
AS
SELECT     a.SLoc, a.Material AS SAPPartNo, b_1.PartNo, a.[Material description], a.[Matl grp], ISNULL(a.[Stand Price], 0.00) AS Stand_Price, ISNULL(a.Unrestricted, 0) AS SAPqty, 
                      SUM(ISNULL(b_1.Qty, 0)) AS lvqty, SUM(ISNULL(b_1.Qty, 0)) - ISNULL(a.Unrestricted, 0) AS VarianceQty, (SUM(ISNULL(b_1.Qty, 0)) - ISNULL(a.Unrestricted, 0)) 
                      * ISNULL(a.[Stand Price], 0.00) AS VarianceValue
FROM         dbo.tmp_Sap_Inventory AS a FULL OUTER JOIN
                          (SELECT     OrderID, PartNo, Qty, GRN, ScanTime, PreparedBy, Side, Remark, PreparedID, RegDate, WorkCell, BayNum, Sloc, Model, Sets, UploadBy, UploadTime, 
                                                   CheckFlag, CheckTime, CheckBy, QtyUpdateRmk, FlagGroup, DoneMark
                            FROM          dbo.Tb_PreparedList AS a
                            WHERE      (OrderID IN
                                                       (SELECT DISTINCT OrderID
                                                         FROM          dbo.Tb_Order_Details AS b
                                                         WHERE      (OrderStatus = 'Open') AND (CurrentPlace = 'LVHM') AND (FlagGroup = 'MI')))) AS b_1 ON a.Material = b_1.PartNo
GROUP BY a.SLoc, a.Material, b_1.PartNo, a.[Material description], a.[Matl grp], a.[Stand Price], a.Unrestricted
GO
