-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-10-29>
-- Description:	<SyncPPLSetupSheet>
-- =============================================
CREATE PROCEDURE [dbo].[SyncPPLSetupSheet]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    truncate table [dbo].[BAS_PPL]    
	INSERT INTO [dbo].[BAS_PPL]
           ([CustomerText]
           ,[DivisionText]
           ,[Number]
           ,[Revision]
           ,[Version]
           ,[Assembly]
           ,[FactoryText]
           ,[MAText]
           ,[RouteText]
           ,[StepOrder]
           ,[StepText]
           ,[RouteStepText]
           ,[Equipment]
           ,[Feeder]
           ,[Tray]
           ,[Track]
           ,[FeederType]
           ,[Media]
           ,[IsAddOn]
           ,[Material]
           ,[MaterialDescr]
           ,[ComponentType]
           ,[PinCount]
           ,[CRDCount]
           ,[EquipmentSetup_ID]
           ,[Active]
           ,[LastUpdated]
           ,[LastUpdateBy])
	SELECT [CustomerText]
      ,[DivisionText]
      ,[Number]
      ,[Revision]
      ,[Version]
      ,[Assembly]
      ,[FactoryText]
      ,[MAText]
      ,[RouteText]
      ,[StepOrder]
      ,[StepText]
      ,[RouteStepText]
      ,[Equipment]
      ,[Feeder]
      ,[Tray]
      ,[Track]
      ,[FeederType]
      ,[Media]
      ,[IsAddOn]
      ,[Material]
      ,[MaterialDescr]
      ,[ComponentType]
      ,[PinCount]
      ,[CRDCount]
      ,[EquipmentSetup_ID]
      ,[Active]
      ,[LastUpdated]
      ,'sp_SyncPPL'
  FROM [PPLS].[dbo].[PPLS_EquipmentSetupSheet]
  where Active = '1' and len(FeederType) > 0
  
  
  exec sp_SendingAlert 'Dai_Lisong@jabil.com,Hanson_Zhang@jabil.com','SyncPLVBom Notification','Hi, Inform you that the PLVBOM has been updated succesfully.'
END
GO
