--exec dbo.SP_Machine_Feeder_LoadXMLDirectory 'E:\xml','E:\xml\ResultLog.txt'
--select *		from Res_XML_Dir_Tree  

CREATE proc [dbo].[SP_Machine_Feeder_BatchUploadFromXML] 
	@DirTree nvarchar(100),
	@ResultPath nvarchar(100)
AS BEGIN
	Declare  @Dir nvarchar(1000)
			,@Project nvarchar(30)
	        ,@MAText nchar(12)
			,@Number nchar(50)
			,@Rev nchar(10)
			,@BoardSide nchar(10)
			,@JobRevision nchar(10)
			,@Str varchar(2000)
			,@LogFileName varchar(1000)
			
    set @LogFileName = @ResultPath + '\ResultLog.txt'
    EXEC p_Writefile @LogFileName,'Start Line (Process Started)---------------------------------------------------------------------------'
    	
	exec dbo.SP_Machine_Feeder_LoadXMLDirectory @DirTree,@LogFileName  --读取并装载文件目录到表,装载过程中根据情况写入装载日志
	
	Declare fCursor cursor scroll dynamic for                        --游标处理循环写入
                    select MAText,Number,Rev,BoardSide,JobRevision,UpDir from Res_XML_Dir_Tree
		
		--where upper(MAText) <> 'BAY03'
		
		open fCursor                   
		fetch next from fCursor  into @MAText,@Number,@Rev,@BoardSide,@JobRevision,@Dir
		while(@@fetch_status=0)		
		BEGIN
			PRINT @DIR
			set @Str =  CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Calculating:' + rtrim(@DIR)
			EXEC p_Writefile @LogFileName, @Str
			exec dbo.[SP_Machine_Nokia_A1_Process] @Dir ,@ResultPath        --如果是NOKIA_A1,，同一条线打2个MODEL,则新建子目录，并重新整理文件
			EXEC dbo.SP_Machine_Feeder_Calc_BrdNum_FromXML @Dir,@ResultPath	--循环计算拼板数量并读取各子目录执行导入
			
			
			EXEC p_Writefile @LogFileName, 'Move to next record...and start calculating again.'	
			fetch next from fCursor into @MAText,@Number,@Rev,@BoardSide,@JobRevision,@Dir
			
		end		
	CLOSE fCursor	
	DEALLOCATE fCursor
	
	EXEC p_Writefile @LogFileName,'End Line (Process Finished)-----------------------------------------------------------------------------'
END

GO
