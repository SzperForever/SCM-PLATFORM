
CREATE PROCEDURE [dbo].[Ep_SP_addNewTransferOrder]
		@FlagGroup varchar(10),
		@PullListNo varchar(13),
		@CreateBy varchar(10),
		@CreateTime SMALLdatetime,
		@WorkCell varchar(20),
		@PartAmount int,	
		@BuildPlanTime SMALLdatetime,
		@Remark varchar(255)
		
AS
	if (select Count(pulllistno) from Tb_Order_Details where PullListNo = @PullListNo and PullStatus <> 'Cancel') >0 
		begin
			raiserror('You are about to insert a duplicate pull list which is not allowed.',16,1)	
		end
	else begin
			insert into Tb_Order_Details 
			(OrderType,PullStatus,StockSts,Sloc,WorkCell,BayNum,StoreArea,PullListNo,PartAmount,BuildPlanTime,LVHMrequestTime, CreateBy,CreateTime,KTE,FlagGroup,Remark,CurrentPlace,AP_Flag )
			values('TransferOrder','Open','NotStarted','',@WorkCell,'','0300',@PullListNo,@PartAmount,@BuildPlanTime,@BuildPlanTime,@CreateBy,@CreateTime,'Y',@FlagGroup,@Remark,'3PL','0')
		end
GO
