CREATE PROCEDURE [dbo].[Sp_MarkSupMaintainInfo]
		@MaintainedBy varchar(10),
		@MaintainTime smalldatetime,
		@TableName varchar(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if @TableName = 'Sup_BuildPlan'
		begin
			update Sup_BuildPlan set MaintainedBy = @MaintainedBy ,MaintainTime = @MaintainTime 
		end
	else if @TableName = 'Sup_BOM'
		begin
			update Sup_BOM set MaintainedBy = @MaintainedBy ,MaintainTime = @MaintainTime 
		end
	else if @TableName = 'Sup_OnlineInventory'
		begin
			update Sup_OnlineInventory set MaintainedBy = @MaintainedBy ,MaintainTime = @MaintainTime 		
		end
	else if @TableName = 'Sup_WIP'
		begin
			update Sup_WIP set MaintainedBy = @MaintainedBy ,MaintainTime = @MaintainTime 		
		end
	else begin
			update dbo.Sup_Bas_UPH set MaintainedBy = @MaintainedBy ,MaintainTime = @MaintainTime 	
		end
END
GO
