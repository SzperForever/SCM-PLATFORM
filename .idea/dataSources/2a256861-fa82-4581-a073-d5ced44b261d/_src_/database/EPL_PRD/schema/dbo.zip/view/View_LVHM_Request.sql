CREATE VIEW dbo.View_LVHM_Request
AS
SELECT     WorkCell, COUNT(DISTINCT Sloc) AS Requested
FROM         dbo.Tb_Order_Details
WHERE     (OrderStatus = 'Open') AND (BuildPlanTime < GETDATE()) AND (CurrentPlace <> 'IA') AND (CurrentPlace <> 'RTS') AND (CurrentPlace <> 'Online')
GROUP BY WorkCell
GO
