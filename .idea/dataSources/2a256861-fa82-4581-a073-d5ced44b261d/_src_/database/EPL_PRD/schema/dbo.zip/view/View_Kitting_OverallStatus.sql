

CREATE VIEW [dbo].[View_Kitting_OverallStatus]
AS
SELECT     TOP (100) PERCENT a.WorkCell, a.KittingPartNum, a.[Part Description] AS PartDescription, COUNT(DISTINCT a.OrderID) AS OrderCnt, ISNULL(b.PkgCnt, 0) AS PkgCnt, 
                      ISNULL(SUM(a.Kits_Qty), 0) AS DemandQty, ISNULL(b.Qty, 0) AS ActualQty, CAST(ROUND(ABS(ISNULL(b.Qty, 
                      0)) / ISNULL(SUM(a.Kits_Qty), 0), 3) * 100 AS varchar(9)) + '%' AS KitsRate, ISNULL(b.Qty, 0) - ISNULL(SUM(a.Kits_Qty), 0) AS DiffQty
FROM         dbo.View_Kitting_Order_Headers AS a  with (nolock) LEFT OUTER JOIN
                      dbo.View_Kitting_ActualQty AS b  with (nolock) ON b.KittingPartNum = a.KittingPartNum
WHERE     (a.OrderStatus = 'OPEN')
GROUP BY a.WorkCell, a.KittingPartNum, a.[Part Description], b.PkgCnt, b.Qty
ORDER BY ActualQty DESC


GO
