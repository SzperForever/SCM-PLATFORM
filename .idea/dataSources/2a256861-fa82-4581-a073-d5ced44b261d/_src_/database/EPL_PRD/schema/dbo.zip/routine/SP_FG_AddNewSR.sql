


CREATE  PROCEDURE [dbo].[SP_FG_AddNewSR]

		@Project varchar(20),
		@SoldToCode varchar(20),
		@ShipToCode varchar(20),
		@SoldToAdd varchar(1000),
		@ShipToAdd varchar(1000),
		@ForwarderID INT,
		@Requestor varchar(20),
		@TradeTerms nvarchar(20),			
		@Priority varchar(10),
		@CreateBy nchar(10),
		@Flag nchar(10) = 'I',
		--@PlanPickTime smalldatetime,
		@Remark varchar(300)
		
AS
	begin		
		declare @SRno Varchar(12)
		DECLARE @dt CHAR(6)
		declare @Rcount int
		
		Declare @UnClosedItemCnt int,@ErrMsg varchar(500)
		set @UnClosedItemCnt = (select COUNT(*) from TB_FG_SR_Header where SR_SP_Status = '911' and CreateBy = @CreateBy)
		
		if @TradeTerms not in ('DAP','DDP','EXW','FCA From Plant','FCA Jabil Sha','FCA shanghai','FOB') 
			begin
				set @ErrMsg = 'TradeTerms is invalid. Ensure it contains one of them:[DAP,DDP,EXW,FCA From Plant,FCA Jabil Sha,FCA shanghai,FOB](@TradeTerms 变量传递的值不合法。)'
				raiserror (@ErrMsg,16,1)
				Return			
			end

		if RTRIM(UPPER(@Project)) = 'NOKIA'
			begin		
				if @UnClosedItemCnt > = 1
					begin
						set @ErrMsg = 'You still have unclosed items that pending input AWB number please close them first before adding new orders.(请关闭sp_status（inputAWB）的SR。就可以下新的SR订单。)'
						raiserror (@ErrMsg,16,1)
						return
					end
			end
		else begin
			if @UnClosedItemCnt > = 1
			begin
				set @ErrMsg = 'You still have unclosed items that pending input AWB number please close them first before adding new orders.(请关闭sp_status（inputAWB）的SR。就可以下新的SR订单。)'
				raiserror (@ErrMsg,16,1)
				return
			end		
		end 
	
		SELECT @dt=dt FROM v_GetDate	
			
		--set @SRno = (SELECT @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(SRno),6),0),6) 
		--				FROM TB_FG_SR_Header  WITH(XLOCK,PAGLOCK) 
		--				WHERE SRno  like @dt+'%')
		set @SRno = (SELECT @dt+RIGHT(1001+ISNULL(RIGHT(MAX(SRno),3),0),3) 
						FROM TB_FG_SR_Header  WITH(XLOCK,PAGLOCK) 
						WHERE SRno  like @dt+'%')		
			
		INSERT INTO [dbo].[TB_FG_SR_Header]
           ([SRno]
           ,[Project]
           ,ForwarderID
           ,[Requestor]
           ,[TradeTerms]
           ,[SoldToCode]
           ,[ShipToCode]
		   ,[SoldToAddress]
		   ,[ShipToAddress]
           ,[CreateTime]
           ,[SR_Status]
		   ,[SR_OrderStatus]
		   ,[SR_SP_Status]
		   ,[CreateBy]
           ,[Priority]
           --,[Plan_Pick_Time] 
           ,[Flag]
           ,[OrderNotes] )
     VALUES
		(@SRno
		,@Project 
		,@ForwarderID 
		,@Requestor 
		,@TradeTerms 
		,@SoldToCode 
		,@ShipToCode
		,@SoldToAdd 
		,@ShipToAdd 
		,GETDATE()
		,'900'-- SRNotActivated
		,'200' --open
		,'902' --MPNotCreated
		,@CreateBy
		,@Priority
		--,@PlanPickTime
		,@Flag
		,@Remark ) 
		
end

--CodeGroup	Code	Chinese_DESC	English_DESC	CodeGroup_Desc
--57	9         	900       	创建订单	SRNotActivated	SR_Status
--58	9         	901       	激活订单	SRActivated	SR_Status
--59	9         	902       	未创建拣货单	MPNotCreated	SR_SP_Status
--60	9         	903       	拣货单创建	MPCreated	SR_SP_Status
--61	9         	904       	拣货中	MPPicking	SR_SP_Status
--62	9         	905       	打印唛头中	PrintShippingMark	SR_SP_Status
--63	9         	906       	等待PGI中	PGI NotStarted	SR_SP_Status
--64	9         	907       	扣PGI中	PGI InProgress	SR_SP_Status
--65	9         	908       	待装车	TruckNotLoaded	SR_SP_Status
--66	9         	909       	发货中	TruckLoading	SR_SP_Status
--67	9         	910       	已发货	ShippedOut	SR_SP_Status

--200  open
--201  closed
--202  cancel
--203  hold
--204  activated
GO
