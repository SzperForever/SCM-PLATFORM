

CREATE procedure [dbo].[SP_FG_Init_EPS_Data]

as begin

if exists (Select * from tempdb.dbo.sysobjects Where name='##eP_tmp_FG_EPS' and  Xtype='U') drop table [##eP_tmp_FG_EPS]

CREATE TABLE [dbo].##eP_tmp_FG_EPS (
	[Packinglist_ID] [nchar](10) NOT NULL,
	[DetailID] [nchar](10) NOT NULL,
	[Delivery_ID] [nchar](10) NOT NULL,
	[CaseNO] [nchar](10) NULL,
	[EpsCustomerCode] [nchar](20) NOT NULL,
	[PartNumber] [nchar](20) NOT NULL,
	[DeliveryNumber] [nchar](10) NOT NULL,	
	[SO#] [nchar](20) NOT NULL,
	[PO#] [nchar](20) NOT NULL,
	[ShipToParty_ID] [nchar](10) NOT NULL,
	[ShipToName] nvarchar(200) not null,
	[Qty] [int] NOT NULL,
	[BoxQty] [int] NOT NULL,
	[BOXID] [nchar](20) NOT NULL,
	[SerialNumber] [nchar](20) NOT NULL,
	[Updated_Date] [datetime] NULL,
	[EndCustPO] [nchar](15) NULL
) ON [PRIMARY]

end
GO
