
CREATE  PROCEDURE [dbo].[Ep_SP_addNewKitting_DemandItem]

		@PartNo varchar(20),
		@DemandQty numeric(18, 0),
		@OrderID varchar(12),
		@AddBy varchar(10),
		@DmdType varchar(3)
AS
	begin		
			
		INSERT INTO TB_Kitting_Demand
           ([OrderID]
           ,[PartNo]
           ,[Demand]
           ,[DmdType]
           ,[AddTime]
           ,[AddBy])
			VALUES (@orderid			
					,@PartNo
					,@DemandQty
					,@DmdType
					,GETDATE()
					,@AddBy )
					
end
GO
