/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.View_RMA_MFG_SAP_VA_EPULL
AS
SELECT     TOP (100) PERCENT ISNULL(b.Mtrl_Grp, 0) AS Mtrl_Grp, ISNULL(b.Material, 0) AS S_PN, ISNULL(a.[SAP Part No], 0) AS E_PN, ISNULL(b.Unrestricted, 0) AS S_QTY, ISNULL(a.QTY, 0) AS E_QTY, 
                      ISNULL(b.Unrestricted, 0) - ISNULL(a.QTY, 0) AS DiffQty
FROM         (SELECT     [SAP Part No], COUNT(Serialnumber) AS QTY
                       FROM          dbo.tb_RMA_Tracking
                       WHERE      (Status = 'open') AND (CurrentArea = 'MFG')
                       GROUP BY [SAP Part No]) AS a FULL OUTER JOIN
                          (SELECT     Sloc, Material, Mtrl_Grp, Mtrl_Type, StandPrice, Unrestricted, Unrestr_Cnsgt, Stock_In_Tfr, In_Qual_Insp, Cnsgt_Qual_In, Blocked, Blocked_Cnsgt, Total_Value, MRP, Mtrl_Desc, 
                                                   LastUpdateTime
                            FROM          dbo.TB_SAP_INV_FINAL
                            WHERE      (Sloc = '0150') AND (Plant = 'cn04')) AS b ON a.[SAP Part No] = b.Material
WHERE     (ISNULL(b.Unrestricted, 0) - ISNULL(a.QTY, 0) <> 0)
ORDER BY S_PN
GO
