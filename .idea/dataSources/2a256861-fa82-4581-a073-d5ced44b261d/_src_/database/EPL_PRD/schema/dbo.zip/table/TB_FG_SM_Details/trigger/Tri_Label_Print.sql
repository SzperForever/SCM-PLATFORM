-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Tri_Label_Print]
   ON  dbo.TB_FG_SM_Details
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    if @@rowcount > 1 return    
    
    
	if update([PrintFlag]) Begin
		Goto PGIConfirm
	end
	
	 if update([Length]) or update([Width]) or update([Height]) or update([GrossWeight]) or update([NetWeight]) begin
		Goto PGIConfirm
	 end
	 
Return

PGIConfirm:
		Declare @rcnt int
				,@SRid bigint
				,@PrintFlag bit
				,@IsFullKitted bit = 0
				,@HasSizeInfo bit = 0
				,@SPStatus nchar(3)
				,@OrderStatus nchar(3)
				,@SRStatus nchar(3) 
				,@ErrMsg varchar(1000)
		select @SRid= [SRid],@PrintFlag = [PrintFlag] from inserted
		select @SPStatus = SR_SP_Status from dbo.TB_FG_SR_Header where SRID = @SRID
		
		set @OrderStatus = (Select SR_OrderStatus  from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)		
		if @OrderStatus <> '200' begin
			set @ErrMsg = 'Process denied since SR Order status is not [Open]. （由于SR订单状态未开启，拒绝进行下一步操作。）'
			raiserror (@ErrMsg,16,1)
			rollback tran
			return
		end

		set @SRStatus = (Select [SR_Status] from [dbo].[TB_FG_SR_Header] where [SRid] = @SRid)
		if @SRStatus <> '901' begin
			set @ErrMsg = 'Process denied since this SR is not activated. （由于SR订单状态未被激活，拒绝进行下一步操作。）'
			raiserror (@ErrMsg,16,1)
			rollback tran
			return
		end

		set @SPStatus = (Select [SR_SP_Status] from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
		if @SPStatus not IN ('905','906') begin
			set @ErrMsg = ' Operation is denied in current progress.(当前订单状态不允许此操作。)'
			raiserror (@ErrMsg,16,1)
			rollback tran
			return
		end
		
		if @PrintFlag <> 1 return --condition 1
	
	--如果没有被全部打印，则返回
		if (select count(*) from dbo.TB_FG_SM_Details where srid = @SRid and PrintFlag = 0) > 0 return 		 
	--判断数量全部满足
		IF (Select count(*) from [dbo].[View_FG_SR_Details_Status] where SRid = @SRid AND [Difference] < 0  ) =0 set @IsFullKitted = 1	
	--判断包装已经维护
		if (Select count(*) from [View_FG_PKG_Details] where SRid = @SRid and HasSizeInfo = 'N') = 0 set @HasSizeInfo = 1 --condition 3		
		
		if @IsFullKitted = 1 and @HasSizeInfo = 1  begin
				exec SP_FG_StartPGI @SRid	
			end
		else begin
			Return
		end
		
END


--SELECT * FROM [View_FG_PKG_Details] WHERE SRID = 10
--SELECT * FROM TB_FG_SM_Details WHERE SRID = 10
--Select * from [dbo].[View_FG_SR_Details_Status] where SRid =10
--SELECT * FROM TB_FG_SR_HEADER WHERE SRID = 10

--Select count(*) from [View_FG_PKG_Details] where SRid = 10 and HasSizeInfo = 'N'
--Select count(*) from [dbo].[View_FG_SR_Details_Status] where SRid = 10 AND [Difference] < 0
GO
