
-- =============================================
-- Author:		<Hanson >
-- Create date: <2014-10-21,>
-- Description:	<Batch Close Kitting Orders base on scanned sheet,,>
-- =============================================
CREATE  PROCEDURE [dbo].[SP_Kitting_Close_Order_Batch]
	-- Add the parameters for the stored procedure here
	@CloseBy varchar(15),
	@ReturnCode nvarchar(300)='' output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    Declare @Rowcnt int
				update Tb_Kitting_Order_Header 
				set OrderStatus = 'CLOSED',
					closedtime = getdate(),
					ClosedBy = @CloseBy 
				where OrderID in (Select orderid  
						from View_Kitting_Order_Headers with (nolock)
						where [KittingPartNum] in 
								(Select KittingPartNum from View_Kitting_OverallStatus  with (nolock) where DiffQty >=0))	
						
		set @Rowcnt =@@ROWCOUNT 
		if @@ERROR <> 0 begin
			set @ReturnCode = '999,Batch close was not proceed correctly.'
			return
		end
		set @ReturnCode = CONVERT(varchar(4),@rowcnt) + ' order(s) been closed by ' + @CloseBy 
						
END


GO
