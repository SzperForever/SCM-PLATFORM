

Create  PROCEDURE [dbo].[SP_Kitting_Print_Details_Item]
		@BatchID varchar(13)
AS	
	begin
	
		update TB_Kitting_BatchList 
		set printflag = 1
		where BatchID = @BatchID 
	
		
		if @@ERROR <> 0 begin
			raiserror('Print Flag mark fails.',16,1)
			return
		end
		return
					
end


GO
