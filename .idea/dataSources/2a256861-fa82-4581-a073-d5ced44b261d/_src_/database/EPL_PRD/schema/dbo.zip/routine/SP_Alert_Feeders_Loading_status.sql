-- =============================================
-- Author:		HANSON
-- Create date: 2017-01-22
-- Description:	<Send SR Order Value amount alert for each sr status group by workcell>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Alert_Feeders_Loading_status]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

Declare      @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
		
	set @AlertName = 'Feeders_Loading_status'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	--set @Rcnt = 0
	--set @Rcnt =(select COUNT(distinct PullListNo) 
	--		from Tb_Order_Details 
	--		where DATEDIFF(Minute,sendlinetime, GETDATE())> 1440 and OrderStatus = 'Open' and CurrentPlace = 'Online')
	--if @Rcnt > 0
	
	--if @Rcnt = 0 or @@ERROR <> 0 begin
	--	return
	--end


	SET @tableHTML =
		N'<H1>Feeders_Loading_status</H1>' +
		N'<table border="1">' +
		N'<tr><th>[[OrderID]]</th><th>[[Workcell]]</th><th>[[BayNum]]</th><th>[[ModelName]]</th><th>[[PlanBuildTime]]</th><th>[[Sets]]</th><th>[SlotCount]</th><th>[[Bottom_Progress]]</th>' +
		N'<th>[[Top_Progress]]</th><th>[[OrderNotes]]</th></tr>' +
		CAST ( ( SELECT td = [OrderID],'',
						td = [Workcell], '',
						td = [BayNum],'',
						td = [ModelName],'',						
						td = [PlanBuildTime],'',
						td = [Sets],'',
						td = SlotCount,'',
						td = [Bottom_Progress],'',
						td = [Top_Progress],'',
						td = [OrderNotes],'' 
			  
FROM [EPL_PRD].[dbo].[TB_Feeder_Setup_History]
 where [SetupStatus]='open' 
 AND [Bottom_Progress] in('Queued','LoadingCompleted','OnLoading ')
 OR [Top_Progress]in('Queued','LoadingCompleted','OnLoading ')
 order by [BayNum],[PlanBuildTime]
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';
	
	 EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;
	


END
GO
