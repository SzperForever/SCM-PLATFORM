CREATE PROCEDURE [dbo].[AddNewEmpFile]

           @empCode nchar(10),
           @empName nchar(10),
           @Sex nchar(2),
           @Nation nchar(10),
           @Marrage nchar(10),
           @JG nchar(10),
           @ID nchar(18),
           @Birthday date,
           @CellPhone nchar(20),
           @Hobbies nchar(10),
           @Advantage nchar(20),
           @SOSContact nchar(10),
           @SOSPhone nchar(11),
           @HomeAddress nchar(100),
           @HomePhone nchar(20),
           @School nchar(20),
           @Degree nchar(10),
           @Major nchar(20),
           @RelatedCrd nchar(50),
           @Area nchar(20),
           @Responsible nvarchar(50),
           @Bkp nchar(10),
           @Lvl nchar(10),
           @ShiftChange nchar(1),
           @Position nchar(30),
           @NTID nchar(15),
           @SapID NCHAR(30),
           @ShoeSize nchar(2),
           @ShoeReleasedDate DATE,
           @MailBox NCHAR(40),
           @Access NCHAR(30),
           @Rmk nchar(100),
           @AddWho nchar(10),
           @AddTime smalldatetime,
           @JoinDate date
AS
begin
	SET NOCOUNT ON;
		INSERT INTO [dbo].[Bas_empFile]
				   ([empCode]
				   ,[empName]
				   ,[Sex]
				   ,[Nation]
				   ,[Marrage]
				   ,[JG]
				   ,[ID]
				   ,[Birthday]
				   ,[CellPhone]
				   ,[Hobbies]
				   ,[Advantage]
				   ,[SOSContact]
				   ,[SOSPhone]
				   ,[HomeAddress]
				   ,[HomePhone]
				   ,[School]
				   ,[Degree]
				   ,[Major]
				   ,[RelatedCrd]
				   ,[Area]
				   ,[Responsible]
				   ,[Bkp]
				   ,[Lvl]
				   ,[ShiftChange]
				   ,[Position]
				   ,[NTID] 
				   ,[SAPID] 
				   ,[ShoeSize] 
				   ,[ShoeReleasedDate] 
				   ,[MailBox] 
				   ,[Access] 
				   ,[Rmk]
				   ,[AddWho]
				   ,[AddTime]
				   ,[JoinDate])
			 VALUES(@empCode
				   ,@empName
				   ,@Sex 
				   ,@Nation 
				   ,@Marrage 
				   ,@JG 
				   ,@ID 
				   ,@Birthday 
				   ,@CellPhone 
				   ,@Hobbies 
				   ,@Advantage 
				   ,@SOSContact 
				   ,@SOSPhone 
				   ,@HomeAddress 
				   ,@HomePhone 
				   ,@School 
				   ,@Degree 
				   ,@Major 
				   ,@RelatedCrd 
				   ,@Area 
				   ,@Responsible 
				   ,@Bkp
				   ,@Lvl 
				   ,@ShiftChange
				   ,@Position 
				   ,@NTID
				   ,@SapID
				   ,@ShoeSize
				   ,@ShoeReleasedDate
				   ,@MailBox
				   ,@Access 
				   ,@Rmk 
				   ,@AddWho 
				   ,@AddTime
				   ,@JoinDate)


END
GO
