-- =============================================
-- Author:		Hanson
-- Create date: 2015.4.29
-- Description:	Add a pkl file
-- =============================================
CREATE PROCEDURE [dbo].[SP_FG_AddNewPKL]
	-- Add the parameters for the stored procedure here

	@SRid bigint
	,@DocName nchar(30)
	,@FilePath nchar(300)
	,@AddBy nchar(13)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	Declare @SRStatus nchar(3),@OrderStatus nchar(3),@ErrMsg varchar(300),@Rcnt int,@SPStatus nchar(3),@LineID int
	set @Rcnt = (Select count(*) from [dbo].[TB_FG_MP_Details] where [SRid] = @SRid )
	set @LineID = (Select count(*) from [dbo].[TB_FG_PKL_Details] where [SRid] = @SRid ) + 1
	--if @Rcnt <> 0 begin
	--set @ErrMsg = 'This pulllist is already exsit.（拣货单已经存在，不允许重复下单。）'
	--		raiserror (@ErrMsg,16,1)
	--		return
	--end

	set @OrderStatus = (Select SR_OrderStatus  from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
		if @OrderStatus <> '200' begin
			set @ErrMsg = 'Process denied since SR Order status is not [Open]. （由于SR订单状态未开启，拒绝进行下一步操作。）'
			raiserror (@ErrMsg,16,1)
			return
		end

	set @SRStatus = (Select [SR_Status] from [dbo].[TB_FG_SR_Header] where [SRid] = @SRid)
	if @SRStatus <> '901' begin
		set @ErrMsg = 'Process denied since this SR is not activated. （由于SR订单状态未被激活，拒绝进行下一步操作。）'
		raiserror (@ErrMsg,16,1)
		return
	end

	set @SPStatus = (Select [SR_SP_Status] from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
	if @SPStatus not IN ('906','907') begin
		set @ErrMsg = 'Invalid SR Stauts which SP Status is not [PGI]. (该SR订单状态非等待PGI状态时不允许进行此操作。)'
		raiserror (@ErrMsg,16,1)
		return
	end


	INSERT INTO [dbo].[TB_FG_PKL_Details]
           ([SRid]
           ,[DocName]
		   ,[LineID]
           ,[FilePath]
           ,[AddBy]
           ,[AddTime])
     VALUES
           (@SRid
		   ,@DocName 
		   ,@LineID
		   ,@FilePath 
		   ,@AddBy 
		   ,Getdate())

	if @@ERROR = 0 begin
		update [TB_FG_SR_Header]
		set SR_SP_Status = '907'
		where SRid = @SRid and SR_SP_Status = '906'
	end
END




--CodeGroup	Code	Chinese_DESC	English_DESC	CodeGroup_Desc
--57	9         	900       	创建订单	SRNotActivated	SR_Status
--58	9         	901       	激活订单	SRActivated	SR_Status
--59	9         	902       	未创建拣货单	MPNotCreated	SR_SP_Status
--60	9         	903       	拣货单创建	MPCreated	SR_SP_Status
--61	9         	904       	拣货中	MPPicking	SR_SP_Status
--62	9         	905       	打印唛头中	PrintShippingMark	SR_SP_Status
--63	9         	906       	等待PGI中	PGI NotStarted	SR_SP_Status
--64	9         	907       	扣PGI中	PGI InProgress	SR_SP_Status
--65	9         	908       	待装车	TruckNotLoaded	SR_SP_Status
--66	9         	909       	发货中	TruckLoading	SR_SP_Status
--67	9         	910       	已发货	ShippedOut	SR_SP_Status

--200  open
--201  closed
--202  cancel
--203  hold
--204  activated
GO
