-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2011-02-18>
-- Description:	<Mailling SMT Online Shortage List.>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Alert_SMT_Online_ShortageItems]
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	declare @iRecordCount int 
	Declare @MailAdd nvarchar(100)	
		,@RecList nvarchar(500)	
		,@copy_recipients NVARCHAR(500)	
		,@MailSubj varchar(1000)
		,@BlindCopyList varchar(1000)
		,@AlertName nvarchar(200)
	set @iRecordCount = (select COUNT(distinct OrderID ) as PullCnt 
					from Tb_Order_Details 
					where OrderStatus = 'Open' and PullStatus = 'Close' and CurrentPlace = 'online' and ConditionalFormat = 'InProgress' AND FlagGroup = 'SMT')

	if @iRecordCount = 0 return

	set @AlertName = 'SMTOnlineShortageList'
	set @RecList = ''
	SET @copy_recipients = (Select CopyList from Cfg_DBmail where AlertName = @AlertName)
	set @MailSubj = (Select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList=(Select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	
	DECLARE Mycursor cursor 
	Read_only FOR 
		Select mailaddress
		from epl_sec.dbo.com_member 
		where username in 
			(select distinct createby from dbo.tb_order_details as a
			where a.FlagGroup = 'SMT' and a.orderstatus = 'Open' AND a.Pullstatus = 'Close' and a.currentplace = 'Online' and a.conditionalformat = 'Inprogress')
	
	--打开游标Mycursor
	OPEN Mycursor; 
	FETCH NEXT FROM Mycursor
		INTO @MailAdd	
	WHILE (@@FETCH_STATUS = 0) --       0-FETCH statement was successful.		
		BEGIN
			select @RecList = @RecList + ';'+ isnull(@MailAdd,'') 
			FETCH NEXT  FROM Mycursor 
			INTO @MailAdd
		END		
	--关闭游标
	CLOSE Mycursor
	DEALLOCATE Mycursor		

	Set @RecList =  SUBSTRING(@Reclist,2,len(@reclist)-1) 
	
	--设置HTML表头
	DECLARE @tableHTML  NVARCHAR(MAX) ;
	SET @tableHTML =
		N'<H1>SMT Shortage Material List</H1>' +
		N'<table border="1">' +
		N'<tr><th>OrderID</th><th>WorkCell</th>' +
		N'<th>BuildPlanTime</th><th>CreateBy</th><th>BayNum</th><th>Model</th><th>FinishRate</th><th>Component</th><th>Needqty</th><th>Actualqty</th><th>Diffqty</th></tr>' +
		CAST ( ( SELECT td = OrderID,       '',
						td = WorkCell, '',
						td = BuildPlanTime, '',
						td = CreateBy, '',
						td = BayNum, '',
						td = Model, '',
						td = FinishRate, '',
						td = Component, '',
						td = convert(int,Needqty), '',
						td = convert(int,Actualqty), '',
						td = convert(int,Diffqty), ''
				  from View_SMT_Online_ShortageList   
				  order by createby asc              
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';

	EXEC msdb.dbo.sp_send_dbmail 
		@profile_name ='EpullSqlMail',
		@recipients = @RecList,
		@copy_recipients=@copy_recipients,
		@blind_copy_recipients = @BlindCopyList,
		@subject = @MailSubj ,
		@body = @tableHTML,
    @body_format = 'HTML' ;
    

		
END


GO
