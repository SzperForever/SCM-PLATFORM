-- =============================================
-- Author:		DAILS
-- Create date: 2018-04-18
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_SAP_VA_GRN]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@tableHTML2 nvarchar(max)
			,@tableHTML3 nvarchar(max)		
			,@Msg nvarchar(300)
			,@Rcnt int
			,@Rcnt2 int
			,@Rcnt3 int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
			
	set @AlertName = 'SAP VA GRNGRN Tracebility Syst_0600(ODC)'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	

	
	set @Rcnt = (SELECT count(0) FROM(
			SELECT  
      a.[Sloc] 
      ,CASE WHEN (b.[SLoc])IS NULL THEN 'S' ELSE (b.[SLoc]) END AS GSLoc  
      ,a.[Typ] 
      ,CASE WHEN (b.[StorageType])IS NULL THEN'T' ELSE (b.[StorageType]) END AS GTyp  
      ,a.[StorageBin]
      ,CASE WHEN (b.[StorageBin])IS NULL THEN'B' ELSE (b.[StorageBin]) END AS GStorageBin
      ,a.[Material] 
      ,CASE WHEN (b.[Material])IS NULL THEN'M' ELSE (b.[Material]) END AS GMaterial      
      ,SUM(a.[Available stock]) AS S_QTY     
      ,CASE WHEN (SUM(B.[Quantity])) IS NULL  THEN (0) ELSE SUM(B.[Quantity])END  AS G_QTY         
      ,convert(int,SUM(a.[Available stock]) - CASE WHEN (SUM(B.[Quantity])) IS NULL  THEN (0) ELSE SUM(B.[Quantity])END) AS DiffQty      
      
  FROM (SELECT *
FROM (
  SELECT      
       [Sloc]
      ,[Typ]
      ,[StorageBin]
      ,[Material]
      ,SUM([Available stock]) as [Available stock]
       FROM [EPL_PRD].[dbo].[TB_SAP_INV_WH]
       group by      
      [Sloc]
      ,[Typ]
      ,[StorageBin]
      ,[Material]   ) as  u )  a    Left Join        
(SELECT *
FROM (
SELECT 
      [SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]     
      ,SUM([Quantity]) AS [Quantity]  

  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  where [Active]='1'
  group by [SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]   )  as t)  b
      
     on a.[Material]collate SQL_Latin1_General_CP1_CI_AS = b.[Material]
        and a.[Sloc]collate SQL_Latin1_General_CP1_CI_AS = b.[SLoc]
        and a.[Typ]collate SQL_Latin1_General_CP1_CI_AS = b.[StorageType]
        and a.[StorageBin]collate SQL_Latin1_General_CP1_CI_AS =b.[StorageBin]
  WHERE a.[Sloc]='0600'  collate SQL_Latin1_General_CP1_CI_AS
        and a.[StorageBin] like '%ODC%'  collate SQL_Latin1_General_CP1_CI_AS         
  GROUP BY a.[Material]
      ,a.[Sloc]
      ,a.[Typ] 
      ,a.[StorageBin]
      ,b.[SLoc] 
      ,b.[StorageType]
      ,b.[StorageBin]
      ,b.[Material] 
      ) as t
     where DiffQty <>  '0' )
     
     
     
     
	set @Rcnt2 = 
		(SELECT count(0) 
FROM(
SELECT  
       a.[Sloc] 
      ,b.[SLoc] as GSLoc
      ,a.[Typ] 
      ,b.[StorageType]AS GTyp
      ,a.[StorageBin]
      ,b.[StorageBin]AS GStorageBin
      ,a.[Material] 
      ,b.[Material] AS GMaterial
      ,b.GRN
      ,B.[Quantity] AS G_QTY       
 FROM [EPL_PRD].[dbo].[TB_SAP_INV_WH]as a
     Right  JOIN
[SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]as b      
         on a.[Material]collate SQL_Latin1_General_CP1_CI_AS = b.[Material]
        and a.[Sloc]collate SQL_Latin1_General_CP1_CI_AS = b.[SLoc]
        and a.[Typ]collate SQL_Latin1_General_CP1_CI_AS = b.[StorageType]
        and a.[StorageBin]collate SQL_Latin1_General_CP1_CI_AS =b.[StorageBin]
       where b.Active='1'and b.[SLoc]='0600'   ) as t
     where [Material]IS NULL  )
     	
	
	set @Rcnt3 = 	 
	(SELECT count(0) 
FROM(
SELECT [Plant]
      ,[SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]
      ,[MaterialGroup]      
      ,[GRN]
      ,[Quantity]
      ,[UnitPrice]
      ,[UnitPrice]*[Quantity] AS TotalPrice
      --,[SLED]
      ,CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END  AS U_SLED
      ,DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )as Non_Expired
      ,[DateCode]
      ,[CreatedBy]
      ,[CreatedDate]  
  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1'and [SLoc]='0600'
  )AS A
		WHERE Non_Expired  > '1' )
		

     
     
     
     
	
    set @tableHTML3 = ''	
    set @tableHTML2 = ''	
	SET @tableHTML =
	    N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
		N'<H1> 0600   SAP VS GRN Differenc </H1>' +
		N'<table border="1">' +
		N'<font color=#FF0000><H1> 下面是SAP与GRN Tracebility System的数量差异(0600-ODC-BIN)</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[Sloc]</th><th>GSLoc</th><th>[Typ]</th><th>GTyp</th><th>[StorageBin]</th><th>GStorageBin</th><th>[Material]</th><th>GMaterial</th>' +
		N'<th>S_QTY</th><th>G_QTY</th><th>DiffQty</th></tr>' +
		CAST ( ( SELECT
		                 td = [Sloc],'',
						 td = GSLoc,'',
						 td = [Typ],'',
                         td = GTyp,'',
                         td = [StorageBin],'',
                         td = GStorageBin,'',
                         td = [Material],'',
                         td = GMaterial,'',
                         td = convert(int,S_QTY),'',
                         td = convert(int,G_QTY),'',
                         td = convert(int,DiffQty),''
FROM(
SELECT  
      a.[Sloc] 
      ,CASE WHEN (b.[SLoc])IS NULL THEN 'S' ELSE (b.[SLoc]) END AS GSLoc  
      ,a.[Typ] 
      ,CASE WHEN (b.[StorageType])IS NULL THEN'T' ELSE (b.[StorageType]) END AS GTyp  
      ,a.[StorageBin]
      ,CASE WHEN (b.[StorageBin])IS NULL THEN'B' ELSE (b.[StorageBin]) END AS GStorageBin
      ,a.[Material] 
      ,CASE WHEN (b.[Material])IS NULL THEN'M' ELSE (b.[Material]) END AS GMaterial      
      ,SUM(a.[Available stock]) AS S_QTY     
      ,CASE WHEN (SUM(B.[Quantity])) IS NULL  THEN (0) ELSE SUM(B.[Quantity])END  AS G_QTY         
      ,convert(int,SUM(a.[Available stock]) - CASE WHEN (SUM(B.[Quantity])) IS NULL  THEN (0) ELSE SUM(B.[Quantity])END) AS DiffQty      
      
  FROM (SELECT *
FROM (
  SELECT      
       [Sloc]
      ,[Typ]
      ,[StorageBin]
      ,[Material]
      ,SUM([Available stock]) as [Available stock]
       FROM [EPL_PRD].[dbo].[TB_SAP_INV_WH]
       group by      
      [Sloc]
      ,[Typ]
      ,[StorageBin]
      ,[Material]   ) as  u )  a    Left Join        
(SELECT *
FROM (
SELECT 
      [SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]     
      ,SUM([Quantity]) AS [Quantity]  

  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  where [Active]='1'
  group by [SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]   )  as t)  b
      
     on a.[Material]collate SQL_Latin1_General_CP1_CI_AS = b.[Material]
        and a.[Sloc]collate SQL_Latin1_General_CP1_CI_AS = b.[SLoc]
        and a.[Typ]collate SQL_Latin1_General_CP1_CI_AS = b.[StorageType]
        and a.[StorageBin]collate SQL_Latin1_General_CP1_CI_AS =b.[StorageBin]
  WHERE a.[Sloc]='0600'  collate SQL_Latin1_General_CP1_CI_AS
        and a.[StorageBin] like '%ODC%'  collate SQL_Latin1_General_CP1_CI_AS         
  GROUP BY a.[Material]
      ,a.[Sloc]
      ,a.[Typ] 
      ,a.[StorageBin]
      ,b.[SLoc] 
      ,b.[StorageType]
      ,b.[StorageBin]
      ,b.[Material] 
      ) as t
     where DiffQty <>  '0' 
     --AND G_QTY <>'0'
     order by [StorageBin]              
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' 
		

				
set @tableHTML2 = 
		N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
     	N'<font color=#FF0000><H1> 下面是GRN Tracebility System有库存的差异</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>GSLoc</th><th>GTyp</th><th>GMaterial</th><th>GRN</th><th>G_QTY</th><th>GStorageBin</th><th>CreatedDate</th></tr>' +
		CAST ( (SELECT
                         td = GSLoc,'',
                         td = GTyp,'',
                         td = GMaterial,'',
                         td = GRN,'',
                         td = convert(int,G_QTY) ,'',
                         td = GStorageBin ,'',
                         td = CreatedDate,''
FROM(
SELECT  
       a.[Sloc] 
      ,b.[SLoc] as GSLoc
      ,a.[Typ] 
      ,b.[StorageType]AS GTyp
      ,a.[StorageBin]
      ,b.[StorageBin]AS GStorageBin
      ,a.[Material] 
      ,b.[Material] AS GMaterial
      ,b.GRN
      ,B.[Quantity] AS G_QTY 
      ,B.[CreatedDate]       
 FROM [EPL_PRD].[dbo].[TB_SAP_INV_WH]as a
     Right  JOIN
[SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]as b      
         on a.[Material]collate SQL_Latin1_General_CP1_CI_AS = b.[Material]
        and a.[Sloc]collate SQL_Latin1_General_CP1_CI_AS = b.[SLoc]
        and a.[Typ]collate SQL_Latin1_General_CP1_CI_AS = b.[StorageType]
        and a.[StorageBin]collate SQL_Latin1_General_CP1_CI_AS =b.[StorageBin]
       where b.Active='1'and b.[Sloc]='0600'   ) as t
     where [Material]IS NULL
     order by GStorageBin             
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
		N'</table>'     
set @tableHTML3 = 
		N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
		N'<font color=#FF0000><H1> 下面是GRN Tracebility System库存没有过期的物料</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[SLoc]</th><th>[StorageType]</th><th>[Material]</th><th>GRN</th><th>G_QTY</th><th>GStorageBin</th><th>U_SLED</th><th>Non_Expired</th><th>[CreatedDate]</th></tr>' +
		
	CAST ( (	SELECT 
		  td = [SLoc],'',
          td = [StorageType],'',
          td = [Material],'',
          td = [GRN],'',
          td = convert(int,[Quantity]) ,'',
          td = [StorageBin] ,'',	
          td = U_SLED,'',
          td = Non_Expired,'',
          td = [CreatedDate],''	
		
FROM(
SELECT [Plant]
      ,[SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]
      ,[MaterialGroup]      
      ,[GRN]
      ,[Quantity]
      ,[UnitPrice]
      ,[UnitPrice]*[Quantity] AS TotalPrice
      --,[SLED]
      ,CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END  AS U_SLED
      ,DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )as Non_Expired
      ,[DateCode]
      ,[CreatedBy]
      ,[CreatedDate]  
  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1' and [SLoc]='0600'
  )AS A
		WHERE Non_Expired  > '1' 
		order by [StorageBin],Non_Expired
				FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>'+
    
		'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';
    if @Rcnt =0 and @Rcnt2 =0 and @Rcnt3 =0 return

	if @Rcnt > 0 and @Rcnt2 = 0 and @Rcnt3 = 0  begin
		set @tableHTML=@tableHTML
	end	
	if @Rcnt > 0 and @Rcnt2 > 0 and @Rcnt3 = 0  begin
		set @tableHTML=@tableHTML+ @tableHTML2
	end	
	if @Rcnt > 0 and @Rcnt2 = 0 and @Rcnt3 > 0  begin
		set @tableHTML=@tableHTML+ @tableHTML3
	end	
	if @Rcnt = 0 and @Rcnt2 > 0 and @Rcnt3 = 0  begin
		set @tableHTML=@tableHTML2
	end
	if @Rcnt = 0 and @Rcnt2 > 0 and @Rcnt3 > 0  begin
		set @tableHTML=@tableHTML2+@tableHTML3
	end
	if @Rcnt = 0 and @Rcnt2 = 0 and @Rcnt3 > 0  begin
		set @tableHTML=@tableHTML3
	end	
	if @Rcnt > 0 and @Rcnt2 > 0 and @Rcnt3 > 0  begin
		set @tableHTML=@tableHTML + @tableHTML2 + @tableHTML3
	end
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END

GO
