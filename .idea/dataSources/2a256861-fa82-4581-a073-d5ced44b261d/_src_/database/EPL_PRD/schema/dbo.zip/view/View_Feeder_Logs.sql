CREATE VIEW dbo.View_Feeder_Logs
AS
SELECT     a.OrderID, b.PlanBuildTime, b.Workcell, b.BayNum, b.ModelName, b.Sets, a.Step, b.Rev, a.Op_Text, a.SlotCnt, a.OccuredTime, a.HostName, a.NTId, a.UserID, 
                      C.UserName, a.Remark
FROM         dbo.Tb_Feeder_Logs AS a INNER JOIN
                      dbo.TB_Feeder_Setup_History AS b ON a.OrderID = b.OrderID INNER JOIN
                      EPL_SEC.dbo.COM_Member AS C ON a.UserID = C.UserID
GROUP BY a.OrderID, b.PlanBuildTime, b.Workcell, b.BayNum, b.ModelName, b.Sets, a.Step, b.Rev, a.Op_Text, a.SlotCnt, a.OccuredTime, a.HostName, a.NTId, a.UserID, 
                      a.Remark, C.UserName
GO
