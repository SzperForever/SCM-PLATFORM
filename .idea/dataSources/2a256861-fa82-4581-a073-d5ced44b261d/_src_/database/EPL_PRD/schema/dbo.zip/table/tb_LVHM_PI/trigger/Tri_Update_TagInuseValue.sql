CREATE TRIGGER [dbo].[Tri_Update_TagInuseValue]
   ON  [dbo].[tb_LVHM_PI]
   AFTER insert
AS 
BEGIN

	SET NOCOUNT ON;
	declare @TagNo varchar(7),
			@Errmsg varchar(100),
			@TagFlag varchar(10),
			@PIYear varchar(4)
	set @TagNo = (select tagno from inserted)
	set @TagFlag =(select TagFlag from inserted)
	set @PIYear = (select year(getdate()))		
	if @tagflag='1'
		begin
			if exists(select tagno from Bas_PI_Tag where tagno = @tagno)
				begin
					update dbo.Bas_PI_Tag set inuse = 'Y' where tagno = @tagno and PIYear = @PIYear
				end
			else
				begin
						rollback tran
						set @Errmsg = '盘点票号不存在！操作失败！'
						raiserror(@ErrMsg,16,1)	
				end
		end
END
GO
