-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
Create PROCEDURE [dbo].[SP_Var_AddNew]
	-- Add the parameters for the stored procedure here

	@PN Nchar(30),
	@qty float,
	@Bin nchar(15),
	@AddBy nchar(13)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	Declare @ErrMsg varchar(300)

	INSERT INTO [dbo].[Tb_VarRecord]
           ([PN]
           ,[Qty]
           ,[BinLoc]
           ,[AddBy]
           ,[AddTime]
           ,[Status]
           ,[ClosedBy]
           ,[ClosedTime]
           ,[Reason]
           ,[Remark])
     VALUEs( @PN,
			@qty,
			@Bin ,
			@AddBy ,
			GETDATE(),
			'Open',
			'',
			'',
			'',
			'')

	if @@ERROR <> 0 begin
			set @ErrMsg = 'Insert failed. Error occured.'	
			raiserror (@ErrMsg,16,1)
			return
	end 

END

GO
