CREATE PROCEDURE [dbo].[sp_Figure_RemainingQty] 

		@BU varchar(10),
		@Material varchar(20),
		@Sloc varchar(4),
		@Assy# varchar(50),
		@PlanQty int,
		@BuildDate date,
		@RequrieQty int,
		
		@AvailableQty numeric(18, 3) output,
		@UpdateOnlineInventory numeric(18, 3) output,		
		@RemaingQty numeric(18, 3) output,
		@OnlineInventory numeric(18,3) output,
		@ExcessQty numeric(18,3) output,
		@ErrCode int output,
		@UP2H numeric(18,3) output
		
AS
BEGIN
	set nocount on	
	declare @Errmsg varchar(255)
	set @ErrCode = 0		
	
	if not EXISTS(select [Component P/N] from dbo.Sup_BOM where [Parent P/N] = @Assy# and [Component P/N] = @material)
		begin
			set @Errmsg = '提供的料号:' + @material + ',在BOM中Model列表：' + @Assy# + '中不存在。'
			raiserror(@ErrMsg,16,1)	
		end
	else begin	

		--执行下面代码需要前台程序完成重新计算sup_excessinventory列表。
		select @OnlineInventory =(select onlineinventory from Sup_ExcessInventory where Material = @Material and [Build Date] = @BuildDate
									and BU=@BU and sloc = @Sloc and Assy# =@Assy# and [Plan Qty]= @PlanQty )
		
		select @ExcessQty =(select ExcessQty  from Sup_ExcessInventory where Material = @Material and [Build Date] = @BuildDate
									and BU=@BU and sloc = @Sloc and Assy# =@Assy# and [Plan Qty]= @PlanQty )
		
		select @RemaingQty =(select RemaingQty  from Sup_ExcessInventory where Material = @Material and [Build Date] = @BuildDate
									and BU=@BU and sloc = @Sloc and Assy# =@Assy# and [Plan Qty]= @PlanQty )
		
		select @UP2H	=(select UP2H  from Sup_ExcessInventory where Material = @Material and [Build Date] = @BuildDate
									and BU=@BU and sloc = @Sloc and Assy# =@Assy# and [Plan Qty]= @PlanQty )		
		
		if not EXISTS(select [UPH*2(material)] from dbo.Sup_Bas_UPH  where [Component P/N] = @material and [Parent P/N] =@Assy# )
			begin
				set @Errmsg = '提供的料号:' + @material + ',[UPH*2(material)]没有正确维护。请联系IA重新维护此料的UPH.'
				raiserror(@ErrMsg,16,1)	
			end	
		if @RemaingQty >=0 --线上库存已足够，不允许领用。
			begin
				select @AvailableQty = 0
				set @ErrCode = 1				
			end
		else begin
				IF @UP2H = 0 
					BEGIN
						set @ErrCode = 0
						set @Errmsg = 'MFG UP2H 设置为0，不允许领用。'
						raiserror(@ErrMsg,16,1)	
					END
					
				if @RequrieQty > @UP2H --大于UP2H,尝试多领。
					begin
						set @ErrCode = 2
						select @AvailableQty = @UP2H
						--传ERRCODE变量给前台程序，用IF条件限定分支条件执行
					end
				else if @RequrieQty <= @UP2H --小于等于UP2H,属于正常情况，在可控范围以内，可以领。
					begin
						set @ErrCode = 3
						select @AvailableQty = @RequrieQty
					end
			end			
		--select @UpdateOnlineInventory = @AvailableQty +@OnlineInventory 
		select @UpdateOnlineInventory = @OnlineInventory 
	end 
END


GO
