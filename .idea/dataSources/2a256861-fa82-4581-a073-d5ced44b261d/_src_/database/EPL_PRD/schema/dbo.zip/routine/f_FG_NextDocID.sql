
CREATE FUNCTION [dbo].[f_FG_NextDocID]()
RETURNS char(12)
AS
BEGIN
    DECLARE @dt CHAR(6)
    SELECT @dt=dt FROM v_GetDate
    RETURN(
        SELECT '9K' + @dt+RIGHT(10001+ISNULL(RIGHT(MAX(DocNo),4),0),4) 
        FROM TB_BFscan  WITH(XLOCK,PAGLOCK)
        WHERE DocNo  like '9K' + @dt+'%')
END

GO
