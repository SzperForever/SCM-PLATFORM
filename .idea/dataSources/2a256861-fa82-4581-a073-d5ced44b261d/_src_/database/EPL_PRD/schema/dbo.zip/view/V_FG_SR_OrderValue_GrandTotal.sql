CREATE VIEW dbo.V_FG_SR_OrderValue_GrandTotal
AS
SELECT [Project]
      ,[Amount_NotStarted]
      ,[SRCount_NotStarted]
      ,[PartCount_NotStarted]
      ,[Amount_InProgress]
      ,[SRCount_InProgress]
      ,[PartCount_InProgress]
      ,[Amount_Completed]
      ,[SRCount_Completed]
      ,[PartCount_Completed]
FROM  [dbo].[V_FG_SR_OrderValuePerStatus] AS v union 
(select 'zGrandTotal',
			 CONVERT(money, ISNULL
                             ((SELECT        SUM(Amount) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE       (SP_Status IN ('MPCreated', 'MPNotCreated', 'MPPicking'))), 0)) AS Amount_NotStarted, ISNULL
                             ((SELECT        SUM(OrderCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE       (SP_Status IN ('MPCreated', 'MPNotCreated', 'MPPicking'))), 0) AS SRCount_NotStarted, ISNULL
                             ((SELECT        SUM(PartCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE       (SP_Status IN ('MPCreated', 'MPNotCreated', 'MPPicking'))), 0) AS PartCount_NotStarted, CONVERT(money, ISNULL
                             ((SELECT        SUM(Amount) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE       (SP_Status IN ('PrintShippingMark'))), 0)) AS Amount_InProgress, ISNULL
                             ((SELECT        SUM(OrderCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE       (SP_Status IN ('PrintShippingMark'))), 0) AS SRCount_InProgress, ISNULL
                             ((SELECT        SUM(PartCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE       (SP_Status IN ('PrintShippingMark'))), 0) AS PartCount_InProgress, CONVERT(money, ISNULL
                             ((SELECT        SUM(Amount) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE       (SP_Status IN ('TruckNotLoaded', 'Packing'))), 0)) AS Amount_Completed, ISNULL
                             ((SELECT        SUM(OrderCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE       (SP_Status IN ('TruckNotLoaded', 'Packing'))), 0) AS SRCount_Completed, ISNULL
                             ((SELECT        SUM(PartCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE       (SP_Status IN ('TruckNotLoaded', 'Packing'))), 0) AS PartCount_Completed)
GO
