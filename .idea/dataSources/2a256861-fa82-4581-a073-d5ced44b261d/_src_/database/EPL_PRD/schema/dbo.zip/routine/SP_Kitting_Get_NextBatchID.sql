

Create  PROCEDURE [dbo].[SP_Kitting_Get_NextBatchID] 
	@BatchID varchar(13) output
AS
	begin
	
		SET @BatchID = NULL
		SET @BatchID = (SELECT DBO.f_Kitting_NextBatchID())				
	
	RETURN
     
	end

GO
