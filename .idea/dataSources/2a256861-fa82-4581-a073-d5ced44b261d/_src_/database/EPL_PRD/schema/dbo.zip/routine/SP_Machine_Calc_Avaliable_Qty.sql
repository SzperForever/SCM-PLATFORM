-- =============================================
-- Author:		<Hanson>
-- Create date: <2013-10-31>
-- Description:	<Fulfill the shortages on Top side from the availbale qty on Bottom side.>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Machine_Calc_Avaliable_Qty]
	-- Add the parameters for the stored procedure here
	@OrderID NVARCHAR(12)
	,@fsPartNum nvarchar(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    if @fsPartNum = '' begin
		select OrderID,fsPartNum ,fsSetPos ,Step,DiffQty AS T_ShortageQty
		,[B_Slot_Map] = STUFF((select ',' + rtrim([b_sloc])
						from View_Machine_Step_Exchange as g 
						where g.fssetpos = d.fssetpos and g.orderid = d.orderid
					for XML path ('')),1,1,'')
		,[B_Qty_Map]  = STUFF((select ',' + convert(varchar,[b_qty]) 
						from View_Machine_Step_Exchange as g 
						where g.fssetpos = d.fssetpos  and g.orderid = d.orderid
					for XML path ('')),1,1,'')			
		,[B_Sum_Qty] = (select sum(b_qty) 
						from view_machine_step_exchange as g 
						where g.fsPartNum = d.fsPartNum and g.orderid = d.orderid)
		,[Fnl_Rmn_Qty] = (select sum(b_qty) 
						from view_machine_step_exchange as g 
						where g.fsPartNum = d.fsPartNum and g.orderid = d.orderid) - ABS(d.diffqty )
		from View_Machine_Step_Exchange as d
		where orderid = @OrderID 
		group by orderid,fsPartNum ,fsSetPos ,Step,DiffQty
		order by fsSetPos asc
	end
	else begin
		select OrderID,fsPartNum ,fsSetPos ,Step,DiffQty AS T_ShortageQty
		,[B_Slot_Map] = STUFF((select ',' + rtrim([b_sloc])
						from View_Machine_Step_Exchange as g 
						where g.fssetpos = d.fssetpos and g.orderid = d.orderid
					for XML path ('')),1,1,'')
		,[B_Qty_Map]  = STUFF((select ',' + convert(varchar,[b_qty]) 
						from View_Machine_Step_Exchange as g 
						where g.fssetpos = d.fssetpos  and g.orderid = d.orderid
					for XML path ('')),1,1,'')			
		,[B_Sum_Qty] = (select sum(b_qty) 
						from view_machine_step_exchange as g 
						where g.fsPartNum = d.fsPartNum and g.orderid = d.orderid)
		,[Fnl_Rmn_Qty] = (select sum(b_qty) 
						from view_machine_step_exchange as g 
						where g.fsPartNum = d.fsPartNum and g.orderid = d.orderid) - ABS(d.diffqty )
		from View_Machine_Step_Exchange as d
		where orderid = @OrderID and fspartnum = @fsPartNum 
		group by orderid,fsPartNum ,fsSetPos ,Step,DiffQty
		order by fsSetPos asc
	end
END
GO
