-- =============================================
-- Author:		<Hanson Zhang)
-- Create date: <2014/6/20>
-- Description:	<Rules to check the upload item >
-- =============================================
CREATE PROCEDURE [dbo].[SP_SMT_Order_Check_Upload_Rules]
	-- Add the parameters for the stored procedure here
		 @WorkCell varchar(20),
		 @MAText varchar(20),
		 @Model nchar(80),
		 @Rev nchar(20),
		 @Sloc nchar(10),
		 @PullListNo nchar(13),
		 @Sets int,
		 @BuildPlanTime datetime,
		 @MinLt varchar(10),
		 @ReturnCode  varchar(1000) output ,
		 @BreakRuleID int output,
		 @ErrCode int output
AS BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


--上传料单规则	                                         ID命名
--Normal	 N/A	 检查sap&Machine bom	         标准（时间+Sloc）
--BayNum	 BAY 2B	 检查sap         	             标准（时间+Sloc）
--WorkCell	 包含-AI	 检查sap	                 计数
--WorkCell	 SCHNEIDER-AI	 检查sap&Machine bom	 标准（时间+Sloc）
--WorkCell	 包含-CN07	 检查Machine bom	         标准（时间+Sloc）

	DECLARE @PLVBomModelname varchar(30),
			@rowcount1 int,
			@rowcount2 int,
			@rowcount3 int,
			@RuleCode int,
			@ProjectName varchar(20),
			@IsSlocClear int
		

		
		If Upper(RIGHT(rtrim(@workcell),3))= '-AI'  --or UPPER(RTRIM(@MAText)) = 'BAY 2B' 
			begin
				Set @RuleCode = 1 --只检查 SAP BOM
			end
		ELSE IF Upper(RIGHT(rtrim(@workcell),4))=  'CN07'
			BEGIN
				Set @RuleCode = 2 --只检查 MACHINE BOM
			END
		ELSE BEGIN
			Set @RuleCode = 3 --检查 SAP & MACHINE BOM
			set @IsSlocClear = (Select COUNT(*) from TB_SAP_INV_FINAL where Sloc = @Sloc )
		END
		
		set @BreakRuleID = 0 
		SET @ProjectName= @workcell
		
		if @RuleCode = 1 or @RuleCode = 3 goto Chk_SAP_BOM
		if @RuleCode = 2 goto Chk_Machine_BOM
		
Chk_SAP_BOM:
        IF Upper(RIGHT(rtrim(@workcell),3))= '-AI' BEGIN
			SET @workcell = LEFT(RTRIM(@WORKCELL),LEN(RTRIM(@WORKCELL))-3)
		END
		Set @rowcount2 = (select COUNT(*) from Bas_SAPbom where [Assembly Name] = @model and [Material Group] = @workcell )
		IF @rowcount2 = 0 
			BEGIN
				set @ErrCode = 2
				set @BreakRuleID= 2
				set @ReturnCode = 'No records return from BAS_SAPBOM base on the information you provided. Assembly Name:'  + @model + ',Workcell:' + @WorkCell 
				RAISERROR (@ReturnCode, 16, 1)
				return				
			END
		if @RuleCode = 1 goto CommonRules --针对RULECODE1的规则，跳过检查MACHINEBOM,反之正常检查MACHINEBOM
		
Chk_Machine_BOM:
		Set @rowcount1 = (Select count(PLVBomModelname) from bas_bomlink where sapbommodelname = @model)
		if @rowcount1 = 0 
			begin
						Set @ErrCode = 20
						set @BreakRuleID= 20
						set @ReturnCode = 'Check with BOM Link Profile please.'
						RAISERROR (@ReturnCode, 16, 1)
						return
			end
		Set @PLVBomModelname = (Select PLVBomModelname from bas_bomlink where sapbommodelname = @model)
		
		--if RTRIM(UPPER(@MATEXT)) <> 'BAY 2B'  begin
			set @rowcount3 = (Select count(*) from bas_machine_feeder_report where Number = @PLVBomModelname and MAText = @MAText and Rev = @Rev)
				if @rowcount3 =0 
					begin
						Set @ErrCode = 10
						set @BreakRuleID= 10
						set @ReturnCode = 'No records return from the [BAS_Machine_feeder_report] for this information: Model(' + RTRIM(@PLVBomModelname) + '),MAText:( ' + RTRIM(@matext) + '),Rev:('+ RTRIM(@Rev) + ').Check with MachineBom is needed.'
						RAISERROR (@ReturnCode, 16, 1)
						return
					end			
			--end			

CommonRules:
		if @IsSlocClear > 0 begin
			set @ReturnCode = 'This SAP sloc is not empty. Before use this sloc again you need ensure that you have cleaned the sloc in SAP. A Gap might be exsit since system need an hour to sync with SAP system.' 
			RAISERROR (@ReturnCode, 16, 1)
			return
		end 
		
		if Upper(rtrim(@ProjectName)) = 'SCHNEIDER-AI' or Upper(rtrim(@ProjectName)) = 'CAREFUS-AI' OR Upper(RIGHT(rtrim(@ProjectName),3)) <> '-AI'  begin
			Set @rowcount1 = (Select count(Sloc) from Tb_Order_Details where OrderStatus = 'Open' and Sloc = @Sloc and OrderType = 'AutoPull')
			if @rowcount1 > 0
				begin
					set @ErrCode = 1
					set @BreakRuleID= 1
					set @ReturnCode = 'This Sloc is still in use. You may try to assign another sloc which is available for use. Incorrect Sloc:'  + @Sloc 
					RAISERROR (@ReturnCode, 16, 1)
					return
				end
		end

		set @rowcount3 = (Select count(DISTINCT REV) from bas_machine_feeder_report where Number = @PLVBomModelname and MAText = @MAText)
		if @rowcount3 >1 
			begin
				Set @ErrCode = 99
				set @BreakRuleID= 99
				set @ReturnCode = 'There are several revisions available for this model and baynum detected. Model(' + RTRIM(@PLVBomModelname) + '),MAText:( ' + RTRIM(@matext) + ').Please double confirm and ensure the rev value:' + RTRIM(@Rev) + ' which you typed in your worksheet is the correct one.'
				--RAISERROR (@ReturnCode, 16, 1)
				--return
			end	
					
		if @Model is null or LEN(@model)= 0
			begin
				set @ErrCode = 4
				set @BreakRuleID= 4
				set @ReturnCode = 'Model name is invalid. '
				RAISERROR (@ReturnCode, 16, 1)
				return				
			end
		
		if @MAText is null or LEN(@MAText)= 0
			begin
				set @ErrCode = 5
				set @BreakRuleID= 5
				set @ReturnCode = 'Bay number name is invalid. '
				RAISERROR (@ReturnCode, 16, 1)
				return				
			end
		
		if @PullListNo is null or len(@PullListNo) <> 13 
			begin
				set @ErrCode = 7
				set @BreakRuleID= 7
				set @ReturnCode = 'Pull list number is invalid. '
				RAISERROR (@ReturnCode, 16, 1)
				return				
			end
			
		if @Sets is null  or @Sets = 0
			begin
				set @ErrCode = 8
				set @BreakRuleID= 8
				set @ReturnCode = 'Column:[Sets] is invalid. '
				RAISERROR (@ReturnCode, 16, 1)
				return				
			end
			
		 if LEN(@Sloc) <> 4 or @Sloc is null
			begin
				set @ErrCode = 9
				set @BreakRuleID= 9
				set @ReturnCode = 'Column:[Sloc] is invalid. '
				RAISERROR (@ReturnCode, 16, 1)
				return					
			end
END
GO
