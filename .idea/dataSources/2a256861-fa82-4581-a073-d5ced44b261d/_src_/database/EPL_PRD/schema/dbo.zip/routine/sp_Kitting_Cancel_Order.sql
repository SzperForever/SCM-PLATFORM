

CREATE PROCEDURE [dbo].[sp_Kitting_Cancel_Order]
	@OrderID nvarchar(13)
AS
BEGIN
	SET NOCOUNT ON;

	Update Tb_Kitting_Order_Header set orderstatus = 'CANCEL' where OrderID = @OrderID

END


GO
