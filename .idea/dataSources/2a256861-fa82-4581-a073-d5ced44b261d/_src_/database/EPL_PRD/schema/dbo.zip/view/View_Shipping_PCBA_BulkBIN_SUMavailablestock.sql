
CREATE VIEW [dbo].[View_Shipping_PCBA_BulkBIN_SUMavailablestock]
AS
SELECT     Mtrl_Grp, Material, SUM([Available stock]) AS [Available stock]
FROM         dbo.View_Shipping_PCBA_BulkBIN AS v
GROUP BY Mtrl_Grp, Material

GO
