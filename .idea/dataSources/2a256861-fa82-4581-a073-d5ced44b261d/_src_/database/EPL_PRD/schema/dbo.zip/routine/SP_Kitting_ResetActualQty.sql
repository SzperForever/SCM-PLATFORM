-- =============================================
-- Author:		<HANSON
-- Create date: <2014-11-14>
-- Description:	<Reset Actual Qty>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_ResetActualQty]
	-- Add the parameters for the stored procedure here
	@KittingPartNum nvarchar(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	update [TB_Kitting_BatchList]
	set [IsCalculable] = 0
	where orderid in 
		(select distinct orderid 
			from tb_kitting_order_header with (nolock)
			where kittingpartnum = @KittingPartNum and orderstatus = 'OPEN')
	
	if @@ERROR <> 0 begin
		raiserror ('Unknown error occured. Procee may failed. ',16,1)
		return
	end	
	
	
	
			
END
GO
