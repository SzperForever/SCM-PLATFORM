
CREATE VIEW [dbo].[V_KIT_Closable_Orders]
AS
SELECT        h.OrderID, h.KittingPartNum, h.Kits_Qty, h.FinalQty, SUM(r.Qnty) AS ActualQty, SUM(r.Qnty) - h.FinalQty AS DiffQty
FROM            dbo.TB_KIT_ORDER_HEADER AS h INNER JOIN
                         dbo.TB_KIT_RIPE_HISTORY AS r ON h.OrderID = r.OrderID AND h.KittingPartNum = r.KittingPartNum
WHERE        (h.OrderStatus = 'OPEN') AND (h.ProgressCode = 312)
GROUP BY h.OrderID, h.KittingPartNum, h.Kits_Qty, h.FinalQty

GO
