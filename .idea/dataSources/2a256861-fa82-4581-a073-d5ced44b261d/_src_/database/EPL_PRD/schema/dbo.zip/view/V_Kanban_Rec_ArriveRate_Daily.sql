CREATE VIEW dbo.V_Kanban_Rec_ArriveRate_Daily
AS
SELECT     TOP (15) DocYear, ShortDate_Rec, LongDate_Rec, COUNT(DocNo) AS ClosedDocCnt,
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.TB_RCV_InboundTracking
                            WHERE      (CONVERT(date, AddTime) = v.LongDate_Rec)) AS TotalDocCnt,
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v1
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls12')) AS DocCnt_LS12,
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls24Gt12')) AS DocCnt_LS24,
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v3
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls48Gt24')) AS DocCnt_LS48,
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v4
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Gt48')) AS DocCnt_GT48, CONVERT(DECIMAL(18, 2),
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v1
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls12')) / CAST(ISNULL(NULLIF
                          ((SELECT     COUNT(DocNo) AS Expr1
                              FROM         dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_8
                              WHERE     (CONVERT(date, AddTime) = v.LongDate_Rec)), 0), 1) AS FLOAT) * 100) AS V_LS12, CONVERT(DECIMAL(18, 2),
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls24Gt12')) / CAST(ISNULL(NULLIF
                          ((SELECT     COUNT(DocNo) AS Expr1
                              FROM         dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_7
                              WHERE     (CONVERT(date, AddTime) = v.LongDate_Rec)), 0), 1) AS FLOAT) * 100) AS V_LS24, CONVERT(DECIMAL(18, 2),
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v3
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls48Gt24')) / CAST(ISNULL(NULLIF
                          ((SELECT     COUNT(DocNo) AS Expr1
                              FROM         dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_6
                              WHERE     (CONVERT(date, AddTime) = v.LongDate_Rec)), 0), 1) AS FLOAT) * 100) AS V_LS48, CONVERT(DECIMAL(18, 2),
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v4
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'GT48')) / CAST(ISNULL(NULLIF
                          ((SELECT     COUNT(DocNo) AS Expr1
                              FROM         dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_5
                              WHERE     (CONVERT(date, AddTime) = v.LongDate_Rec)), 0), 1) AS FLOAT) * 100) AS V_GT48, CAST(CONVERT(DECIMAL(18, 2),
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v1
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls12')) / CAST(ISNULL(NULLIF
                          ((SELECT     COUNT(DocNo) AS Expr1
                              FROM         dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_4
                              WHERE     (CONVERT(date, AddTime) = v.LongDate_Rec)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_LS12, CAST(CONVERT(DECIMAL(18, 2),
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls24Gt12')) / CAST(ISNULL(NULLIF
                          ((SELECT     COUNT(DocNo) AS Expr1
                              FROM         dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_3
                              WHERE     (CONVERT(date, AddTime) = v.LongDate_Rec)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_LS24, CAST(CONVERT(DECIMAL(18, 2),
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v3
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Ls48Gt24')) / CAST(ISNULL(NULLIF
                          ((SELECT     COUNT(DocNo) AS Expr1
                              FROM         dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_2
                              WHERE     (CONVERT(date, AddTime) = v.LongDate_Rec)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_LS48, CAST(CONVERT(DECIMAL(18, 2),
                          (SELECT     COUNT(DocNo) AS Expr1
                            FROM          dbo.V_Kanban_Rec_ArriveRate_Source AS v4
                            WHERE      (LongDate_Rec = v.LongDate_Rec) AND (PeriodType = 'Gt48')) / CAST(ISNULL(NULLIF
                          ((SELECT     COUNT(DocNo) AS Expr1
                              FROM         dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_1
                              WHERE     (CONVERT(date, AddTime) = v.LongDate_Rec)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_GT48
FROM         dbo.V_Kanban_Rec_ArriveRate_Source AS v
WHERE     (LongDate_Rec BETWEEN DATEADD(dd, - 10, GETDATE()) AND GETDATE() - 1)
GROUP BY LongDate_Rec, ShortDate_Rec, DocYear
ORDER BY LongDate_Rec DESC
GO
