/*SNCOUNT GROUP BY SNAGEDDAY PER HMPPARTNO*/
CREATE VIEW dbo.View_PCBA_PNSNCountGroupBySNagedDay
AS
SELECT     TOP (100) PERCENT Model,
                          (SELECT     COUNT(DISTINCT SN) AS Expr1
                            FROM          dbo.View_PCBA_Tracker
                            WHERE      (SNagedDay < 7) AND (Model = a.Model)) AS LT7D,
                          (SELECT     COUNT(DISTINCT SN) AS Expr1
                            FROM          dbo.View_PCBA_Tracker AS View_PCBA_Tracker_3
                            WHERE      (SNagedDay >= 7) AND (SNagedDay < 14) AND (Model = a.Model)) AS LT14DO7D,
                          (SELECT     COUNT(DISTINCT SN) AS Expr1
                            FROM          dbo.View_PCBA_Tracker AS View_PCBA_Tracker_2
                            WHERE      (SNagedDay >= 14) AND (SNagedDay < 30) AND (Model = a.Model)) AS LT30DO14D,
                          (SELECT     COUNT(DISTINCT SN) AS Expr1
                            FROM          dbo.View_PCBA_Tracker AS View_PCBA_Tracker_1
                            WHERE      (SNagedDay > 30) AND (Model = a.Model)) AS O30D
FROM         dbo.View_PCBA_Tracker AS a
GROUP BY Model
GO
