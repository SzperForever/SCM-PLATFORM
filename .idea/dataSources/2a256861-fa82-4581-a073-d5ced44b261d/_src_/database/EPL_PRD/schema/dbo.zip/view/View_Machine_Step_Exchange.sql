CREATE VIEW dbo.View_Machine_Step_Exchange
AS
SELECT     c.OrderID, c.fsPartNum, c.fsSetPos, c.Step, c.DiffQty, a.fsSetPos AS B_Sloc, SUM(a.DiffQty) AS B_qty
FROM         dbo.View_Machine_Material_List AS c LEFT OUTER JOIN
                          (SELECT     OrderID, fsPartNum, Number, Step, fsSetPos, Rev, MAText, fsPartQty, Sets, DifRST_M_Cnt, NeedQty, Actualqty, PkgCount, DiffQty, 
                                                   ArrangePos, pkgInfoTapeWidth, SeqBrdNum
                            FROM          dbo.View_Machine_Material_List
                            WHERE      (Step = 'B')) AS a ON c.OrderID = a.OrderID AND c.fsPartNum = a.fsPartNum
WHERE     (c.Step = 'T') AND (c.DiffQty <= 0)
GROUP BY c.OrderID, c.fsPartNum, c.fsSetPos, c.Step, c.DiffQty, a.fsSetPos
GO
