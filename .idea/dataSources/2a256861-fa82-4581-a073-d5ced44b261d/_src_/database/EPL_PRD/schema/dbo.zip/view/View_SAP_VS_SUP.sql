CREATE VIEW dbo.View_SAP_VS_SUP
AS
SELECT     B.Sloc, A.Material AS SUP_PN, B.Material AS SAP_PN, B.StandPrice, ISNULL(A.AvailableQty, 0) AS SUP_QTY, ISNULL(B.Unrestricted, 0) AS SAP_QTY, 
                      ISNULL(A.AvailableQty, 0) - ISNULL(B.Unrestricted, 0) AS VarianceQty, (ISNULL(A.AvailableQty, 0) - ISNULL(B.Unrestricted, 0)) * B.StandPrice AS VarianceValue
FROM         dbo.Sup_Inventory AS A FULL OUTER JOIN
                          (SELECT     Sloc, Material, Mtrl_Grp, Mtrl_Type, StandPrice, Unrestricted, Unrestr_Cnsgt, Stock_In_Tfr, In_Qual_Insp, Cnsgt_Qual_In, Blocked, Blocked_Cnsgt, 
                                                   Total_Value, MRP, Mtrl_Desc, LastUpdateTime
                            FROM          dbo.TB_SAP_INV_FINAL
                            WHERE      (Sloc = '01SM')) AS B ON A.Material = B.Material
GROUP BY B.Sloc, A.Material, B.Material, B.StandPrice, A.AvailableQty, B.Unrestricted
GO
