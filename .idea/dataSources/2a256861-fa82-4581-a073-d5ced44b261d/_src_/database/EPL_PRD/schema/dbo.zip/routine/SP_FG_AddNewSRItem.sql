


CREATE  PROCEDURE [dbo].[SP_FG_AddNewSRItem]

		@SRID INT,
		@PO varchar(40),
		@SO varchar(40),
		@Item int,
		@PartNum varchar(20),			
		@TotalQty float,
		@AddBy nchar(10),
		@UnitNetWeight float = 0.000,
		@IsSucceed bit = 0 output
AS
	begin		
		DECLARE @Proj varchar(35),@rcount int,@SRStatus nchar(3),@OrderStatus  nchar(3) , @SP_Status nchar(3),@ErrMsg varchar(500),@AllowUpdate bit = 0
		
		Select @Proj=Project
				,@SRStatus=SR_Status
				,@OrderStatus=SR_OrderStatus
				,@AllowUpdate=AllowUpdate  
				,@SP_Status=SR_SP_Status 
		from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRID
	
		if @OrderStatus <> '200' begin
			set @ErrMsg = 'SR status is not open.'
			raiserror (@ErrMsg,16,1)
			return
		end

		--在获得特别权限情况下允许特别添加
		if @AllowUpdate = 1 goto JumpHere
		
		if @SRStatus = '901'  begin
			set @ErrMsg = 'This SR is already activated which appendent is not allowed.（SR已激活情况下不允许添加新行。）'
			raiserror (@ErrMsg,16,1)
			return
		end
		
JumpHere:
		SET @rcount= (Select count(*) from [TB_FG_SR_Header] where createby = @AddBy and srid = @srid)
		if @rcount  = 0 begin
			set @ErrMsg = 'Operation is denied since you do not have the right to perform the appendent.(操作被拒绝因为你没有权限添加此行。)'
			raiserror (@ErrMsg,16,1)
			return
		end
		
		if cast(@SP_Status as int) > 907 begin
			set @ErrMsg = 'You are not allowed to perform the appendent at this time.(此时已经不允许更新！)'
			raiserror (@ErrMsg,16,1)
			return		
		end
		if not EXISTS(Select * from dbo.BAS_SKU where Material = @PartNum)-- and [Matlgroup] = @Proj)
			begin
				raiserror('Invalid Partnum. It does not exist. (料号无效不存在!)',16,1)	
			end
		else begin
			
			INSERT INTO [TB_FG_SR_Details]
					   ([SRid]
					   ,[PO]
					   ,[SO]
					   ,[Item]
					   ,[PartNum]
					   ,[TotalQty]
					   ,[Currency]
					   ,[UnitNetWeight]
					   ,AddBy
					   ,AddTime)
				 VALUES(@SRID 
						,@PO
						,@SO
						,@Item 
						,@PartNum 
						,@TotalQty 
						,'USD'
						,@UnitNetWeight
						,@AddBy
						,Getdate())
						
				if @@ERROR = 0 set @IsSucceed = 1 else set @IsSucceed = 0
		end


		--if @@ERROR<> 0 begin
		--	Raiserror ('Error occured.Insert failed',16,1)

		--	end
		--else begin
			--update [TB_FG_SR_Header]
			--set SR_Status = '902'
			--where SRid = @SRID 
		--end

		
end

--CodeGroup	Code	Chinese_DESC	English_DESC	CodeGroup_Desc
--57	9         	900       	创建订单	SRNotActivated	SR_Status
--58	9         	901       	激活订单	SRActivated	SR_Status
--59	9         	902       	未创建拣货单	MPNotCreated	SR_SP_Status
--60	9         	903       	拣货单创建	MPCreated	SR_SP_Status
--61	9         	904       	拣货中	MPPicking	SR_SP_Status
--62	9         	905       	打印唛头中	PrintShippingMark	SR_SP_Status
--63	9         	906       	等待PGI中	PGI NotStarted	SR_SP_Status
--64	9         	907       	扣PGI中	PGI InProgress	SR_SP_Status
--65	9         	908       	待装车	TruckNotLoaded	SR_SP_Status
--66	9         	909       	发货中	TruckLoading	SR_SP_Status
--67	9         	910       	已发货	ShippedOut	SR_SP_Status

--200  open
--201  closed
--202  cancel
--203  hold
--204  activated
GO
