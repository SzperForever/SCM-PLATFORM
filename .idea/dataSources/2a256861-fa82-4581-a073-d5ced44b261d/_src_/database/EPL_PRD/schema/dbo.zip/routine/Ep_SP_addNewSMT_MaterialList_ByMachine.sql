
CREATE PROCEDURE [dbo].[Ep_SP_addNewSMT_MaterialList_ByMachine]

	 @OrderID nchar(12)
	,@PartNo nvarchar(20)
	,@Qty float
	,@GRN nvarchar(18)
	,@Step nvarchar(6)
	,@PreparedBy nchar(10)
	,@Remark nchar(20)
	,@PreparedID nvarchar(15)
	,@WorkCell nvarchar(50)
	,@Model nvarchar(50)
	,@FlagGroup nchar(10)	
	,@Feeder nchar(20)	
	,@PCName nchar(10)
	,@LineNo int  
	,@SLEDInfo nvarchar(200) =''
AS
begin
	Declare @Sloc varchar(4),@MAText varchar(10)
	--检查该FEEDER 待补料的余数,传给@Remainder变量
	  Set @Sloc = (select top 1 Sloc from tb_order_details where OrderID = @OrderID )
	  set @MAText = (select top 1 Baynum from Tb_Order_Details where OrderID = @OrderID )
	--if @Remainder > @Qty and  @AllowOverKit =0 --如果扫描要补料的数量大于KTE需求的余数，并且允许多KIT开关为关，即不允许多配时
	--		begin
	--			raiserror ('This item is not allow over kit. Please kit as the remainder.',16,4)
	--			return
	--		end
	--else
		--begin
			INSERT INTO [dbo].[Tb_PreparedList]
					   ([OrderID]
					   ,[PartNo]
					   ,[Qty]
					   ,[GRN]
					   ,[Step]
					   ,[ScanTime]
					   ,[PreparedBy]
					   ,[Remark]
					   ,[PreparedID]
					   ,[WorkCell]
					   ,[Model]
					   ,[CheckFlag]
					   ,[FlagGroup]
					   ,[Feeder]
					   ,[HostName]
					   ,[RuleFlag]
					   ,[Line_No]
					   ,[Sloc]
					   ,[BayNum]
					   ,[SLEDInfo])
				 VALUES
					(@OrderID,@PartNo,@Qty,@GRN,@Step,GETDATE(),@PreparedBy,@Remark,@PreparedID,@WorkCell,@Model,'N',@FlagGroup,@Feeder,@PCName,'1',@LineNo,@Sloc,@MAText,@SLEDInfo )
 		--end 
	end
GO
