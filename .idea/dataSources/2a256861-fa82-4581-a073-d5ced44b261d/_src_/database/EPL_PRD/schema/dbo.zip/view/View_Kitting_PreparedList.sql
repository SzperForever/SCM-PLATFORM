
CREATE VIEW [dbo].[View_Kitting_PreparedList]
AS
SELECT     TOP (100) PERCENT a.OrderID AS BatchID, a.PartNo AS KittingPartNum, a.Qty, a.GRN, a.PreparedBy AS AddBy, a.ScanTime
FROM         dbo.Tb_PreparedList AS a with (nolock)  INNER JOIN
                      dbo.View_Kitting_Order_Headers AS b with (nolock)  ON a.PartNo = b.KittingPartNum
WHERE     (a.FlagGroup = 'Kitting') AND (a.PreparedID = 'KOM')
GROUP BY a.OrderID, a.PartNo, a.Qty, a.GRN, a.PreparedBy, a.ScanTime
ORDER BY BatchID

GO
