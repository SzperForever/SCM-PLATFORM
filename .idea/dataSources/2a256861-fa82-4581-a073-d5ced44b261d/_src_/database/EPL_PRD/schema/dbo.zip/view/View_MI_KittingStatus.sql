CREATE VIEW dbo.View_MI_KittingStatus
AS
SELECT     TOP (100) PERCENT c.CageBin, c.OrderID, c.WorkCell, c.Model, c.BayNum, c.Sloc, c.BuildPlanTime, c.CreateBy, a.PartNum, a.QtyPer, c.Sets, 
                      c.OrderStatus, c.Sets * a.QtyPer AS NeedQty,
                          (SELECT     ISNULL(SUM(Qty), 0) AS Actualqty
                            FROM          dbo.Tb_PreparedList AS h
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.PartNum) AND (FlagGroup = 'MI')) AS Actualqty,
                          (SELECT     ISNULL(SUM(Qty), 0) AS Expr1
                            FROM          dbo.Tb_PreparedList AS h
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.PartNum) AND (FlagGroup = 'MI')) - c.Sets * a.QtyPer AS DiffQty,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Tb_PreparedList AS g
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.PartNum)) AS PkgCount, c.FinishRate
FROM         dbo.Bas_Bom AS a LEFT OUTER JOIN
                      dbo.Tb_Order_Details AS c ON c.Model = a.Model LEFT OUTER JOIN
                      dbo.Tb_PreparedList AS b ON a.Model = b.Model AND a.PartNum = b.PartNo AND b.OrderID = c.OrderID AND c.FlagGroup = a.FlagGroup
WHERE     (c.OrderStatus <> 'Cance') AND (c.FlagGroup = 'MI') AND (c.OrderID IS NOT NULL) AND (c.OrderStatus = 'Open')
GROUP BY c.CageBin, c.OrderID, c.WorkCell, c.Model, c.BayNum, c.Sloc, c.BuildPlanTime, c.CreateBy, a.PartNum, a.QtyPer, c.Sets, c.FinishRate, 
                      c.OrderStatus
ORDER BY a.PartNum
GO
