
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_KIT_INSPECTION_PASS]
	-- Add the parameters for the stored procedure here
	
	@ORDERID VARCHAR(13),
	@TestStep int, --1(FI), 2(PROCESS CHECK) ,3 (FNI) , 4 (OBA TEST)
	@FailQty float = 0,
	@IsFail bit = 0,
	@ActionBy varchar(20),
	@ReturnCode varchar(200)	 = ''	output		

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @CurtProgressCode int

	select @CurtProgressCode = ProgressCode
	from TB_KIT_ORDER_HEADER
	where orderid = @orderid 

	IF @TestStep = 1
		BEGIN
				if @CurtProgressCode <> 306
					begin
							set @ReturnCode = 'Current process code is not correct.'
							raiserror (@ReturnCode,16,1)
							return
					end

					UPDATE TB_KIT_ORDER_HEADER 
					SET [FI_FinishedTime] = GETDATE()
						,[FI_FinishedBy] = @ActionBy
						,ProgressCode = 307
					WHERE ORDERID = @ORDERID 
					set @ReturnCode ='Operation successed.'
		END

	IF @TestStep = 2
		BEGIN
					if @CurtProgressCode <> 307
					begin
							set @ReturnCode = 'Current process code is not correct.'
							raiserror (@ReturnCode,16,1)
							return
					end

			    UPDATE TB_KIT_ORDER_HEADER 
				SET [Processing_FinishTime] = GETDATE()
					,[Processing_FinishedBy] = @ActionBy
					,ProgressCode = 308
					,[FailedQty_Processing]=@FailQty
					,[FinalQty]=Kits_Qty-@FailQty
				WHERE ORDERID = @ORDERID 
				set @ReturnCode ='Operation successed.'
		END

	IF @TestStep = 3
		BEGIN
					if @CurtProgressCode <> 308
					begin
							set @ReturnCode = 'Current process code is not correct.'
							raiserror (@ReturnCode,16,1)
							return
					end
				if @IsFail = 1 
					begin
						UPDATE TB_KIT_ORDER_HEADER 
						SET [FNI_FinishedTime] = GETDATE()
							,[FNI_FinishedBy] = @ActionBy
							,ProgressCode = 307
							,[FailedQty_Processing]=0
							,FinalQty = NULL
							,OrderNotes = OrderNotes + char(10) + char(13) + convert(varchar,getdate()) +  '/FNI inspection fail. Tester: #' + @ActionBy + '#'
						WHERE ORDERID = @ORDERID 
					end
				else begin
					UPDATE TB_KIT_ORDER_HEADER 
					SET [FNI_FinishedTime] = GETDATE()
						,[FNI_FinishedBy] = @ActionBy
						,ProgressCode = 309
					WHERE ORDERID = @ORDERID 
				end

				set @ReturnCode ='Operation successed.'
		END
	IF @TestStep = 4
		BEGIN
					if @CurtProgressCode <> 309
					begin
							set @ReturnCode = 'Current process code is not correct.'
							raiserror (@ReturnCode,16,1)
							return
					end
				if @IsFail = 1 
					begin
						UPDATE TB_KIT_ORDER_HEADER 
						SET [FNI_FinishedTime] = GETDATE()
							,[FNI_FinishedBy] = @ActionBy
							,ProgressCode = 307
							,[FailedQty_Processing]=0
							,FinalQty = NULL
							,OrderNotes = OrderNotes + char(10) + char(13) + convert(varchar,getdate()) +  '/OBA inspection fail. Tester: #' + @ActionBy + '#'
						WHERE ORDERID = @ORDERID 
					end
					else begin
						UPDATE TB_KIT_ORDER_HEADER 
						SET [OBA_FinishedTime] = GETDATE()
							,[OBA_FinishedBy] = @ActionBy
							,ProgressCode = 310
						WHERE ORDERID = @ORDERID 
					end
				set @ReturnCode ='Operation successed.'
		END
END

GO
