

CREATE VIEW [dbo].[View_Kitting_Order_Headers_Ref]
AS
SELECT     a.OrderID, a.BuildPlanTime, c.[Material Group] AS WorkCell, a.KittingPartNum, a.Kits_Qty, a.Selective, CASE WHEN b.KittingType IS NULL 
                      THEN 'None' ELSE b.kittingtype END AS KittingType, COUNT(DISTINCT c.Component) AS RawPartCnt, c.[Part Description], a.CurrentPlace, d.OrderCnt, d.PkgCnt, 
                      d.DemandQty, d.ActualQty, d.DiffQty, a.PullListNo, a.AddPullBy, a.CreatePullTime, a.CreateBy AS OrderCreateBy, a.CreateTime, a.OrderStatus, a.Stocksts, 
                      a.Stock_AssignedBy, a.Stock_AssignedTo, a.Stock_ReceivedTime, a.Stock_PickingTime, a.Stock_CompleteTime, a.Stock_LeadTime, a.KittingStatus, 
                      a.Kitting_ReceivedTime, a.Kitting_CompleteTime, a.Kitting_LeadTime, a.PullLeadTime, a.SendToWho, a.SendByWho, a.ConditionalFormat, a.CancelTime, 
                      a.CanceledBy, a.ClosedTime, a.ClosedBy, (CASE WHEN a.Flag = 0 THEN 'Normal' WHEN a.Flag = 1 THEN 'Shortage' END) AS DemandType, b.[UCT(Sec)], 
                      ISNULL(b.[UCT(Sec)], 0) * a.Kits_Qty / 60 AS [Expect_LeadTime(m)], a.Flag, a.UserDefinedColumn1 AS FatherOrderID, b.DocIndex,
                          (SELECT     OutOfStock
                            FROM          dbo.View_Kitting_OutofStock_OrderList
                            WHERE      (OrderID = a.OrderID)) AS OutofStkFlag, a.OrderNotes
FROM         dbo.Tb_Kitting_Order_Header AS a  with (nolock) LEFT OUTER JOIN
                      dbo.Bas_Kitting_Doc AS b  with (nolock) ON a.KittingPartNum = b.KittingPartNum INNER JOIN
                      dbo.Bas_SAPbom AS c with (nolock)  ON a.KittingPartNum = c.[Assembly Name] LEFT OUTER JOIN
                      dbo.View_Kitting_OverallStatus AS d with (nolock)  ON a.KittingPartNum = d.KittingPartNum
GROUP BY a.OrderID, a.BuildPlanTime, c.[Material Group], a.KittingPartNum, a.Kits_Qty, a.Selective, c.[Part Description], a.CurrentPlace, a.PullListNo, a.CreateBy, 
                      a.CreateTime, a.OrderStatus, a.KittingStatus, a.Kitting_ReceivedTime, a.Stocksts, a.Stock_ReceivedTime, a.Kitting_CompleteTime, a.Kitting_LeadTime, 
                      a.Stock_CompleteTime, a.Stock_LeadTime, a.PullLeadTime, a.SendToWho, a.SendByWho, a.ConditionalFormat, a.CancelTime, a.CanceledBy, a.ClosedTime, a.Flag, 
                      a.OrderNotes, a.AddPullBy, a.CreatePullTime, a.Stock_AssignedBy, a.Stock_AssignedTo, a.Stock_PickingTime, b.DocIndex, b.KittingType, a.ClosedBy, 
                      a.UserDefinedColumn1, b.[UCT(Sec)], ISNULL(b.[UCT(Sec)], 0) * a.Kits_Qty / 60, d.OrderCnt, d.PkgCnt, d.DemandQty, d.ActualQty, d.DiffQty


GO
