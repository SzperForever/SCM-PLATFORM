-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-10-28>
-- Description:	<Auto cancel MI order those not actived within intervalhours>
-- =============================================
CREATE PROCEDURE SP_MI_AutoCancelOrders
	-- Add the parameters for the stored procedure here
	@IntervalHour int
	,@ReturnCode nvarchar(200) output
	,@IsSucceed bit output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    Declare @AffectedRows int
	Update tb_Order_Details 
	set OrderStatus = 'Cancel',CancelTime = GETDATE(),OrderNotes = OrderNotes + '/auto cancelled since over interval hours.'
	WHERE FlagGroup = 'MI' 
		AND (LVHMrequestTime is null or rtrim(LVHMrequestTime) = '') 
		and DATEDIFF(HH ,CreateTime,GETDATE())> @IntervalHour
		and OrderStatus = 'Open'
		
	set @AffectedRows = @@ROWCOUNT 
	set @IsSucceed = 1
	set @ReturnCode = str(@AffectedRows) + ' items affected.'
	return

END
GO
