CREATE VIEW dbo.View_RTS_VS_SAP_STK
AS
SELECT     c.RTSNO, b.RTSID, c.ScanPartNo, b.Material,
                          (SELECT     COUNT(GRNno) AS Expr1
                            FROM          dbo.Tb_RTS WITH (nolock)
                            WHERE      (RTSNO = c.RTSNO) AND (ScanPartNo = c.ScanPartNo)) AS PkgCnt, ISNULL
                          ((SELECT     SUM(ScanQty) AS EP_TotalRTSQty
                              FROM         dbo.Tb_RTS AS Tb_RTS_2 WITH (nolock)
                              WHERE     (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS EP_SubTotal, ISNULL
                          ((SELECT     SUM(Qty) AS Expr1
                              FROM         dbo.Temp_RTS_SAPData WITH (nolock)
                              WHERE     (Material = b.Material) AND (RTSID = b.RTSID)), 0) AS SAP_SubTotal, ISNULL
                          ((SELECT     SUM(Qty) AS Expr1
                              FROM         dbo.Temp_RTS_SAPData AS Temp_RTS_SAPData_1 WITH (nolock)
                              WHERE     (Material = b.Material) AND (RTSID = b.RTSID)), 0) - ISNULL
                          ((SELECT     SUM(ScanQty) AS EP_TotalRTSQty
                              FROM         dbo.Tb_RTS AS Tb_RTS_1 WITH (nolock)
                              WHERE     (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS DiffQty
FROM         dbo.Temp_RTS_SAPData AS b WITH (nolock) FULL OUTER JOIN
                      dbo.Tb_RTS AS c WITH (nolock) ON b.Material = c.ScanPartNo AND b.RTSID = c.RTSNO
GROUP BY c.RTSNO, b.RTSID, c.ScanPartNo, b.Material
GO
