CREATE  proc  [dbo].[p_dirtree]  
@path  nvarchar(1000),            --要查询的目录名  
@depth  int=1,            --要检索的目录层数,如果是0,表示搜索所有的目录  
@file  int=2,            --检索的类型,为0,表示只返回目录,为1,只返回文件,为2,返回文件及目录  
@filter  nvarchar(10)=''            --要返回的目录/文件的匹配条件,规则是like的匹配规则  
as  
set  nocount  on  
declare  @s  nvarchar(4000),@i  int  
 
--规范参数  
if  isnull(@path,'')=''            return  
if  right(@path,1)<>'/'  set  @path=@path+'/'  
if  isnull(@depth,-1)<0  set  @depth=1  
if  isnull(@file,0)  not  in(0,1,2)  set  @file=2  
set  @i=len(@path)-len(replace(@path,'/',''))-1  
 
--检索目录/文件  
create  table  #t(subdirectory  nvarchar(2000),depth  int,isfile  bit  default  0)  
if  @file=0  
           insert  #t(subdirectory,depth)  exec  master..xp_dirtree  @path,@depth,0  
else  
           insert  #t  exec  master..xp_dirtree  @path,@depth,1  
 
--补充目录信息  
set  @depth=0  
update  #t  set  @path=case    
                       when  isfile=1  then  dbo.f_split(@path,depth+@i)  
                       else  dbo.f_split(@path,depth+@i)+subdirectory+'/'  
                       end  
           ,subdirectory=case  when  isfile=1  then  @path+subdirectory  else  @path  end  
           ,@depth=depth  
 
--返回结果  
select  @s=case  when  @file=1  then  '  and  isfile=1'  else  ''  end  
                       +case  when  @filter=''  then  ''  else  '  and  subdirectory  like  @filter'  end  
           ,@s='select  *  from  #t'+case  when  @s=''  then  ''  else  '  where  '+stuff(@s,1,4,'')  end  
exec  sp_executesql  @s,N'@filter  nvarchar(10)',@filter
GO
