CREATE VIEW dbo.View_Calc_RawPartList_BaseOn_AssemblyList
AS
SELECT     Component, SUM(TotalSets) AS TotalSets2, Standard_price, SUM(TotalQty) AS TotalQty, SUM(TotalPrice) AS TotalPrice
FROM         dbo.View_Calc_RawPartList_BaseOn_AssemblyList_A
GROUP BY Component, Standard_price
GO
