CREATE VIEW dbo.View_FG_PickList
AS
SELECT        TOP (100) PERCENT dbo.View_FG_SR_Details.SRid, dbo.View_FG_SR_Details.SRno, dbo.View_FG_SR_Details.PartNum AS FG_PartNumber, 
                         dbo.View_FG_SR_Details.Material_description AS FG_Desc, dbo.View_FG_SR_Details.TotalQty, dbo.View_FG_SR_Details.Remark, 
                         dbo.View_FG_SR_Headers.Project, dbo.View_FG_SR_Headers.Requestor, dbo.View_FG_SR_Headers.ForwarderName, dbo.View_FG_SR_Headers.Plan_Pick_Time, 
                         dbo.View_FG_SR_Headers.CreateBy, dbo.View_FG_SR_Headers.MP_Cnt, dbo.View_FG_SR_Headers.MP_Items_Cnt, dbo.View_FG_SR_Headers.SR_Part_Cnt, 
                         dbo.View_FG_SR_Headers.OrderNotes, dbo.View_FG_SR_Details.[Delivery Number], dbo.View_FG_SR_Details.PO, dbo.View_FG_SR_Details.SO, 
                         dbo.View_FG_SR_Details.Item, dbo.View_FG_SR_Headers.SoldToAddress, dbo.View_FG_SR_Headers.ShipToAddress, dbo.View_FG_SR_Headers.SoldToCode, 
                         dbo.View_FG_SR_Headers.ShipToCode, dbo.View_FG_SR_Headers.TradeTerms, dbo.View_FG_SR_Details.UnitNetWeight AS UNW_g
FROM            dbo.View_FG_SR_Details INNER JOIN
                         dbo.View_FG_SR_Headers ON dbo.View_FG_SR_Details.SRid = dbo.View_FG_SR_Headers.SRid
ORDER BY dbo.View_FG_SR_Details.SO
GO
