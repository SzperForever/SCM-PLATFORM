
CREATE VIEW [dbo].[V_KIT_PULLS]
AS
SELECT        PullListNo, Pull_ReleasedBy, Pull_ReleasedTime, Stock_Sts, Stock_AssignedBy, Stock_AssignedTo, Stock_PickingTime, Pull_FinishedTime, 
                         SUBSTRING(PullListNo, 9, 4) AS StoreArea
FROM            dbo.V_KIT_ORDER_HEADER AS h
WHERE        (LEN(ISNULL(PullListNo, '')) <> 0)
GROUP BY PullListNo, Pull_ReleasedBy, Pull_ReleasedTime, Stock_Sts, Stock_AssignedBy, Stock_AssignedTo, Stock_PickingTime, Pull_FinishedTime

GO
