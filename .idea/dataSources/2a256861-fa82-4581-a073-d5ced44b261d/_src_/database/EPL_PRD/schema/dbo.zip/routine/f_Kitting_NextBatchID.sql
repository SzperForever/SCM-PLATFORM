
CREATE FUNCTION [dbo].[f_Kitting_NextBatchID]()
RETURNS char(13)
AS
BEGIN
    DECLARE @dt CHAR(6)
    SELECT @dt=dt FROM v_GetDate
    RETURN(
        SELECT 'B' + @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(BatchID),6),0),6) 
        FROM TB_Kitting_BatchList WITH(XLOCK,PAGLOCK)
        WHERE BatchID like 'B' + @dt+'%')
END

GO
