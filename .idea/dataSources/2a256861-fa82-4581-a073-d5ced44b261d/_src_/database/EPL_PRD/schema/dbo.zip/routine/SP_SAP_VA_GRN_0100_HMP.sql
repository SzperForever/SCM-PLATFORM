-- =============================================
-- Author:		DAILS
-- Create date: 2017-05-19
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_SAP_VA_GRN_0100_HMP]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@tableHTML2 nvarchar(max)
			,@tableHTML3 nvarchar(max)		
			,@Msg nvarchar(300)
			,@Rcnt int
			,@Rcnt2 int
			,@Rcnt3 int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
			
	set @AlertName = 'SAP VA GRNGRN Tracebility Syst_0100(HMP)'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	

	
	set @Rcnt = (SELECT count(0) FROM(
			SELECT  
      a.[Sloc] 
      ,CASE WHEN (b.[SLoc])IS NULL THEN 'S' ELSE (b.[SLoc]) END AS GSLoc  
      ,a.[Typ] 
      ,CASE WHEN (b.[StorageType])IS NULL THEN'T' ELSE (b.[StorageType]) END AS GTyp  
      ,a.[StorageBin]
      ,CASE WHEN (b.[StorageBin])IS NULL THEN'B' ELSE (b.[StorageBin]) END AS GStorageBin
      ,a.[Material] 
      ,CASE WHEN (b.[Material])IS NULL THEN'M' ELSE (b.[Material]) END AS GMaterial      
      ,SUM(a.[Available stock]) AS S_QTY     
      ,CASE WHEN (SUM(B.[Quantity])) IS NULL  THEN (0) ELSE SUM(B.[Quantity])END  AS G_QTY         
      ,convert(int,SUM(a.[Available stock]) - CASE WHEN (SUM(B.[Quantity])) IS NULL  THEN (0) ELSE SUM(B.[Quantity])END) AS DiffQty      
      
  FROM (SELECT *
FROM (
  SELECT      
       [Sloc]
      ,[Typ]
      ,[StorageBin]
      ,[Material]
      ,SUM([Available stock]) as [Available stock]
       FROM [EPL_PRD].[dbo].[TB_SAP_INV_WH]
       group by      
      [Sloc]
      ,[Typ]
      ,[StorageBin]
      ,[Material]   ) as  u )  a    Left Join        
(SELECT *
FROM (
SELECT 
      [SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]     
      ,SUM([Quantity]) AS [Quantity]  

  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  where [Active]='1'
  group by [SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]   )  as t)  b
      
     on a.[Material]collate SQL_Latin1_General_CP1_CI_AS = b.[Material]
        and a.[Sloc]collate SQL_Latin1_General_CP1_CI_AS = b.[SLoc]
        and a.[Typ]collate SQL_Latin1_General_CP1_CI_AS = b.[StorageType]
        and a.[StorageBin]collate SQL_Latin1_General_CP1_CI_AS =b.[StorageBin]
  WHERE a.[Sloc]='0100'  collate SQL_Latin1_General_CP1_CI_AS
        --and a.[StorageBin] like '%ODC%'  collate SQL_Latin1_General_CP1_CI_AS 
        and a.[StorageBin] in (
'1-H-01-06A',
'1-H-01-06C',
'1-H-01-06D',
'1-H-01-07A',
'1-H-01-07B',
'1-H-01-07D',
'1-H-02-3A1',
'1-H-02-3B2',
'1-H-02-3C1',
'1-H-02-3C2',
'1-H-02-3D1',
'1-H-02-3D2',
'1-H-02-4A1',
'1-H-02-4B2',
'1-H-02-4C1',
'1-H-02-4C2',
'1-H-02-4D1',
'1-H-02-4D2',
'1-H-02-5A1',
'1-H-02-5A2',
'1-H-02-5B2',
'1-H-02-5C1',
'1-H-02-5D1',
'1-H-02-5D2',
'1-H-02-6A1',
'1-H-02-6A2',
'1-H-02-6B1',
'1-H-02-6B2',
'1-H-02-6C1',
'1-H-02-6C2',
'1-H-02-6D1',
'1-H-02-6D2',
'1-H-02-7A1',
'1-H-02-7A2',
'1-H-02-7B2',
'1-H-02-7C2',
'1-H-03-5D1',
'1-H-03-5D2',
'1-H-03-6A1',
'1-H-03-6A2',
'1-H-03-6B1',
'1-H-03-6B2',
'1-H-03-6C1',
'1-H-03-6C2',
'1-H-03-6D1',
'1-H-03-6D2',
'1-H-03-7A1',
'1-H-03-7A2',
'1-H-03-7B1',
'1-H-03-7B2',
'1-H-03-7C1',
'1-H-03-7C2',
'1-H-03-7D1',
'1-H-03-7D2',
'1-H-04-1A1',
'1-H-04-1A2',
'1-H-04-1B1',
'1-H-04-1B2',
'1-H-04-1C1',
'1-H-04-1C2',
'1-H-04-1D1',
'1-H-04-1D2',
'1-H-04-5E1',
'1-I-01-06E',
'1-I-01-06F',
'1-I-01-06G',
'1-I-01-06H',
'1-I-01-06I',
'1-I-01-07E',
'1-I-01-07F',
'1-I-01-07G',
'1-I-01-07H',
'1-I-01-07I',
'1-I-02-1E1',
'1-I-02-1E2',
'1-I-02-1F1',
'1-I-02-1F2',
'1-I-02-1H1',
'1-I-02-1H2',
'1-I-02-1I1',
'1-I-02-1I2',
'1-I-02-2E1',
'1-I-02-2E2',
'1-I-02-2F1',
'1-I-02-2F2',
'1-I-02-2G1',
'1-I-02-2H1',
'1-I-02-2I1',
'1-I-02-2I2',
'1-I-02-3E1',
'1-I-02-3E2',
'1-I-02-3G1',
'1-I-02-3G2',
'1-I-02-3I1',
'1-I-02-3I2',
'1-I-02-4E1',
'1-I-02-4E2',
'1-I-02-4F1',
'1-I-02-4F2',
'1-I-02-4G2',
'1-I-02-4H1',
'1-I-02-4H2',
'1-I-02-4I1',
'1-I-02-5E1',
'1-I-02-5E2',
'1-I-02-5F1',
'1-I-02-5F2',
'1-I-02-5G1',
'1-I-02-5G2',
'1-I-02-5H1',
'1-I-02-5H2',
'1-I-02-5I1',
'1-I-02-5I2',
'1-I-02-6E1',
'1-I-02-6E2',
'1-I-02-6F1',
'1-I-02-6G1',
'1-I-02-6G2',
'1-I-02-6H2',
'1-I-02-6I2',
'1-I-02-7E1',
'1-I-02-7E2',
'1-I-02-7F2',
'1-I-02-7G1',
'1-I-02-7G2',
'1-I-02-7H1',
'1-I-02-7I1',
'1-I-03-5E1',
'1-I-03-5E2',
'1-I-03-5F2',
'1-I-03-5G1',
'1-I-03-5G2',
'1-I-03-6E1',
'1-I-03-6F2',
'1-I-03-6G2',
'1-I-03-6H2',
'1-I-03-7E1',
'1-I-03-7E2',
'1-I-03-7F1',
'1-I-03-7F2',
'1-I-03-7G1',
'1-I-03-7G2',
'1-I-03-7H1',
'1-I-03-7H2',
'1-I-03-7I1',
'1-I-03-7I2',
'1-I-04-1E1',
'1-I-04-1E2',
'1-I-04-1F2',
'1-I-04-2E1',
'1-I-04-2F1',
'1-I-04-2F2',
'1-I-04-2G1',
'1-I-04-2G2',
'1-I-04-2H1',
'1-I-04-2H2',
'1-I-04-2I1',
'1-I-04-2I2',
'1-I-04-3E1',
'1-I-04-3E2',
'1-I-04-4E1',
'1-I-04-4E2',
'1-I-04-6E1',
'1-I-04-6E2',
'1-I-04-6G2',
'1-I-04-6H2',
'1-I-04-7F1',
'1-I-04-7F2',
'1-I-04-7G1',
'1-I-04-7G2',
'1-H-01-07C',
'1-H-02-1A1',
'1-H-02-1A2',
'1-H-02-1B1',
'1-H-02-1B2',
'1-H-02-1C1',
'1-H-02-1C2',
'1-H-02-1D1',
'1-H-02-1D2',
'1-H-02-2A1',
'1-H-02-2A2',
'1-H-02-2B1',
'1-H-02-2B2',
'1-H-02-2C1',
'1-H-02-2C2',
'1-H-02-2D1',
'1-H-02-2D2',
'1-H-02-5C2',
'1-I-04-7E1',
'1-I-04-5E2',
'1-I-03-6F1',
'1-I-03-6E2',
'1-I-04-5E1',
'1-I-04-5C2',
'1-H-01-06B',
'1-H-02-3B1',
'1-I-04-1F1',
'1-I-04-2E2', 
'1-H-02-4B1',
'1-H-02-7B1',
'1-H-02-7C1',
'1-H-02-7D1' 
)           
  GROUP BY a.[Material]
      ,a.[Sloc]
      ,a.[Typ] 
      ,a.[StorageBin]
      ,b.[SLoc] 
      ,b.[StorageType]
      ,b.[StorageBin]
      ,b.[Material] 
      ) as t
     where DiffQty <>  '0' )
     
     
     
     
	set @Rcnt2 =  (SELECT count(0) 
FROM(
SELECT  
       a.[Sloc] 
      ,b.[SLoc] as GSLoc
      ,a.[Typ] 
      ,b.[StorageType]AS GTyp
      ,a.[StorageBin]
      ,b.[StorageBin]AS GStorageBin
      ,a.[Material] 
      ,b.[Material] AS GMaterial
      ,b.GRN
      ,B.[Quantity] AS G_QTY       
 FROM [EPL_PRD].[dbo].[TB_SAP_INV_WH]as a
     Right  JOIN
[SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]as b      
         on a.[Material]collate SQL_Latin1_General_CP1_CI_AS = b.[Material]
        and a.[Sloc]collate SQL_Latin1_General_CP1_CI_AS = b.[SLoc]
        and a.[Typ]collate SQL_Latin1_General_CP1_CI_AS = b.[StorageType]
        and a.[StorageBin]collate SQL_Latin1_General_CP1_CI_AS =b.[StorageBin]
       where b.Active='1'and b.[SLoc]='0100'   ) as t
     where [Material]IS NULL  )
     
     
     
		
	

	
	
	set @Rcnt3 = (SELECT count(0) 
FROM(
SELECT [Plant]
      ,[SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]
      ,[MaterialGroup]      
      ,[GRN]
      ,[Quantity]
      ,[UnitPrice]
      ,[UnitPrice]*[Quantity] AS TotalPrice
      --,[SLED]
      ,CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END  AS U_SLED
      ,DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )as Non_Expired
      ,[DateCode]
      ,[CreatedBy]
      ,[CreatedDate]  
  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1'and [SLoc]='0100'
  )AS A
		WHERE Non_Expired  < '1' )
	
	
     
     
	
    set @tableHTML3 = ''	
    set @tableHTML2 = ''	
	SET @tableHTML =
	    N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
		N'<H1> HMP  SAP VS GRN Differenc </H1>' +
		N'<table border="1">' +
		N'<font color=#FF0000><H1> 下面是SAP与GRN Tracebility System的数量差异(0100_HMP)</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[Sloc]</th><th>GSLoc</th><th>[Typ]</th><th>GTyp</th><th>[StorageBin]</th><th>GStorageBin</th><th>[Material]</th><th>GMaterial</th>' +
		N'<th>S_QTY</th><th>G_QTY</th><th>DiffQty</th></tr>' +
		CAST ( ( SELECT
		                 td = [Sloc],'',
						 td = GSLoc,'',
						 td = [Typ],'',
                         td = GTyp,'',
                         td = [StorageBin],'',
                         td = GStorageBin,'',
                         td = [Material],'',
                         td = GMaterial,'',
                         td = convert(int,S_QTY),'',
                         td = convert(int,G_QTY),'',
                         td = convert(int,DiffQty),''
FROM(
SELECT  
      a.[Sloc] 
      ,CASE WHEN (b.[SLoc])IS NULL THEN 'S' ELSE (b.[SLoc]) END AS GSLoc  
      ,a.[Typ] 
      ,CASE WHEN (b.[StorageType])IS NULL THEN'T' ELSE (b.[StorageType]) END AS GTyp  
      ,a.[StorageBin]
      ,CASE WHEN (b.[StorageBin])IS NULL THEN'B' ELSE (b.[StorageBin]) END AS GStorageBin
      ,a.[Material] 
      ,CASE WHEN (b.[Material])IS NULL THEN'M' ELSE (b.[Material]) END AS GMaterial      
      ,SUM(a.[Available stock]) AS S_QTY     
      ,CASE WHEN (SUM(B.[Quantity])) IS NULL  THEN (0) ELSE SUM(B.[Quantity])END  AS G_QTY         
      ,convert(int,SUM(a.[Available stock]) - CASE WHEN (SUM(B.[Quantity])) IS NULL  THEN (0) ELSE SUM(B.[Quantity])END) AS DiffQty      
      
  FROM (SELECT *
FROM (
  SELECT      
       [Sloc]
      ,[Typ]
      ,[StorageBin]
      ,[Material]
      ,SUM([Available stock]) as [Available stock]
       FROM [EPL_PRD].[dbo].[TB_SAP_INV_WH]
       group by      
      [Sloc]
      ,[Typ]
      ,[StorageBin]
      ,[Material]   ) as  u )  a    Left Join        
(SELECT *
FROM (
SELECT 
      [SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]     
      ,SUM([Quantity]) AS [Quantity]  

  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  where [Active]='1'
  group by [SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]   )  as t)  b
      
     on a.[Material]collate SQL_Latin1_General_CP1_CI_AS = b.[Material]
        and a.[Sloc]collate SQL_Latin1_General_CP1_CI_AS = b.[SLoc]
        and a.[Typ]collate SQL_Latin1_General_CP1_CI_AS = b.[StorageType]
        and a.[StorageBin]collate SQL_Latin1_General_CP1_CI_AS =b.[StorageBin]
  WHERE a.[Sloc]='0100'  collate SQL_Latin1_General_CP1_CI_AS
        and a.[StorageBin] in (
'1-H-01-06A',
'1-H-01-06C',
'1-H-01-06D',
'1-H-01-07A',
'1-H-01-07B',
'1-H-01-07D',
'1-H-02-3A1',
'1-H-02-3B2',
'1-H-02-3C1',
'1-H-02-3C2',
'1-H-02-3D1',
'1-H-02-3D2',
'1-H-02-4A1',
'1-H-02-4B2',
'1-H-02-4C1',
'1-H-02-4C2',
'1-H-02-4D1',
'1-H-02-4D2',
'1-H-02-5A1',
'1-H-02-5A2',
'1-H-02-5B2',
'1-H-02-5C1',
'1-H-02-5D1',
'1-H-02-5D2',
'1-H-02-6A1',
'1-H-02-6A2',
'1-H-02-6B1',
'1-H-02-6B2',
'1-H-02-6C1',
'1-H-02-6C2',
'1-H-02-6D1',
'1-H-02-6D2',
'1-H-02-7A1',
'1-H-02-7A2',
'1-H-02-7B2',
'1-H-02-7C2',
'1-H-03-5D1',
'1-H-03-5D2',
'1-H-03-6A1',
'1-H-03-6A2',
'1-H-03-6B1',
'1-H-03-6B2',
'1-H-03-6C1',
'1-H-03-6C2',
'1-H-03-6D1',
'1-H-03-6D2',
'1-H-03-7A1',
'1-H-03-7A2',
'1-H-03-7B1',
'1-H-03-7B2',
'1-H-03-7C1',
'1-H-03-7C2',
'1-H-03-7D1',
'1-H-03-7D2',
'1-H-04-1A1',
'1-H-04-1A2',
'1-H-04-1B1',
'1-H-04-1B2',
'1-H-04-1C1',
'1-H-04-1C2',
'1-H-04-1D1',
'1-H-04-1D2',
'1-H-04-5E1',
'1-I-01-06E',
'1-I-01-06F',
'1-I-01-06G',
'1-I-01-06H',
'1-I-01-06I',
'1-I-01-07E',
'1-I-01-07F',
'1-I-01-07G',
'1-I-01-07H',
'1-I-01-07I',
'1-I-02-1E1',
'1-I-02-1E2',
'1-I-02-1F1',
'1-I-02-1F2',
'1-I-02-1H1',
'1-I-02-1H2',
'1-I-02-1I1',
'1-I-02-1I2',
'1-I-02-2E1',
'1-I-02-2E2',
'1-I-02-2F1',
'1-I-02-2F2',
'1-I-02-2G1',
'1-I-02-2H1',
'1-I-02-2I1',
'1-I-02-2I2',
'1-I-02-3E1',
'1-I-02-3E2',
'1-I-02-3G1',
'1-I-02-3G2',
'1-I-02-3I1',
'1-I-02-3I2',
'1-I-02-4E1',
'1-I-02-4E2',
'1-I-02-4F1',
'1-I-02-4F2',
'1-I-02-4G2',
'1-I-02-4H1',
'1-I-02-4H2',
'1-I-02-4I1',
'1-I-02-5E1',
'1-I-02-5E2',
'1-I-02-5F1',
'1-I-02-5F2',
'1-I-02-5G1',
'1-I-02-5G2',
'1-I-02-5H1',
'1-I-02-5H2',
'1-I-02-5I1',
'1-I-02-5I2',
'1-I-02-6E1',
'1-I-02-6E2',
'1-I-02-6F1',
'1-I-02-6G1',
'1-I-02-6G2',
'1-I-02-6H2',
'1-I-02-6I2',
'1-I-02-7E1',
'1-I-02-7E2',
'1-I-02-7F2',
'1-I-02-7G1',
'1-I-02-7G2',
'1-I-02-7H1',
'1-I-02-7I1',
'1-I-03-5E1',
'1-I-03-5E2',
'1-I-03-5F2',
'1-I-03-5G1',
'1-I-03-5G2',
'1-I-03-6E1',
'1-I-03-6F2',
'1-I-03-6G2',
'1-I-03-6H2',
'1-I-03-7E1',
'1-I-03-7E2',
'1-I-03-7F1',
'1-I-03-7F2',
'1-I-03-7G1',
'1-I-03-7G2',
'1-I-03-7H1',
'1-I-03-7H2',
'1-I-03-7I1',
'1-I-03-7I2',
'1-I-04-1E1',
'1-I-04-1E2',
'1-I-04-1F2',
'1-I-04-2E1',
'1-I-04-2F1',
'1-I-04-2F2',
'1-I-04-2G1',
'1-I-04-2G2',
'1-I-04-2H1',
'1-I-04-2H2',
'1-I-04-2I1',
'1-I-04-2I2',
'1-I-04-3E1',
'1-I-04-3E2',
'1-I-04-4E1',
'1-I-04-4E2',
'1-I-04-6E1',
'1-I-04-6E2',
'1-I-04-6G2',
'1-I-04-6H2',
'1-I-04-7F1',
'1-I-04-7F2',
'1-I-04-7G1',
'1-I-04-7G2',
'1-H-01-07C',
'1-H-02-1A1',
'1-H-02-1A2',
'1-H-02-1B1',
'1-H-02-1B2',
'1-H-02-1C1',
'1-H-02-1C2',
'1-H-02-1D1',
'1-H-02-1D2',
'1-H-02-2A1',
'1-H-02-2A2',
'1-H-02-2B1',
'1-H-02-2B2',
'1-H-02-2C1',
'1-H-02-2C2',
'1-H-02-2D1',
'1-H-02-2D2', 
'1-H-02-5C2',
'1-I-04-7E1',
'1-I-04-5E2',
'1-I-03-6F1',
'1-I-03-6E2',
'1-I-04-5E1',
'1-I-04-5C2',
'1-H-01-06B',
'1-H-02-3B1',
'1-I-04-1F1',
'1-I-04-2E2',
'1-H-02-4B1',  
'1-H-02-7B1',
'1-H-02-7C1',
'1-H-02-7D1'   
)            
  GROUP BY a.[Material]
      ,a.[Sloc]
      ,a.[Typ] 
      ,a.[StorageBin]
      ,b.[SLoc] 
      ,b.[StorageType]
      ,b.[StorageBin]
      ,b.[Material] 
      ) as t
     where DiffQty <>  '0' 
     --AND G_QTY <>'0'
     order by [StorageBin]              
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' 
set @tableHTML2 = 
		N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
     	N'<font color=#FF0000><H1> 下面是GRN Tracebility System有库存的差异</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>GSLoc</th><th>GTyp</th><th>GMaterial</th><th>GRN</th><th>G_QTY</th><th>GStorageBin</th></tr>' +
		CAST ( (SELECT
                         td = GSLoc,'',
                         td = GTyp,'',
                         td = GMaterial,'',
                         td = GRN,'',
                         td = convert(int,G_QTY) ,'',
                         td = GStorageBin ,''
FROM(
SELECT  
       a.[Sloc] 
      ,b.[SLoc] as GSLoc
      ,a.[Typ] 
      ,b.[StorageType]AS GTyp
      ,a.[StorageBin]
      ,b.[StorageBin]AS GStorageBin
      ,a.[Material] 
      ,b.[Material] AS GMaterial
      ,b.GRN
      ,B.[Quantity] AS G_QTY       
 FROM [EPL_PRD].[dbo].[TB_SAP_INV_WH]as a
     Right  JOIN
[SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]as b      
         on a.[Material]collate SQL_Latin1_General_CP1_CI_AS = b.[Material]
        and a.[Sloc]collate SQL_Latin1_General_CP1_CI_AS = b.[SLoc]
        and a.[Typ]collate SQL_Latin1_General_CP1_CI_AS = b.[StorageType]
        and a.[StorageBin]collate SQL_Latin1_General_CP1_CI_AS =b.[StorageBin]
       where b.Active='1'and b.[Sloc]='0100'   ) as t
     where [Material]IS NULL
     order by GStorageBin             
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
		        N'</table>'
		
set @tableHTML3 = 
		N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
		N'<font color=#FF0000><H1> 下面是HMP库存过期的物料</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[SLoc]</th><th>[StorageType]</th><th>[Material]</th><th>GRN</th><th>G_QTY</th><th>GStorageBin</th><th>U_SLED</th><th>Non_Expired</th><th>[CreatedDate]</th></tr>' +
		
	CAST ( (	SELECT 
		  td = [SLoc],'',
          td = [StorageType],'',
          td = [Material],'',
          td = [GRN],'',
          td = convert(int,[Quantity]) ,'',
          td = [StorageBin] ,'',	
          td = U_SLED,'',
          td = Non_Expired,'',
          td = [CreatedDate],''	
		
FROM(
SELECT [Plant]
      ,[SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]
      ,[MaterialGroup]      
      ,[GRN]
      ,[Quantity]
      ,[UnitPrice]
      ,[UnitPrice]*[Quantity] AS TotalPrice
      --,[SLED]
      ,CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END  AS U_SLED
      ,DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )as Non_Expired
      ,[DateCode]
      ,[CreatedBy]
      ,[CreatedDate]  
  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1' and [SLoc]='0100'
  )AS A
		WHERE Non_Expired  <= '0' 
		order by Non_Expired
				FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		
				

		N'</table>' +    

    
		'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';
    if @Rcnt =0 and @Rcnt2 =0 and @Rcnt3 =0 return

	if @Rcnt > 0 and @Rcnt2 = 0 and @Rcnt3 = 0  begin
		set @tableHTML=@tableHTML
	end	
	if @Rcnt > 0 and @Rcnt2 > 0 and @Rcnt3 = 0  begin
		set @tableHTML=@tableHTML+ @tableHTML2
	end	
	if @Rcnt > 0 and @Rcnt2 = 0 and @Rcnt3 > 0  begin
		set @tableHTML=@tableHTML+ @tableHTML3
	end	
	if @Rcnt = 0 and @Rcnt2 > 0 and @Rcnt3 = 0  begin
		set @tableHTML=@tableHTML2
	end
	if @Rcnt = 0 and @Rcnt2 > 0 and @Rcnt3 > 0  begin
		set @tableHTML=@tableHTML2+@tableHTML3
	end
	if @Rcnt = 0 and @Rcnt2 = 0 and @Rcnt3 > 0  begin
		set @tableHTML=@tableHTML3
	end	
	if @Rcnt > 0 and @Rcnt2 > 0 and @Rcnt3 > 0  begin
		set @tableHTML=@tableHTML + @tableHTML2 + @tableHTML3
	end
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END

GO
