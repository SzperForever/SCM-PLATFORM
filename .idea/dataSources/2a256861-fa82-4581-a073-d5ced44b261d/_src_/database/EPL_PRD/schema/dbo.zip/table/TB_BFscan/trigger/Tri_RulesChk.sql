CREATE TRIGGER [dbo].[Tri_RulesChk]
   ON  dbo.TB_BFscan
   AFTER INSERT,UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @@ROWCOUNT > 1 RETURN

	declare @SerialNumber nvarchar(50),
			@DocNo nchar(14),
			@Errmsg varchar(200),
			@CurtDocBoxIDcount int,
			@ShowTimes int,
			@LstMvmtTyp nchar(20),
			@CurrentMvmtType nchar(20),
			@PartNo varchar(30),
			@LstPartNo varchar(30),
			@LstID BIGINT,
			@CurtID bigint
    -- Insert statements for trigger here
	set @DocNo = (select docno from inserted)
	set @SerialNumber = (select SerialNumber from inserted)
	set @CurrentMvmtType = (select [Movement] from inserted)
	set @PartNo = (select [PartNo] from inserted)
	set @CurtID = (select ID from inserted) 

	if left(ltrim(@SerialNumber),1) not in ('S','J','B','0','T','R') or len(rtrim(ltrim(@SerialNumber))) < 7 goto RejectInsert
	if (left(ltrim(@SerialNumber),1)= '0' and len(rtrim(ltrim(@SerialNumber))) < 7) goto RejectInsert
	if (left(ltrim(@SerialNumber),1) = 'S' AND len(rtrim(ltrim(@SerialNumber)))<> 7 AND LEFT(LTRIM(@SerialNumber),2) not in ('SJ', 'SS'))
		BEGIN
			RejectInsert:
				
				set @Errmsg = 'BoxID(SeriaNumber):' + @SerialNumber + ' is not valid. Please retry.'
				raiserror(@ErrMsg,16,1)
				rollback tran
				return
		END		

	set @ShowTimes =(Select count(*) from dbo.TB_BFscan where SerialNumber = @SerialNumber and [PartNo] = @PartNo and [Movement] Not in('CycleCount','HFGStoreIn','HFGStoreOut'))	
	if @ShowTimes > 1
		begin
			--SET @LstID = (Select top 1 ID  from [dbo].[TB_BFscan] where SerialNumber = @SerialNumber and [PartNo] = @PartNo  and [Movement] Not in('CycleCount','HFGStoreIn','HFGStoreOut') order by  id  DESC )
			set @LstMvmtTyp = (Select TOP 1 [Movement]  from [dbo].[TB_BFscan] where SerialNumber = @SerialNumber and [PartNo] = @PartNo  and [Movement] Not in('CycleCount','HFGStoreIn','HFGStoreOut') and ID < @CurtID Order By ID desc )
				--set @Errmsg = 'LAST:' + STR(@ShowTimes)
				--raiserror(@ErrMsg,16,1)	
				--return
			--set @LstPartNo = (select top 1 [PartNo] from [dbo].[TB_BFscan] where SerialNumber = @SerialNumber and [PartNo] = @PartNo  and [Movement] Not in('CycleCount','HFGStoreIn','HFGStoreOut') order by  [AddTime] desc )
			if RTRIM(@LstMvmtTyp) = RTRIM(@CurrentMvmtType) begin				
					rollback tran
					--set @Errmsg = 'This boxID or serianumber is not allowed to be proceed since it has been transfered with same movement:' + @LstMvmtTyp + ' last time.SerialNumber:' + @SerialNumber + ',DocNo:'+ @DocNo + ',PartNo:'+ @PartNo
					Declare @Substr varchar(100)
					set @Substr = '重复异动:'+@LstMvmtTyp + ',箱号:' + @SerialNumber+',成品:'+ @PartNo
					set @Errmsg = '单号:'+ @DocNo +  ',检测到重复异动:'+@LstMvmtTyp + ',箱号:' + @SerialNumber+',成品:'+ @PartNo
					raiserror(@ErrMsg,16,1)	
					exec [sp_SendingAlert] '13817503000@139.com;_13ba9e@jabil.com;Yihua_Wang@jabil.com ;dai_lisong@jabil.com;13472510523@138.com',@Substr,@Errmsg
					return	
				end	
			else begin
				return
			end
		end
END


--Select top 1 [Movement]  from [dbo].[TB_BFscan] where SerialNumber = '0000000' and [PartNo] = 'SHM600005' and [Movement] <> 'CycleCount' order by  [AddTime] desc
--SELECT * from [dbo].[TB_BFscan] where SerialNumber = '0000000' and [PartNo] = 'SHM600005' and [Movement] <> 'CycleCount' order by  [id] desc


--SELECT * FROM TB_BFscan WHERE SerialNumber = 'BOX00038375' ORDER  BY ID DESC
GO
