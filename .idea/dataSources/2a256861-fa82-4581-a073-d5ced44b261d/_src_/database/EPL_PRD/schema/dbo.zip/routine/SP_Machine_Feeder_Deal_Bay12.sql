-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-8-28>
-- Description:	<Deal with machine feeder setup BOM // specfic baynum which is 'Bay 12'>
-- =============================================
CREATE PROCEDURE SP_Machine_Feeder_Deal_Bay12
	-- Add the parameters for the stored procedure here
		@Number nvarchar(50),
		@MAText nchar(12),
		@Rev nchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--Declare @Rcnt int
	--Declare @Rcnt2 int
    if UPPER(RTRIM(@MAText))= 'BAY 12' BEGIN
		--set @Rcnt = (select COUNT(*) from Bas_Machine_Feeder_Report where MAText in ('Bay 12A','Bay 12B')  and Number = @number and Rev = @rev )
		Delete from Bas_Machine_Feeder_Report where MAText in ('Bay 12A','Bay 12B') and Number = @number and Rev = @rev 
		
		INSERT INTO Bas_Machine_Feeder_Report 
			SELECT [WorkCell]
           ,'BAY 12A'
           ,[Number]
           ,[Rev]
           ,[BoardSide]
           ,[JobRevision]
           ,[fsSetPos]
           ,[fsPartNum]
           ,[fsFdrName]
           ,[pkgInfoPkgType]
           ,[pkgInfoTapeWidth]
           ,[SlotPitch]
           ,[ArrangePos]
           ,[LineID]
           ,[SeqBrdNum]
           ,[pkgInfoFeedPitch]
           ,[favFdrPkg]
           ,[favReelWidth]
           ,[asBodyHeight]
           ,[fsStatus]
           ,[fsPartQty]
           ,[fsTrayDir]
           ,[pnPartComment]
           ,[pnBarcode]
           ,[fsRefList]
           ,[asAsmShape]
           ,[LstUpdateTime]
           ,[PrgName]
			FROM Bas_Machine_Feeder_Report 
			WHERE MAText = 'Bay 12' and Number = @number and Rev = @rev
			
			
		INSERT INTO Bas_Machine_Feeder_Report 
			SELECT [WorkCell]
           ,'BAY 12B'
           ,[Number]
           ,[Rev]
           ,[BoardSide]
           ,[JobRevision]
           ,[fsSetPos]
           ,[fsPartNum]
           ,[fsFdrName]
           ,[pkgInfoPkgType]
           ,[pkgInfoTapeWidth]
           ,[SlotPitch]
           ,[ArrangePos]
           ,[LineID]
           ,[SeqBrdNum]
           ,[pkgInfoFeedPitch]
           ,[favFdrPkg]
           ,[favReelWidth]
           ,[asBodyHeight]
           ,[fsStatus]
           ,[fsPartQty]
           ,[fsTrayDir]
           ,[pnPartComment]
           ,[pnBarcode]
           ,[fsRefList]
           ,[asAsmShape]
           ,[LstUpdateTime]
           ,[PrgName]
			FROM Bas_Machine_Feeder_Report 
			WHERE MAText = 'Bay 12' and Number = @number and Rev = @rev
    END
	
END
GO
