create proc dbo.dt_checkinobject
    @chObjectType  char(4),
    @vchObjectName varchar(255),
    @vchComment    varchar(255)='',
    @vchLoginName  varchar(255),
    @vchPassword   varchar(255)='',
    @iVCSFlags     int = 0,
    @iActionFlag   int = 0,   /* 0 => AddFile, 1 => CheckIn */
    @txStream1     Text = '', /* drop stream   */ /* There is a bug that if items are NULL they do not pass to OLE servers */
    @txStream2     Text = '', /* create stream */
    @txStream3     Text = ''  /* grant stream  */


as

	set nocount on

	declare @iReturn int
	declare @iObjectId int
	select @iObjectId = 0
	declare @iStreamObjectId int

	declare @VSSGUID varchar(100)
	select @VSSGUID = 'SQLVersionControl.VCS_SQL'

	declare @iPropertyObjectId int
	select @iPropertyObjectId  = 0

    select @iPropertyObjectId = (select objectid from dbo.dtproperties where property = 'VCSProjectID')

    declare @vchProjectName   varchar(255)
    declare @vchSourceSafeINI varchar(255)
    declare @vchServerName    varchar(255)
    declare @vchDatabaseName  varchar(255)
    declare @iReturnValue	  int   -- Return value for AddStream
    declare @pos			  int   -- Start position in stream to send to AddStream
    declare @posChange		  int   -- Number of characters being sent to AddStream
    declare @posChangeMax     int   -- Maximum number of characters that will be sent to AddStream
    select @posChangeMax = 255
    declare @truncSpaces      int   -- Number of spaces that will be truncated from the end of the string sent to AddStream
    select @truncSpaces = 0
    -- To be able to use datalength to determine the length of the text in #proclines
    -- @Bytes2Chars will be 1 for ansi 2 for unicode
    declare @Bytes2Chars      int
    select @Bytes2Chars = syscolumns.length/syscolumns.prec
        from sysobjects,syscolumns 
        where 
            sysobjects.name = 'syscomments'
            and sysobjects.id = syscolumns.id
            and syscolumns.name='text'
    declare @vchProcLinePiece varchar(255) -- Piece of the procedure that will be sent to AddStream that will be <= @posChangeMax

    
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSProject',       @vchProjectName   OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSourceSafeINI', @vchSourceSafeINI OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLServer',     @vchServerName    OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLDatabase',   @vchDatabaseName  OUT

    if @chObjectType = 'PROC'
    begin
        if @iActionFlag = 1
        begin
            /* Procedure Can have up to three streams
            Drop Stream, Create Stream, GRANT stream */

            begin tran compile_all

            /* try to compile the streams */
            exec (@txStream1)
            if @@error <> 0 GOTO E_Compile_Fail

            exec (@txStream2)
            if @@error <> 0 GOTO E_Compile_Fail

            exec (@txStream3)
            if @@error <> 0 GOTO E_Compile_Fail
        end

        exec @iReturn = master.dbo.sp_OACreate @VSSGUID, @iObjectId OUT
        if @iReturn <> 0 GOTO E_OAError

        exec @iReturn = master.dbo.sp_OAGetProperty @iObjectId, 'GetStreamObject', @iStreamObjectId OUT
        if @iReturn <> 0 GOTO E_OAError
        
        if @iActionFlag = 1
        begin
            
            declare @iStreamLength int
			
			select @pos=1
			select @iStreamLength = datalength(@txStream2)
			
			if @iStreamLength > 0
			begin
			
				while @pos < @iStreamLength
				begin
						
					-- The following changed between SQL Server 7.0 and SQL Server 2000
					-- sp_OAMethod trims the spaces off of string parameters passed
					-- To resolve problem and be backward compatible, the number of trailing spaces
					-- are saved and pre-pended to the next string to be sent to AddStream
					select @vchProcLinePiece = substring(@txStream2, @pos, @posChangeMax)
					select @vchProcLinePiece = rtrim(@vchProcLinePiece)
					select @posChange = len(@vchProcLinePiece)
                                        if @posChange < 1 GOTO E_Space_Fail
					
					exec @iReturn = master.dbo.sp_OAMethod @iStreamObjectId, 'AddStream', @iReturnValue OUT, @vchProcLinePiece
            		                if @iReturn <> 0 GOTO E_OAError
            		
					select @pos = @pos + @posChange
					
				end
            
				exec @iReturn = master.dbo.sp_OAMethod @iObjectId,
														'CheckIn_StoredProcedure',
														NULL,
														@sProjectName = @vchProjectName,
														@sSourceSafeINI = @vchSourceSafeINI,
														@sServerName = @vchServerName,
														@sDatabaseName = @vchDatabaseName,
														@sObjectName = @vchObjectName,
														@sComment = @vchComment,
														@sLoginName = @vchLoginName,
														@sPassword = @vchPassword,
														@iVCSFlags = @iVCSFlags,
														@iActionFlag = @iActionFlag,
														@sStream = ''
                                        
			end
        end
        else
        begin
        
			-- The following changed between SQL Server 7.0 and SQL Server 2000
			-- sp_OAMethod trims the spaces off of string parameters passed
			-- To resolve problem and be backward compatible, the number of trailing spaces
			-- are saved and pre-pended to the next string to be sent to AddStream
			-- This is done in two places.  Since the stored procedure is stored in 
			-- 4000 character blocks in the syscomments table, the number of trailing spaces
			-- in each record is stored and pre-pended to the next block
			-- Then each 4000 character block is split into ~256 character blocks to be sent
			-- by calling AddStream. The ~256 character blocks are always right trimmed so that 
			-- they never end with a space.
			
			-- Put stored procedure into temp table
			-- iLenTrunc = len of the block after truncating trailing spaces
			-- iLen = len of the block including the trailing spaces
            select colid, len(text) iLenTrunc, datalength(text)/@Bytes2Chars iLen, text
            into #ProcLines
            from syscomments
            where id = object_id(@vchObjectName)
            order by colid
			
            declare @iCurProcLine int  -- Current block of text from stored procedure
            declare @iProcLines int    -- Total number of blocks of text from stored procedure
            select @iCurProcLine = 1 
            select @iProcLines = (select count(*) from #ProcLines)
            while @iCurProcLine <= @iProcLines  -- Loop through each block of the stored procedure 
            begin
                select @pos = 1
                declare @iCurLineSize int        -- Total chars of the block from 1 record from syscomments
                declare @iCurLineSizeTrunc int   -- Total chars of the block with the trailing spaces truncated
                select @iCurLineSize = iLen, @iCurLineSizeTrunc = iLenTrunc 
                from #ProcLines where colid = @iCurProcLine
                
                while @pos <= @iCurLineSizeTrunc   -- Loop through block in <= 255 character blocks
                begin                
                    -- Cut chunk out of current block, size of chunk should be 
                    -- 255 - the number of trailing spaces from previous block from syscomments
                    select @vchProcLinePiece = convert(varchar(255),  -- @posChangeMax
                        substring((select text from #ProcLines where colid = @iCurProcLine),
                                  @pos, @posChangeMax - @truncSpaces ))

                    if len(@vchProcLinePiece) < 1 GOTO E_Space_Fail  -- Fails if @vchProcLinePiece is all spaces
                    -- Set the string increment to the start of the next string to pass to AddStream
                    -- since len() does not count trailing spaces, string will always end with a non-space 
                    select @posChange = len(@vchProcLinePiece)
                    -- pre-pend spaces from previous syscomments block to 
                    -- @vchProcLinePiece (@truncSpaces can only be non-zero first time through the inner loop)
                    -- and rtrim any spaces from @vchProcLinePiece
                    select @vchProcLinePiece = space(@truncSpaces) + rtrim(@vchProcLinePiece)
                    exec @iReturn = master.dbo.sp_OAMethod @iStreamObjectId, 'AddStream', @iReturnValue OUT, @vchProcLinePiece
                    if @iReturn <> 0 GOTO E_OAError
                    -- Set the start of the next string to pass to AddStream
                    select @pos = @pos + @posChange   
                    -- Reset @truncSpaces.  It can only be > 0 the first time though the inner loop
                    select @truncSpaces = 0            
                end
                select @iCurProcLine = @iCurProcLine + 1   -- Go to next record in syscomments
                -- Number of spaces from previous record to pre-pend to next record
                select @truncSpaces = @iCurLineSize - @iCurLineSizeTrunc 
                if (@truncSpaces >= @posChangeMax) GOTO E_Space_Fail 
            end
            drop table #ProcLines

            exec @iReturn = master.dbo.sp_OAMethod @iObjectId,
													'CheckIn_StoredProcedure',
													NULL,
													@sProjectName = @vchProjectName,
													@sSourceSafeINI = @vchSourceSafeINI,
													@sServerName = @vchServerName,
													@sDatabaseName = @vchDatabaseName,
													@sObjectName = @vchObjectName,
													@sComment = @vchComment,
													@sLoginName = @vchLoginName,
													@sPassword = @vchPassword,
													@iVCSFlags = @iVCSFlags,
													@iActionFlag = @iActionFlag,
													@sStream = ''
        end

        if @iReturn <> 0 GOTO E_OAError

        if @iActionFlag = 1
        begin
            commit tran compile_all
            if @@error <> 0 GOTO E_Compile_Fail
        end

    end

CleanUp:
	return

E_Space_Fail:
	if @iActionFlag = 1 rollback tran compile_all
	RAISERROR ('Cannot check in a Stored Procedure that contains more than %d repeated spaces.',16,-1, @posChangeMax)
	goto CleanUp

E_Compile_Fail:
	declare @lerror int
	select @lerror = @@error
	rollback tran compile_all
	RAISERROR (@lerror,16,-1)
	goto CleanUp

E_OAError:
	if @iActionFlag = 1 rollback tran compile_all
	exec dbo.dt_displayoaerror @iObjectId, @iReturn
	goto CleanUp


GO
