CREATE PROCEDURE [dbo].[SP_VersionTracker]
	@ComputerName varchar(20),
	@NTuser varchar(20),
	@CurrentVersion varchar(20),
	@FilePath varchar(254),
	@LastUserName varchar(20),
	@LastLoginTime smalldatetime,
	@Remark varchar(20)
AS
BEGIN
	SET NOCOUNT ON;
	
	if (select count(ComputerName) from  dbo.Sys_VersionTracker where  ComputerName=@ComputerName ) > 0
		UPDATE [dbo].[Sys_VersionTracker]
		SET [ComputerName] = @ComputerName
		  ,[NTuser] = @NTuser
		  ,[CurrentVersion] = @CurrentVersion
		  ,[FilePath] = @FilePath
		  ,[LastUserName]=@LastUserName
		  ,[LastLoginTime]=@LastLoginTime
		  ,[Remark] = @Remark
		WHERE ComputerName=@ComputerName
	else
		INSERT INTO [dbo].[Sys_VersionTracker]
           ([ComputerName]
           ,[NTuser]
           ,[CurrentVersion]
           ,[FilePath]
           ,[LastUserName]
           ,[LastLoginTime]
           ,[Remark])
		VALUES
           (@ComputerName,@NTuser,@CurrentVersion,@FilePath,@LastUserName,@LastLoginTime,@Remark)
END
GO
