
CREATE  PROCEDURE [dbo].[Ep_SP_addNewFeederLog]
	@OrderID nchar(15),
	@WorkCell varchar(25),
	@Number varchar(30),
	@MAText varchar(10),
	@Rev varchar(10),
	@Step nvarchar(10),
	@Op_Text nvarchar(max),
	@HostName nchar(20),
	@NTId nchar(19),
	@UserID nchar(10),
	@Remark nvarchar(500),
	@CntFlag int
AS
	begin
	
	Declare @SlotCnt int
	
	if @CntFlag = 0 
		begin
			set @SlotCnt = 0 
			goto InsertData
		end
	
		if @Step = 'Both'
			begin
				set @SlotCnt = (Select Count(fsSetPos) from Bas_Machine_Feeder_Report where MAText = @MAText and Number = @Number and Rev = @Rev)
			end
		else begin
			set @SlotCnt = (Select Count(fsSetPos) from Bas_Machine_Feeder_Report where MAText = @MAText and Number = @Number and BoardSide = @Step and Rev = @Rev)
		end

	if @SlotCnt = 0 set @Remark = 'Get PartCount from Bas_Machine_Feeder_Report Failed.'
	
InsertData:	
		INSERT INTO [dbo].[Tb_Feeder_Logs]
		   ([OrderID]
		   ,[Step]
		   ,[SlotCnt]
		   ,[Op_Text]
		   ,[OccuredTime]
		   ,[HostName]
		   ,[NTId]
		   ,[UserID]
		   ,[Remark])
		 VALUES(
			@OrderID,
			@Step,
			@SlotCnt,
			@Op_Text,
			GETDATE(),
			@HostName,
			@NTId,
			@UserID,
			@Remark)	
	end
GO
