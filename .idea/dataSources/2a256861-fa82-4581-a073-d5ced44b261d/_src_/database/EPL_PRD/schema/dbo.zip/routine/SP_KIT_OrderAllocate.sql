
--SP_KIT_OrderAllocate  '8,9,10',1,getdate()
CREATE  PROCEDURE [dbo].[SP_KIT_OrderAllocate]

		@OrderIDList varchar(1000),
		@StationID INT,
		@StartFrom datetime,
		@ReturnCode varchar(200)	 = ''	output		
AS
	begin	
		Declare @errormessage varchar(1000)
		if @StationID = 0
			begin
				set @ReturnCode = 'StationID is not valid.'
				raiserror (@ReturnCode,16,1)
				return
			end	

		if @StartFrom < getdate()
			begin
				set @ReturnCode = '此工作站的预计开始时间不可以早于当前时间.'
				raiserror (@ReturnCode,16,1)
				return
			end	

		if @StartFrom < (Select max( ScheduledEndTime) from TB_KIT_ORDER_HEADER where station = @StationID)
			begin
				set @ReturnCode = '此工作站预计时间内已经被安排订单.'
				raiserror (@ReturnCode,16,1)
				return
			end	


		declare @T table (OrderID bigint,seq int)
		declare @ID bigint
		
		 --去掉前导的分隔符
		 while Charindex(',',@OrderIDList,0)=1
		  set @OrderIDList=right(@OrderIDList,len(@OrderIDList)-1)
		 --去掉后面的分隔符
		 while right(@OrderIDList,1)=','
		  set @OrderIDList=left(@OrderIDList,len(@OrderIDList)-1)

			 declare @nIndex int
			 declare @Order int--次序
			 set @Order=1
			 while len(@OrderIDList)>0
			 begin
			  set @nIndex=Charindex(',',@OrderIDList,0)
			  if @nIndex>0
			  begin
			   set @ID=left(@OrderIDList,@nIndex-1)
			   set @OrderIDList=right(@OrderIDList,len(@OrderIDList)-@nIndex)
			  end
			  else
			  begin
			   set @ID=@OrderIDList
			   set @OrderIDList=''
			  end
			  if len(@ID)>0
			  begin
			   insert into @T(OrderID,seq) values(@ID,@Order)
			   set @Order=@Order+1
			  end
			 end
		
		--select orderid from @T
		--return

--BEGIN TRY
--    begin transaction

	declare @KittingPartNum VARCHAR(40),@Kits_Qty float,@Station int,@ScheduledStartTime datetime,@ScheduledEndTime datetime,@UPH float,@TimeCost float,@Seq Int 
	set @Seq = 0	
			
		Declare Cur_Tasks cursor scroll dynamic for                        --游标处理循环写入
							select id,KittingPartNum,Kits_Qty,Station
										,UPH = (Select [UPH(Hr)] FROM TB_KIT_DOC WHERE KittingPartNum = h.KittingPartNum )
										,TimeCost =Kits_Qty/ (Select [UPH(Hr)] FROM TB_KIT_DOC WHERE KittingPartNum = h.KittingPartNum ) * 3600
							from  TB_KIT_ORDER_HEADER as h right outer join @T as t on h.ID = t.OrderID
							order by t.seq asc
							--where id in (select orderid from @T)
		for update-- 定义游标可读写

		open Cur_Tasks                   
		fetch next from Cur_Tasks  into @ID,@KittingPartNum,@Kits_Qty,@Station,@UPH,@TimeCost
		while(@@fetch_status=0)		
		BEGIN
			set @Seq= @Seq +1
			if @seq = 1 begin
				SET @ScheduledStartTime = @StartFrom
				SET @ScheduledEndTime = DATEADD(SECOND, @TimeCost,@ScheduledStartTime)
			end 
			else if @seq >1 begin
				SET @ScheduledStartTime = @ScheduledEndTime
				SET @ScheduledEndTime = DATEADD(SECOND, @TimeCost,@ScheduledStartTime)
			end			
			update dbo.TB_KIT_ORDER_HEADER
			set ScheduledStartTime = @ScheduledStartTime
				 ,ScheduledEndTime = @ScheduledEndTime
				 ,Station=@StationID
				 ,ProgressCode = 306
			WHERE ID = @ID

			fetch next from Cur_Tasks into @ID,@KittingPartNum,@Kits_Qty,@Station,@UPH,@TimeCost								
		end		
	CLOSE Cur_Tasks	
	DEALLOCATE Cur_Tasks

	SELECT * FROM TB_KIT_ORDER_HEADER
	WHERE STATION >0

	--commit transaction
	--END TRY  
	
--	BEGIN CATCH    
--		ROLLBACK TRANSACTION
--    -- Log the error 
--    insert dbo.Application_Error_Log (UserName, ModuleName,     
--            errorNumber, errorSeverity, errorState, errorMessage)
--    values (suser_sname(), 'SP_KIT_OrderAllocate', ERROR_NUMBER(),  
--            ERROR_SEVERITY(), ERROR_STATE(), ERROR_MESSAGE())  
--    RAISERROR (@errormessage, 16,1)
----返回用户定义的错误信息并设系统标志，记录发生错误。

--END CATCH

	set @ReturnCode = 'Allocated successed. ' 
	return
end


GO
