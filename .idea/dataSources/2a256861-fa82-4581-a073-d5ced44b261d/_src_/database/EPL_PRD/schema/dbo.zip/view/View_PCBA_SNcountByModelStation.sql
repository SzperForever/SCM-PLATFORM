CREATE VIEW dbo.View_PCBA_SNcountByModelStation
AS
SELECT     TOP (100) PERCENT Model, Station, COUNT(DISTINCT SN) AS snCount
FROM         dbo.PRO_PCBA_Tracking
GROUP BY Model, Station
ORDER BY Model
GO
