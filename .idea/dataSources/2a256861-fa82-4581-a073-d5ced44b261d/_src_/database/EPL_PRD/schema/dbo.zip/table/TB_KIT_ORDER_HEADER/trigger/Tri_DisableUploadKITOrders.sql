-- =============================================
-- Author:		<Hanson>
-- Create date: <2012-08-08>
-- Description:	<Disable/Enable upload according to the period time appointed>
-- =============================================
CREATE TRIGGER [dbo].[Tri_DisableUploadKITOrders]
   ON  [dbo].[TB_KIT_ORDER_HEADER]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;		            		
	Declare
		 @BuildPlanTime smalldatetime,
		 @msg varchar(550)

	set @BuildPlanTime = (select BuildPlanTime from inserted)
	
		      --All Autopull order need check PLV BOM first except AI pulls .
		      --New rule:AP_FLAG will be updated as '1' if a new SMT Order created. no matter it is belong to internal or exernal warehouse.
    
	--如果需要定时停止服务，则启用如下代码：
    declare @DatePeriod smalldatetime
    set @DatePeriod = getdate()

--如果需要手动停止服务，则启用如下代码：

	if @BuildPlanTime between '2017-09-13 0:00:00' and '2017-09-16 0:00:00' goto normal	
    if @DatePeriod between '2017-09-03 17:00:00' and '2017-09-11 00:00:00'     
	begin		
		rollback tran
		set @msg = 'You are not allowed to upload build plan during this period. 
		ePull is out of service during (2017-09-01 00:00:00--2017-09-11 00:00:00)
		EPull  （BuildPlanTime > 2017-09-13 0:00:00  )does not stop during the service.
		Any unclear please contact with Dai lisong-65141.'
		RAISERROR (@msg, 16, 1)
		return
     end
normal:     
	Return
end
GO
