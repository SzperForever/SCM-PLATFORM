-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-4-10,>
-- Description:	<Send a batch order list to supplier team,,>
-- =============================================
CREATE PROCEDURE  [dbo].[SP_ALERT_Order_M_BOM_Notin_S_BOM]        
	-- Add the parameters for the stored procedure here
	@AlertName nvarchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
		
  	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	set @Rcnt = 0
	set @Rcnt =(Select count(0) from V_RMA_MFG_SAP_vs_EPL)
	
	if @Rcnt = 0 or @@ERROR <> 0 begin
		raiserror ('Unknown Error Detected.',16,1)
		return
	end
	
	
	--set @Rcnt =(SELECT COUNT(0) from [View_Shipping_MergeBox] WHERE Mtrl_Grp IN (@Mtrl_Grp) )	
	--if @Rcnt = 0 or @@ERROR <> 0 begin
	--	print 'No records return from the view.'
	--	return
	--end
	
	SET @tableHTML = 
		N'<font color=#FF0000><H1> Dear IA：</H1></font>' +
		N'<font color=#FF0000><H1>下表显示的是MachineBOM出现的料号未出现在SAPBOM。</H1></font>' +
		N'<font color=#FF0000><H1> 非常重要，可以避免错料。</H1></font>' +
		
		
	    --N'<H3>RMA_INV_COMPARE</H3>' +
		N'<table border="1">' +
		N'<tr><th>[OrderID]</th><th>[WorkCell]</th><th>[MachineBOM]</th><th>[SAPBOM]</th><th>[Rev]</th><th>[BayNum]</th><th>[CurrentPlace]</th><th>[fsPartNum]</th><th>[pkgInfoTapeWidth]</th><th>[CreateBy]</th></tr>' +
		CAST ( ( SELECT  td = [OrderID],'',
						 td = [WorkCell],'',
						 td = [MachineBOM],'',
                         td = ISNULL([SAPBOM],0),'',
                         td = [Rev],'',
                         td = [BayNum],'',
                         td = [CurrentPlace],'',
                         td = [fsPartNum],'',
                         td = [pkgInfoTapeWidth],'',
                         td = [CreateBy],''
  FROM [EPL_PRD].[dbo].[V_Order_M_BOM_Notin_S_BOM]  
  WHERE [WorkCell] NOT LIKE '%CN07%'
  ORDER BY [OrderID]
				           
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		
		
	   N'<font color=#FF0000>Do not reply to this mail since it is an automatical notification message.</font>';
       EXEC msdb.dbo.sp_send_dbmail 
	--@profile_name ='EpullSqlMail',
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;
END
GO
