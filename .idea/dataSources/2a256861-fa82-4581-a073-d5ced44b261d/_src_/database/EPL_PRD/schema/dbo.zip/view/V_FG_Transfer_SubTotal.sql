CREATE VIEW dbo.V_FG_Transfer_SubTotal
AS
SELECT     TOP (100) PERCENT a.RegDate, a.Movement, b.Matlgroup, a.DocNo, a.PartNo, a.Description, SUM(a.Qty) AS Qty, a.AddWho, a.empID
FROM         dbo.TB_BFscan AS a LEFT OUTER JOIN
                      dbo.BAS_SKU AS b ON a.PartNo = b.Material
WHERE     (b.Plant <> 'cn07') AND (a.AddTime < GETDATE())
GROUP BY a.RegDate, a.Movement, b.Matlgroup, a.DocNo, a.PartNo, a.Description, a.AddWho, a.empID
ORDER BY a.RegDate, a.PartNo
GO
