CREATE VIEW dbo.VIEW_OrderCountByBay
AS
SELECT     TOP (100) PERCENT BayNum,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details
                            WHERE      (CurrentPlace = 'StockRoom') AND (StockSts = 'NotStarted') AND (BayNum = a.BayNum) AND (OrderStatus = 'Open') AND 
                                                   (FlagGroup = 'SMT')) AS NotStarted,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_6
                            WHERE      (CurrentPlace = 'StockRoom') AND (StockSts = 'Picking') AND (BayNum = a.BayNum) AND (OrderStatus = 'Open') AND (FlagGroup = 'SMT')) 
                      AS StkInprogress,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_5
                            WHERE      (CurrentPlace = 'LVHM') AND (StockSts = 'EndPicking') AND (LVHMsts = 'Received') AND (BayNum = a.BayNum) AND 
                                                   (OrderStatus = 'Open') AND (FlagGroup = 'SMT')) AS LVInprogress,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_4
                            WHERE      (CurrentPlace = 'LVHM') AND (StockSts = 'EndPicking') AND (LVHMsts = 'Prepared') AND (BayNum = a.BayNum) AND 
                                                   (OrderStatus = 'Open') AND (FlagGroup = 'SMT')) AS LVCompleted,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_3
                            WHERE      (CurrentPlace = 'Online') AND (StockSts = 'EndPicking') AND (LVHMsts = 'SentToBuild') AND (BayNum = a.BayNum) AND 
                                                   (OrderStatus = 'Open') AND (FlagGroup = 'SMT')) AS SentToMFG,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_2
                            WHERE      (CurrentPlace = 'RTS') AND (StockSts = 'EndPicking') AND (LVHMsts = 'SentToBuild') AND (BayNum = a.BayNum) AND 
                                                   (OrderStatus = 'Open') AND (FlagGroup = 'SMT')) AS RTSing,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_1
                            WHERE      (CurrentPlace = 'IA') AND (StockSts = 'EndPicking') AND (LVHMsts = 'SentToBuild') AND (BayNum = a.BayNum) AND (OrderStatus = 'Open') 
                                                   AND (FlagGroup = 'SMT')) AS WaitingToBeClosed
FROM         dbo.Tb_Order_Details AS a
WHERE     (FlagGroup = 'SMT') AND (OrderStatus = 'Open')
GROUP BY BayNum
ORDER BY BayNum
GO
