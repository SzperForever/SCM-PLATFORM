CREATE PROCEDURE [dbo].[sp_ReplaceOrderID]
	@OldOrderID varchar(12),
	@OldSloc varchar(4),
	@NewOrderID Varchar(12),
	@NewSloc varchar(4)
AS
BEGIN
	SET NOCOUNT ON;
	update Tb_Order_Details 
	SET OrderID = @NewOrderID ,Sloc =@NewSloc ,Remark = Remark + 'Replaced:' + @OldOrderID + ' with new OrderID:' + @NewOrderID 
	WHERE OrderID = @OldOrderID AND Sloc = @OldSloc AND FlagGroup = 'SMT' and OrderStatus = 'Open'
	
	UPDATE Tb_PreparedList 
	SET OrderID = @NewOrderID,Sloc =@NewSloc ,PreparedID = @NewOrderID,Remark = 'Replaced:' + @OldOrderID + ' with new OrderID:' + @NewOrderID 
	WHERE OrderID = @OldOrderID 
	
END
GO
