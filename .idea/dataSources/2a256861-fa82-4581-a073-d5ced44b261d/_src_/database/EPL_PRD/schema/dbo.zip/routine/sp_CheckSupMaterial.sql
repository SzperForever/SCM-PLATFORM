
CREATE PROCEDURE [dbo].[sp_CheckSupMaterial]
		@Material varchar(20),
		@BU varchar(10),
		@Assy# varchar(50),
		@PlanQty int,
		@BuildDate date		,
		@sloc varchar(4)
AS
BEGIN
	SET NOCOUNT ON;				
			SELECT		 a.BU,
						 a.Assy#,
						 a.[Plan Qty], 
						 a.[Build Date], 
						 b.[Component P/N] AS Material, 
						 ISNULL(b.[Qty Per] * a.[Plan Qty], 0.000) AS BPDemand,
						 ISNULL(SUM(c.Unrestricted), 0.000) AS OnlineInventory, 
						 ISNULL(b.[Qty Per] * d.WIP_Qty, 0.000) AS WIPDemand, 
						 ISNULL(SUM(c.Unrestricted) - b.[Qty Per] * d.WIP_Qty, 0.000) AS ExcessQty, 
						 ISNULL((SUM(c.Unrestricted) - (b.[Qty Per] * d.WIP_Qty)-(b.[Qty Per] * a.[Plan Qty])),ISNULL(b.[Qty Per] * a.[Plan Qty], 0.000)) AS RemaingQty, 
						 ISNULL(SUM(e.Qty), 0.000) AS IssuedQty
			FROM         dbo.Sup_BuildPlan AS a left JOIN
						 dbo.Sup_BOM AS b ON a.[Assy#] = b.[Parent P/N] left JOIN
						 dbo.Sup_OnlineInventory AS c ON c.Material = b.[Component P/N] inner JOIN
						 dbo.Sup_WIP AS d ON d.[Assy#] = a.[Assy#] AND d.[Assy#] = b.[Parent P/N] AND  
						 d.BU = a.BU left JOIN
						 dbo.SUP_PullListHistory AS e ON e.[Assy#] = a.[Assy#] AND e.BU = a.BU AND e.[Plan Qty] = a.[Plan Qty] AND 
						 e.PartNum = b.[Component P/N] AND e.PickFlag = 1 AND c.SLoc = e.Sloc 		
			where b.[Component P/N] = @Material and a.[Build Date]=@BuildDate and a.Assy# =@Assy# and a.[Plan Qty]=@PlanQty and a.BU = @BU and c.SLoc =@sloc	
			GROUP BY a.BU, a.Assy#, a.[Build Date], a.[Plan Qty], b.[Component P/N], b.[Qty Per],d.WIP_Qty 
			ORDER BY Material,a.[Build Date] asc
		
END
GO
