
CREATE PROCEDURE sp_PCBA_GroupByModelandStation

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		DECLARE @s NVARCHAR(1000)
		SET @s='select [Model]'
		Select  @s=@s+','+QUOTENAME([Station])+'=sum(case when [Station]='''+[Station]+''' then [snCount] else 0 end)'
		from View_PCBA_SNcountByModelStation 
		GROUP BY [Station]
		EXEC(@s+' from View_PCBA_SNcountByModelStation group by [Model]')
END
GO
