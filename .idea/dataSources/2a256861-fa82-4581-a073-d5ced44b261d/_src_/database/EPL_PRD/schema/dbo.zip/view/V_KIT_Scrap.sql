
CREATE VIEW [dbo].[V_KIT_Scrap]
AS
SELECT        TOP (100) PERCENT h.OrderID, h.KittingPartNum, h.Kits_Qty, h.FinalQty,
                             (SELECT        SUM(Qnty) AS Expr1
                               FROM            dbo.TB_KIT_RIPE_HISTORY
                               WHERE        (OrderID = h.OrderID)) AS ActualQty, h.FailedQty_Processing, s.Component, s.[Qty Per], s.[Qty Per] * (h.Kits_Qty -
                             (SELECT        SUM(Qnty) AS Expr1
                               FROM            dbo.TB_KIT_RIPE_HISTORY AS TB_KIT_RIPE_HISTORY_1
                               WHERE        (OrderID = h.OrderID))) AS ScrapQnty
FROM            dbo.TB_KIT_ORDER_HEADER AS h LEFT OUTER JOIN
                         dbo.Bas_SAPbom AS s ON h.KittingPartNum = s.[Assembly Name]
WHERE        (h.ProgressCode >= 312)
ORDER BY h.OrderID DESC

GO
