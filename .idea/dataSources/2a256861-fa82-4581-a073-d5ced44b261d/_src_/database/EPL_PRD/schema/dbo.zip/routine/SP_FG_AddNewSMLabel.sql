-- =============================================
-- Author:		Hanson
-- Create date: 2015.4.27
-- Description:	Add a Shipping Mark Lable
-- =============================================
CREATE PROCEDURE [dbo].[SP_FG_AddNewSMLabel]
	-- Add the parameters for the stored procedure here

	 @SRid bigint
	,@Length INT
    ,@Width INT
    ,@Height INT
    ,@GrossWeight Float
    ,@NetWeight Float
	,@CreateBy nchar(13)
	,@SMType int  -- by plt or by ctn : 0 = ctn, 1 = plt
	,@EstimatePkgCnt int
	,@ReturnCode int = 1 output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	Declare @SRStatus nchar(3),@OrderStatus nchar(3),@ErrMsg varchar(500),@Rcnt int,@SPStatus nchar(3),@LbID int,@PkgCnt int

--Validation Process

	set @Rcnt = (Select count(*) from [dbo].[TB_FG_SM_Details] where [SRid] = @SRid )

	if @EstimatePkgCnt =0 
		begin
			set @ErrMsg = 'Invalid EstimatePkgCnt.(预计唛头包装数量无效，不可以为0。)'
			raiserror (@ErrMsg,16,1)
			return
		end

	if @Rcnt = 0 begin
		update [dbo].[TB_FG_SR_Header] 
		set [EstimatePkgCnt] =@EstimatePkgCnt ,IsPlt = @SMType
		WHERE [SRid] = @SRid 
	end 

	set @OrderStatus = (Select SR_OrderStatus  from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
		if @OrderStatus <> '200' begin
			set @ErrMsg = 'Process denied since SR Order status is not [Open]. （由于SR订单状态未开启，拒绝进行下一步操作。）'
			raiserror (@ErrMsg,16,1)
			return
		end

	set @SRStatus = (Select [SR_Status] from [dbo].[TB_FG_SR_Header] where [SRid] = @SRid)
	if @SRStatus <> '901' begin
		set @ErrMsg = 'Process denied since this SR is not activated. （由于SR订单状态未被激活，拒绝进行下一步操作。）'
		raiserror (@ErrMsg,16,1)
		return
	end

	set @SPStatus = (Select [SR_SP_Status] from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
	if @SPStatus not IN ('904','905') begin
		set @ErrMsg = 'Invalid SR Stauts . (该SR订单状态不允许执行此操作。)'
		raiserror (@ErrMsg,16,1)
		return
	end

	set @PkgCnt = (Select [EstimatePkgCnt] from [dbo].[TB_FG_SR_Header] where [SRid] = @SRid )
	if @Rcnt  >= @PkgCnt begin
		set @ErrMsg = 'Shipping mark label count met maxmum number.(唛头标签数量已经达到最大允许数量，不可继续增加。)'
		raiserror (@ErrMsg,16,1)
		return
	end
	
--Begin Process
	
	if @SMType = 0 begin
			set @ReturnCode =0
			return -- 如果是箱出货，则在此退出，因为插入唛头动作在扫描料号信息后同步进行
		end

	SET ANSI_WARNINGS OFF  --加这句话的原因是为了防止有NULL值 返回时，系统报不相干的警告信息

	if (select COUNT(*)
		from dbo.View_FG_SM_Blanklb
		where SRid = @SRid AND PkgCnt =0) > 0
		begin
			set @ErrMsg = 'Please finish blank lable(s) before adding a new one.(请扫描完现有的空唛头再尝试添加。)'
			raiserror (@ErrMsg,16,1)
			return		
		end

	
	INSERT INTO [dbo].[TB_FG_SM_Details]
           ([SRid]
		   ,[lbid]
           ,[CreateBy]
           ,[CreateTime]
           ,[Length]
           ,[Width]
           ,[Height]
           ,[GrossWeight]
           ,[NetWeight]
           ,[PrintFlag]
           ,[ScanFlag]
		   ,[SMType])
     VALUES
           (@SRid 
		   ,@Rcnt+1 
		   ,@CreateBy
		   ,Getdate()
		   ,@Length
		   ,@Width 
		   ,@Height
		   ,@GrossWeight
		   ,@NetWeight
		   ,0
		   ,0
		   ,@SMType)

	if @@ERROR = 0 begin
		set @ReturnCode =0
		--update [TB_FG_SR_Header]
		--set SR_SP_Status = '905',MPPickingTime_End = GETDATE()
		--where SRid = @SRid and SR_SP_Status = '904'

		update [dbo].[TB_FG_MP_Details]
		set [SR_MP_Status] = '905', MP_Complete_Time = getdate()
		where SRid = @SRid	
	end
	else
		begin
			set @ReturnCode =1 
			return
		end

		--if @PkgCnt =@LbID exec SP_FG_StartPGI @SRid  -- 如果添加的标签序号等于定义的包装数量，则判断为结束，进行扣PGI操作。
END


--CodeGroup	Code	Chinese_DESC	English_DESC	CodeGroup_Desc
--57	9         	900       	创建订单	SRNotActivated	SR_Status
--58	9         	901       	激活订单	SRActivated	SR_Status
--59	9         	902       	未创建拣货单	MPNotCreated	SR_SP_Status
--60	9         	903       	拣货单创建	MPCreated	SR_SP_Status
--61	9         	904       	拣货中	MPPicking	SR_SP_Status
--62	9         	905       	打印唛头中	PrintShippingMark	SR_SP_Status
--63	9         	906       	等待PGI中	PGI NotStarted	SR_SP_Status
--64	9         	907       	扣PGI中	PGI InProgress	SR_SP_Status
--65	9         	908       	待装车	TruckNotLoaded	SR_SP_Status
--66	9         	909       	发货中	TruckLoading	SR_SP_Status
--67	9         	910       	已发货	ShippedOut	SR_SP_Status

--200  open
--201  closed
--202  cancel
--203  hold
--204  activated
GO
