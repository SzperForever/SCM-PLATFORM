CREATE  PROCEDURE [dbo].[AddNewPCBA]
	@WorkCell varchar(25),
	@Model varchar(30),
	@SN Varchar(11),
	@Station varchar(10),
	@HMPPartNo varchar(20),
	@HMPGRN Varchar(18),
	@AddTime smalldatetime,
	@AddWho varchar(10),
	@Birthday smalldatetime,
	@Remark varchar(50)
           
AS
begin
	SET NOCOUNT ON;
	INSERT INTO [dbo].[PRO_PCBA_Tracking]
           ([WorkCell]
           ,[Model]
           ,[SN]
           ,[Station]
           ,[HMPPartNo]
           ,[HMPGRN]
           ,[AddTime]
           ,[AddWho]
           ,[birthday]
           ,[Remark])
     VALUES(@Workcell,@Model,@SN,@Station,@HMPPartNo,@HMPGRN,@AddTime,@AddWho,@birthday,@Remark)
end
GO
