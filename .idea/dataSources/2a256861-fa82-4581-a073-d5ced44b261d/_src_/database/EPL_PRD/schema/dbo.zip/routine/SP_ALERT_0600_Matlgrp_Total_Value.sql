-- =============================================
-- Author:		DAILS	
-- Create date: 2017-04-21
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_ALERT_0600_Matlgrp_Total_Value] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
		    ,@link nvarchar(max)
		    
	set @AlertName = '0600_Matlgrp_Total_Value'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	--set @Rcnt = 0
	--set @Rcnt =(select COUNT(distinct PullListNo) 
	--		from Tb_Order_Details 
	--		where DATEDIFF(Minute,BuildPlanTime, GETDATE())> 2880 and OrderStatus = 'Open' and ConditionalFormat <> 'NotStarted' and FlagGroup = 'MI' and Ordertype = 'MIPull')
	--if @Rcnt > 0
	
	if @Rcnt = 0 or @@ERROR <> 0 begin
		return
	end
   
	SET 
	
	@tableHTML =
	  	N'<font color=#FF0000><H1> 0600_Matlgrp_Total_Value</H1></font>' +
	  	
		N'<table border="1">' +
	    N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
		N'<tr><th>MaterialGroup</th><th>COUNT_PN</th><th>Total_Value</th><th>COUNT_PN>2years </th><th>Value>2years </th></tr>' +
	
		CAST ( (SELECT
                         td = [MaterialGroup],'',
                         td = COUNT_PN,'',
                         td = convert(varchar(30),cast(Total_Value as money),1),'',
                         td = COUNT_PN_2,'',
                         td = convert(varchar(30),cast(Total_Value_2 as money),1),''
                         
FROM(                      
SELECT  a.MaterialGroup
		, A.COUNT_PN
		, A.Total_Value		
		,CASE WHEN (B.COUNT_PN)IS NULL THEN '0' ELSE (B.COUNT_PN) END AS COUNT_PN_2	
		,CASE WHEN (B.Total_Value)IS NULL THEN '0' ELSE (B.Total_Value) END AS Total_Value_2  
FROM         (SELECT     TOP (100) PERCENT MaterialGroup, COUNT(GRN) AS COUNT_PN, SUM(Quantity * UnitPrice) AS Total_Value
                       FROM          SHASMESQL01.Warehouse.dbo.WH_GRNTracebility AS WH_GRNTracebility_2
                       WHERE      (Active = '1') AND (SLoc = '0600')
                       AND ([StorageBin] NOT IN (
							'8FODC-1G1',
							'8FODC-1G2',
							'8FODC-2G1',
							'8FODC-2G2',
							'8FODC-3G1',
							'8FODC-3G2',
							'ODC-S-12D1',
							'ODC-S-17B2',
							'ODC-S-17B3',
							'ODC-S-17C1',
							'ODC-S-17C2',
							'ODC-S-17C3',
							'ODC-S-17D1',
							'ODC-S-17D2',
							'ODC-S-17D3',
							'ODC-S-17D4',
							'ODC-S-17D5',
							'ODC-S-17D6',
							'ODC-S-17D7'
							))
                       GROUP BY MaterialGroup
                       ORDER BY Total_Value DESC) AS A LEFT OUTER JOIN
                          (SELECT     TOP (100) PERCENT MaterialGroup, COUNT(GRN) AS COUNT_PN, SUM(Quantity * UnitPrice) AS Total_Value
                            FROM          SHASMESQL01.Warehouse.dbo.WH_GRNTracebility AS WH_GRNTracebility_1
                            WHERE      (Active = '1') AND (SLoc = '0600') AND (DATEDIFF(DD, GETDATE(), CASE WHEN [SLED] IS NULL THEN '12-31-9999' ELSE [SLED] END) < '-730')
                              AND [StorageBin] NOT IN (
							'8FODC-1G1',
							'8FODC-1G2',
							'8FODC-2G1',
							'8FODC-2G2',
							'8FODC-3G1',
							'8FODC-3G2',
							'ODC-S-12D1',
							'ODC-S-17B2',
							'ODC-S-17B3',
							'ODC-S-17C1',
							'ODC-S-17C2',
							'ODC-S-17C3',
							'ODC-S-17D1',
							'ODC-S-17D2',
							'ODC-S-17D3',
							'ODC-S-17D4',
							'ODC-S-17D5',
							'ODC-S-17D6',
							'ODC-S-17D7')
                            GROUP BY MaterialGroup
                            ORDER BY Total_Value DESC) AS B ON A.MaterialGroup = B.MaterialGroup )as t
                             ORDER BY Total_Value DESC
    
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +	 
  
     N'</table>' +         
     	N'<font color=#FF0000><H1> 0600_VEN_Matlgrp_Total_Value</H1></font>' +
		N'<table border="1">' +
	    N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
		N'<tr><th>MaterialGroup</th><th>COUNT_PN</th><th>Total_Value</th><th>COUNT_PN>2years </th><th>Value>2years </th></tr>' +
	
		CAST ( (SELECT
                         td = [MaterialGroup],'',
                         td = COUNT_PN,'',
                         td = convert(varchar(30),cast(Total_Value as money),1),'',
                         td = COUNT_PN_2,'',
                         td = convert(varchar(30),cast(Total_Value_2 as money),1),''
                         
FROM(                      
SELECT  a.MaterialGroup
		, A.COUNT_PN
		, A.Total_Value		
		,CASE WHEN (B.COUNT_PN)IS NULL THEN '0' ELSE (B.COUNT_PN) END AS COUNT_PN_2	
		,CASE WHEN (B.Total_Value)IS NULL THEN '0' ELSE (B.Total_Value) END AS Total_Value_2  
FROM         (SELECT     TOP (100) PERCENT MaterialGroup, COUNT(GRN) AS COUNT_PN, SUM(Quantity * UnitPrice) AS Total_Value
                       FROM          SHASMESQL01.Warehouse.dbo.WH_GRNTracebility AS WH_GRNTracebility_2
                       WHERE      (Active = '1') AND (SLoc = '0600')
                       AND ([StorageBin]  IN (
							'8FODC-1G1',
							'8FODC-1G2',
							'8FODC-2G1',
							'8FODC-2G2',
							'8FODC-3G1',
							'8FODC-3G2',
							'ODC-S-12D1',
							'ODC-S-17B2',
							'ODC-S-17B3',
							'ODC-S-17C1',
							'ODC-S-17C2',
							'ODC-S-17C3',
							'ODC-S-17D1',
							'ODC-S-17D2',
							'ODC-S-17D3',
							'ODC-S-17D4',
							'ODC-S-17D5',
							'ODC-S-17D6',
							'ODC-S-17D7'
							))
                       GROUP BY MaterialGroup
                       ORDER BY Total_Value DESC) AS A LEFT OUTER JOIN
                          (SELECT     TOP (100) PERCENT MaterialGroup, COUNT(GRN) AS COUNT_PN, SUM(Quantity * UnitPrice) AS Total_Value
                            FROM          SHASMESQL01.Warehouse.dbo.WH_GRNTracebility AS WH_GRNTracebility_1
                            WHERE      (Active = '1') AND (SLoc = '0600') AND (DATEDIFF(DD, GETDATE(), CASE WHEN [SLED] IS NULL THEN '12-31-9999' ELSE [SLED] END) < '-730')
                              AND [StorageBin]  IN (
							'8FODC-1G1',
							'8FODC-1G2',
							'8FODC-2G1',
							'8FODC-2G2',
							'8FODC-3G1',
							'8FODC-3G2',
							'ODC-S-12D1',
							'ODC-S-17B2',
							'ODC-S-17B3',
							'ODC-S-17C1',
							'ODC-S-17C2',
							'ODC-S-17C3',
							'ODC-S-17D1',
							'ODC-S-17D2',
							'ODC-S-17D3',
							'ODC-S-17D4',
							'ODC-S-17D5',
							'ODC-S-17D6',
							'ODC-S-17D7')
                            GROUP BY MaterialGroup
                            ORDER BY Total_Value DESC) AS B ON A.MaterialGroup = B.MaterialGroup )as t
                             ORDER BY Total_Value DESC
    
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +	 
  
  N'</table>' + 
  N'<table border="1">' +

       	N'<tr><th>VEN_BIN</th></tr>' +   
     	CAST ((  SELECT
                         td = [StorageBin],''                                      
                         
FROM( 
SELECT 						     *
  FROM          SHASMESQL01.Warehouse.dbo.WH_GRNTracebility
                       WHERE      (Active = '1') AND (SLoc = '0600')
                       AND ([StorageBin]  IN (
							'8FODC-1G1',
							'8FODC-1G2',
							'8FODC-2G1',
							'8FODC-2G2',
							'8FODC-3G1',
							'8FODC-3G2',
							'ODC-S-12D1',
							'ODC-S-17B2',
							'ODC-S-17B3',
							'ODC-S-17C1',
							'ODC-S-17C2',
							'ODC-S-17C3',
							'ODC-S-17D1',
							'ODC-S-17D2',
							'ODC-S-17D3',
							'ODC-S-17D4',
							'ODC-S-17D5',
							'ODC-S-17D6',
							'ODC-S-17D7'))) AS T
							group by [StorageBin]
				 FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +	 
  
  N'</table>' + 


	'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';
    
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END

GO
