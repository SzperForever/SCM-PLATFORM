-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2013/10/19>
-- Description:	<Load Directory of XML Files>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Machine_Feeder_LoadXMLDirectory] 
	-- Add the parameters for the stored procedure here
	@Path nvarchar(500),
	@LogFileName nvarchar(1000)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @Str varchar(2000)
	Declare @ParentDirTree varchar(1000) = @path + '\Resource'
    -- Insert statements for procedure here
	IF RIGHT(@Path, 1) <> '\'
	SET @Path = @Path + '\'

	IF OBJECT_ID('tempdb..#') IS NOT NULL
	DROP TABLE #

	CREATE TABLE #(
				id int IDENTITY,
				directory nvarchar(1000),
				depth int,
				IsFile bit)
				
	INSERT # EXEC master.dbo.xp_dirtree 
			@path = @path,
			@depth = 0,
			@file = 1
	
	DECLARE @depth int, @depthMax int
	UPDATE # SET directory = @Path + directory 	WHERE depth = 1
	SELECT 	@depth = 2,	@depthMax = MAX(depth) FROM #

	WHILE @depth <= @depthMax
	BEGIN
		UPDATE A SET directory = (SELECT TOP 1 directory 
								  FROM # 
								  WHERE depth = @depth - 1 AND IsFile = 0 AND id < A.id 
								  ORDER BY id DESC ) + N'\' + directory
		FROM # A WHERE depth = @depth

		SET @depth= @depth + 1
	END
	SELECT * FROM #
	Delete from dbo.res_xml_dir_tree
	set @Str = '[SP_Machine_Feeder_LoadXMLDirectory]:' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Truncated table: res_xml_dir_tree'
	EXEC p_Writefile @LogFileName, @Str
	
	insert into dbo.res_xml_dir_tree (directory,depth,IsFile) 
		select directory,depth,IsFile 
		from # 
		where IsFile = 1 and directory like '%FeederReportUnit%' and directory not like '%Failure%'
	
	set @Str = '[SP_Machine_Feeder_LoadXMLDirectory]:' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Inserted' + STR(@@rowcount) + ' records of path lists to table: res_xml_dir_tree'
	EXEC p_Writefile @LogFileName, @Str
	
	SELECT * from dbo.res_xml_dir_tree
	
	--截取相关字段写入对应列
		update dbo.Res_XML_Dir_Tree 
		set --Project = dbo.GetStrPara(Directory,3,'\') ,
			MAText = dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),1,'_'),
			--MAText = Left((dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),1,'_')),3)+SPACE(1)+ SUBSTRING((select dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),1,'_')),4,LEN(Left((select dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),1,'_')),3))-3),
			Number = LEFT(RTRIM(dbo.GetStrPara(Directory,2,'_')),LEN(RTRIM(DBO.GETSTRPARA(DIRECTORY,2,'_')))-1),
			Rev = dbo.GetStrPara(Directory,3,'_'),
			BoardSide = dbo.GetStrPara(dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),4,'_'),1,'-'),
			JobRevision = dbo.GetStrPara(dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),4,'_'),2,'-'),
			UpDir = left(Directory,len(directory)-len(dbo.GetStrPara(Directory,5,'\'))-1),
			ParentFolder = dbo.GetStrPara(Directory,4,'\') ,
			ParentDirTree = @ParentDirTree
		where depth = 2
		
		update dbo.Res_XML_Dir_Tree 
		set --Project = dbo.GetStrPara(Directory,3,'\') ,
			MAText = dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),1,'_'),
			--MAText = Left((dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),1,'_')),3)+SPACE(1)+ SUBSTRING((select dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),1,'_')),4,LEN(Left((select dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),1,'_')),3))-3),
			Number = LEFT(RTRIM(dbo.GetStrPara(Directory,2,'_')),LEN(RTRIM(DBO.GETSTRPARA(DIRECTORY,2,'_')))-1),
			Rev = dbo.GetStrPara(Directory,3,'_'),
			BoardSide = dbo.GetStrPara(dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),4,'_'),1,'-'),
			JobRevision = dbo.GetStrPara(dbo.GetStrPara(dbo.GetStrPara(Directory,4,'\'),4,'_'),2,'-'),
			UpDir = left(Directory,len(directory)-len(dbo.GetStrPara(Directory,5,'\'))-1),
			ParentFolder = dbo.GetStrPara(Directory,4,'\') ,
			ParentDirTree = @ParentDirTree 
		where depth = 3
		
		set @Str = '[SP_Machine_Feeder_LoadXMLDirectory]:' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Updated columns value base on the folder information to table.'
		EXEC p_Writefile @LogFileName, @Str
	
	    --SELECT * from dbo.res_xml_dir_tree
	
END
GO
