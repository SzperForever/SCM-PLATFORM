CREATE VIEW dbo.View_Shipping_Movement
AS
SELECT     TOP (100) PERCENT a.PartNo, a.Qty, a.AddTime, a.Movement, b.Matlgroup, DATEPART(YY, a.AddTime) AS YYNUM, DATEPART(MM, a.AddTime) AS MMNUM, 
                      DATEPART(DD, a.AddTime) AS DDNUM
FROM         dbo.TB_BFscan AS a INNER JOIN
                      dbo.BAS_SKU AS b ON a.PartNo = b.Material
GROUP BY a.PartNo, a.Qty, a.AddTime, a.Movement, b.Matlgroup, DATEPART(YY, a.AddTime), DATEPART(MM, a.AddTime), DATEPART(DD, a.AddTime)
ORDER BY YYNUM, MMNUM, DDNUM
GO
