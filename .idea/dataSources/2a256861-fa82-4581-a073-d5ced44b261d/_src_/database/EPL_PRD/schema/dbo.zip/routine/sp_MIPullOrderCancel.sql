CREATE PROCEDURE [dbo].[sp_MIPullOrderCancel]
	@PullListNo varchar(9),
	@CancelBy varchar(10),
	@Reason varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	declare @Msg varchar(200),@MailSubj  varchar(100),@Rec_List nvarchar(2000)
	
	update Tb_Order_Details set Remark = Remark + '/OrderCancelation is proceed. Canceled by:' + @CancelBy + ',Reason:' + @reason , OrderStatus = 'Cancel',PullStatus = 'Cancel',CancelTime =GETDATE() where left(PullListNo,9) = left(@PullListNo,9) and OrderType = 'MIPull' and FlagGroup = 'MI'
	select @Msg= 'MI PullListNo:' + @PullListNo + ' was canceled By:' + @CancelBy + '!The reason marked is :' + @reason + ' Total ' + ltrim(STR(@@ROWCOUNT)) + ' Items affected. Please be noticed.'
	set  @MailSubj =(select Subject from Cfg_DBmail where AlertName  = 'MIOrderCancelation')
	set @Rec_List = (select recipients  from Cfg_DBmail where AlertName  = 'MIOrderCancelation')
	
	EXEC msdb.dbo.sp_send_dbmail 
	@profile_name ='EpullSqlMail',
	@recipients = @Rec_List,
	@subject = @MailSubj,
	@body =@Msg
ENd
GO
