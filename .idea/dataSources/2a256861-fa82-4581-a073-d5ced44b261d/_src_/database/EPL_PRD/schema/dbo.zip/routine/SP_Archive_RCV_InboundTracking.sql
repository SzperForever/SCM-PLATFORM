-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-11-15>
-- Description:	<Remove RCV Inbound items to history db>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Archive_RCV_InboundTracking]
	-- Add the parameters for the stored procedure here
	AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
   Declare @P_Date smalldatetime,
			@Archive_DaysAhead int,
			@Archive_Enable bit,
			@ArchivedRowCnt int,
			@Err_Num int,
			@Return_Code VARCHAR(1000)
			
	set @Archive_Enable =(Select Archive_Enable from tbconfig where YesForUse = 'Y')
	IF @Archive_Enable is null or @Archive_Enable = 0
		BEGIN
			set @Err_Num = 99
			set @Return_Code= 'Archive_Enable in tbconfig is configured as disabled or unconfigured. Err_Num:' + STR(@err_num)
			Raiserror (@Return_Code,16,1)
			Return
		END
		
	set @Archive_DaysAhead = (Select Archive_DaysAhead from tbconfig where yesforuse = 'Y')
	if @Archive_DaysAhead is null 
			BEGIN
				set @Err_Num = 98
				set @Return_Code= 'Archive_DaysAhead is unconfigured. Err_Num:'+ STR(@err_num)
				Raiserror (@Return_Code,16,1)
				Return
			END
			
	Set @P_Date = (select dateadd(day,-@Archive_DaysAhead,GETDATE()))  
	--print @P_Date
    -- Insert statements for procedure here
    
	insert into EPL_HST.dbo.TB_RCV_InboundTracking 
	SELECT *
	FROM [dbo].TB_RCV_InboundTracking
	where AddTime < @P_Date and ItemStatus  <> 'Open'
	
	set @ArchivedRowCnt = @@ROWCOUNT 
	
		if @@Error<>0
			begin
				set @Return_Code = STR(@@ERROR) + ',System Error when inserting the data into history database.'
				Raiserror (@Return_Code,16,1)
				return
			end
	
	Delete from TB_RCV_InboundTracking  where AddTime < @P_Date and ItemStatus <> 'Open'
		if @@Error<>0
			begin
				set @Return_Code = STR(@@ERROR) + ',System Error when deleting the source data from the source table.'
				Raiserror (@Return_Code,16,1)
				return
			end
	INSERT INTO [dbo].[Tb_Sys_log]
           ([OP_Module]
           ,[OperateTime]
           ,[Operation]
           ,[Result]
           ,[ByWho]
           ,[ByComputer]
           ,[Rmk]
           ,[ServerName])
     VALUES
           ('Archive Data'
           ,GETDATE()
           ,'Archived tb_rcv_InboundTracking Data to History database. Date Period :Before ' + convert(varchar,@P_Date) + '.Total:' + str(@ArchivedRowCnt) + ' items affected.'
           ,'Done'
           ,'Sys'
           ,'Server'
           ,''
           ,@@SERVERNAME)
           
		if @@Error<>0
			begin
				set @Return_Code = STR(@@ERROR) + ',Failed to log the archive logs of current operation.'
				Raiserror (@Return_Code,16,1)
				return
			end	             
END
GO
