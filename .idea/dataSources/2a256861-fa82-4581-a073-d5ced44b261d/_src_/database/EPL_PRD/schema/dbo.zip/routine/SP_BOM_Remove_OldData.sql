-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-11-15>
-- Description:	<Remove AGED BAS_PPL items>
-- Method Exec  [SP_BOM_Remove_OldData]
-- =============================================
CREATE PROCEDURE [dbo].[SP_BOM_Remove_OldData]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    Declare @P_Date smalldatetime,
			@RemoveBom_DaysAhead int,
			@RemoveBom_Enable bit,
			@RemovedRowCnt int,
			@Err_Num int,
			@Return_Code VARCHAR(1000)
	
	--获得系统设置的是否允许自动清除旧数据的开关
	set @RemoveBom_Enable =(Select RemoveBom_Enable from tbconfig where YesForUse = 'Y')
	IF @RemoveBom_Enable is null or @RemoveBom_Enable = 0
		BEGIN
			set @Err_Num = 99
			set @Return_Code= 'RemoveBom_Enable in tbconfig is configured as disabled or unconfigured. Err_Num:' + STR(@err_num)
			Raiserror (@Return_Code,16,1)
			Return
		END
	
	--获得系统设置的天数变量，提前多少天的数据算作旧有数据进行清除。
	set @RemoveBom_DaysAhead = (Select RemoveBom_DaysAhead from tbconfig where yesforuse = 'Y')
	if @RemoveBom_DaysAhead is null or @RemoveBom_DaysAhead = 0
			BEGIN
				set @Err_Num = 98
				set @Return_Code= 'RemoveBom_DaysAhead is unconfigured. Err_Num:'+ STR(@err_num)
				Raiserror (@Return_Code,16,1)
				Return
			END
			
	Set @P_Date = (select dateadd(day,-@RemoveBom_DaysAhead,GETDATE()))  

	--在每天进行删除之前，将当前记录COPY到历史库
	Truncate Table EPL_HST.dbo.BAS_PPL
	insert into EPL_HST.dbo.BAS_PPL 
				select * from bas_ppl
	if @@Error<>0
		begin
			set @Return_Code = STR(@@ERROR) + ',System Error when backing up source data to the History Database table.'
			Raiserror (@Return_Code,16,1)
			return
		end
	--开始删除（删除时不会删除tb_order_details表中正在进行中的MODEL。）
	Delete from BAS_PPL  
	where LASTUPDATED < @P_Date and 
			Number not in (select distinct PPLModelName  
							from Tb_Order_Details 
							where OrderStatus = 'Open' and FlagGroup = 'SMT' and OrderType = 'AutoPull' and PPLModelName is not null)
	--计算影响的行数
	set @RemovedRowCnt = @@ROWCOUNT 
	
	if @@Error<>0
			begin
				set @Return_Code = STR(@@ERROR) + ',System Error when deleting the source data from the BAS_PPL table.'
				Raiserror (@Return_Code,16,1)
				return
			end
	
	--执行成功则写入日志
	INSERT INTO [Tb_Sys_log]
           ([OP_Module]
           ,[OperateTime]
           ,[Operation]
           ,[Result]
           ,[ByWho]
           ,[ByComputer]
           ,[Rmk]
           ,[ServerName])
     VALUES
           ('Remove BAS_PPL Data'
           ,GETDATE()
           ,'Removed BAS_PPL Data which Date Period :Before ' + convert(varchar,@P_Date) + '.Total:' + str(@RemovedRowCnt) + ' items affected.'
           ,'Done'
           ,'Sys'
           ,'Server'
           ,''
           ,@@SERVERNAME)
           
		if @@Error<>0
			begin
				set @Return_Code = STR(@@ERROR) + ',Failed to log the archive logs of current operation.'
				Raiserror (@Return_Code,16,1)
				return
			end	           
END
GO
