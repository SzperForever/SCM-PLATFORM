CREATE PROCEDURE [dbo].[sp_SAP_VS_HMP]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT  A.[SLoc],
			A.[Material] as SAPPartNo,
			COUNT(b.in_Id) as IDnum,
			B.Material,
			a.[Material description],
			A.[Matl grp],
			A.[Stand Price],
			isnull(A.[Unrestricted],0) as SAPqty,
			isnull(sum(B.AvailableQty),0) as HMPQty ,
			(isnull(sum(B.AvailableQty),0)- isnull(A.[Unrestricted],0)) AS VarianceQty, 
			(a.[stand price] * (isnull(sum(B.AvailableQty),0)-isnull(A.[Unrestricted],0))) as VarianceValue 
	FROM dbo.view_hmp_stock B full join
	dbo.tmp_SAP_Inventory A   on A.Material = B.Material  
	group by A.[SLoc],A.[Material],B.material,a.[Material description],A.[Matl grp],A.[Stand Price],A.[Unrestricted]
	order by A.[SLoc],A.[Material] asc
END

GO
