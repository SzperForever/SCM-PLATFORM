CREATE VIEW dbo.V_Kanban_Shipping_AgingDays_ByWorkcell
AS
SELECT        TOP (100) PERCENT Matlgroup, CONVERT(DECIMAL(18, 2), CAST(LessThan1Week AS float) / CAST(TotalAgingCnt AS float)) * 100 AS P1, CONVERT(DECIMAL(18, 2), 
                         CAST(LessThan1Month_GreaterThan1Week AS float) / CAST(TotalAgingCnt AS float)) * 100 AS P2, CONVERT(DECIMAL(18, 2), 
                         CAST(LessThan3Month_GreaterThan1Month AS float) / CAST(TotalAgingCnt AS float)) * 100 AS P3, CONVERT(DECIMAL(18, 2), CAST(GreaterThan3months AS float) 
                         / CAST(TotalAgingCnt AS float)) * 100 AS P4, LessThan1Week, LessThan1Month_GreaterThan1Week, LessThan3Month_GreaterThan1Month, GreaterThan3months, 
                         TotalAgingCnt
FROM            (SELECT        Matlgroup, COUNT(0) AS TotalAgingCnt,
                                                        (SELECT        COUNT(0) AS Expr1
                                                          FROM            dbo.V_Kanban_Shipping_AgingDays_Resource AS v1
                                                          WHERE        (PeriodType = 'LessThan1Week') AND (Matlgroup = v.Matlgroup)) AS LessThan1Week,
                                                        (SELECT        COUNT(0) AS Expr1
                                                          FROM            dbo.V_Kanban_Shipping_AgingDays_Resource AS v1
                                                          WHERE        (PeriodType = 'LessThan1Month_GreaterThan1Week') AND (Matlgroup = v.Matlgroup)) AS LessThan1Month_GreaterThan1Week,
                                                        (SELECT        COUNT(0) AS Expr1
                                                          FROM            dbo.V_Kanban_Shipping_AgingDays_Resource AS v1
                                                          WHERE        (PeriodType = 'LessThan3Month_GreaterThan1Month') AND (Matlgroup = v.Matlgroup)) AS LessThan3Month_GreaterThan1Month,
                                                        (SELECT        COUNT(0) AS Expr1
                                                          FROM            dbo.V_Kanban_Shipping_AgingDays_Resource AS v1
                                                          WHERE        (PeriodType = 'GreaterThan3months') AND (Matlgroup = v.Matlgroup)) AS GreaterThan3months
                          FROM            dbo.V_Kanban_Shipping_AgingDays_Resource AS v
                          GROUP BY Matlgroup) AS v2
ORDER BY Matlgroup
GO
