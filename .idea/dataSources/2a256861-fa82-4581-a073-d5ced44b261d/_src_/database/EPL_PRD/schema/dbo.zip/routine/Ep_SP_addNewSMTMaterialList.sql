CREATE PROCEDURE [dbo].[Ep_SP_addNewSMTMaterialList]

	 @OrderID nchar(12)
	,@PartNo nvarchar(20)
	,@Qty numeric(18, 2)
	,@GRN nvarchar(18)
	,@Step nvarchar(4)
	,@PreparedBy nchar(10)
	,@Remark nchar(20)
	,@PreparedID nvarchar(15)
	,@WorkCell nvarchar(50)
	,@Model nvarchar(50)
	,@FlagGroup nchar(10)	
	,@Feeder nchar(10)	
	,@PCName nchar(10)
	,@RuleFlag nchar(10)
AS
begin
	INSERT INTO [dbo].[Tb_PreparedList]
			   ([OrderID]
			   ,[PartNo]
			   ,[Qty]
			   ,[GRN]
			   ,[Step]
			   ,[ScanTime]
			   ,[PreparedBy]
			   ,[Remark]
			   ,[PreparedID]
			   ,[WorkCell]
			   ,[Model]
			   ,[CheckFlag]
			   ,[FlagGroup]
			   ,[Feeder]
			   ,[HostName]
			   ,[RuleFlag])
		 VALUES
			(@OrderID,@PartNo,@Qty,@GRN,@Step,GETDATE(),@PreparedBy,@Remark,@PreparedID,@WorkCell,@Model,'N',@FlagGroup,@Feeder,@PCName,@RuleFlag)
 end
GO
