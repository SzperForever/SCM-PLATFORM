CREATE VIEW dbo.V_Kanban_Rec_ArriveRate_OPEN_Daily
AS
SELECT     DocNo, ItemStatus, DeliveryNote, Forwarder, Qty, Unit, ReceivedBy, AddWho, AddTime, Remark
FROM         dbo.TB_RCV_InboundTracking
WHERE     (ItemStatus = 'open') AND (LEFT(CONVERT(varchar, AddTime, 120), 10) BETWEEN DATEADD(dd, - 2, GETDATE()) AND GETDATE())
GO
