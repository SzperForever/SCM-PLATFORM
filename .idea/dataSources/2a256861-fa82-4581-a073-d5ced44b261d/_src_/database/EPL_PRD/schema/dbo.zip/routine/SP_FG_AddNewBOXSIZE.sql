CREATE PROCEDURE [dbo].[SP_FG_AddNewBOXSIZE]
           @FG_PartNum varchar(30)
           ,@CtnSize VARCHAR(30)
           ,@Length decimal(18, 3)
           ,@Width decimal(18, 3)
           ,@Height decimal(18, 3)
           ,@Weight decimal(18, 3)
           ,@AddWho varchar(10)
           ,@Remark varchar(100)
AS
BEGIN

	SET NOCOUNT ON;
	INSERT INTO [dbo].[BAS_FG_BOX]
           ([FG_PartNum]
           ,[CtnSize]
           ,[Length]
           ,[Width]
           ,[Height]
           --,[Weight(kg)]
           ,[AddWho]
           ,[AddTime]
           ,[Remark])
     VALUES
		(@FG_PartNum 
		,@CtnSize 
		,@Length 
		,@Width
		,@Height 
		--,@Weight 
		,@AddWho 
		,GETDATE()
		,@Remark )

END
GO
