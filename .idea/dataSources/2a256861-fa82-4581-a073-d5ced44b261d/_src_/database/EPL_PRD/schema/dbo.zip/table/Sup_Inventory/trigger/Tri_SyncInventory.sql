CREATE TRIGGER [dbo].[Tri_SyncInventory]
   ON  [dbo].[Sup_Inventory]
   AFTER INSERT,UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	declare @Inventory numeric(18, 7),
			@sku varchar(20)
			
	set @sku = (select  material from inserted)
	set @Inventory = (select  AvailableQty from inserted)	
	
	update Sup_SKuMap set inventory = @Inventory where Material = @sku
	
	if update(AvailableQty)
		begin
			update Sup_SKuMap set inventory = @Inventory where Material = @sku
		end
END
GO
