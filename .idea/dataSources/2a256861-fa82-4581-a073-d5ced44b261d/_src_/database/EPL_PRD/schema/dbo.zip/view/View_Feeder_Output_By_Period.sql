CREATE VIEW dbo.View_Feeder_Output_By_Period
AS
SELECT     TOP (100) PERCENT CONVERT(varchar(13), CONVERT(varchar, OccuredTime, 120), 120) + ':00' AS TimePeriod, Op_Text, COUNT(Op_Text) 
                      AS LogItemsCnt
FROM         dbo.Tb_Feeder_Logs
GROUP BY CONVERT(varchar(13), CONVERT(varchar, OccuredTime, 120), 120) + ':00', Op_Text
ORDER BY TimePeriod
GO
