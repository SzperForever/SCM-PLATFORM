CREATE VIEW dbo.View_SAPBOM_VS_MachineBOM
AS
SELECT     a.OrderID, c.OrderID AS OrderNo, a.Model, a.BayNum, a.Component AS S_Mtrl, c.fsPartNum AS M_Mtrl, a.[Qty Per] AS S_QtyPer, SUM(CONVERT(int, c.fsPartQty)) 
                      AS M_QtyPer, a.NeedQty AS S_NeedQty, SUM(c.NeedQty) AS M_NeedQty, a.NeedQty - SUM(c.NeedQty) AS VarianceQty, a.Actualqty, a.Actualqty - a.NeedQty AS DiffQty,
                       c.SeqBrdNum AS BoardNumber, COUNT(c.fsPartNum) AS SlotCnt, a.PkgCount AS PkgCnt, c.pkgInfoTapeWidth
FROM         dbo.View_Machine_Material_List AS c FULL OUTER JOIN
                      dbo.View_SMT_KittingStatus AS a ON a.Component = c.fsPartNum AND c.OrderID = a.OrderID
GROUP BY a.OrderID, c.OrderID, a.Model, a.BayNum, a.Component, a.[Qty Per], a.NeedQty, a.Actualqty, c.fsPartNum, c.SeqBrdNum, a.PkgCount, c.pkgInfoTapeWidth
GO
