

CREATE VIEW [dbo].[View_Kitting_Report_Overview_By_Workcell]
AS
SELECT     WorkCell, COUNT(DISTINCT KittingPartNum) AS KittingPartCnt, SUM(RawPartCnt) AS RawPartCnt, COUNT(DISTINCT PullListNo) AS PullCnt, COUNT(OrderID) 
                      AS OrderCnt,
                          (SELECT     COUNT(OrderID) AS Expr1
                            FROM          dbo.View_Kitting_Order_Headers with (nolock) 
                            WHERE      (WorkCell = a.WorkCell) AND (OrderStatus = 'Open')) AS OpenOrderCnt,
                          (SELECT     COUNT(DISTINCT PullListNo) AS Expr1
                            FROM          dbo.View_Kitting_Order_Headers AS View_Kitting_Order_Headers_1 with (nolock) 
                            WHERE      (WorkCell = a.WorkCell) AND (OrderStatus = 'Open')) AS OpenPullCnt
FROM         dbo.View_Kitting_Order_Headers AS a  with (nolock) 
GROUP BY WorkCell


GO
