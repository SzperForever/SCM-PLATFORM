-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-10-12>
-- Description:	<Fill the BOM Data from table tmp_bas_sapbom>
-- =============================================
CREATE PROCEDURE [dbo].[sp_FillData_SAPBOM]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	TRUNCATE TABLE BAS_SAPBOM
	
	INSERT INTO Bas_SAPbom SELECT * FROM dbo.Tmp_Bas_SAPbom
	truncate table Tmp_Bas_SAPbom
	
END
GO
