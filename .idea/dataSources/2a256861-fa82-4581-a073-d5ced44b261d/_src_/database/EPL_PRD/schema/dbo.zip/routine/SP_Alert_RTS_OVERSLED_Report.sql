-- =============================================
-- Author:		DAILS
-- Create date: 2016-08-23
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Alert_RTS_OVERSLED_Report] 
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@tableHTML2 nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@Rcnt2 int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
		
	set @AlertName = 'RTS_OVERSLEDAlert'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	set @Rcnt = (SELECT count(0)
					  FROM [EPL_PRD].[dbo].[Tb_RTS]
						WHERE [MAremark] LIKE '%RECODE":1%' and [RTSNO] not LIKE 'r%' AND ScanTime BETWEEN DATEADD(dd,-1,getdate()) AND getdate())	
	
	set @Rcnt2 = (SELECT count(0) from (SELECT     a.Sloc
			, a.PI_ID
			, a.BinLoc
			, a.PartNum
			,convert(int,a.Qty) as qty
			, a.GRN
			, a.SledInfo
			, a.AddBy
			, a.LstUpdateTime
			, a.Remark
			, a.id
			, b.Matlgroup
FROM         dbo.Tb_PI_By_Bin AS a LEFT JOIN
                      dbo.BAS_SKU AS b ON a.PartNum = b.Material)as t
 WHERE [SledInfo] LIKE '%RECODE":1%' and  [LstUpdateTime] BETWEEN DATEADD(dd,-1,getdate()) AND getdate())	
	
	

	
	set @tableHTML2 = ''	
	SET @tableHTML =
	
    N'<H1>Hi, All: </H1>' +
    N'<H1>下面为RTS每天发现的过期物料</H1>' +    
    N'<table border="1">' +
    N'<tr><th>RTSNO</th><th>WorkCell</th><th>StoreLocation</th><th>ScanPartNo</th><th>ScanQty</th><th>MAremark</th><</tr>' +
    
    CAST ( ( SELECT td = RTSNO,       '',
                    td = WorkCell, '',
                    td = StoreLocation, '',
                    td = ScanPartNo, '',
                    td = ScanQty, '',
                    td = MAremark,''
                  
              from 
					(SELECT [RTSNO]
					  ,[WorkCell]
					  ,[StoreLocation]
					  ,[ScanPartNo]
					  ,[ScanQty]
					  ,[GRNno]
					  ,[ScanTime]
					  ,[MAremark]
					  FROM [EPL_PRD].[dbo].[Tb_RTS]
						WHERE [MAremark] LIKE '%RECODE":1%' and [RTSNO] not LIKE 'r%' AND ScanTime BETWEEN DATEADD(dd,-1,getdate()) AND getdate())as v     
			   
              FOR XML PATH('tr'), TYPE 
				) AS NVARCHAR(MAX) ) +

	
	
	N'</table>'  
	
	set @tableHTML2 = 
    N'<H1>下面为仓库(0100)每天发现的过期物料</H1>' +
    N'<table border="1">' +
    N'<tr><th>BinLoc</th><th>Matlgroup</th><th>PartNum</th><th>Qty</th><th>SledInfo</th><</tr>' +
    
   CAST ( (  SELECT  
					 td = BinLoc, '',
				     td = Matlgroup, '',
				     td = PartNum, '',
				     td = Qty,  '',
		             --td = GRN, '',
		             --td = LstUpdateTime, '',
					 td = SledInfo, ''
			FROM(
				   SELECT     a.Sloc
							, a.PI_ID
							, a.BinLoc
							, a.PartNum
							,convert(int,a.Qty) as qty
							, a.GRN
							, a.SledInfo
							, a.AddBy
							, a.LstUpdateTime
							, a.Remark
							, a.id
							, b.Matlgroup
					FROM         dbo.Tb_PI_By_Bin AS a LEFT JOIN
									  dbo.BAS_SKU AS b ON a.PartNum = b.Material)as t
			 WHERE [SledInfo] LIKE '%RECODE":1%' and  [LstUpdateTime] BETWEEN DATEADD(dd,-1,getdate()) AND getdate()                  
              FOR XML PATH('tr'), TYPE 
				) AS NVARCHAR(MAX) ) +
    N'</table>' +    
    'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';

	if @Rcnt =0 and @Rcnt2 =0 return
	
	if @Rcnt > 0 and @Rcnt2 = 0 begin
		set @tableHTML=@tableHTML
	end
	
	if @Rcnt = 0 and @Rcnt2 > 0 begin
		set @tableHTML=@tableHTML2
	end
	
	if @Rcnt > 0 and @Rcnt2 > 0 begin
		set @tableHTML=@tableHTML + @tableHTML2
	end

    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END
GO
