CREATE PROCEDURE [dbo].[Ep_SP_addNewLbInfoToTempTb]

           @PartNum nvarchar(20)
           ,@Qty nvarchar(20)
           ,@GRNnum nvarchar(18)
           ,@PrintBy nvarchar(20)
           ,@RaisedBy nvarchar(20)
           ,@ApplicatorCode  nvarchar(20)
           ,@Remark nvarchar(50)
		
AS
	 begin		
			
			INSERT INTO [dbo].[Tb_LabelPrintDB]
           ([PartNum]
           ,[Qty]
           ,[GRNnum]
           ,[PrintTime]
           ,[PrintBy]
           ,[RaisedBy]
           ,[ApplicatorCode]
           ,[Remark])
     VALUES(@PartNum,@Qty,@GRNnum,GETDATE(),@PrintBy,@RaisedBy,@ApplicatorCode,@Remark)

			
end
GO
