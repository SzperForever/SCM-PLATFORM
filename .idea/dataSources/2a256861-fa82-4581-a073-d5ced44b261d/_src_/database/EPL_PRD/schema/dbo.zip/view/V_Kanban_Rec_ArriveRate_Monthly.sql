/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.V_Kanban_Rec_ArriveRate_Monthly
AS
SELECT        TOP (12) DocYear, ClosedDay_MonthNo, COUNT(DocNo) AS ClosedDocCnt,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.TB_RCV_InboundTracking
                               WHERE        (DATEPART(MONTH, ClosedTime) = v.ClosedDay_MonthNo)) AS TotalDocCnt,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v1
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Ls12')) AS DocCnt_LS12,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Ls24Gt12')) AS DocCnt_LS24,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v3
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Ls48Gt24')) AS DocCnt_LS48,
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v4
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Gt48')) AS DocCnt_GT48, CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v1
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Ls12')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_8
                                 WHERE        (DATEPART(MONTH, ClosedTime) = v.ClosedDay_MonthNo)), 0), 1) AS FLOAT) * 100) AS V_LS12, CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Ls24Gt12')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_7
                                 WHERE        (DATEPART(MONTH, ClosedTime) = v.ClosedDay_MonthNo)), 0), 1) AS FLOAT) * 100) AS V_LS24, CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v3
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Ls48Gt24')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_6
                                 WHERE        (DATEPART(MONTH, ClosedTime) = v.ClosedDay_MonthNo)), 0), 1) AS FLOAT) * 100) AS V_LS48, CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v4
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Gt48')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_5
                                 WHERE        (DATEPART(MONTH, ClosedTime) = v.ClosedDay_MonthNo)), 0), 1) AS FLOAT) * 100) AS V_GT48, CAST(CONVERT(DECIMAL(18, 2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v1
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Ls12')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_4
                                 WHERE        (DATEPART(MONTH, ClosedTime) = v.ClosedDay_MonthNo)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_LS12, CAST(CONVERT(DECIMAL(18, 
                         2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v2
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Ls24Gt12')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_3
                                 WHERE        (DATEPART(MONTH, ClosedTime) = v.ClosedDay_MonthNo)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_LS24, CAST(CONVERT(DECIMAL(18, 
                         2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v3
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Ls48Gt24')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_2
                                 WHERE        (DATEPART(MONTH, ClosedTime) = v.ClosedDay_MonthNo)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_LS48, CAST(CONVERT(DECIMAL(18, 
                         2),
                             (SELECT        COUNT(DocNo) AS Expr1
                               FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v4
                               WHERE        (ClosedDay_MonthNo = v.ClosedDay_MonthNo) AND (PeriodType = 'Gt48')) / CAST(ISNULL(NULLIF
                             ((SELECT        COUNT(DocNo) AS Expr1
                                 FROM            dbo.TB_RCV_InboundTracking AS TB_RCV_InboundTracking_1
                                 WHERE        (DATEPART(MONTH, ClosedTime) = v.ClosedDay_MonthNo)), 0), 1) AS FLOAT) * 100) AS VARCHAR(10)) + '%' AS P_GT48
FROM            dbo.V_Kanban_Rec_ArriveRate_Source AS v
GROUP BY ClosedDay_MonthNo, DocYear
ORDER BY ClosedDay_MonthNo DESC
GO
