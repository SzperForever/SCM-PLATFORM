CREATE PROCEDURE [dbo].[SP_201Recieption]
	@DocNo varchar(13),
	@ReceivedBy varchar(20),
	@ReceiptTime smalldatetime,
	@PullStatus varchar(10),
	@PullLeadTime varchar(25),
	@ReceiptRemark varchar(200)

AS
BEGIN
	update tb_3pl201 set ReceivedBy=@ReceivedBy,ReceiptTime=@ReceiptTime,PullStatus=@PullStatus,PullLeadTime=@PullLeadTime,ReceiptRemark=@ReceiptRemark
	where stocksts = '已发货' and storearea = '0300' and docno = @DocNo and FlagGroup = '201'
END
GO
