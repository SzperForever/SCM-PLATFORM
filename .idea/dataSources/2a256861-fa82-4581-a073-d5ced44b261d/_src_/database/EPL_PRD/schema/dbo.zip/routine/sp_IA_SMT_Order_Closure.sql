-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-2-16>
-- Description:	<IA Close Sloc via maitaining the adjust value.>
-- =============================================
CREATE PROCEDURE sp_IA_SMT_Order_Closure
	-- Add the parameters for the stored procedure here
	@Sloc  varchar(4),
	@AdjValue money,
	@Owner varchar(10),
	@ActiveRCount int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
    set @ActiveRCount= 0
    select @ActiveRCount = (Select COUNT(orderid) 
						from Tb_Order_Details 
						where Sloc = @Sloc and CreateBy = @Owner and OrderStatus = 'Open' and CurrentPlace = 'IA' and FlagGroup = 'SMT')
						
	update Tb_Order_Details 
	set OrderStatus = 'Close',PullStatus = 'Close',AdjustValue =@AdjValue,ClosedTime = getdate()
	where Sloc = @Sloc and CreateBy = @Owner and OrderStatus = 'Open' and CurrentPlace = 'IA' and FlagGroup = 'SMT'
END
GO
