
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_AssignPeople]
	-- Add the parameters for the stored procedure here
	@AssignedTo nchar(10),
	@AssignedBy nchar(10),
	@PullListNo nchar(13)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE Tb_Kitting_Order_Header 
	SET Stocksts  = 'InProgress'
	  ,Stock_PickingTime = GETDATE()
      ,Stock_AssignedBy = @AssignedBy
      ,Stock_AssignedTo = @AssignedTo
	WHERE Pulllistno = @PullListNo and OrderStatus = 'Open'	

END

GO
