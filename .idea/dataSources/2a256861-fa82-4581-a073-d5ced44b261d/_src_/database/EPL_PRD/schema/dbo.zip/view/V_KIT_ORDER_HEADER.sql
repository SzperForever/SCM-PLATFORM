CREATE VIEW dbo.V_KIT_ORDER_HEADER
AS
SELECT        h.OrderID, h.OrderStatus, s.[Material Group] AS Workcell, h.BuildPlanTime, h.Selective, h.KittingPartNum, h.Kits_Qty, h.FailedQty_Processing AS FailedQty, 
                         h.FinalQty,
                             (SELECT        ISNULL(SUM(Qnty), 0) AS Expr1
                               FROM            dbo.TB_KIT_RIPE_HISTORY
                               WHERE        (OrderID = h.OrderID)) AS FinalDeliveryQnty, c1.Chinese_DESC AS [Processing Status], d.ProcessingType, h.Station, h.ScheduledStartTime, 
                         h.ScheduledEndTime, h.PullListNo, h.CurrentPlace, h.Order_ReleasedBy AS OrderCreateBy, h.Order_ReleasedTime, h.Pull_ReleasedBy, h.Pull_ReleasedTime, 
                         h.Pull_FinishedTime, h.FI_FinishedBy, h.FI_FinishedTime, h.Processing_FinishedBy, h.Processing_FinishTime, h.FNI_FinishedBy, h.FNI_FinishedTime, 
                         h.OBA_FinishedBy, h.OBA_FinishedTime, h.Order_ClosedBy, h.Order_ClosedTime, h.CancelTime, h.CanceledBy, h.Flag, h.IsChildOrder, h.ReasonCode, 
                         c.English_DESC AS ReasonDesc, d.[UCT(Sec)], d.[UPH(Hr)], d.MvmtTyp, h.ID, h.Stock_PickingTime, h.Stock_AssignedTo, h.Stock_AssignedBy, h.Stock_Sts, 
                         h.ProgressCode, c.English_DESC AS ReasonText, c1.English_DESC AS OrderProgress, (CASE WHEN
                             (SELECT        COUNT(0)
                               FROM            V_KIT_RAW_Calc
                               WHERE        ISSTOCKAVL = 'N' AND OrderID = h.OrderID) > 0 THEN 'N' ELSE 'Y' END) AS IsStkAvl, h.OrderNotes
FROM            dbo.TB_KIT_ORDER_HEADER AS h LEFT OUTER JOIN
                         dbo.Bas_Code AS c1 ON h.ProgressCode = c1.Code LEFT OUTER JOIN
                         dbo.Bas_Code AS c ON h.ReasonCode = c.Code LEFT OUTER JOIN
                         dbo.TB_KIT_MP_DETAILS AS m ON h.OrderID = m.OrderID LEFT OUTER JOIN
                         dbo.TB_KIT_DOC AS d ON d.KittingPartNum = h.KittingPartNum LEFT OUTER JOIN
                         dbo.Bas_SAPbom AS s ON s.[Assembly Name] = h.KittingPartNum
GROUP BY h.OrderID, h.OrderStatus, h.BuildPlanTime, h.KittingPartNum, h.Kits_Qty, h.Selective, c1.English_DESC, s.[Material Group], h.Station, h.ScheduledStartTime, 
                         h.ScheduledEndTime, h.PullListNo, h.CurrentPlace, h.Order_ReleasedBy, h.Order_ReleasedTime, h.Pull_ReleasedBy, h.Pull_ReleasedTime, h.Pull_FinishedTime, 
                         h.FI_FinishedBy, h.FI_FinishedTime, h.Processing_FinishedBy, h.FNI_FinishedBy, h.FNI_FinishedTime, h.OBA_FinishedBy, h.OBA_FinishedTime, 
                         h.Order_ClosedBy, h.Order_ClosedTime, h.CancelTime, h.CanceledBy, h.Flag, h.ReasonCode, c1.English_DESC, d.[UCT(Sec)], d.[UPH(Hr)], d.MvmtTyp, h.ID, 
                         h.Stock_PickingTime, h.Stock_AssignedTo, h.Stock_AssignedBy, h.Stock_Sts, h.ProgressCode, c.English_DESC, c1.Chinese_DESC, h.Processing_FinishTime, 
                         h.FailedQty_Processing, h.FinalQty, d.ProcessingType, h.IsChildOrder, h.OrderNotes
GO
