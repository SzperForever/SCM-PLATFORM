
CREATE VIEW [dbo].[View_Kitting_RawShortage_CheckAvlbStock]
AS
SELECT     a.RawPartNum, a.[Qty Per], a.RawPartDemand_Before AS Demand_Before, a.RawPartInvTotal_Before AS InvTotal_Before, 
                      a.RawPartsDiffQty_Before AS DiffQty_Before, b.Shortage AS Shortage_After, b.Inv_Total AS TotalInv_After, b.DiffQty AS DiffQty_After, 
                      CASE WHEN b.DiffQty > a.RawPartsDiffQty_Before THEN 'Y' ELSE 'N' END AS AvailableStock, a.AddTime, GETDATE() AS RefreshTime
FROM         dbo.Tb_Kitting_RawPart_Inv_Compare AS a with (nolock)  INNER JOIN
                      dbo.View_Kitting_RawPart_Inv AS b  with (nolock) ON a.RawPartNum = b.RawPartNum

GO
