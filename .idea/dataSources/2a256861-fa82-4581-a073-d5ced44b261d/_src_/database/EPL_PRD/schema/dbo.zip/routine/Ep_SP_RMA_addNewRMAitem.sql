CREATE PROCEDURE [dbo].[Ep_SP_RMA_addNewRMAitem]

--	[Status],[Progress],[Family],[Serialnumber],[RMA Number],[SAP Part No],[Assembly],[NewAssembly],[Failure Category],[Qty],[AddTime],[AddWho],[CurrentArea],[WorkCell],[SNNullFlag]
			@Family varchar(10),
			@RMANumber varchar(20),
			@SAPPartNo varchar(20),
			@Assembly varchar(20),
			@FailureCategory varchar(20),
			@AddWho varchar(10),
			@WorkCell varchar(18),
			@SNNullFlag varchar(10)
AS

	if @SNNullFlag = 1 begin
	
		if (select Count(*) from dbo.tb_RMA_Tracking where [RMA Number] = @RMANumber and Status <> 'Cancel' and Assembly  <> @Assembly and SNNullFlag = '1') >0 
			begin
				raiserror('Invaild RMANo and Assembly information. The RMANo information is already exsit and matched with other Assembly.',16,1)	
			end
		else begin			
			declare @RMASN Varchar(12)
			DECLARE @dt CHAR(6)
			declare @Rcount int
			Declare @IsAllowUpload bit = 0
			DECLARE @MSG varchar(1000)
				SELECT @dt=dt FROM v_GetDate		
				--select @Rcount = (select COUNT(*) from tb_RMA_Tracking where [RMA Number] = @RMANumber and Status <> 'Cancel' and Assembly = @Assembly and SNNullFlag = '1')
				--if @Rcount = 0 
					--begin
						set @RMASN = (SELECT @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(Serialnumber),6),0),6) 
										FROM tb_RMA_Tracking WITH(XLOCK,PAGLOCK) 
										WHERE Serialnumber like @dt+'%' and SNNullFlag = '1')
					--end
				--else begin
					--set @RMASN =(select distinct Serialnumber from tb_RMA_Tracking where WORKCELL = @WORKCELL AND model = @Model and batch = @Batch and FlagGroup = 'MI' and left(PullListNo,8) = left(@PullListNo,8) and OrderStatus <> 'Cancel')
				--end
				

				set @Rcount = (Select count(0) from [dbo].[tb_RMA_Tracking] where Serialnumber =@RMASN and status = 'Open')
				if @Rcount > 0 begin
					set @MSG = 'The RMA information with SN: ' + @RMASN + ' is already exsit and not closed previously. so you may not allowed to upload it again.'
					raiserror(@MSG,16,1)
					return
				end


				INSERT INTO [dbo].[tb_RMA_Tracking]
				   ([Status]
				   ,[Progress]
				   ,[Family]
				   ,[Serialnumber]
				   ,[RMA Number]
				   ,[SAP Part No]
				   ,[Assembly]
				   ,[NewAssembly]
				   ,[GRN]
				   ,[ItemOption]
				   ,[Rework Category]
				   ,[Failure Category]
				   ,[Failure]
				   ,[MRBOption]
				   ,[AddTime]
				   ,[AddWho]
				   ,[CurrentArea]
				   ,[WorkCell]
				   ,[SNNullFlag]
				   ,[Qty])
			 VALUES
				   ('Open'
				   ,'Upload completed'
				   ,@Family
				   ,@RMASN
				   ,@RMANumber
				   ,@SAPPartNo
				   ,@Assembly
				   ,@Assembly
				   ,''
				   ,'RCV'
				   ,''
				   ,@FailureCategory
				   ,''
				   ,''
				   ,GETDATE()
				   ,@AddWho				
				   ,'Planning'
				   ,@WorkCell
				   ,@SNNullFlag
				   ,1)		
		end
			
end
GO
