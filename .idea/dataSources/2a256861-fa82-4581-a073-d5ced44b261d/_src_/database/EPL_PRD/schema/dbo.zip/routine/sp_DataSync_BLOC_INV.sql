CREATE proc [dbo].[sp_DataSync_BLOC_INV]
AS BEGIN

	DECLARE @DELFILENAME varchar(2000) 	
	declare @RecAddress varchar(300)
	Declare @HasError bit ,@AbnormalRowCnt int ,@errmsg varchar(1000)

	set @RecAddress = '13636387165@139.com;13817503000@139.com;13524709329@139.COM;13761064316@139.COM;15002168379@139.com'
	set @HasError = 0

	--TRUNCATE TABLE TB_RES_SOURCE_SAP_INV
	truncate table TB_SAP_INV_WH

	delete from [dbo].TB_RES_SOURCE_SAP_INV 
		--select * from TB_RES_SOURCE_SAP_INV 
		where			LEFT(ltrim([Column 0]),1) <> '|' OR 
						LEFT(ltrim([column 0]),9) in('|Material') or
						dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) < 14 						

		----If there is columns string '|' more over than 15 then alert administrator
		

		set @AbnormalRowCnt = (Select count(*) FROM TB_RES_SOURCE_SAP_INV  with (nolock) WHERE dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) > 15)
		if @AbnormalRowCnt > 0 
			begin
				INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
					VALUES ('sp_DataSync_BLOC_INV', 'Fail to parser bulk data into temporary table.',99,GETDATE())
				set @errmsg = 'There is an error just occured during the sync stock inventory process. ErrDesc: There are more than 17 specfic chacters detected. Error Number:' + str(@@error)
				RAISERROR ( @ERRMSG,16,1)
				RETURN 1
			end
			
			
	insert into TB_SAP_INV_WH
		SELECT  dbo.GetStrPara([Column 0],2,'|') as Material ,
					dbo.GetStrPara([Column 0],3,'|') as Plnt ,
					dbo.GetStrPara([Column 0],4,'|') as Sloc ,
					dbo.GetStrPara([Column 0],5,'|') as S ,
					dbo.GetStrPara([Column 0],6,'|') as Batch ,
					dbo.GetStrPara([Column 0],7,'|') as K ,
					dbo.GetStrPara([Column 0],8,'|') as [Special Stock Number],
					dbo.GetStrPara([Column 0],9,'|') as [Material Description],
					dbo.GetStrPara([Column 0],10,'|') as Typ,
					dbo.GetStrPara([Column 0],11,'|') as StorageBin,
					replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],12,'|')),1,' '),',','')  as [Available stock1] ,		
					0,		
					dbo.GetStrPara([Column 0],13,'|') as Bun,
					dbo.GetStrPara([Column 0],14,'|') as [GR Date],
					getdate() as LstUpdateTime,
					(case dbo.GetStrPara([Column 0],10,'|') when 'RET' then 1 when 'PRD' THEN 2 WHEN 'MRO' THEN 3 WHEN 'HMP' THEN 4 WHEN 'VEN' THEN 5 ELSE 9 end) AS TypIdx
			  FROM TB_RES_SOURCE_SAP_INV with (nolock)
			  where dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) = 14
			  
			  insert into TB_SAP_INV_WH
		  	  SELECT  dbo.GetStrPara([Column 0],2,'|') as Material ,
					dbo.GetStrPara([Column 0],3,'|') as Plnt ,
					dbo.GetStrPara([Column 0],4,'|') as Sloc ,
					dbo.GetStrPara([Column 0],5,'|') as S ,
					dbo.GetStrPara([Column 0],6,'|') as Batch ,
					dbo.GetStrPara([Column 0],7,'|') as K ,
					dbo.GetStrPara([Column 0],8,'|') as [Special Stock Number],
					dbo.GetStrPara([Column 0],9,'|') + dbo.GetStrPara([Column 0],10,'|') as [Material Description],
					dbo.GetStrPara([Column 0],11,'|') as Typ,
					dbo.GetStrPara([Column 0],12,'|') as StorageBin,
					replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],13,'|')),1,' '),',','') as [Available stock1] ,	
					0,			
					dbo.GetStrPara([Column 0],14,'|') as Bun,
					dbo.GetStrPara([Column 0],15,'|') as [GR Date],
					getdate() as LstUpdateTime,
					(case dbo.GetStrPara([Column 0],10,'|') when 'RET' then 1 when 'PRD' THEN 2 WHEN 'MRO' THEN 3 WHEN 'HMP' THEN 4 WHEN 'VEN' THEN 5 ELSE 9 end) AS TypIdx
			  FROM TB_RES_SOURCE_SAP_INV with (nolock)
			  where dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) = 15
			  
			  UPDATE TB_SAP_INV_WH
			  SET [Available stock] = 0 - CONVERT(FLOAT,REPLACE([Available stock1],'-','')) 
			  WHERE RIGHT(RTRIM([Available stock1]),1)='-'
		  
			  UPDATE TB_SAP_INV_WH
			  SET [Available stock] = CONVERT(FLOAT,[Available stock1])
			  WHERE RIGHT(RTRIM([Available stock1]),1) <> '-'

			  --set @DELFILENAME = 'Del /s /q ' + @SourceFilePath + 'STKINV?.TXT'
			  --EXEC xp_cmdshell @DELFILENAME
			  RETURN 0
			  
			  truncate table TB_RES_SOURCE_SAP_INV
			  
END
GO
