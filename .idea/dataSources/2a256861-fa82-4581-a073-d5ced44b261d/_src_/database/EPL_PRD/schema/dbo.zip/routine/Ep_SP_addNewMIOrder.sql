
CREATE  PROCEDURE [dbo].[Ep_SP_addNewMIOrder]

		@WorkCell varchar(20),
		@Model varchar(100),
		@PullListNo varchar(13),
		@BuildPlanTime SMALLdatetime,
		@CreateBy varchar(10),			
		@Batch int,
		@Sets varchar(20),
		@StoreArea varchar(4),
		@Baynum varchar(10),
		@Sloc varchar(4),
		@Remark varchar(max),
		@CurrentPlace VArchar(10),
		@Priority varchar(10),
		@KTE varchar(1)
		
AS
	if (select Count(pulllistno) from Tb_Order_Details where PullListNo = @PullListNo and PullStatus <> 'Cancel' and model = @model and Batch = @batch) >0 
		begin
			raiserror('This pull order already exsit,insert failed.',16,1)	
		end
	else begin	
	
		declare @OrderID Varchar(12)
		DECLARE @dt CHAR(6)
		declare @Rcount int,@Lvrequesttime smalldatetime
			--SELECT @Lvrequesttime = DATEADD(hh,-12,(select min(buildplantime) 
												--from Tb_Order_Details 
												--where FlagGroup = 'MI' and PullListNo = @PullListNo and orderstatus <> 'Cancel'))
			SELECT @dt=dt FROM v_GetDate		
			select @Rcount = (select COUNT(*) from Tb_Order_Details where WorkCell = @workcell and model = @Model and batch = @Batch and FlagGroup = 'MI' and left(PullListNo,8) = left(@PullListNo,8) and OrderStatus <> 'Cancel')
			if @Rcount = 0 
				begin
					set @orderid = (SELECT @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(orderid),6),0),6) 
									FROM tb_order_details WITH(XLOCK,PAGLOCK) 
									WHERE orderid like @dt+'%' and flaggroup = 'MI')
				end
			else begin
				set @orderid =(select distinct orderid from Tb_Order_Details where WORKCELL = @WORKCELL AND model = @Model and batch = @Batch and FlagGroup = 'MI' and left(PullListNo,8) = left(@PullListNo,8) and OrderStatus <> 'Cancel')
			end
			
			set @Lvrequesttime = DATEADD(hh,-12,@buildplantime)
			--if UPPER(left(@WorkCell,7))='PHILIPS'
			--	begin
			--		set @Lvrequesttime = DATEADD(hh,-8,@buildplantime)
			--	end
			
			INSERT INTO [dbo].[Tb_Order_Details] 
				([OrderID]
				,[OrderType]
				,[OrderStatus]
				,[WorkCell]
				,[Model]
				,[BayNum]
				,[StoreArea]
				,[PullListNo]
				,[PullStatus]
				,[PartAmount]
				,[Sets]
				,[BuildPlanTime]
				,[Sloc]
				,[CreateBy]
				,[CreateTime]
				,[StockSts]
				,[LVHMrequestTime]
				,[LVHMsts]
				,[KTE]
				,[OrderNotes]
				,[FlagGroup]
				,[CurrentPlace]
				,[Priority]
				,[Batch]
				,[ConditionalFormat])  
			VALUES (@orderid			
				--dbo.f_NextBH(@Model,@Batch)--自定义函数，相同MODEL,相同套数,相同BATCH用同一个orderID.
				,'MIPull'
				,'Open'
				,@WorkCell
				,@Model
				,@BayNum
				,@StoreArea
				,@PullListNo
				,'Open'
				,dbo.F_GetPartCount(@Model)--自定义函数，用于获取该MODEL下的物料数量
				,@Sets
				,@BuildPlanTime
				,@Sloc
				,@CreateBy
				,GETDATE()
				,'NotStarted'
				,@Lvrequesttime
				,'NotReceived'
				,@KTE
				,@Remark
				,'MI'
				,@CurrentPlace
				,@Priority
				,@batch
				,'NotStarted')		
			
end
GO
