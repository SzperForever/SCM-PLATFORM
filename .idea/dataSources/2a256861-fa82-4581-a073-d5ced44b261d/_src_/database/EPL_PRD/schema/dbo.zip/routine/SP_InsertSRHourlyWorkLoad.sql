-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_InsertSRHourlyWorkLoad]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [dbo].[TB_Chart_SR_WorkLoad]
           ([SR_Date]
           ,[TimePeriod]
           ,[TotalMPItems]
           ,[TotalOpenMPItems]
           ,[TotalOpenSR])
	VALUES ((select left(CONVERT(date,getdate()),10)),
	(select left(CONVERT(time,getdate()),8)),
	(SELECT Sum(MPItems) FROM Tb_SR_Details where  SRSTATUS <> 'ShippedOut' and SRSTATUS <> 'Canceled')
	,(SELECT Sum(MPItems) FROM Tb_SR_Details where SRSTATUS <> 'PGI_Done' and SRSTATUS <> 'ShippedOut' and SRSTATUS <> 'Canceled')
	,(SELECT COUNT(SRNo) FROM Tb_SR_Details where SRSTATUS <> 'PGI_Done' and SRSTATUS <> 'ShippedOut' and SRSTATUS <> 'Canceled' ))

END


GO
