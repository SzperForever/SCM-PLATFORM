CREATE PROCEDURE [dbo].[Ep_SP_addNewFeederQueue]
				@BayNum nchar(10)
			   ,@OrderID nchar(12)
			   ,@ModelName nchar(30)
			   ,@PlanBuildTime smalldatetime
			   ,@AddWho nchar(20)
			   ,@Remark nvarchar(50)
			   ,@CustomerText nchar(15)
			   ,@Revision nchar(10)
			   ,@Workcell nchar(20)
			   ,@Sets int
			   ,@PlanCompleteTime smalldatetime =  ''
AS
BEGIN

	SET NOCOUNT ON;
	Declare @SlotCount int
	set @SlotCount = 0
	Set @SlotCount =(Select COUNT ( fsSetPos ) 
					FROM Bas_Machine_Feeder_Report  
					WHERE [Number]=@ModelName and
						REV=@Revision and [MAText]=@Baynum )
	--if @SlotCount = 0 
	--	begin
	--		--raiserror ('Failed to get the slotcount. Invalid Order information provided. Please check the paremeters (@CustomerText,@ModelName,@Revision,@Baynum,@RouteStepText). System will set this slotcount as 0.',16,4)
	--		--return
	--	end
	--else 
	--begin
		INSERT INTO [dbo].[TB_Feeder_Setup_History]
				   ([BayNum]
				   ,[OrderID]
				   ,[ModelName]
				   ,[Sets]
				   ,[Rev]
				   ,[PlanBuildTime]
				   ,[PlanCompleteTime]
				   ,[SlotCount]
				   ,[SetupStatus]
				   ,[AddWho]
				   ,[AddTime]
				   ,[Workcell]
				   ,[Remark]
				   ,[Bottom_Progress] 
				   ,[Top_Progress]
				   ,[Bottom_Step]
				   ,[Top_Step])
			 VALUES
				   (@BayNum
				   ,@OrderID
				   ,@ModelName
				   ,@Sets 
				   ,@Revision
				   ,@PlanBuildTime
				   ,@PlanCompleteTime
				   ,@SlotCount
				   ,'Open'
				   ,@AddWho
				   ,GETDATE()
				   ,@Workcell 
				   ,@Remark
				   ,'Queued'
				   ,'Queued'
				   ,1
				   ,1)
	--end			   
END
GO
