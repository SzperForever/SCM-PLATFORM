-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tri_DN_Update]
   ON  dbo.TB_FG_SR_Details
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    if @@rowcount > 1 return    
    
    BEGIN TRAN
	if update(DN)  begin
		Goto jumphere
	end
	
	if update(TotalQty)  begin
		Goto jumphere2
	end
Return

jumphere:
		Declare @rcnt int,@SPStatus nchar(3),@SRid bigint,@DN NCHAR(10),@ErrMsg NVARCHAR(1000),@AllowUpdate bit = 0
		
		select @SRid= srid,@DN = DN from inserted
		SELECT @SPStatus = SR_SP_Status,@AllowUpdate=AllowUpdate FROM dbo.TB_FG_SR_Header WHERE SRID = @SRID
		
		if @AllowUpdate <> 1 
			begin
			IF @SPStatus NOT IN ('902','903')  
				BEGIN			
					set @ErrMsg = 'You cannot update this column at this time. （此时不允许更新此列。）'
					raiserror (@ErrMsg,16,1)
					rollback TRAN
					return
				END
			end
		
		commit tran
		return
jumphere2:		
		select @SRid= srid,@DN = DN from inserted
		SELECT @SPStatus = SR_Status,@AllowUpdate=AllowUpdate FROM dbo.TB_FG_SR_Header WHERE SRID = @SRID
		
		if @AllowUpdate <> 1 
			begin
			IF @SPStatus NOT IN ('900')  
				BEGIN			
					set @ErrMsg = 'You cannot update this column at this time. Reach to Dai lisong or Chen wei for more assistance.（此时不允许更新此列，如果确实需要更新，请联系CHEN WEI 或 DAILISONG.）'
					raiserror (@ErrMsg,16,1)
					rollback TRAN
					return
				END
			end
		
		commit tran
END
GO
