-- =============================================
-- Author:		<HANSON>
-- Create date: <2014-10-27,>
-- Description:	<Verfication when inserting a new item,,>
-- =============================================
CREATE TRIGGER [dbo].[Tri_Kitting_Doc] on [dbo].[Bas_Kitting_Doc]
   AFTER INSERT,update
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Declare @KittingPartNum nvarchar(30)
    Declare @KittingType nchar(20)
    
    Declare @RowCnt int
    declare @Errmsg nvarchar(800)
    
    Set @KittingPartNum  = (SELECT KittingPartNum FROM inserted)
    Set @KittingType  = (SELECT KittingType FROM inserted)
	
	set @RowCnt= 0 
	
	set @RowCnt =  (select COUNT(0) from Bas_SAPbom where [Assembly Name]  = @KittingPartNum )
	if @RowCnt = 0  begin
		rollback tran
		set	@Errmsg = 'The Part you are trying to addin or update is not exsit in the SAP BOM. Insert fails with this kittingpart:' + @KittingPartNum
		raiserror(@ErrMsg,16,1)
		return
	end
	
	if  @kittingtype not in (SELECT [English_DESC] FROM [dbo].[Bas_Code] WHERE [CodeGroup_Desc] = 'KittingType') begin
		rollback tran
		set	@Errmsg = 'The kittingtype value is not valid. Please input a valid one. Invalid KittingType:' + @KittingType
		raiserror(@ErrMsg,16,1)
		return	
	end 
	
	update bas_kitting_doc set KITTINGPARTNUM = UPPER(KITTINGPARTNUM),KITTINGTYPE = UPPER(KITTINGTYPE) ,AddTime = getdate() ,addby = 'User',[UCT(Sec)] =[UPH(Hr)]/3600 where kittingpartnum = @Kittingpartnum
END
GO
