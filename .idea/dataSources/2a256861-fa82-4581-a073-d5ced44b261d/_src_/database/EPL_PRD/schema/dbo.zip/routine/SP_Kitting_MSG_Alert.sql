-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-12-16>
-- Description:	<Add New Kitting Order send an alert msg.>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_MSG_Alert]
	-- Add the parameters for the stored procedure here
			--@RegDate date
            @OrderID nchar(12)
            
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @Msg nvarchar(max)
			,@tableHeaderHTML  NVARCHAR(MAX) 
			,@tableDemandHTML  NVARCHAR(MAX) 
			,@tablePullHTML  NVARCHAR(MAX) 
			,@BodyHTML  NVARCHAR(MAX) 
			,@RecAddressList NVARCHAR(MAX) 
			,@copy_recipients NVARCHAR(MAX) 
			
	select @Msg = 'Dear Supplier,' + CHAR(10) + 
			 'You have a new kitting order as below , please supply the kitting part as demand on schedule.'  
	select @RecAddressList = (select recipients from Cfg_DBmail where AlertName = 'KittingOrder')
	select @copy_recipients =(select copylist from Cfg_DBmail where AlertName = 'KittingOrder')
	
	SET @tableHeaderHTML = @Msg +
		N'<H1>New Kitting Order Header Info:</H1>' +
		N'<table border="1">' +
		N'<tr><th>OrderID</th><th>WorkCell</th><th>Model</th><th>KittingPartCount</th><th>RawPartCount</th><th>BuildPlanTime</th>' +
		N'<th>Kits_Qty</th><th>CreateBy</th><th>Priority</th><th>OrderNotes</th></tr>' +
		CAST ( ( SELECT td = OrderID,       '',
						td = WorkCell, '',
						td = Model, '',
						td = KittingPartCount, '',
						td = RawPartCount, '',
						td = BuildPlanTime , '',
						td = Kits_Qty, '',
						td = CreateBy, '',
						td = Priority,'',
						td = OrderNotes, ''
				  from [dbo].[Tb_Kitting_Order_Header]
				  where OrderID = @OrderID 			
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' ;
		
		set @tableDemandHTML = N'<H1>Ordered Demand List Of Both Kitting and RAW Parts :</H1>' +
		N'<table border="1">' +
		N'<tr><th>OrderID</th><th>PartNo</th><th>Demand</th><th>DmdType</th><th>AddTime</th><th>AddBy</th></tr>' +
		CAST ( ( SELECT td = OrderID,       '',
						td = PartNo, '',
						td = Demand, '',
						td = DmdType, '',
						td = AddTime, '',
						td = AddBy , ''
				  from [dbo].[TB_Kitting_Demand]
				  where OrderID = @OrderID 			
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' ;
	
		set @tablePullHTML = N'<H1>Pull List Information of this Order: </H1>' +
		N'<table border="1">' +
		N'<tr><th>OrderID</th><th>PullListNo</th><th>StoreArea</th><th>AddBy</th><th>AddTime</th></tr>' +
		CAST ( ( SELECT td = OrderID,       '',
						td = PullListNo, '',
						td = StoreArea, '',
						td = AddBy, '',
						td = AddTime, ''
				  from [dbo].[TB_Kitting_Pulls]
				  where OrderID = @OrderID 			
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		'Do not reply to this mail because it is a system generated email.';
		
		
		set @BodyHTML = @tableHeaderHTML+@tableDemandHTML+@tablePullHTML

    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name ='EpullSqlMail',
	@recipients = @RecAddressList,
	@copy_recipients=@copy_recipients,
	@subject = '(Test Only)New Kitting Order has been Placed',
	@body = @BodyHTML,
    @body_format = 'HTML' ;
END
GO
