create PROCEDURE [dbo].ME_UpdateFeeder
            @FeederID	varchar(10)
           ,@WorkCell	varchar(20)
           ,@FeederStatus varchar(10)
           ,@LastPMDate date
           ,@NextPMDate date
           ,@LastPMBy varchar(10)
           ,@LastPMTime smalldatetime
           ,@LastPMNotes varchar(50)
           ,@RepairDate date
           ,@RepariNotes varchar(50)
           ,@LastRepairedBy varchar(10)
           ,@LastRepairTime smalldatetime
           ,@Remark varchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	update ME_Feeders set WorkCell= @WorkCell,
			FeederStatus = @FeederStatus ,
			LastPMDate=@LastPMDate,
			[NextPMDate]=@nextpmdate,
			LastPMBy =@lastpmby
           ,[LastPMTime]=@lastpmtime
           ,[LastPMNotes]=@lastpmnotes
           ,[RepairDate]=@RepairDate
           ,[RepariNotes]=@RepariNotes
           ,[LastRepairedBy]=@LastRepairedBy
           ,[LastRepairTime]=@LastRepairTime
           ,[Remark]=@Remark
     where feederid = @feederid

END
GO
