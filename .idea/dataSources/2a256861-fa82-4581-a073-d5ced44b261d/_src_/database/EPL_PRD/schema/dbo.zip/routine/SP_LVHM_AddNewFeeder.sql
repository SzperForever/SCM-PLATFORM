Create  PROCEDURE [dbo].[SP_LVHM_AddNewFeeder]
	@FeederID varchar(12),
	@HostName varchar(15),
	@ScanBy Varchar(15)
           
AS
begin
	SET NOCOUNT ON;

	INSERT INTO [dbo].[TB_LVHM_Feeders]
			   ([FeederID]
			   ,[ScanTime]
			   ,[ScanMachine]
			   ,[Scanby])
		 VALUES
			   (@FeederID,
				GETDATE(),
				@HostName,
				@ScanBy)

end

GO
