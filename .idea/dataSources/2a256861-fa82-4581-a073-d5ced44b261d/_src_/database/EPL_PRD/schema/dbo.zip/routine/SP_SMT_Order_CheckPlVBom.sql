-- =============================================
-- Author:		<Hanson Zhang)
-- Create date: <2013/8/13>
-- Description:	<Rules to check the upload item whether match with the PLV bom>
-- =============================================
CREATE PROCEDURE [dbo].[SP_SMT_Order_CheckPlVBom]
	-- Add the parameters for the stored procedure here
		 @WorkCell varchar(20),
		 @MAText varchar(20),
		 @Model nchar(80),
		 @Rev nchar(20),
		 @ReturnCode varchar(1000) output,
		 @ErrCode int output
AS BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @PLVBomModelname varchar(30),
			@rowcount1 int,
			@rowcount2 int,@rowcount3 int
	Set @rowcount1 = (Select count(PLVBomModelname) from bas_bomlink where sapbommodelname = @model)
	
	if @rowcount1 =0 
		begin
			set @ErrCode = 1
			set @ReturnCode = 'No records return from the Bom Link Profile for this SAP model:' + @Model + ',You may go check the Bom Link profile.'
			RAISERROR (@ReturnCode, 16, 1)
			return
		end
	else begin
		set @PLVBomModelname = (Select PLVBomModelname from bas_bomlink where sapbommodelname = @model)
		
		--IF (rtrim(upper(@WORKCELL)) = 'NETAPP' or rtrim(upper(@WORKCELL)) = 'CAREFUS' OR rtrim(upper(@WORKCELL)) = 'THALES'  OR rtrim(upper(@WORKCELL)) = 'CISCO' or rtrim(upper(@WORKCELL)) = 'SCHNEIDER') AND RTRIM(UPPER(@MATEXT)) <> 'BAY 2B'  begin
		if RTRIM(UPPER(@MATEXT)) <> 'BAY 2B'  begin
			set @rowcount3 = (Select count(*) from bas_machine_feeder_report where Number = @PLVBomModelname and MAText = @MAText and Rev = @Rev)
			if @rowcount3 =0 
				begin
					Set @ErrCode = 3
					set @ReturnCode = 'No records return from the [BAS_Machine_feeder_report] for this information: Model(' + RTRIM(@PLVBomModelname) + '),MAText:( ' + RTRIM(@matext) + '),Rev:('+ RTRIM(@Rev) + ').Check with MachineBom is needed.'
					RAISERROR (@ReturnCode, 16, 1)
					return
				end
		end
		
		--IF  RTRIM(UPPER(@MATEXT)) ='BAY 2B' or (rtrim(upper(@WORKCELL)) <> 'NETAPP' and rtrim(upper(@WORKCELL)) <> 'CAREFUS' and rtrim(upper(@WORKCELL)) <> 'THALES' and rtrim(upper(@WORKCELL)) <> 'CISCO' and rtrim(upper(@WORKCELL)) <> 'SCHNEIDER') Begin
		If RTRIM(UPPER(@MATEXT)) = 'BAY 2B' BEGIN
				set @rowcount2 = (Select count(*) from bas_ppl where Number = @PLVBomModelname and MAText = @MAText and Revision = @Rev)
				if @rowcount2 =0 
					begin
						set @ErrCode = 2
						set @ReturnCode = 'No records return from the [BAS_PPL] for this information: Model(' + RTRIM(@PLVBomModelname) + '),MAText:( ' + RTRIM(@matext) + '),Rev:('+ RTRIM(@Rev) + ').Check Bom Link profile with QM feeder setup sheet to confirm if the SMT Bom match with this Model.'
						RAISERROR (@ReturnCode, 16, 1)
						return
					end
		end
	end
	set @ErrCode =9
	set @ReturnCode = 'Checked. Ok to go.'
	
END
GO
