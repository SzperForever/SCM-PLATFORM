

CREATE PROCEDURE [dbo].[sp_Kitting_Delete_Order]
	-- Add the parameters for the stored procedure here
	@OrderID nvarchar(13)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	Delete from Tb_Kitting_Order_Header where OrderID = @OrderID

	--Declare @Msg nvarchar(max)
	--		,@RecAddressList NVARCHAR(MAX) 
	--		,@copy_recipients NVARCHAR(MAX) 
			
	--select @Msg = 'Dear Supplier,' + CHAR(10) + 
	--		 'Please be noted that kitting order:' + @OrderID + ' has been deleted from the order list by administrator.'  
	--select @RecAddressList = (select recipients from Cfg_DBmail where AlertName = 'KittingOrder')
	--select @copy_recipients =(select copylist from Cfg_DBmail where AlertName = 'KittingOrder')

 --   EXEC msdb.dbo.sp_send_dbmail 
	--@profile_name ='EpullSqlMail',
	--@recipients = @RecAddressList,
	--@copy_recipients=@copy_recipients,
	--@subject = '(Test Only)One Kitting Order has been deleted',
	--@body = @Msg,
 --   @body_format = 'HTML' ;	
	
	
END

GO
