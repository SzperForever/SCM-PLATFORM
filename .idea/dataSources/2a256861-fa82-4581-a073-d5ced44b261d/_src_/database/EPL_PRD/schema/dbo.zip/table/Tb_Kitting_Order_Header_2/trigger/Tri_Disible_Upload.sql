-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Tri_Disible_Upload]
   ON  [dbo].[Tb_Kitting_Order_Header_2]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--如果需要定时停止服务，则启用如下代码：

        declare @DatePeriod smalldatetime
	 
	if  getdate() < '2017-09-05 00:00:00' return
    if  getdate() < '2017-09-11 06:00:00' 
	begin		
		rollback tran
		RAISERROR ('You are not allowed to upload build plan during this period. ePull is out of service between 2017-09-05  and 2017-09-11. Any unclear please contact with Dai lisong.', 16, 1)
		return
     end

	return
END
GO
