CREATE PROCEDURE [dbo].[SP_HMP_History]
			@IN_ID nchar(8),
			@Movement nchar(3),
            @Bay nchar(10),
            @RegDate date,
            @Model nchar(30),
            @Material nchar(20),
            @AvailableQty nchar(10),
            @PullListNo nchar(13),
            @MoveQty float,
            @IssuedBy nchar(10),
            @IssuedToWho nchar(10),
            @OperateTime smalldatetime,
            @Remark nchar(10)
AS
BEGIN
	SET NOCOUNT ON;
					
	if @Movement = 'In'
		begin
			declare @OutBatch nchar(10),
					@IDSum int
			set @IDSum = (select COUNT(distinct in_id) as IDsum from Tb_HMP_IssueHistory where Movement = 'In')
			set @IN_ID = @IDSum + 1
			set @OutBatch=rtrim(@IN_ID) + '-1'
		end
	else if @Movement = 'Out'
		begin
			declare	@OutRowCount int
			set @OutRowCount =(select COUNT(*) from Tb_HMP_IssueHistory where in_id = @IN_ID)
			set @OutBatch= rtrim(@IN_ID) + '-' + ltrim((@OutRowCount+1))
--			set @AvailableQty=(select  @MoveQty   select MAX(outbatch) from Tb_HMP_IssueHistory where in_id = '1'
			
		end
		
	INSERT INTO [dbo].Tb_HMP_IssueHistory
           ([IN_ID]
           ,[OutBatch]
           ,[Movement]
           ,[Bay]
           ,[RegDate]
           ,[Model]
           ,[Material]
           ,[AvailableQty]
           ,[PullListNo]
           ,[MoveQty]
           ,[IssuedBy]
           ,[IssuedToWho]
           ,[OperateTime]
           ,[Remark])
     VALUES
			(@IN_ID,@OutBatch,@Movement,@Bay,@RegDate,@Model,@Material,@AvailableQty,@PullListNo,@MoveQty, @IssuedBy,@IssuedToWho,@OperateTime,@Remark)
END
GO
