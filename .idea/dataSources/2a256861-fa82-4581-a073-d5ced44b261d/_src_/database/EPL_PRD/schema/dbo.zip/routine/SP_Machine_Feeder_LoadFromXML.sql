-- =============================================
-- Author:		<Hanson Zhnag>
-- Create date: <2013/10/18>
-- Description:	<Load XML feeder report to ePullDB>
-- Alter History: 
	--2016-08-09 , add nokia_A1 jugement switch
	--exec dbo.SP_Machine_Feeder_BatchUploadFromXML 'E:\XML','E:\XML'
	--SELECT * FROM Bas_Machine_Feeder_Report WHERE Number = '088411A.102' AND BoardSide IN ('B','2B','B2')
-- =============================================
CREATE PROCEDURE [dbo].[SP_Machine_Feeder_LoadFromXML] 
	-- Add the parameters for the stored procedure here
	@DIR varchar(2000),
	@ResultPath varchar(2000),
	@SeqBrdNum int
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @XMLDIR varchar(2000),                        --XML放置的文件全路径
			@FileFullName varchar(8000),                  --游标用,文件名称(全路径)
			@Str varchar(2000),                           --文本日志内容
			@LogFileName varchar(1000),                   --日志路径
			@DELFILENAME varchar(2000),                   --删除文件的CMDSHELL
			@MoveFileName_WhenFailure varchar(2000),
			@MoveFileName_WhenSucceed varchar(2000),
			@CmdCreateNewFolder varchar(1000),
			@CmdMoveToCopyFolder varchar(1000),
			@ParentFolderName varchar(200)
			
	Declare @FileTable TABLE(x varchar(MAX))             --临时表,存储 文件夹所有XML文件名称

		SET @XMLDIR=N'DIR '+ @DIR + '\*.xml'             --*.xml 只读取是XML的扩展名的文件
		set @LogFileName = @ResultPath + '\ResultLog.txt'--日志文件路径
		SET @MoveFileName_WhenFailure = 'Move  ' + @DIR  + SPACE(1) + @ResultPath + '\Failure\'
		--set @ParentFolderName = dbo.GetStrPara(@DIR,4,'\') + '_Copy'		
		--set @CmdCreateNewFolder = 'mkdir ' + @DIR  + '\' + @ParentFolderName  --调用DOS命令创建project文件夹
		
		INSERT @FileTable
		exec xp_cmdshell @XMLDIR                        --将文件夹的内容读取插入临时表中		
	
		delete from  @FileTable where x not like '%FeederReportHead%.xml' or x is null			
		update @FileTable set x=@DIR+'\'+SUBSTRING(x,40,120)


		declare fCursor_Header cursor for  
				select x from  @FileTable
		open fCursor_Header                   
		fetch next from fCursor_Header  into @FileFullName
		while(@@fetch_status=0)
		
		BEGIN

				Declare @xml varchar(Max),                --XML转换成列的内容
						@Pointer INT                      --指向位置的变量

						
				Declare	@Table TABLE(x varchar(MAX))
				Declare	@HeaderTable TABLE(McName varchar(255),BoardSide varchar(255),prgName varchar(255),JobRevision varchar(255))
				Declare @McName varchar(255)
						,@BoardSide varchar(255)
						,@prgName varchar(255)
						,@JobRevision varchar(255)
						,@MAText varchar(10)
						,@Rev varchar(10)
						,@Number varchar(40)						
				
				
				insert into @table EXEC ('(SELECT *
											FROM OPENROWSET(BULK '''+@FileFullName+''',SINGLE_CLOB) as x)')							
				select @xml=x from @table
	
				EXECUTE sp_xml_PReparedocument @Pointer OUTPUT,@xml
				if @@ERROR <> 0
					begin
						EXEC xp_cmdshell @MoveFileName_WhenFailure
						set @Str =  CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Folder:' + rtrim(@DIR) + ',Error occured during preparing the document.'
						EXEC p_Writefile @LogFileName, @STR
					end
					
				set @Str = '[SP_Machine_Feeder_LoadFromXML]:' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Load and read Header xmlfile:' + @FileFullName + '.'
				EXEC p_Writefile @LogFileName, @Str
				
				insert into @HeaderTable 
				SELECT * FROM OPENXML (@Pointer,'/FeederReportHeader/Header',2)
				WITH(McName nvarchar(255),
				      BoardSide	nvarchar(255),
				      prgName	nvarchar(255),
				      JobRevision nvarchar(255))				      
				where McName <> 'McName'				 		
				
				IF @@ROWCOUNT <> 1 
					BEGIN
						EXEC xp_cmdshell @MoveFileName_WhenFailure
						set @Str = '[SP_Machine_Feeder_LoadFromXML](Error):' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Folder:' + rtrim(@DIR) + ' failed to analize the header xml file. This folder will be moved to Failure Folder'
						EXEC p_Writefile @LogFileName, @STR
						Return
					END		
				ELSE BEGIN			
					EXEC sp_xml_removedocument @Pointer	
									
					set @McName = (select McName from @HeaderTable )
					set @prgName = (select prgName from @HeaderTable )
					set @JobRevision = (select JobRevision from @HeaderTable )
					set @MAText = (select dbo.GetStrPara(@prgName,1,'_'))	
								
					
					IF LEN(RTRIM(@MATEXT)) = 4 
						begin
							--对类似BAY1规则的线别，自动+ 0
							set @MATEXT = LEFT(@MAText,3) + ' 0' + right(rtrim(@matext),1)					
						end
					ELSE BEGIN
						set @MAText = Left((select dbo.GetStrPara(@prgName,1,'_')),3)+SPACE(1)+ SUBSTRING((select dbo.GetStrPara(@prgName,1,'_')),4,4)
					END
				    -- Deal //Abnormal Prgname 
					DECLARE @SplitStrCnt int,@Sint int
					set @SplitStrCnt = (Select dbo.fn_SCountOneWordOnOtherWord('_',@prgName))
					SET @Sint = @SplitStrCnt -3
					if @Sint > 0 begin
							set @Number = LEFT(RTRIM(dbo.GetStrPara(@prgName,2,'_')) + '_' +  ltrim(dbo.GetStrPara(@prgName,@Sint+2,'_')),LEN(RTRIM(dbo.GetStrPara(@prgName,2,'_')) + '_' +  ltrim(dbo.GetStrPara(@prgName,@Sint+2,'_')))-1)	
							print @Number
							set @Rev = ltrim(dbo.GetStrPara(@prgName,@Sint+3,'_'))
						end
					else begin
							SET @Number = LEFT(RTRIM(dbo.GetStrPara(@prgName,2,'_')),LEN(RTRIM(DBO.GETSTRPARA(@prgName,2,'_')))-1)
							set @Rev = (select dbo.GetStrPara(@prgName,3,'_'))
					end
					
					set @BoardSide = RIGHT(rtrim(@prgname),1)
					

					
					--判断如果MCNAME 是NOKIA_A1，自动 BOTTOM 前加2
					if LTRIM(RTRIM(@McName)) = 'NOKIA_A1' and @MAText = 'Bay 28'
						begin							
							set @BoardSide = rtrim(ltrim(@BoardSide)) + '2'							
							set @Str = '[SP_Machine_Feeder_LoadFromXML](Tip):' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Find NOKIA_A1 Macname and bottom will be uploaded as B2.'
							EXEC p_Writefile @LogFileName, @Str 
						end					
					select @McName,@BoardSide,@MAText,@Number,@Rev
					set @Str = '[SP_Machine_Feeder_LoadFromXML]:' +  CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Get Header Info' + rtrim(@DIR) + ' succefully.Ready to procee Unit xml file.'
					EXEC p_Writefile @LogFileName, @STR
					Goto LbLoadUnit
			    END
				fetch next from fCursor_Header into @FileFullName
			END
			
		close  fCursor_Header  	
		DEALLOCATE	fCursor_Header
	Return
	
LbLoadUnit:	
	delete from @FileTable 

	SET @XMLDIR=N'DIR '+ @DIR + '\*.xml'            --*.xml 只读取是XML的扩展名文件

	INSERT @FileTable
	exec xp_cmdshell @XMLDIR                --将文件夹的内容读取插入临时表中		
		
	delete from  @FileTable where x not like '%FeederReportUnit%.xml' or x is null		
	update @FileTable set x=@DIR+'\'+SUBSTRING(x,40,120)
	
	select * from @FileTable 
	
	declare fCursor_Unit cursor for  
			select x from  @FileTable
	open fCursor_Unit                   
	fetch next from fCursor_Unit  into @FileFullName
	while(@@fetch_status=0)
		
	BEGIN
		delete from @Table 		
		SET @MoveFileName_WhenSucceed = 'RD ' + @DIR 
		--set @DELFILENAME = 'Del /s /q ' + @DIR + '\*.*'		
		
		set @DELFILENAME = 'Del /s /q ' + @DIR + '\' + @FileFullName	
		
		insert into @table EXEC ('(SELECT *
								FROM OPENROWSET(BULK '''+@FileFullName+''',SINGLE_CLOB) as x)')
						
		select @xml=x from @table

		EXECUTE sp_xml_PReparedocument @Pointer OUTPUT,@xml
		
		if @@ERROR <> 0 
					begin
						EXEC xp_cmdshell @MoveFileName_WhenFailure
						set @Str =  '[SP_Machine_Feeder_LoadFromXML](Error):' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Folder:' + rtrim(@DIR) + ',Error occured during preparing the document.'
						EXEC p_Writefile @LogFileName, @STR
					end
		
		set @Str = '[SP_Machine_Feeder_LoadFromXML]:' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Load and read Unit xmlfile:' + @FileFullName + '.'
		EXEC p_Writefile @LogFileName, @Str
		
		
		--为线别加空格
		set @MAText =UPPER( LEFT(@matext,3) + SPACE(1) + ltrim(SUBSTRING(@matext,4,len(@matext)-3)))
		
			--检查有没有旧记录存在
			EXEC p_Writefile @LogFileName,  '[SP_Machine_Feeder_LoadFromXML]:Checking old records...'
			if exists(Select * 
						from dbo.Bas_Machine_Feeder_Report						
						where MAText =@MAText and Number=@Number and Rev = @Rev 
							and BoardSide=@BoardSide) --AND WorkCell = @McName)
				begin
					Delete from Bas_Machine_Feeder_Report 
					where MAText =@MAText and Number=@Number and Rev = @Rev 
							and BoardSide=@BoardSide --AND WorkCell = @McName
					
					set @Str = '[SP_Machine_Feeder_LoadFromXML]:(Found old records)'+ CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Removed old records:' + rtrim(@JobRevision) + rtrim(@Number) + rtrim(@MAText) + rtrim(@Rev)  + ' from table:Bas_Machine_Feeder_Report'
					EXEC p_Writefile @LogFileName, @STR			
				end		
		
		
		SELECT UPPER(@McName),upper(@MAText),upper(@Number),upper(@Rev),upper(@BoardSide),upper(@JobRevision)
		
		 INSERT INTO dbo.Bas_Machine_Feeder_Report
		 ([WorkCell],[MAText],[Number],[Rev],[BoardSide],[JobRevision],[fsSetPos],[fsPartNum],[fsFdrName],[pkgInfoPkgType],[pkgInfoTapeWidth],[pkgInfoFeedPitch],[favFdrPkg],[favReelWidth],[asBodyHeight],[fsStatus],[fsPartQty],[fsTrayDir],[pnPartComment],[pnBarcode],[fsRefList],[asAsmShape],[LstUpdateTime],[prgName],[seqBrdNum],[slotpitch])
		 SELECT UPPER(@McName),upper(@MAText),upper(@Number),upper(@Rev),upper(@BoardSide),upper(@JobRevision),* ,GETDATE(),upper(@prgName),UPPER(@SeqBrdNum)
				,(case  favReelWidth  --slotpitch 为FEEDER备料槽间隔以加量推移形式计算。
					when '8' then 0 
					when '12' then 1 
					when '16' then 1 
					when '24' then 1 
					when '32' then 1 
					when '44' then 2 
					when '56' then 2 
					when '72' then 2 
					when '88' then 2 					
					else 0 end)
		 FROM OPENXML (@Pointer,'/FeederReportUnit/Unit',2)
		 WITH(
					[fsSetPos] nchar(12),
					[fsPartNum] nvarchar(25),
					[fsFdrName] nvarchar(30),
					[pkgInfoPkgType] nvarchar(25),
					[pkgInfoTapeWidth] nvarchar(25),
					[pkgInfoFeedPitch] nvarchar(10),
					[favFdrPkg] nvarchar(20),
					[favReelWidth] nvarchar(20),
					[asBodyHeight] nvarchar(20),
					[fsStatus] nvarchar(20),
					[fsPartQty] nchar(10),
					[fsTrayDir] nvarchar(20),
					[pnPartComment] nvarchar(25),
					[pnBarcode] nvarchar(50),
					[fsRefList] nvarchar(Max),
					[asAsmShape] nvarchar(100))	
					--字母B 的问题
					
		--order by convert(int,dbo.GetStrPara(fssetpos,1,'-')) asc,convert(int,dbo.GetStrPara(fssetpos,2,'-')) asc
					
		IF @@ROWCOUNT =0 
					BEGIN
						EXEC xp_cmdshell @MoveFileName_WhenFailure
						set @Str = '[SP_Machine_Feeder_LoadFromXML](Error):' +  CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + 'Folder:' + rtrim(@DIR) + ' has 0 records returned from the unit xml file according to the header information. There mighe some error occured or invalid unit xml file was detected.'
						EXEC p_Writefile @LogFileName, @STR
					END		
		ELSE  BEGIN			
					EXEC sp_xml_removedocument @Pointer
					
					--EXEC xp_cmdshell @DELFILENAME		
					set @DELFILENAME = 'Del /s /q ' + @FileFullName	
					EXEC xp_cmdshell @DELFILENAME	
					
					set @Str =  '[SP_Machine_Feeder_LoadFromXML]:XML File:' + rtrim(@FileFullName) + ' has been succesfully uploaded and the file has been deleted as well.'
					EXEC p_Writefile @LogFileName, @STR
			    	Delete from DBO.[Bas_Machine_Feeder_Report] where fssetpos = 'fssetpos' --删除第一行，因为第一行是表头
			    	Delete FROM DBO.[Bas_Machine_Feeder_Report] WHERE fsPartQty = 0 AND pkgInfoPkgType <> 'Tray' --剔除用量为0的无效记录，防止因为BUFFER 的设定而多备料。
			    	
		END
		fetch next from fCursor_Unit into @FileFullName
	END			
Close  fCursor_Unit  
DEALLOCATE	fCursor_Unit
			
			set @DELFILENAME = 'Del /s /q ' + @DIR + '\*.*'				
			EXEC xp_cmdshell @DELFILENAME	
			EXEC xp_cmdshell @MoveFileName_WhenSucceed
			
			--set @CmdMoveToCopyFolder= 'Move ' + @DIR + '\*A1*.xml'  + SPACE(1) + @ParentFolderName 
			--EXEC xp_cmdshell @CmdCreateNewFolder	
			--EXEC xp_cmdshell @CmdMoveToCopyFolder		
			
			
			EXEC p_Writefile @LogFileName, '[SP_Machine_Feeder_LoadFromXML]:Folder Removed and ready to Setting arrange orders...'			
			exec dbo.SP_Machine_Feeder_ArrangeOrder @Number,@MAText ,@Rev,@BoardSide  --在BOM中更新每一个FEEDER备好料时在TABLE上应该摆放的位置。

            if @@ERROR <> 0 
					begin
						set @Str =  '[SP_Machine_Feeder_LoadFromXML](Error):' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + ',Error occured during setting arrange orders'
						EXEC p_Writefile @LogFileName, @STR
					end
			--IA 已经单独处理上传了，故不需要后台进行特别处理了
            --EXEC dbo.SP_Machine_Feeder_Deal_Bay12 @Number,@MAText,@Rev -- 针对 12线的进行特别处理。
            
            if @@ERROR <> 0 
					begin
						set @Str ='[SP_Machine_Feeder_LoadFromXML](Error):' + CONVERT(NVARCHAR,GETDATE()) + SPACE(1) + ',Error occured during dealing with the specfic baynum which is bay 12.'
						EXEC p_Writefile @LogFileName, @STR
					end
		
END
GO
