CREATE VIEW dbo.View_SAP_VS_LVHMMI
AS
SELECT     a_1.Sloc, a_1.Material AS SAPPartNo, b_1.PartNo, a_1.Mtrl_Desc, a_1.Mtrl_Grp, ISNULL(a_1.StandPrice, 0.00) AS Stand_Price, ISNULL(a_1.Unrestricted, 0) AS SAPqty, 
                      SUM(ISNULL(b_1.Qty, 0)) AS lvqty, SUM(ISNULL(b_1.Qty, 0)) - ISNULL(a_1.Unrestricted, 0) AS VarianceQty, (SUM(ISNULL(b_1.Qty, 0)) - ISNULL(a_1.Unrestricted, 0)) 
                      * ISNULL(a_1.StandPrice, 0.00) AS VarianceValue
FROM         (SELECT     Sloc, Material, Mtrl_Grp, Mtrl_Type, StandPrice, Unrestricted, Unrestr_Cnsgt, Stock_In_Tfr, In_Qual_Insp, Cnsgt_Qual_In, Blocked, Blocked_Cnsgt, 
                                              Total_Value, MRP, Mtrl_Desc, LastUpdateTime
                       FROM          dbo.TB_SAP_INV_FINAL
                       WHERE      (Sloc = '0141')) AS a_1 FULL OUTER JOIN
                          (SELECT     OrderID, PartNo, Qty, GRN, ScanTime, PreparedBy, Side, Remark, PreparedID, RegDate, WorkCell, BayNum, Sloc, Model, Sets, UploadBy, UploadTime, 
                                                   CheckFlag, CheckTime, CheckBy, QtyUpdateRmk, FlagGroup, DoneMark
                            FROM          dbo.Tb_PreparedList AS a
                            WHERE      (OrderID IN
                                                       (SELECT DISTINCT OrderID
                                                         FROM          dbo.Tb_Order_Details AS b
                                                         WHERE      (OrderStatus = 'Open') AND (CurrentPlace = 'LVHM') AND (FlagGroup = 'MI')))) AS b_1 ON a_1.Material = b_1.PartNo
GROUP BY a_1.Sloc, a_1.Material, b_1.PartNo, a_1.Mtrl_Desc, a_1.Mtrl_Grp, a_1.StandPrice, a_1.Unrestricted
GO
