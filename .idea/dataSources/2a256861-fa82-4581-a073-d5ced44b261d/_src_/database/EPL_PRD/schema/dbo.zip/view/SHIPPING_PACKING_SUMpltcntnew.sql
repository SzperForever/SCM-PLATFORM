CREATE VIEW dbo.SHIPPING_PACKING_SUMpltcntnew
AS
SELECT     TOP (100) PERCENT PackingTime_DocYear, PackingTime_HH, SUM(Pltcntnew) AS INQTY
FROM         (SELECT     CONVERT(VARCHAR(19), PackingTime, 112) AS PackingTime_DocYear, DATEPART(day, PackingTime) AS PackingTime_day, DATEPART(HH, PackingTime) AS PackingTime_HH, 
                                              DATEPART(day, Actual_Pick_Time) AS Actual_Pick_Time_day, DATEPART(HH, Actual_Pick_Time) AS Actual_Pick_Time_HH, (CASE WHEN [TotalPltCnt] = 0 THEN ([TotalCtnCnt] / 5) 
                                              ELSE [TotalPltCnt] END) AS Pltcntnew
                       FROM          dbo.View_FG_SR_Headers
                       WHERE      (Order_Status NOT IN ('Cance', 'Hold')) AND (PackingTime IS NOT NULL)) AS T
GROUP BY PackingTime_DocYear, PackingTime_HH
ORDER BY PackingTime_DocYear, PackingTime_HH
GO
