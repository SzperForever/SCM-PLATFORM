CREATE VIEW dbo.View_Users
AS
SELECT        EPL_SEC.dbo.COM_Member.MemberID, EPL_SEC.dbo.COM_Member.UserID, EPL_SEC.dbo.COM_WorkPlace.WorkPlace, 
                         EPL_SEC.dbo.COM_User_Group.Group_Name, EPL_SEC.dbo.COM_Member.UserName, EPL_SEC.dbo.COM_Member.EnglishName, 
                         EPL_SEC.dbo.COM_Member.Contacts
FROM            EPL_SEC.dbo.COM_Member LEFT OUTER JOIN
                         EPL_SEC.dbo.COM_WorkPlace ON EPL_SEC.dbo.COM_Member.WorkPlaceID = EPL_SEC.dbo.COM_WorkPlace.ID LEFT OUTER JOIN
                         EPL_SEC.dbo.COM_User_Group ON EPL_SEC.dbo.COM_Member.GroupID = EPL_SEC.dbo.COM_User_Group.GroupID
GO
