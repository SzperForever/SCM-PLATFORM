

CREATE PROCEDURE [dbo].[SP_verify_PassCode_function](
 @username nvarchar(10),
 @password nvarchar(30),
 @pass_flag int output
)
AS
BEGIN
 -- 小写字母字符.
 declare @chararray_lower varchar(26);
 -- 大写字母字符.
 declare @chararray_upper varchar(26);
 -- 循环索引.
 declare @check_index INT;
 -- 密码索引.
 declare @password_index INT;
 -- 错误信息.
 declare @ErrMsg varchar(500);
 
	if @username = '135435' return(0)
	
	set @ErrMsg = 'Srong Password Rule Break. A strong password:' + CHAR(10) + CHAR(13) + CHAR(10) + CHAR(13) + ' has at least 10 characters;'+ CHAR(10) + CHAR(13) + ' has uppercase letters;' + CHAR(10) + CHAR(13) + ' has lowercase letters;'+ CHAR(10) + CHAR(13) + ' has numbers;'+ CHAR(10) + CHAR(13) + ' has symbols;'+ CHAR(10) + CHAR(13) + ' is not your current login;'+ CHAR(10) + CHAR(13) + ' is not a dictionary word;'+ CHAR(10) + CHAR(13) + ' is not a common name;'+ CHAR(10) + CHAR(13) + ' is not a keyboard pattern, such as qwerty, asdfghjkl, or 12345678.' + CHAR(10) + CHAR(13) +  CHAR(10) + CHAR(13) + 'Please change your password immediately.'
	
	IF @password = 'Jabil' begin
		RAISERROR('Your password is default one which is not safe. Please change it to a strong password immediately.',16,1)WITH NOWAIT
		return (1);
	end
	
 -- 检查是否 用户名与密码 是否相同
	 IF LOWER(@username) = LOWER(@password)
	 BEGIN
		  raiserror(@ErrMsg,16,1)
		  return (1);
	 END
 -- 长度检查
	 IF LEN(@password) < 10
	 BEGIN
	  -- SET @ErrMsg = '密码' + @password + '长度为' + LTRIM(STR(LEN(@password))) + '，必须大于等于10位！';
	  raiserror( @ErrMsg ,  16,  1)
	  return (1);
	 END
 -- 检查密码是否至少包含 一个 数字、一个小写字母，一个大写字母.
	select @chararray_lower = 'abcdefghijklmnopqrstuvwxyz';
	select @chararray_upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

 -- 检查密码是否至少包含 一个 数字
	IF PATINDEX( '%[0-9]%',  @password ) = 0
	BEGIN
		raiserror(@ErrMsg,16,1)
		return (1);
	END

 -- 初始化有效性标志.
	SET @pass_flag = 0;
 -- 初始化 检查索引.
	SET @check_index = LEN( @chararray_lower );

 -- 检查小写字母.
	 WHILE @check_index >= 1 AND @pass_flag = 0
	  BEGIN
	  SET @password_index = LEN( @password );
	  WHILE @password_index >= 1
	  BEGIN
	   IF ASCII ( SUBSTRING(@chararray_lower, @check_index, 1) ) = ASCII (  SUBSTRING(@password, @password_index, 1)  )
	   BEGIN
		-- 密码中存在有小写字母.
		-- 密码是有效的.
		SET @pass_flag = 1;
		-- 结束循环.
		BREAK;
	   END
	   SET @password_index = @password_index - 1;
	  END
	  SET @check_index = @check_index - 1;
	 END
	 IF @pass_flag = 0
		 BEGIN
			  -- SET @ErrMsg = '密码' + @password + '中至少要包含一个小写字母！';
			  --SET @ErrMsg = 'Srong Password Rule:One lower case of character at least!';
			  raiserror(@ErrMsg,16,1);
			  return (1);
		 END
 -- 初始化有效性标志.
	SET @pass_flag = 0;
 -- 初始化 检查索引.
	SET @check_index = LEN( @chararray_upper );

 -- 检查大写字母.
	 WHILE @check_index >= 1 AND @pass_flag = 0
	 BEGIN
	  SET @password_index = LEN( @password );
	  WHILE @password_index >= 1
	  BEGIN
	   IF ASCII ( SUBSTRING(@chararray_upper, @check_index, 1) ) = ASCII (  SUBSTRING(@password, @password_index, 1)  )
	   BEGIN
		-- 密码中存在有大写字母.
		-- 密码是有效的.
		SET @pass_flag = 1;
		-- 结束循环.
		BREAK;
	   END
	   SET @password_index = @password_index - 1;
	  END
	  SET @check_index = @check_index - 1;
	 END
	 IF @pass_flag = 0
	 BEGIN
	  --raiserror('Srong Password Rule:One upper case of character at least!',16,1)
	  raiserror(@ErrMsg,16,1);
	  return (1);
	 END
 
 -- 能够执行到这里，姑且认为是密码复杂度满足要求了.
 RETURN (0);
END

GO
