-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-3-24>
-- Description:	<Password Encryption / MD5>
-- =============================================
CREATE TRIGGER [dbo].[tr_I_D_Encryption]
   ON  [dbo].[Bas_User]
   AFTER INSERT,UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	IF (UPDATE(Password))
		BEGIN
			--Declare @Password nvarchar(100)
			--set @password = (Select password from inserted)
			
			UPDATE B
			SET Password= sys.fn_VarBinToHexStr(hashbytes('MD5', A.Password)) ,referencetext = A.Password
			FROM inserted AS A
				INNER JOIN dbo.Bas_User AS B
				ON A.USERID=B.USERID
		END
	else return
END
GO
