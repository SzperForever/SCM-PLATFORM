CREATE VIEW dbo.View_SAP_VS_SUP_Manual
AS
SELECT        B.SLoc, A.Material AS SUP_PN, B.Material AS SAP_PN, ISNULL(A.AvailableQty, 0) AS SUP_QTY, ISNULL(B.Unrestricted, 0) AS SAP_QTY, ISNULL(A.AvailableQty, 0) 
                         - ISNULL(B.Unrestricted, 0) AS VarianceQty, (ISNULL(A.AvailableQty, 0) - ISNULL(B.Unrestricted, 0)) * B.[Stand Price] AS VarianceValue
FROM            dbo.Sup_Inventory AS A FULL OUTER JOIN
                             (SELECT        SLoc, Material, [Material description], [Matl grp], [Stand Price], Unrestricted, UserDefined1, UserDefined2
                               FROM            dbo.tmp_Sap_Inventory
                               WHERE        (SLoc = '01SM')) AS B ON A.Material = B.Material
GROUP BY B.SLoc, A.Material, B.Material, B.[Stand Price], A.AvailableQty, B.Unrestricted
GO
