-- =============================================
-- Author:		HANSON
-- Create date: 2016-08-12
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Alert_BIN_SLED_Report] 
	@DaysRange int = -180
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
		
	set @AlertName = 'Warehouse_BIN_SLEDAlert'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	set @Rcnt = (SELECT COUNT(*) FROM 
					(SELECT * ,LifeDays = datediff(d, replace( replace(dbo.GetStrPara(SledInfo,3,':'),'"',''),'}]',''),getdate())
					FROM Tb_PI_By_Bin 
					WHERE [SledInfo] LIKE '%RECODE":0%' and  
							[LstUpdateTime] BETWEEN DATEADD(dd,-1,getdate()) AND getdate())as v
				  where LifeDays  >= @DaysRange  )	
	if @Rcnt =0 return	

	SET @tableHTML =
    N'<H1>Hi, All: </H1>' +
    N'<H1>Please pay more attention to below items which the material shelf life will be expired within 180 days </H1>' +
    N'<table border="1">' +
    N'<tr><th>Sloc</th><th>BinLoc</th>' +
    N'<th>Matlgroup</th><th>PartNum</th><th>Qty</th><th>GRN</th><th>SLED</th><th>LifeDays</th></tr>' +
    CAST ( ( SELECT td = Sloc,       '',
                    td = BinLoc, '',
                    td = Matlgroup, '',
                    td = PartNum, '',
                    td = Qty, '',
                    td = GRN,'',
                    td = SLED, '',
                    td = LifeDays, ''
              from 
			    (SELECT   Sloc
                         ,BinLoc
						 ,Matlgroup
						 ,PartNum
						 ,Qty 
						 ,GRN
						 ,[LstUpdateTime]
						 ,SLED = (replace( replace(dbo.GetStrPara(SledInfo,3,':'),'"',''),'}]',''))
						 ,LifeDays = datediff(d, replace( replace(dbo.GetStrPara(SledInfo,3,':'),'"',''),'}]',''),getdate())
					     ,TodayDate = getdate()
FROM(
SELECT     a.Sloc, a.PI_ID, a.BinLoc, a.PartNum,convert(int,a.Qty) as qty, a.GRN, a.SledInfo, a.AddBy, a.LstUpdateTime, a.Remark, a.id, b.Matlgroup
FROM         dbo.Tb_PI_By_Bin AS a LEFT JOIN
                      dbo.BAS_SKU AS b ON a.PartNum = b.Material)as t
 WHERE [SledInfo] LIKE '%RECODE":0%' and  [LstUpdateTime] BETWEEN DATEADD(dd,-1,getdate()) AND getdate() ) as v
  
			WHERE LifeDays >= @DaysRange                   
              FOR XML PATH('tr'), TYPE 
				) AS NVARCHAR(MAX) ) +
    N'</table>' +    
    'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';

    
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END
GO
