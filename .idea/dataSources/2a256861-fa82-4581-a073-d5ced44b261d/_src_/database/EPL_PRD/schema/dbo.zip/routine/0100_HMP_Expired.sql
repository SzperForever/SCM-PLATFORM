-- =============================================
-- Author:		DAILS
-- Create date: 2017-06-26
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[0100_HMP_Expired]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@tableHTML2 nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@Rcnt2 int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
			
	set @AlertName = '0100_HMP_Expired'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	


set @Rcnt = (SELECT count(0) FROM(
SELECT [Plant]
      ,[SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]
      ,[MaterialGroup]      
      ,[GRN]
      ,[Quantity]
      ,[UnitPrice]
      ,[UnitPrice]*[Quantity] AS TotalPrice
      --,[SLED]
      ,CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END  AS U_SLED
      ,DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )as Non_Expired
      ,[DateCode]
      ,[CreatedBy]
      ,[CreatedDate]  
  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1'and [SLoc]='0100'
  )AS A
		WHERE Non_Expired  < '1' )
	
set @Rcnt2 = (SELECT count(0) FROM(
SELECT [Plant]
      ,[SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]
      ,[MaterialGroup]      
      ,[GRN]
      ,[Quantity]
      ,[UnitPrice]
      ,[UnitPrice]*[Quantity] AS TotalPrice
      --,[SLED]
      ,CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END  AS U_SLED
      ,DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )as Non_Expired
      ,[DateCode]
      ,[CreatedBy]
      ,[CreatedDate]  
  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1'and [SLoc]='0100'
  )AS A
		WHERE Non_Expired  < '1' )
     
     
	
   
set @tableHTML2 = ''	
set @tableHTML = 
		N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
     	--N'<font color=#FF0000><H1> [MaterialGroup</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[MaterialGroup]</th><th>GRN_QTY</th><th>TotalPrice</th></tr>' +
		CAST ( (SELECT
                         td = [MaterialGroup],'',
                         td = [GRN_QTY],'',
                         td = [TotalPrice],''
FROM [EPL_PRD].[dbo].[View_0100_HMP_Expired]
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
N'</table>'


		
set @tableHTML2 = 	
		N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
		N'<font color=#FF0000><H1> 下面是HMP库存过期的物料</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[SLoc]</th><th>[StorageType]</th><th>[Material]</th><th>GRN</th><th>QTY</th><th>TotalPrice</th><th>GStorageBin</th><th>SLED</th><th>Expired_AgingDay</th><th>[CreatedDate]</th></tr>' +
		
	CAST ( (	SELECT 
		  td = [SLoc],'',
          td = [StorageType],'',
          td = [Material],'',
          td = [GRN],'',
          td = convert(int,[Quantity]) ,'',
          td = convert(varchar(30),cast(TotalPrice as money),1),'',
          --td = TotalPrice ,'',
          td = [StorageBin] ,'',	
          td = SLED,'',
          td = Expired,'',
          td = [CreatedDate],''	
		
FROM(
SELECT [Plant]
      ,[SLoc]
      ,[StorageType]
      ,[StorageBin]
      ,[Material]
      ,[MaterialGroup]      
      ,[GRN]
      ,[Quantity]
      ,[UnitPrice]
      ,[UnitPrice]*[Quantity] AS TotalPrice
      ,[SLED]
      --,CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END  AS U_SLED
      ,DATEDIFF(DD,GETDATE(),CASE WHEN [SLED] IS NULL  THEN '12-31-9999' ELSE [SLED] END )as Expired
      ,[DateCode]
      ,[CreatedBy]
      ,[CreatedDate]  
  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1' and [SLoc]='0100'
  )AS A
		WHERE Expired  <= '0' 
		order by Expired
				FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +	

		N'</table>' +    
    
		'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';
    if @Rcnt =0 and @Rcnt2 =0  return

	if @Rcnt > 0 and @Rcnt2 = 0 return
		set @tableHTML=@tableHTML
	end	
	if @Rcnt = 0 and @Rcnt2 > 0 begin
		set @tableHTML= @tableHTML2
	end	
	if @Rcnt > 0 and @Rcnt2 > 0  begin
		set @tableHTML=@tableHTML+ @tableHTML2
	--end	
	
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END

GO
