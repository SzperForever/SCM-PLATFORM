CREATE TRIGGER [dbo].[Tri_Assign_Default_Permission]
   ON  dbo.Bas_User     
   AFTER INSERT
AS 
BEGIN

	SET NOCOUNT ON;
	declare @UserRole varchar(20),@UserID varchar(10)
	
	set @UserRole = (Select userrole from inserted)
	set @UserID = (Select Userid from inserted)
	
	exec [SP_UserPermission_Assignment] @UserRole, @UserID 

END
GO
