-- =============================================
-- Author:		HANSON ZHANG
-- Create date: 2016-10-18
-- Description:	UPDATE_STATISTICS
-- =============================================
Create  PROCEDURE [dbo].[SP_SYS_UPDATE_STATISTICS_LVHM]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
SET NOCOUNT ON;DECLARE UpdateStatisticsTables CURSOR READ_ONLY FOR
      SELECT sst.name,
             Schema_name(sst.schema_id)
      FROM   sys.tables sst
      WHERE  sst.TYPE = 'U'  
			and sst.object_id in (
											996914623,--Bas_Bom
											780581869,--Bas_BomLink
											391008474,--Bas_BuyerInfo
											1042154808,--Bas_Code
											1769109393,--BAS_CostCenter
											1244583522,--Bas_Machine_Feeder_Report
											504388866,--Bas_MPN
											1793441463,--Bas_PartInfo
											253959981,--Bas_SAPbom
											194151787,--Bas_Shipping_PCBA_STDQTY
											914154352,--BAS_SKU
											1767729400,--TB_Feeder_Setup_History
											1474156347,--TB_FG_MP_Details
											1342679881,--TB_FG_PKG_Details
											2114158627,--TB_FG_PKL_Details
											123199539,--TB_FG_SM_Details
											1163203244,--TB_FG_SR_Details
											167723700,--TB_FG_SR_Header
											2103730597,--TB_KIT_DOC
											919726379,--TB_KIT_MP_DETAILS
											951726493,--TB_KIT_ORDER_HEADER
											999726664,--TB_KIT_RAW_HISTORY
											2071730483,--TB_KIT_RIPE_HISTORY
											357628367,--TB_Kitting_BatchList
											631725353,--Tb_Kitting_Order_Header
											503724897,--Tb_Kitting_Order_Header_2
											1013630704,--Tb_Kitting_RawPart_Inv_Compare
											2039014345,--TB_LVHM_Feeders
											1527012521,--Tb_Order_Details
											1575012692,--Tb_PreparedList
											1433108196,--Tb_RTS
											354100302,--TB_RTSzz
											807725980,--TB_SAP_INV_FINAL
											2151103,--TB_SAP_INV_WH
											1849109678,--Tb_SR_Details
											1614680850,--Temp_RTS_SAPData
											943394480--tmp_RTS
											) 
    DECLARE @name   VARCHAR(80),
            @schema VARCHAR(40)
     
    OPEN UpdateStatisticsTables
     
    FETCH NEXT FROM UpdateStatisticsTables INTO @name, @schema
     
    WHILE ( @@FETCH_STATUS <> -1 )
      BEGIN
          IF ( @@FETCH_STATUS <> -2 )
            BEGIN
                    DECLARE @sql NVARCHAR(1024)
            SET @sql='UPDATE STATISTICS ' + Quotename(@schema)
                               +
                               '.' + Quotename(@name)
                      EXEC Sp_executesql @sql
            END
     
          FETCH NEXT FROM UpdateStatisticsTables INTO @name, @schema
      END
     
    CLOSE UpdateStatisticsTables
     
    DEALLOCATE UpdateStatisticsTables
     
    
END
GO
