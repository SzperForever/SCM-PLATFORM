create PROCEDURE Sp_AddNewCiscoCountHistoryRecords
	@RegDate date,
	@AddWho varchar(10),
	@RegTime time(0),
	@PartNo varchar(20),
	@TakeOutFrom varchar(4),
	@TakeInTo varchar(4),
	@AddTime smalldatetime,
	@Remark varchar(20),
	@ScanQty varchar(20),
	@ScanGRN varchar(18)
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [dbo].[TbCiscoCountHistory]
           ([RegDate]
           ,[RegTime]
           ,[PartNo]
           ,[ScanQty]
           ,[ScanGRN]
           ,[TakeOutFrom]
           ,[TakeInTo]
           ,[AddWho]
           ,[AddTime]
           ,[Remark])
     VALUES
           (@RegDate,@RegTime,@PartNo,@ScanQty,@ScanGRN,@TakeOutFrom,@TakeInTo,@AddWho,@AddTime,@Remark)
END
GO
