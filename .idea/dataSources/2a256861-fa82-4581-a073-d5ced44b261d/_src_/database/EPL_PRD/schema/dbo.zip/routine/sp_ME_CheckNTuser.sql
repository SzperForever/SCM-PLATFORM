CREATE PROCEDURE [dbo].[sp_ME_CheckNTuser]
	@NTuserID varchar(20),@ReturnValue int output
AS
BEGIN
	SET NOCOUNT ON;
	if (select ID from me_users where ntuserid = @NTuserID) > 0
		set @ReturnValue =1
	else
		set @ReturnValue =0
END
GO
