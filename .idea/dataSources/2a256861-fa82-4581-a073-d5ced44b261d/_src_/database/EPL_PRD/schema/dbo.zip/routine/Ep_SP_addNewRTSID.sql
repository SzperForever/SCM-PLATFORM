
CREATE  PROCEDURE [dbo].[Ep_SP_addNewRTSID] 
	@CreateBy nvarchar(20),
	@RTSNo varchar(12) output
	
AS
	begin
	DECLARE @dt CHAR(6)

	-- Add the T-SQL statements to compute the return value here
	
	SELECT @dt=dt FROM v_GetDate	
	
	set @RTSNo = (SELECT 'R' + @dt+RIGHT(100001+ISNULL(RIGHT(MAX(RTSID),5),0),5) 
					FROM TEMP_RTSID WITH(XLOCK,PAGLOCK) 
					WHERE RTSID like '%R' + @dt+'%')
					
	-- Return the result of the function
	INSERT INTO [dbo].[Temp_RTSID]
           ([RTSID]
           ,[CreateTime]
           ,[CreateBy])
     VALUES
			(@RTSNo,GETDATE(),@CreateBy)
     
	end
GO
