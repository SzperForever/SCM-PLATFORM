

CREATE VIEW [dbo].[View_Kitting_BatchList]
AS
SELECT     b.OrderID AS BatchID, b.PartNo, a.Kits_Qty, a.OrderID, a.OrderStatus
FROM         dbo.View_Kitting_Order_Headers AS a with (nolock) LEFT OUTER JOIN
                      dbo.Tb_PreparedList AS b with (nolock) ON a.KittingPartNum = b.PartNo
WHERE     (b.FlagGroup = 'Kitting') AND (b.PreparedID = 'KOM') AND (a.OrderStatus = 'OPEN')
GROUP BY b.OrderID, a.OrderID, b.PartNo, a.OrderStatus, a.Kits_Qty


GO
