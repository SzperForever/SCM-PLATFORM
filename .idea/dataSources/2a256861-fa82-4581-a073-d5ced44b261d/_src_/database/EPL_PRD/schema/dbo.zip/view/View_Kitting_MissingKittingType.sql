
CREATE VIEW [dbo].[View_Kitting_MissingKittingType]
AS
SELECT DISTINCT KittingPartNum, KittingType, OrderCreateBy AS IA
FROM         dbo.View_Kitting_Order_Headers AS a with (nolock)
WHERE     (OrderStatus = 'OPEN') AND (KittingType = 'None')

GO
