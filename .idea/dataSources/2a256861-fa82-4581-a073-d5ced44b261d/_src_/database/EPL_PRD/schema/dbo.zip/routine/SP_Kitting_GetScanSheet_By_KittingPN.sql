-- =============================================
-- Author:		<Hanson>
-- Create date: <2014-12-4>
-- Description:	<Get Overall Status by kitting pn>
-- Example Cmd: SP_GetOverallStatus_By_KittingPN '2061617$4'
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_GetScanSheet_By_KittingPN] 
	-- Add the parameters for the stored procedure here
	@KittingPartNum varchar(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	declare @TmpScanSheet table
	(	
		ID				int identity(1,1) primary key,
		PartNo	varchar(30) not null,
		Qty		float not null,
		GRN		varchar(18) not null,
		ScanBy	varchar(20) not null,
		ScanTime DateTime not null
	)
	
	
	insert into @TmpScanSheet (PartNo,Qty,GRN,ScanBy,ScanTime)
	SELECT [PartNo],[Qty],[GRN],[ScanBy],[ScanTime]  
	FROM [dbo].[View_Kitting_BatchDetails]  with (nolock) 
	where orderstatus = 'OPEN' 

	Select [PartNo],[Qty],[GRN],[ScanBy],[ScanTime]  
	from 	@TmpScanSheet
	where [PartNo] = @KittingPartNum 
	group by [PartNo],[Qty],[GRN],[ScanBy],[ScanTime]  
	order by ScanTime desc

END
GO
