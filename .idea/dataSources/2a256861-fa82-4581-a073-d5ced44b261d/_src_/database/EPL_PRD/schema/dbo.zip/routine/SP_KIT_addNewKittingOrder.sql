
CREATE  PROCEDURE [dbo].[SP_KIT_addNewKittingOrder]

		--@WorkCell varchar(20),
		@KittingPartNum varchar(30),
		@Kits_Qty FLOAT,
		@BuildPlanTime datetime,
		@CreateBy varchar(10),
		@DmdType int    -- 1 = Normal ,Flag = 0 means normal order
						-- 0 = Shortage, Flag = 1 means shortage order
						
		--@Priority varchar(10)
		
AS
	begin	
		--Declare @MsgInfo varchar(100)
		--set @msginfo = 'Kitting orders are limited to be uploaded during this time.亲：嘿嘿.不要偷偷尝试上传，大过年休息好。'
		--raiserror (@msginfo,16,1)
		--return

		declare @OrderID Varchar(13)
		DECLARE @dt CHAR(6),@Flag int
		declare @NOWI bit
		set @NOWI= 1   --1 means have wi
		SELECT @dt=dt FROM v_GetDate	
			
		set @orderid = (SELECT 'K'+ @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(orderid),6),0),6) 
						FROM dbo.TB_KIT_ORDER_HEADER  WITH(XLOCK,PAGLOCK) 
						WHERE orderid like 'K' + @dt+'%')
		--print @orderid
		
		set @Flag= 0 
		
		if @DmdType = 0 
			begin
				set @BuildPlanTime = '2099-1-1 12:00:00'
				set @Flag = 1
			end
		
		if @DmdType = 1
			begin
				--无图纸的标记FLAG 为2
				if not EXISTS (Select KittingPartNum  from dbo.TB_KIT_DOC where KittingPartNum = @KittingPartNum ) 
					begin
						set @BuildPlanTime = '2099-1-1 12:00:00'
						SET @Flag =2
						raiserror ('Document for this kitting partnumber is not found. Check tb_kit_doc table.',16,1)
						return
					end
			end		
		
		INSERT INTO dbo.TB_KIT_ORDER_HEADER
           ([OrderID]
           ,[OrderStatus]
           ,[KittingPartNum]
           ,[BuildPlanTime]
           ,[Kits_Qty]
           ,[Order_ReleasedBy]
           ,[Order_ReleasedTime]
           ,[CurrentPlace]
           ,[Flag]
		   ,[Station]
		   ,[ProgressCode]
           --,[Old_Kits_Qty]
           ,[OrderNotes])           
			VALUES (@orderid			
				--dbo.f_NextBH(@Model,@Batch)--自定义函数，相同MODEL,相同套数,相同BATCH用同一个orderID.
				,'OPEN'
				,@KittingPartNum
				,@BuildPlanTime
				,@Kits_Qty
				,@CreateBy
				,GETDATE()
				,'KIT'
				,@Flag
				,0
				,300
				,'')		
			
			
			if @@ERROR <> 0 begin
				raiserror ('Error occured during inserting order into Tb_Kitting_order_Header table.',16,1)
				return
			end
end

GO
