


CREATE  PROCEDURE [dbo].[SP_FG_SR_ItemRemove]
		@SRid int,
		@SRitem_ID INT,
		@ActionBy nchar(10)
AS
	begin		
		DECLARE @Proj varchar(35),@rcount int,@SRStatus nchar(3),@OrderStatus  nchar(3) , @ErrMsg varchar(500)

		set @SRStatus = (Select SR_Status from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRID)

		set @OrderStatus = (Select SR_OrderStatus  from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
		if @OrderStatus <> '200' begin
			set @ErrMsg = 'SR status is not open.'
			raiserror (@ErrMsg,16,1)
			return
		end

		if @SRStatus = '901' begin
			set @ErrMsg = 'This SR is already activated which deletion is not allowed.（SR已激活情况下不允许添加和删除行。）'
			raiserror (@ErrMsg,16,1)
			return
		end
		
		SET @rcount= (Select count(*) from [TB_FG_SR_Details] where addby = @ActionBy and srid = @srid)
		if @rcount  = 0 begin
			set @ErrMsg = 'Operation is denied since you do not have the right to perform the deletion.(操作被拒绝因为你没有权限删除此行。)'
			raiserror (@ErrMsg,16,1)
			return
		end

		delete from [TB_FG_SR_Details]
		Where SRID = @SRid AND SR_Item_id = @SRitem_ID 

end


		


--CodeGroup	Code	Chinese_DESC	English_DESC	CodeGroup_Desc
--57	9         	900       	创建订单	SRNotActivated	SR_Status
--58	9         	901       	激活订单	SRActivated	SR_Status
--59	9         	902       	未创建拣货单	MPNotCreated	SR_SP_Status
--60	9         	903       	拣货单创建	MPCreated	SR_SP_Status
--61	9         	904       	拣货中	MPPicking	SR_SP_Status
--62	9         	905       	打印唛头中	PrintShippingMark	SR_SP_Status
--63	9         	906       	等待PGI中	PGI NotStarted	SR_SP_Status
--64	9         	907       	扣PGI中	PGI InProgress	SR_SP_Status
--65	9         	908       	待装车	TruckNotLoaded	SR_SP_Status
--66	9         	909       	发货中	TruckLoading	SR_SP_Status
--67	9         	910       	已发货	ShippedOut	SR_SP_Status

--200  open
--201  closed
--202  cancel
--203  hold
--204  activated
GO
