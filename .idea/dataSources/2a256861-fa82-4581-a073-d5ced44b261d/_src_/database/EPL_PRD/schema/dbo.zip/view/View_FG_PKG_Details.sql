CREATE VIEW dbo.View_FG_PKG_Details
AS
SELECT        TOP (100) PERCENT h.SRid, h.SRno, p.PKGid, p.LineID, p.PartNum, p.Qty, p.BoxID, (CASE WHEN h.isplt = 1 THEN h.SRno + '-' + CONVERT(nchar(12), p.PKGid) 
                         WHEN h.isplt = 0 THEN h.SRno + '-' + CONVERT(nchar(12), p.LineID) END) AS Lbid, u.UserName AS AddBy, p.AddTime, p.ID, (CASE WHEN d .length = 0 OR
                         d .width = 0 OR
                         d .height = 0 OR
                         d .GrossWeight = 0 OR
                         d .NetWeight = 0 THEN 'N' ELSE 'Y' END) AS HasSizeInfo
FROM            dbo.View_FG_SR_Headers AS h INNER JOIN
                         dbo.TB_FG_PKG_Details AS p ON h.SRid = p.SRid INNER JOIN
                         dbo.View_Users AS u ON p.AddBy = u.UserID INNER JOIN
                         dbo.TB_FG_SM_Details AS d ON p.SRid = d.SRid AND p.PKGid = d.Lbid
ORDER BY h.SRid, h.SRno, p.PKGid
GO
