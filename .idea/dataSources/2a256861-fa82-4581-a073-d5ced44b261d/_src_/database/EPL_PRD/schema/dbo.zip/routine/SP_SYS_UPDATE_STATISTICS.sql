-- =============================================
-- Author:		HANSON ZHANG
-- Create date: 2016-10-18
-- Description:	UPDATE_STATISTICS
-- =============================================
CREATE PROCEDURE SP_SYS_UPDATE_STATISTICS
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
SET NOCOUNT ON;DECLARE UpdateStatisticsTables CURSOR READ_ONLY FOR
      SELECT sst.name,
             Schema_name(sst.schema_id)
      FROM   sys.tables sst
      WHERE  sst.TYPE = 'U'
    DECLARE @name   VARCHAR(80),
            @schema VARCHAR(40)
     
    OPEN UpdateStatisticsTables
     
    FETCH NEXT FROM UpdateStatisticsTables INTO @name, @schema
     
    WHILE ( @@FETCH_STATUS <> -1 )
      BEGIN
          IF ( @@FETCH_STATUS <> -2 )
            BEGIN
                    DECLARE @sql NVARCHAR(1024)
            SET @sql='UPDATE STATISTICS ' + Quotename(@schema)
                               +
                               '.' + Quotename(@name)
                      EXEC Sp_executesql @sql
            END
     
          FETCH NEXT FROM UpdateStatisticsTables INTO @name, @schema
      END
     
    CLOSE UpdateStatisticsTables
     
    DEALLOCATE UpdateStatisticsTables
     
    
END
GO
