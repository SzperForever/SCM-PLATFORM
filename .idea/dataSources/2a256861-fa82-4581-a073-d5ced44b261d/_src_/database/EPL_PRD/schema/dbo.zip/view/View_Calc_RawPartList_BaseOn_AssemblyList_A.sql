CREATE VIEW dbo.View_Calc_RawPartList_BaseOn_AssemblyList
AS
SELECT     s.Component, SUM(t.Sets) AS TotalSets, k.Standard_price, SUM(t.Sets) * s.[Qty Per] AS TotalQty, SUM(t.Sets) * s.[Qty Per] * k.Standard_price AS TotalPrice
FROM         dbo.Tmp_AssemblyList AS t INNER JOIN
                      dbo.Bas_SAPbom AS s ON t.AssemblyName = s.[Assembly Name] INNER JOIN
                      dbo.BAS_SKU AS k ON s.Component = k.Material
GROUP BY s.Component, s.[Qty Per], k.Standard_price
GO
