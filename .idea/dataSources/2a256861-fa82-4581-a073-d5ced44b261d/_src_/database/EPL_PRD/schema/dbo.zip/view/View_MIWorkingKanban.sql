CREATE VIEW dbo.View_MIWorkingKanban
AS
SELECT     TOP (100) PERCENT WorkCell,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details
                            WHERE      (StockSts = 'NotStarted') AND (WorkCell = a.WorkCell) AND (OrderStatus = 'Open') AND (OrderType = 'MIPull')) AS NotStarted,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_6
                            WHERE      (StockSts = 'Picking') AND (WorkCell = a.WorkCell) AND (OrderStatus = 'Open') AND (OrderType = 'MIPull')) AS Picking,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_5
                            WHERE      (LVHMsts = 'Received') AND (ConditionalFormat = 'NotStarted') AND (WorkCell = a.WorkCell) AND (OrderStatus = 'Open') AND 
                                                   (OrderType = 'MIPull')) AS LVNotStarted,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_5
                            WHERE      (LVHMsts = 'Received') AND (ConditionalFormat = 'InProgress') AND (WorkCell = a.WorkCell) AND (OrderStatus = 'Open') AND 
                                                   (OrderType = 'MIPull')) AS LVInProgress,
                          (SELECT     COUNT(DISTINCT OrderID) AS Expr1
                            FROM          dbo.Tb_Order_Details AS Tb_Order_Details_4
                            WHERE      (LVHMsts = 'Received') AND (ConditionalFormat = 'Completed') AND (WorkCell = a.WorkCell) AND (OrderStatus = 'Open') AND 
                                                   (OrderType = 'MIPull')) AS LVCompleted
FROM         dbo.Tb_Order_Details AS a
WHERE     (OrderType = 'MIPull') AND (OrderStatus = 'Open')
GROUP BY WorkCell
ORDER BY WorkCell
GO
