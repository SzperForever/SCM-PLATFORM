CREATE VIEW dbo.V_KIT_Inspection
AS
SELECT        h.OrderID, h.OrderStatus, dbo.Bas_SAPbom.[Material Group] AS Workcell, h.KittingPartNum, (CASE WHEN RIGHT(kittingpartnum, 3) 
                         = '-R$' THEN 'ROHS' ELSE 'Non-ROHS' END) AS ROHS_OR_NOT, h.Kits_Qty, h.FinalQty, h.Processing_FinishedBy AS P_empID,
                             (SELECT        EnglishName
                               FROM            EPL_SEC.dbo.COM_Member AS u1
                               WHERE        (UserID = h.Processing_FinishedBy)) AS PFB_Name, h.Processing_FinishTime, h.FI_FinishedBy AS FI_empID,
                             (SELECT        EnglishName
                               FROM            EPL_SEC.dbo.COM_Member AS u2
                               WHERE        (UserID = h.FI_FinishedBy)) AS FI_Name, h.FI_FinishedTime, h.FNI_FinishedBy AS FNI_empID,
                             (SELECT        EnglishName
                               FROM            EPL_SEC.dbo.COM_Member AS u3
                               WHERE        (UserID = h.FNI_FinishedBy)) AS FNI_Name, h.FNI_FinishedTime, h.OBA_FinishedBy AS OBA_empID,
                             (SELECT        EnglishName
                               FROM            EPL_SEC.dbo.COM_Member AS u4
                               WHERE        (UserID = h.OBA_FinishedBy)) AS OBA_Name, h.OBA_FinishedTime, (CASE WHEN FinalQty <= 32 THEN FinalQty WHEN FinalQty BETWEEN 32 AND 
                         50 THEN 32 WHEN FinalQty BETWEEN 51 AND 500 THEN 32 WHEN FinalQty BETWEEN 501 AND 3200 THEN 125 WHEN FinalQty BETWEEN 3201 AND 
                         10000 THEN 200 WHEN FinalQty BETWEEN 10001 AND 35000 THEN 315 WHEN FinalQty BETWEEN 35001 AND 150000 THEN 500 WHEN FinalQty BETWEEN 
                         150001 AND 500000 THEN 800 WHEN FinalQty >= 500001 THEN 1250 END) AS FNI_Insp_Qty, (CASE WHEN FinalQty <= 25 THEN FinalQty WHEN FinalQty BETWEEN
                          26 AND 280 THEN 32 WHEN FinalQty BETWEEN 281 AND 1200 THEN 32 WHEN FinalQty BETWEEN 1201 AND 3200 THEN 125 WHEN FinalQty BETWEEN 3201 AND
                          10000 THEN 200 WHEN FinalQty BETWEEN 10001 AND 35000 THEN 315 WHEN FinalQty BETWEEN 35001 AND 150000 THEN 500 WHEN FinalQty BETWEEN 
                         150001 AND 500000 THEN 800 WHEN FinalQty >= 500001 THEN 1250 END) AS OBA_Insp_Qty
FROM            dbo.TB_KIT_ORDER_HEADER AS h INNER JOIN
                         dbo.Bas_SAPbom ON h.KittingPartNum = dbo.Bas_SAPbom.[Assembly Name]
GO
