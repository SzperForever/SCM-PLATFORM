
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_CLOSE_Pull]
	-- Add the parameters for the stored procedure here
	@PullListNo nchar(13)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @Rcnt int,@TruckInfo varchar(20),@StoreArea varchar(10),@AssignedTo varchar(15)
	
	set @rcnt = (select COUNT(*) from Tb_Kitting_Order_Header  where PullListNo = @PullListNo and OrderStatus = 'OPEN' and Stocksts ='INPROGRESS')
	
	if @rcnt = 0 
	begin
		raiserror ('No pulllist been found or Invalid pull status.',16,1)
		return
	end 
	else begin	
		UPDATE Tb_Kitting_Order_Header
		SET Stocksts  = 'Completed'
			,Stock_completeTime =GETDATE()
			,Kitting_ReceivedTime =GETDATE()
			,KittingStatus = 'InProgress'
			,CurrentPlace = '3Y'
		    ,Stock_LeadTime=(select dbo.f_second_Time(datediff(ss,Stock_ReceivedTime ,GETDATE())))
		WHERE Pulllistno = @PullListNo and OrderStatus = 'OPEN' and Stocksts ='INPROGRESS'
	end

END

GO
