-- =============================================
-- Author:		HANSON ZHANG
-- Create date: 2017-02-8
-- Description:	Rebuild indexes
-- =============================================
CREATE  PROCEDURE [dbo].[SP_SYS_REBUILD_INDEXES_LVHM_Related]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		--使用游标重新组织指定库中的索引,消除索引碎片
		--R_T层游标取出当前数据库所有表
		declare R_T cursor
			for select name from sys.tables
		declare @T varchar(50)
		open r_t
		fetch next from r_t into @t
		while @@fetch_status=0
		begin
		--R_index游标判断指定表索引碎片情况并优化
		declare R_Index cursor
		for select t.name,i.name,s.avg_fragmentation_in_percent from sys.tables t
		  join sys.indexes i on i.object_id=t.object_id
		  join sys.dm_db_index_physical_stats(db_id(),object_id(@T),null,null,'limited') s
		   on s.object_id=i.object_id and s.index_id=i.index_id
		   where i.index_id > 0  
				and s.avg_fragmentation_in_percent > 15.0  
				and s.object_id in (
											996914623,--Bas_Bom
											780581869,--Bas_BomLink
											1244583522,--Bas_Machine_Feeder_Report
											1793441463,--Bas_PartInfo
											253959981,--Bas_SAPbom
											914154352,--BAS_SKU
											1767729400,--TB_Feeder_Setup_History
											2039014345,--TB_LVHM_Feeders
											1527012521,--Tb_Order_Details
											1575012692,--Tb_PreparedList
											1433108196,--Tb_RTS
											354100302,--TB_RTSzz
											807725980,--TB_SAP_INV_FINAL
											2151103,--TB_SAP_INV_WH
											1614680850,--Temp_RTS_SAPData
											943394480--tmp_RTS
											) 
		  
		declare @TName varchar(50),@IName varchar(200),@avg int,@str varchar(500)
		open r_index
		fetch next from r_index into @TName,@Iname,@avg
		while @@fetch_status=0
		begin
		  if @avg>=30  --如果碎片大于30,重建索引
		  begin
		   set @str='alter index '+rtrim(@Iname)+' on dbo.'+rtrim(@tname)+' rebuild'
		  end
		  else   --如果碎片小于30,重新组织索引
		  begin
		   set @STR='alter index '+rtrim(@Iname)+' on dbo.'+rtrim(@tname)+' reorganize'
		  end
		  print @str
		  exec (@str)  --执行
		  fetch next from r_index into @TName,@Iname,@avg
		end
		--结束r_index游标
		close r_index
		deallocate r_index
		fetch next from r_t into @t
		end
		--结束R_T游标
		close r_t
		deallocate r_t
		set nocount off

		--查看指定表的索引情况
		Select * from [V_SYS_Idx_Frag_Analysis_All] 
		where 
						avg_fragmentation_in_percent > 15 and 
						object_id in (
											996914623,--Bas_Bom
											780581869,--Bas_BomLink
											1244583522,--Bas_Machine_Feeder_Report
											1793441463,--Bas_PartInfo
											253959981,--Bas_SAPbom
											914154352,--BAS_SKU
											1767729400,--TB_Feeder_Setup_History
											2039014345,--TB_LVHM_Feeders
											1527012521,--Tb_Order_Details
											1575012692,--Tb_PreparedList
											1433108196,--Tb_RTS
											354100302,--TB_RTSzz
											807725980,--TB_SAP_INV_FINAL
											2151103,--TB_SAP_INV_WH
											1614680850,--Temp_RTS_SAPData
											943394480--tmp_RTS
											) 
				order by avg_fragmentation_in_percent  desc 
		----查看所有表的索引情况		
		--Select * from V_SYS_Idx_Frag_Analysis_All
END
GO
