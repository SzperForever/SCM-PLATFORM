CREATE VIEW dbo.V_FG_SR_OrderValuePerStatus
AS
SELECT DISTINCT Project, CONVERT(money, ISNULL
                             ((SELECT        SUM(Amount) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE        (Project = v.Project) AND (SP_Status IN ('MPCreated', 'MPNotCreated', 'MPPicking'))), 0)) AS Amount_NotStarted, ISNULL
                             ((SELECT        SUM(OrderCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE        (Project = v.Project) AND (SP_Status IN ('MPCreated', 'MPNotCreated', 'MPPicking'))), 0) AS SRCount_NotStarted, ISNULL
                             ((SELECT        SUM(PartCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE        (Project = v.Project) AND (SP_Status IN ('MPCreated', 'MPNotCreated', 'MPPicking'))), 0) AS PartCount_NotStarted, CONVERT(money, ISNULL
                             ((SELECT        SUM(Amount) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE        (Project = v.Project) AND (SP_Status IN ('PrintShippingMark'))), 0)) AS Amount_InProgress, ISNULL
                             ((SELECT        SUM(OrderCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE        (Project = v.Project) AND (SP_Status IN ('PrintShippingMark'))), 0) AS SRCount_InProgress, ISNULL
                             ((SELECT        SUM(PartCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE        (Project = v.Project) AND (SP_Status IN ('PrintShippingMark'))), 0) AS PartCount_InProgress, CONVERT(money, ISNULL
                             ((SELECT        SUM(Amount) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE        (Project = v.Project) AND (SP_Status IN ('TruckNotLoaded', 'Packing'))), 0)) AS Amount_Completed, ISNULL
                             ((SELECT        SUM(OrderCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE        (Project = v.Project) AND (SP_Status IN ('TruckNotLoaded', 'Packing'))), 0) AS SRCount_Completed, ISNULL
                             ((SELECT        SUM(PartCnt) AS Expr1
                                 FROM            dbo.V_FG_SR_OrderValue AS v1
                                 WHERE        (Project = v.Project) AND (SP_Status IN ('TruckNotLoaded', 'Packing'))), 0) AS PartCount_Completed
FROM            dbo.V_FG_SR_OrderValue AS v
GO
