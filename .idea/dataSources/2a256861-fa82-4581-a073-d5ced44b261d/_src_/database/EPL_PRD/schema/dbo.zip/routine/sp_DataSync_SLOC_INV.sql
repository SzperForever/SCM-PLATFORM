


CREATE     PROCEDURE [dbo].[sp_DataSync_SLOC_INV]
AS
BEGIN
	SET NOCOUNT ON
	
    declare @RecAddress varchar(300)
	declare @errmsg nvarchar(2000)
    declare @chartype as varchar(10)
    declare @rt as varchar(40)

	set @RecAddress = '13817503000@139.com;13524709329@139.COM;13761064316@139.COM;15002168379@139.com'

	Delete from [dbo].TB_RES_SOURCE_SAP_INV 
		--select * from TB_RES_SOURCE_SAP_INV 
			where LEFT(ltrim([Column 0]),1) <> '|' or 
				  LEFT(ltrim([column 0]),5) in( 
												'|Name',
												'|Sloc',
												'|   ',
												'|Tota',
												'|Mate')


			 DELETE FROM TB_RES_SOURCE_SAP_INV
			 WHERE dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) < 16

		--If there is columns string '|' more over than 18 then alert administrator
		--select * from TB_RES_SOURCE_SAP_INV
		DECLARE @AbnormalRowCnt int
		set @AbnormalRowCnt = (Select count(*) FROM TB_RES_SOURCE_SAP_INV WHERE dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) > 18)
		if @AbnormalRowCnt > 0 
			begin
				

				INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
					VALUES ('sp_Data_BulkLoadSAPInvData', 'Fail to parser bulk data into temporary table.',99,GETDATE())
								set @errmsg = 'There is an error just occured during the sync sloc inventory process. ErrDesc: There are more than 18 specfic chacters detected. Error Number:' + str(@@error)
				EXEC [sp_SendingAlert] @RecAddress,'SLOC 库存同步错误提醒4',@errmsg
				
				RETURN 1
			end
			
		truncate table TB_SAP_INV_FINAL

		insert into TB_SAP_INV_FINAL
		SELECT  dbo.GetStrPara([Column 0],2,'|') as Sloc ,
				dbo.GetStrPara([Column 0],3,'|') as Material ,
				dbo.GetStrPara([Column 0],5,'|') as Mtrl_Grp ,
				dbo.GetStrPara([Column 0],6,'|') as Mtrl_Type ,
				dbo.GetStrPara([Column 0],7,'|') as StandPrice ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],8,'|')),1,' '),',','')) as Unrestricted ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],9,'|')),1,' '),',','')) as Unrestr_Cnsgt ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],10,'|')),1,' '),',','')) as Stock_In_Tfr ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],11,'|')),1,' '),',','')) as In_Qual_Insp ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],12,'|')),1,' '),',','')) as Cnsgt_Qual_In ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],13,'|')),1,' '),',','')) as Blocked ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],14,'|')),1,' '),',','')) as Blocked_Cnsgt ,
				dbo.GetStrPara([Column 0],15,'|') as Total_Value ,
				dbo.GetStrPara([Column 0],16,'|') as MRP ,
				dbo.GetStrPara([Column 0],4,'|') as Mtrl_Desc ,
				dbo.GetStrPara([Column 0],17,'|') as Plant ,
				getdate() as LastUpdateTime

		  FROM [dbo].TB_RES_SOURCE_SAP_INV  with (nolock)
		  where dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) = 17

		insert into TB_SAP_INV_FINAL
		SELECT  dbo.GetStrPara([Column 0],2,'|') as Sloc ,
				dbo.GetStrPara([Column 0],3,'|') as Material ,
				dbo.GetStrPara([Column 0],6,'|') as Mtrl_Grp ,
				dbo.GetStrPara([Column 0],7,'|') as Mtrl_Type ,
				dbo.GetStrPara([Column 0],8,'|') as StandPrice ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],9,'|')),1,' '),',','')) as Unrestricted ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],10,'|')),1,' '),',','')) as Unrestr_Cnsgt ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],11,'|')),1,' '),',','')) as Stock_In_Tfr ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],12,'|')),1,' '),',','')) as In_Qual_Insp ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],13,'|')),1,' '),',','')) as Cnsgt_Qual_In ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],14,'|')),1,' '),',','')) as Blocked ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],15,'|')),1,' '),',','')) as Blocked_Cnsgt ,
				dbo.GetStrPara([Column 0],16,'|') as Total_Value ,
				dbo.GetStrPara([Column 0],17,'|') as MRP ,
				(dbo.GetStrPara([Column 0],4,'|') + dbo.GetStrPara([Column 0],4,'|')) as Mtrl_Desc ,
				dbo.GetStrPara([Column 0],18,'|') as Plant ,
				getdate() as LastUpdateTime
		  FROM [dbo].TB_RES_SOURCE_SAP_INV  with (nolock)
		  where dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) > 17
		  
			
			IF @@ERROR <> 0
			BEGIN
				set @errmsg = 'There is an error just occured during the sync sloc inventory process. Please see job history to see the details.Error Number:' + str(@@error)
				EXEC [sp_SendingAlert] @RecAddress,'SLOC 库存同步错误提醒5',@errmsg
				RETURN 1
			END
			RETURN 0
		END


GO
