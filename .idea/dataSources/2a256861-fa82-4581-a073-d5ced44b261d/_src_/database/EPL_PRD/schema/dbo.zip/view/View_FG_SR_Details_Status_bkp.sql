CREATE VIEW dbo.View_FG_SR_Details_Status
AS
SELECT        TOP (100) PERCENT s.SRid, p.SRno, s.PartNum, s.TotalQty, SUM(ISNULL(p.Qty, 0)) AS DoneQty, SUM(ISNULL(p.Qty, 0)) - s.TotalQty AS Difference, 
                         COUNT(DISTINCT p.BoxID) AS PkgCnt
FROM            dbo.View_FG_PKG_Details AS p RIGHT OUTER JOIN
                         dbo.TB_FG_SR_Details AS s ON p.SRid = s.SRid AND p.PartNum = s.PartNum
GROUP BY s.PartNum, s.TotalQty, s.SRid, p.SRno
ORDER BY s.SRid DESC
GO
