
Create  PROCEDURE [dbo].[Ep_SP_addNewRTS_LCR_Rec] 
	@PN nvarchar(20),
	@QTY varchar(12),
	@GRN VARCHAR(18),
	@CreateName varchar(25),
	@empID VARCHAR(10),
	@Sts varchar(10)
	
AS
	begin

	-- Return the result of the function
	INSERT INTO [dbo].[TB_RTSzz]
           ([PN]
           ,[Qty]
           ,[GRN]
           ,[CreateTime]
           ,[CreateName]
           ,[empID]
           ,[Status])
     VALUES
	(@PN,@QTY,@GRN,GETDATE(),@CreateName,@empID ,@Sts )
     
	end
GO
