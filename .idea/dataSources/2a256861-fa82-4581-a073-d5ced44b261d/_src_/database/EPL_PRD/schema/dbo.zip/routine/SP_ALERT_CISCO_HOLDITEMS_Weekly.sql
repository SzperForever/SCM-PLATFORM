-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-1-3>
-- Description:	<Add New Trouble Shelf Item and send an alert msg.>
-- =============================================
CREATE PROCEDURE [dbo].[SP_ALERT_CISCO_HOLDITEMS_Weekly]
	-- Add the parameters for the stored procedure here

          -- @BuyerMailAddress nvarchar(100)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare  @RecAddressList nvarchar(250)
			,@CopyList Nvarchar(250)
			,@MailSubj nvarchar(200)
			,@Msg nvarchar(max)
			,@tableHTML  NVARCHAR(MAX) 

	--Steed_gu@jabil.com;qiudi_wang@jabil.com;zhu_jifeng@jabil.com
	select @Msg = 'Dear all,' + CHAR(10) + 
			 'This is an alert message for the trouble items of Cisco. Data range : last week.' 
     
	select @RecAddressList =( select recipients  from Cfg_DBmail where AlertName = 'CiscoWkReportForTroubleShelf')
	set @CopyList =( select CopyList   from Cfg_DBmail where AlertName = 'CiscoWkReportForTroubleShelf')
	set @MailSubj=( select Subject    from Cfg_DBmail where AlertName = 'CiscoWkReportForTroubleShelf')
	
	SET @tableHTML = @Msg +
		N'<H1>Weekly Report of Cisco Trouble Shelf </H1>' +
		N'<table border="1">' +
		N'<tr><th>Date</th><th>Plant</th><th>WorkCell</th><th>TrackingNumber</th><th>PartNumber</th><th>PO</th>' +
		N'<th>Qty</th><th>Vendor</th><th>Source</th><th>HAWB</th><th>Reason</th><th>PIC</th><th>CreateBy</th><th>CreateTime</th><th>SN</th><th>AgingDays</th><th>ItemStatus</th><th>ClosedTime</th></tr>' +
		CAST ( ( SELECT td = a.RegDate,       '',
						td = a.Plant, '',
						td = a.WorkCell, '',
						td = a.TrackingNumber, '',
						td = a.PartNumber, '',
						td = a.PO , '',
						td = a.Qty, '',
						td = a.Vendor, '',
						td = a.FromWhere, '',
						td = a.HAWB,'',
						td = a.Reason, '',
						td = a.Buyer, '',
						td = a.Addwho, '',
						td = a.AddTime, '',
						td = a.SN,'',
						td = datediff(d,addtime,getdate()), '',
						td = a.ItemStatus,
						td = a.ClosedTime
						
				  from TB_RCV_TroubleShelf as a 
				  where a.workcell = 'Cisco'  and DATEDIFF(d,AddTime, GETDATE())<= 7
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		'These records will be also contained to the aging daily report if not being closed within 24 hours.';
		     
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name ='EpullSqlMail',
	@recipients = @RecAddressList,
	@copy_recipients=@CopyList,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;
END
GO
