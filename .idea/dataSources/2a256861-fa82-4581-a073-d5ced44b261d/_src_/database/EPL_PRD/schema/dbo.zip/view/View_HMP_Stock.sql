CREATE VIEW dbo.View_HMP_Stock
AS
SELECT     In_ID, OutBatch, Movement, Bay, RegDate, Model, Material, AvailableQty, PullListNo, MoveQty, IssuedBy, IssuedToWho, OperateTime, Remark
FROM         dbo.Tb_HMP_IssueHistory
WHERE     (Movement = 'In') AND (AvailableQty <> 0)
GO
