CREATE TRIGGER [dbo].[Tri_RulesChecker]   ON  dbo.Sup_TempStoreIn
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	declare @Binloc varchar(6),
			@Partnum varchar(20),@MapCount int,
			@empID varchar(10),
			@ValueCount int,
			@MaxBinPartCount int,
			@Errmsg varchar(255),
			@StgType varchar(2),
			@InsertStgType varchar(2),
			@Movement varchar(3),@MovementBefroe varchar(3),@TempRowCount int,
			@TransferID varchar(15),
			@RemoveQty numeric(18, 7),@Inventory numeric(18, 7),@ActualInventory numeric(18,7)
			
			--入库相关变量
			set @Partnum =(select partnum from inserted)
			set @binloc = (select distinct binloc from inserted)
			set @empid = (select distinct addwho from inserted)
			set @StgType = (select storagetype from bas_sup_binloc where binloc = @Binloc)
			set @InsertStgType =(select distinct StoreType from inserted)
			set @Movement=(select distinct movement from inserted)
			set @TransferID = (select distinct Docno from inserted)
			set @TempRowCount = (select count(*) from [Sup_TempStoreIn] where Docno = @TransferID and addwho = @empID)
			
			if @TempRowCount > 0
				begin
					set @MovementBefroe = (select top 1 movement from [Sup_TempStoreIn] WHERE Docno = @TransferID and addwho = @empID)
					if @Movement <> @MovementBefroe
						begin
							rollback tran
							set @Errmsg = '同一批次操作时交易类型必须相同，此次写入操作失败。当前交易：' + @Movement + ',上一笔交易：' + @MovementBefroe
							raiserror(@ErrMsg,16,1)							
						end
				end
				
			if @Movement = '101' or @Movement = 'ZRT'
				begin
					set @ValueCount = (select count (1) FROM (select partnum from sup_tempstorein where binloc = @binloc union select material  from sup_inventory where binloc = @binloc) as a)
					set @MaxBinPartCount = (select MaxPartCount from bas_sup_binloc where binloc = @binloc)
					if @ValueCount > @MaxBinPartCount			
						begin
							rollback tran
							set @Errmsg = '该BIN位设置MaxPartCount不允许超过的最大允许存放物料数量 ' + ltrim(str(@MaxBinPartCount)) + '个.继续写入后将达到物料数量' + ltrim(str(@ValueCount)) + '。此次写入操作失败。'
							raiserror(@ErrMsg,16,1)	
						end
					else			
						begin
							if @InsertStgType <> @StgType
								begin
									rollback tran
									set @Errmsg = '库存储存类型不允许混放，当前储位' + @binloc + '的储存类型设置为：' + @StgType + ',待入库储存类型为：' + @InsertStgType + '.此次操作失败。'
									raiserror(@ErrMsg,16,1)							
								end
							else
								begin
									update bas_sup_binloc set binsts = 'IN',resuser = @empID where binloc = @Binloc	
								end
						end			
				end
					if @Movement = '311' or @Movement = '9Z1'
						begin										
							--出库相关变量
							set @RemoveQty = (select sum(qty) from [Sup_TempStoreIn] where PartNum =@Partnum and Docno = @TransferID and addwho = @empID)
							set @MapCount=(select count(*) from sup_skumap where material = @partnum)
							set @Inventory =(select AvailableQty from sup_inventory where material = @partnum and binloc =@binloc)
							set @ActualInventory =(select AvailableQty from sup_inventory where material = @partnum)
							
							if @inventory is null
								begin
									rollback tran
									set @Errmsg = '依地图上的库位:' + str(@binloc) + '上未找到有可用库存.如果实际有物理库存请确认实物所在库位与地图维护的库位是否相符。'
									raiserror(@ErrMsg,16,1)	
								end
							if @RemoveQty > @inventory
								begin
									rollback tran
									set @Errmsg = '库存不足，无法出库。此次操作失败。试图出库数量：' + ltrim(str(@RemoveQty)) + '可用库存余量：' + ltrim(str(@inventory))
									raiserror(@ErrMsg,16,1)								
								end
							if @RemoveQty < @inventory
								begin
									update bas_sup_binloc set binsts = 'OT',resuser = @empID where binloc = @Binloc	
								end
							if @RemoveQty = @inventory
								begin
									update bas_sup_binloc set binsts = 'OT',resuser = @empID where binloc = @Binloc	
								end
						end
end
GO
