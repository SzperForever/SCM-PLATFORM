
CREATE VIEW [dbo].[View_Kitting_RawPart_Inv]
AS
SELECT     TOP (100) PERCENT b.Component AS RawPartNum, b.[Qty Per], b.[Qty Per] * SUM(a.DiffQty) AS Shortage,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) + ISNULL(SUM(Unrestr_Cnsgt), 0) + ISNULL(SUM(In_Qual_Insp), 0) + ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_Total
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc IN ('0100', '0300', '0500', '0600', '0143', '01SH', '01TR', '01RB', 'O1RI', '03RI', '03RB'))) AS Inv_Total,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) + ISNULL(SUM(Unrestr_Cnsgt), 0) + ISNULL(SUM(In_Qual_Insp), 0) + ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_Total
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_2 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc IN ('0100', '0300', '0500', '0600', '0143', '01SH', '01TR', '01RB', 'O1RI', '03RI', '03RB'))) + b.[Qty Per] * SUM(a.DiffQty) 
                      AS DiffQty,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_0100
                            FROM          dbo.TB_SAP_INV_FINAL with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '0100')) AS Inv_0100,
                          (SELECT     ISNULL(SUM(Unrestr_Cnsgt), 0) AS Inv_0100
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_3 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '0100')) AS Inv_0100_Cnsgt,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_0300
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_2 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '0300')) AS Inv_0300,
                          (SELECT     ISNULL(SUM(Unrestr_Cnsgt), 0) AS Inv_0300
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_2 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '0300')) AS Inv_0300_Cnsgt,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_0500
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '0500')) AS Inv_0500,
                          (SELECT     ISNULL(SUM(Unrestr_Cnsgt), 0) AS Inv_0500
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '0500')) AS Inv_0500_Cnsgt,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_0600
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '0600')) AS Inv_0600,
                          (SELECT     ISNULL(SUM(Unrestr_Cnsgt), 0) AS Inv_0600
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '0600')) AS Inv_0600_Cnsgt,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_0143
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '0143')) AS Inv_0143,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_01SH
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '01SH')) AS Inv_01SH,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_01TR
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '01TR')) AS Inv_01TR,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_01RB
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '01RB')) AS Inv_01RB,
                          (SELECT     ISNULL(SUM(In_Qual_Insp), 0) AS Inv_01RB
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '01RB')) AS Inv_01RB_IQA,
                          (SELECT     ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_01RB
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '01RB')) AS Inv_01RB_Cnsgt_IQA,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_01RI
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '01RI')) AS Inv_01RI,
                          (SELECT     ISNULL(SUM(In_Qual_Insp), 0) AS Inv_01RI
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '01RI')) AS Inv_01RI_IQA,
                          (SELECT     ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_01RI
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '01RI')) AS Inv_01RI_Cnsgt_IQA,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_03RB
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '03RB')) AS Inv_03RB,
                          (SELECT     ISNULL(SUM(In_Qual_Insp), 0) AS Inv_03RB
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '03RB')) AS Inv_03RB_IQA,
                          (SELECT     ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_03RB
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '03RB')) AS Inv_03RB_Cnsgt_IQA,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) AS Inv_03RI
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '03RI')) AS Inv_03RI,
                          (SELECT     ISNULL(SUM(In_Qual_Insp), 0) AS Inv_03RI
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '03RI')) AS Inv_03RI_IQA,
                          (SELECT     ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_03RI
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1 with (nolock) 
                            WHERE      (Material = b.Component) AND (Sloc = '03RI')) AS Inv_03RI_Cnsgt_IQA, b.[Material Group]
FROM         dbo.Bas_SAPbom AS b  with (nolock) INNER JOIN
                      dbo.View_Kitting_OverallStatus AS a  with (nolock) ON b.[Assembly Name] = a.KittingPartNum
GROUP BY b.Component, b.[Qty Per], b.[Material Group]
ORDER BY DiffQty

GO
