
CREATE VIEW [dbo].[V_KIT_RawHistory]
AS
SELECT        r.OrderID, r.RawPartNum, r.Qnty AS ActualQty, r.GRN, h.KittingPartNum, h.Kits_Qty, r.LineID, s.[Qty Per], h.Kits_Qty * s.[Qty Per] AS DemandQty, d.MvmtTyp, 
                         r.AddWho, r.AddTime, dbo.f_KIT_MergeRowsToOne(h.KittingPartNum) AS RawPartList
FROM            dbo.TB_KIT_RAW_HISTORY AS r INNER JOIN
                         dbo.V_KIT_ORDER_HEADER AS h ON r.OrderID = h.OrderID INNER JOIN
                         dbo.TB_KIT_DOC AS d ON h.KittingPartNum = d.KittingPartNum INNER JOIN
                         dbo.Bas_SAPbom AS s ON h.KittingPartNum = s.[Assembly Name] AND r.RawPartNum = s.Component

GO
