
CREATE PROCEDURE [dbo].[sp_BuildOrderClose]
	@OrderID varchar(15),
	@ClosedBy varchar(10),
	@MailAlertSwitch bit
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	declare @Msg varchar(100),@MailSubj  varchar(100),@RecList varchar(2000)
	
	update Tb_Order_Details set OrderStatus = 'Close',PullStatus = 'Close',CancelTime =GETDATE(),ClosedTime =GETDATE() where OrderID = @OrderID
	select @Msg= 'OrderID:' + @OrderID + ' was Closed By:' + @ClosedBy + ' manually ! Total ' + ltrim(STR(@@ROWCOUNT)) + ' Items affected.'
	set @MailSubj = (Select Subject  from Cfg_DBmail where AlertName = 'SMTOrderManualClosure')
	set @RecList=(Select recipients  from Cfg_DBmail where AlertName = 'SMTOrderManualClosure')
	if @MailAlertSwitch = 1 begin
		EXEC msdb.dbo.sp_send_dbmail 
		@profile_name ='EpullSqlMail',
		@recipients = @RecList,
		@subject = @MailSubj,
		@body =@Msg
	end
END
GO
