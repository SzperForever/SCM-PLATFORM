-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_Pull_Depart]
	-- Add the parameters for the stored procedure here
	@TruckNo nchar(10),
	@SealNo nchar(10),
	@PullListNo nchar(13)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE [TB_Kitting_Pulls]
	SET 
      TRUCKNO = @TRUCKNO
      ,SEALNO = @SealNo      
      ,DepartTime=GETDATE()	
 WHERE Pulllistno = @PullListNo

END
GO
