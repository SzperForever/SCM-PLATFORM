create TRIGGER [dbo].[Tri_UpdateOrderStatus_WhenDelete]
   ON  [dbo].[Tb_PreparedList]
   AFTER delete
AS 
BEGIN

	SET NOCOUNT ON;
	declare @OrderID varchar(12),
			@FlagGroup nchar(10),
			@PartNo nchar(20),
			@Model nchar(50),
			@BomRowCount int,
			@FinishStatus varchar(15),
			@ActualPartCount float,
			@MAtext varchar(12),
			@Revision varchar(4),
			@ruleflag varchar(10)
			
			set @OrderID = (select top 1 orderid from deleted)
			set @FlagGroup = (Select top 1 Flaggroup from deleted)
			set @Partno = (Select top 1 partno from deleted)
			set @Model = (Select top 1 model from deleted)			
			set @ruleflag = (Select top 1 ruleflag from deleted)
			
	if @flaggroup = 'MI' 
		begin
			set @BomRowCount = (Select count(partnum) from bas_bom where model = @model)	
			set @ActualPartCount = (SELECT  ltrim(str(COUNT(distinct PartNum))) FROM  dbo.View_MI_KittingStatus AS b 
								WHERE(b.DiffQty >= 0) and (b.model = @model) 
										AND (b.OrderID = @OrderID))
			set @FinishStatus = (ltrim(Str(@ActualPartCount)) + '/' +  ltrim(str(@BomRowCount)))
			if @ActualPartCount > 0  AND @ActualPartCount < @BomRowCount
				update tb_order_details 
				set FinishRate = @finishstatus,ConditionalFormat = 'InProgress' 
				where orderid = @orderid and model = @model	and flaggroup = 'MI'	
			else
				update tb_order_details 
				set FinishRate = @finishstatus,ConditionalFormat = 'NotStarted' 
				where orderid = @orderid and model = @model	and flaggroup = 'MI'	
		end	
	else if @flaggroup = 'SMT' and @ruleflag is not null
		begin
			--set @BomRowCount = (Select count(Component) from bas_sapbom where [Assembly Name] = @model)	
			set @BomRowCount = (SELECT  ltrim(str(COUNT(distinct Component))) 
						FROM  dbo.View_SMT_KittingStatus AS b 
						WHERE (b.OrderID = @OrderID))
			set @ActualPartCount = (SELECT  ltrim(str(COUNT(distinct Component))) FROM  dbo.View_SMT_KittingStatus AS b 
									WHERE(b.DiffQty >= 0) AND (b.OrderID = @OrderID))	
																	
			set @FinishStatus = (ltrim(Str(@ActualPartCount)) + '/' +  ltrim(str(@BomRowCount)))
			
			if @ActualPartCount > 0  AND @ActualPartCount < @BomRowCount
				update tb_order_details 
				set FinishRate = @finishstatus,ConditionalFormat = 'InProgress' 
				where orderid = @orderid and flaggroup = 'SMT'	
			else
				update tb_order_details 
				set FinishRate = @finishstatus,ConditionalFormat = 'NotStarted' 
				where orderid = @orderid and flaggroup = 'SMT'	
		
		end
				
END
GO
