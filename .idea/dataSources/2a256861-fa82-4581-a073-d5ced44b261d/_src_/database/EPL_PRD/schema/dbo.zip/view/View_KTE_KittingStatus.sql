CREATE VIEW dbo.View_KTE_KittingStatus
AS
SELECT     b.OrderID, b.KTEName, a.RouteStepText, a.Slot, a.Material, a.QtyNeeds, a.GrandTotal,
                          (SELECT     ISNULL(SUM(Qty), 0) AS Actualqty
                            FROM          dbo.Tb_PreparedList AS h
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Material) AND (FlagGroup = 'SMT') AND (Feeder = a.Slot) AND (Step = a.RouteStepText)) 
                      AS Actualqty,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Tb_PreparedList AS g
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Material) AND (FlagGroup = 'SMT') AND (Feeder = a.Slot) AND (Step = a.RouteStepText)) AS PkgCnt,
                          (SELECT     ISNULL(SUM(Qty), 0) AS Actualqty
                            FROM          dbo.Tb_PreparedList AS h
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Material) AND (FlagGroup = 'SMT') AND (Feeder = a.Slot) AND (Step = a.RouteStepText)) 
                      - a.QtyNeeds AS DiffQty, a.FeederType
FROM         dbo.Bas_KTE_Bom AS a LEFT OUTER JOIN
                      dbo.Tb_Order_Details AS b ON a.KTE_Name = b.KTEName LEFT OUTER JOIN
                      dbo.Tb_PreparedList AS c ON b.OrderID = c.OrderID AND a.Material = c.PartNo AND c.Feeder = a.Slot AND c.Step = a.RouteStepText
GROUP BY b.OrderID, b.KTEName, c.OrderID, a.RouteStepText, a.Slot, a.Material, a.QtyNeeds, a.GrandTotal, a.FeederType
GO
