-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-7-8>
-- Description:	<Exec Command from a string of table>
-- =============================================
CREATE PROCEDURE SP_Exec_SqlString
	-- Add the parameters for the stored procedure here
	@StringName NCHAR(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    
    
	Declare @SQLString nvarchar(max)
	set @SQLString = (select sqlstring from TB_SqlString where StringName = @StringName )
	
	exec sp_executesql  @SQLString 
END
GO
