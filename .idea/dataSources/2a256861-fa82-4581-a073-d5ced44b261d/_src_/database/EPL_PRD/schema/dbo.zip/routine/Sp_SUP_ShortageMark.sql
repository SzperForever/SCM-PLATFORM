CREATE PROCEDURE [dbo].[Sp_SUP_ShortageMark]
	@Sku varchar(20),
	@SAPShortageMark bit,
	@ShortageMarkTime smalldatetime,
	@ShortageMarkBy	varchar(10),
	@ShortageRemark varchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	update Sup_SKuMap 
	set SAPShortageMark = @SAPShortageMark ,ShortageMarkTime = @ShortageMarkTime ,ShortageMarkBy = @ShortageMarkBy,ShortageRemark = @ShortageRemark
	WHERE Material = @SKU
END
GO
