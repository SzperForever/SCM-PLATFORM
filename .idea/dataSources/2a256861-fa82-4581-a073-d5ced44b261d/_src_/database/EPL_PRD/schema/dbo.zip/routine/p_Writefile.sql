
/*--在文本文件中追加数据

 在文本文件中追加数据
 如果文件不存在,将创建文件

--邹建 2004.08(引用请保留此信息)--*/

/*--调用示例

 exec p_movefile 'e:\aa.txt','测试写入'
--*/
CREATE proc [dbo].[p_Writefile]
@filename varchar(1000),--要操作的文本文件名
@text varchar(8000) --要写入的内容
as
declare @err int,@src varchar(255),@desc varchar(255)
declare @obj int

exec @err=sp_oacreate 'Scripting.FileSystemObject',@obj out
if @err<>0 goto lberr

exec @err=sp_oamethod @obj,'OpenTextFile',@obj out,@filename,8,1
if @err<>0 goto lberr

exec @err=sp_oamethod @obj,'WriteLine',null,@text
if @err<>0 goto lberr

exec @err=sp_oadestroy @obj
return

lberr:
 exec sp_oageterrorinfo 0,@src out,@desc out
 select cast(@err as varbinary(4)) as ErrNo
  ,@src as ErrSource,@desc as ErrDesc
GO
