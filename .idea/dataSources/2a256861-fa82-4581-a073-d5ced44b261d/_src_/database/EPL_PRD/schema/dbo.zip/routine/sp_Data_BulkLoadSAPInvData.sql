


CREATE     PROCEDURE [dbo].[sp_Data_BulkLoadSAPInvData]
(	@LoadFileName as varchar(20),
    @SourceFilePath as varchar(100),
	@InvName as varchar(4) = 'SLOC' 
)

AS

BEGIN
	SET NOCOUNT ON
	DECLARE @FullPath AS VARCHAR(100)
	DECLARE @BulkSQL AS VARCHAR(300)
	DECLARE @IsFileExist AS INT
    DECLARE @DELFILENAME varchar(2000)    
    declare @RecAddress varchar(300)
	declare @errmsg nvarchar(2000)
    declare @chartype as varchar(10)
    declare @rt as varchar(40)

	set @RecAddress = '13817503000@139.com;13524709329@139.COM;13761064316@139.COM;15002168379@139.com'
	
	IF @InvName = 'SLOC'
	BEGIN
		SET @FullPath = @SourceFilePath + @LoadFileName 
		set @DELFILENAME = 'Del /s /q ' + @FullPath	

		EXEC master..xp_fileexist @FullPath, @IsFileExist out
		IF @IsFileExist = 0
		BEGIN
			INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
				VALUES ('sp_Data_BulkLoadSAPInvData', 'The file does not exist [' + @LoadFileName + '].',99,GETDATE())
			set @errmsg = 'There is an error just occured during the sync sloc inventory process. ErrDesc: The file does not exist [' + @LoadFileName + '].'
			EXEC [sp_SendingAlert] @RecAddress,'SLOC 库存同步错误提醒1',@errmsg
			RETURN
		END
		ELSE
		BEGIN
			SET @BulkSQL = 'BULK INSERT TB_RES_SOURCE_SAP_INV FROM ' + CHAR(39) + @FullPath + CHAR(39) + ' WITH (ROWTERMINATOR = ''' + CHAR(10) + ''')'

			--PRINT @BulkSQL
			TRUNCATE TABLE TB_RES_SOURCE_SAP_INV
			
			
			EXEC sp_sqlexec @BulkSQL

			IF @@ERROR <> 0
			BEGIN
				INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
					VALUES ('sp_Data_BulkLoadSAPInvData', 'Fail to bulk insert [' + @LoadFileName + '].',99,GETDATE())
				set @errmsg = 'There is an error just occured during the sync sloc inventory process. ErrDesc: Fail to bulk insert [' + @LoadFileName + '].'
			    EXEC [sp_SendingAlert] @RecAddress,'SLOC 库存同步错误提醒2',@errmsg
				RETURN 1
			END
			
			
-- Insert and format tmpdata into final table.

		delete from [dbo].TB_RES_SOURCE_SAP_INV 
		--select * from TB_RES_SOURCE_SAP_INV 
			where LEFT(ltrim([Column 0]),1) <> '|' or 
				  LEFT(ltrim([column 0]),5) in( 
												'|Name',
												'|Sloc',
												'|   ',
												'|Tota',
												'|Mate')


			 DELETE FROM TB_RES_SOURCE_SAP_INV

			 --WHERE dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) < 17
			 --New Added
			 WHERE dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) < 17

		--If there is columns string '|' more over than 18 then alert administrator
		
		DECLARE @AbnormalRowCnt int
		set @AbnormalRowCnt = (Select count(*) FROM TB_RES_SOURCE_SAP_INV WHERE dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) > 18)
		if @AbnormalRowCnt > 0 
			begin
				

				INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
					VALUES ('sp_Data_BulkLoadSAPInvData', 'Fail to parser bulk data into temporary table.',99,GETDATE())
								set @errmsg = 'There is an error just occured during the sync sloc inventory process. ErrDesc: There are more than 18 specfic chacters detected. Error Number:' + str(@@error)
				EXEC [sp_SendingAlert] @RecAddress,'前方有怪兽~！',@errmsg
				
				RETURN 1
			end
			
		truncate table TB_SAP_INV_FINAL

		insert into TB_SAP_INV_FINAL
		SELECT  dbo.GetStrPara([Column 0],2,'|') as Sloc ,
				dbo.GetStrPara([Column 0],3,'|') as Material ,
				dbo.GetStrPara([Column 0],5,'|') as Mtrl_Grp ,
				dbo.GetStrPara([Column 0],6,'|') as Mtrl_Type ,
				dbo.GetStrPara([Column 0],7,'|') as StandPrice ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],8,'|')),1,' '),',','')) as Unrestricted ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],9,'|')),1,' '),',','')) as Unrestr_Cnsgt ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],10,'|')),1,' '),',','')) as Stock_In_Tfr ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],11,'|')),1,' '),',','')) as In_Qual_Insp ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],12,'|')),1,' '),',','')) as Cnsgt_Qual_In ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],13,'|')),1,' '),',','')) as Blocked ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],14,'|')),1,' '),',','')) as Blocked_Cnsgt ,
				dbo.GetStrPara([Column 0],15,'|') as Total_Value ,
				dbo.GetStrPara([Column 0],16,'|') as MRP ,
				dbo.GetStrPara([Column 0],4,'|') as Mtrl_Desc ,
				dbo.GetStrPara([Column 0],17,'|') as Plant ,
				getdate() as LastUpdateTime
		  FROM [dbo].TB_RES_SOURCE_SAP_INV  with (nolock)
		  	--new added
		  where dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) = 17
		  --where dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) = 16

		insert into TB_SAP_INV_FINAL
		SELECT  dbo.GetStrPara([Column 0],2,'|') as Sloc ,
				dbo.GetStrPara([Column 0],3,'|') as Material ,
				dbo.GetStrPara([Column 0],6,'|') as Mtrl_Grp ,
				dbo.GetStrPara([Column 0],7,'|') as Mtrl_Type ,
				dbo.GetStrPara([Column 0],8,'|') as StandPrice ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],9,'|')),1,' '),',','')) as Unrestricted ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],10,'|')),1,' '),',','')) as Unrestr_Cnsgt ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],11,'|')),1,' '),',','')) as Stock_In_Tfr ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],12,'|')),1,' '),',','')) as In_Qual_Insp ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],13,'|')),1,' '),',','')) as Cnsgt_Qual_In ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],14,'|')),1,' '),',','')) as Blocked ,
				convert(FLOAT,replace(dbo.GetStrPara(ltrim(dbo.GetStrPara([Column 0],15,'|')),1,' '),',','')) as Blocked_Cnsgt ,
				dbo.GetStrPara([Column 0],16,'|') as Total_Value ,
				dbo.GetStrPara([Column 0],17,'|') as MRP ,
				(dbo.GetStrPara([Column 0],4,'|') + dbo.GetStrPara([Column 0],4,'|')) as Mtrl_Desc ,
				--new added
				dbo.GetStrPara([Column 0],18,'|') as Plant ,
				getdate() as LastUpdateTime
		  FROM [dbo].TB_RES_SOURCE_SAP_INV  with (nolock)
		  where dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) > 16
		  
			
			IF @@ERROR <> 0
			BEGIN
				--declare @errmsg nvarchar(2000)

				INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
					VALUES ('sp_Data_BulkLoadSAPInvData', 'Fail to parser bulk data into temporary table [' + @LoadFileName + '].',99,GETDATE())
				set @errmsg = 'There is an error just occured during the sync sloc inventory process. Please see job history to see the details.Error Number:' + str(@@error)
				EXEC [sp_SendingAlert] @RecAddress,'SLOC 库存同步错误提醒3',@errmsg
				RETURN 1
			END
			
			EXEC xp_cmdshell @DELFILENAME
			RETURN 0
		END
	END
	
	-----------------------------'stk inventory:'
	ELSE BEGIN
		
		SET @FullPath = @SourceFilePath + @LoadFileName 
		set @DELFILENAME = 'Del /s /q ' + @FullPath	
                --set @chartype = 'char'
                --set @rt = '0x0a'
		--set @rt = 'CHAR(10)'
		--set @rt = ' WITH (ROWTERMINATOR = ''' + CHAR(10) + ''')'
		
		EXEC master..xp_fileexist @FullPath, @IsFileExist out
		IF @IsFileExist = 0
		BEGIN
			INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
				VALUES ('sp_Data_BulkLoadSAPInvData', 'The file does not exist [' + @LoadFileName + '].',99,GETDATE())
			set @errmsg = 'There is an error just occured during the sync stock inventory process. ErrDesc: The file does not exist [' + @LoadFileName + '].'
			RAISERROR ( @ERRMSG,16,1)
			--EXEC [sp_SendingAlert] @RecAddress,'STOCK INVENTORY SYNC ERROR ALERT SERVICE',@errmsg
			RETURN 		
		END
		ELSE
		BEGIN
			SET @BulkSQL = 'BULK INSERT TB_RES_SOURCE_SAP_INV FROM ' + CHAR(39) + @FullPath + CHAR(39) + ' WITH (ROWTERMINATOR = ''' + CHAR(10) + ''')'

			EXEC sp_sqlexec @BulkSQL

			IF @@ERROR <> 0
			BEGIN
				INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
					VALUES ('sp_Data_BulkLoadSAPInvData', 'Fail to bulk insert [' + @LoadFileName + '].',99,GETDATE())
				set @errmsg = 'There is an error just occured during the sync stock inventory process. ErrDesc: Fail to bulk insert [' + @LoadFileName + '].'
				RAISERROR ( @ERRMSG,16,1)
				EXEC [sp_SendingAlert] @RecAddress,'STOCK INVENTORY SYNC ERROR ALERT SERVICE',@errmsg
				RETURN 1
			END
			
			
-- Insert and format tmpdata into final table.

		delete from [dbo].TB_RES_SOURCE_SAP_INV 
		--select * from TB_RES_SOURCE_SAP_INV 
		where			LEFT(ltrim([Column 0]),1) <> '|' OR 
						LEFT(ltrim([column 0]),9) in('|Material') or
						dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) < 14 						

		----If there is columns string '|' more over than 15 then alert administrator
		

		set @AbnormalRowCnt = (Select count(*) FROM TB_RES_SOURCE_SAP_INV  with (nolock) WHERE dbo.fn_SCountOneWordOnOtherWord('|',[Column 0]) > 15)
		if @AbnormalRowCnt > 0 
			begin
				INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
					VALUES ('sp_Data_BulkLoadSAPInvData', 'Fail to parser bulk data into temporary table.',99,GETDATE())
				set @errmsg = 'There is an error just occured during the sync stock inventory process. ErrDesc: There are more than 17 specfic chacters detected. Error Number:' + str(@@error)
				RAISERROR ( @ERRMSG,16,1)
				--EXEC [sp_SendingAlert] @RecAddress,'STOCK INVENTORY SYNC ERROR ALERT SERVICE',@errmsg
				
				RETURN 1
			end
			
	

			IF @@ERROR <> 0
			BEGIN
				--declare @errmsg nvarchar(2000)
				INSERT INTO TblCheckLog (SP_Name, strValue, type,LogTime) 
					VALUES ('sp_Data_BulkLoadSAPInvData', 'Fail to parser bulk data into temporary table [' + @LoadFileName + '].',99,GETDATE())
				
				set @errmsg = 'There is an error just occured during the sync stock inventory process. Please see job history to see the details.Error Number:' + str(@@error)
				RAISERROR ( @ERRMSG,16,1)
				--EXEC [sp_SendingAlert] @RecAddress,'STOCK INVENTORY SYNC ERROR ALERT SERVICE',@errmsg
				RETURN 1
			END
			
		
		--	EXEC xp_cmdshell @DELFILENAME
		--	RETURN 0
		END
	END

END

GO
