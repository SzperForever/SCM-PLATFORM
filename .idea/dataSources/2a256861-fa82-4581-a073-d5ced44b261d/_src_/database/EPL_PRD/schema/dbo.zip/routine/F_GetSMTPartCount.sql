
CREATE FUNCTION [dbo].[F_GetSMTPartCount](@Model varchar(100)) 
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @PartCount int

	-- Add the T-SQL statements to compute the return value here
	SELECT @PartCount = (select distinct count([Component]) from bas_sapbom where [Assembly Name] = @model)

	-- Return the result of the function
	RETURN @PartCount

END
GO
