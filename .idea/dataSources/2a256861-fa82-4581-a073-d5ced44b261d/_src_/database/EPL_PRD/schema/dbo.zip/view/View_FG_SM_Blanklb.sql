CREATE VIEW dbo.View_FG_SM_Blanklb
AS
SELECT     s.SRid, s.Lbid, ISNULL(COUNT(DISTINCT p.BoxID), 0) AS PkgCnt
FROM         dbo.TB_FG_SM_Details AS s LEFT OUTER JOIN
                      dbo.TB_FG_PKG_Details AS p ON s.SRid = p.SRid AND s.Lbid = p.PKGid
GROUP BY s.SRid, s.Lbid
GO
