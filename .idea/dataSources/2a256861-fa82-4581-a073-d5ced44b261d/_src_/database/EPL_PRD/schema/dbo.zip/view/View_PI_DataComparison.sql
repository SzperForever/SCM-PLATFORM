CREATE VIEW dbo.View_PI_DataComparison
AS
SELECT     TOP (100) PERCENT A.Sloc AS S_sloc, B.Bay AS E_sloc, A.Material AS SAPPartNo, B.Material AS PIPartNo, A.Mtrl_Desc, A.Mtrl_Grp, A.StandPrice, 
                      ISNULL(A.Unrestricted, 0) AS SAPqty, ISNULL(SUM(B.Qty), 0) AS PIqty, COUNT(B.Qty) AS TagCount, ISNULL(SUM(B.Qty), 0) - ISNULL(A.Unrestricted, 0) AS VarianceQty, 
                      A.StandPrice * (ISNULL(SUM(B.Qty), 0) - ISNULL(A.Unrestricted, 0)) AS VarianceValue
FROM         dbo.tb_LVHM_PI AS B FULL OUTER JOIN
                          (SELECT     Sloc, Material, Mtrl_Grp, Mtrl_Type, StandPrice, Unrestricted, Unrestr_Cnsgt, Stock_In_Tfr, In_Qual_Insp, Cnsgt_Qual_In, Blocked, Blocked_Cnsgt, 
                                                   Total_Value, MRP, Mtrl_Desc, LastUpdateTime
                            FROM          dbo.TB_SAP_INV_FINAL
                            WHERE      (Sloc IN
                                                       (SELECT DISTINCT Bay
                                                         FROM          dbo.tb_LVHM_PI))) AS A ON B.Bay = A.Sloc AND B.Material = A.Material
GROUP BY A.Sloc, A.Material, B.Bay, B.Material, A.Mtrl_Desc, A.Mtrl_Grp, A.StandPrice, A.Unrestricted
ORDER BY S_sloc, SAPPartNo
GO
