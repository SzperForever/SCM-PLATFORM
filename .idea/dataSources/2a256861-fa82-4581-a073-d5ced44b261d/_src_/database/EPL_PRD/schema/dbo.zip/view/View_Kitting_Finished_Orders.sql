

CREATE VIEW [dbo].[View_Kitting_Finished_Orders]
AS
SELECT     b.KittingPartNum, b.BatchID
FROM         dbo.View_Kitting_OverallStatus AS a with (nolock) INNER JOIN
                      dbo.View_Kitting_PreparedList AS b with (nolock) ON a.KittingPartNum = b.KittingPartNum
WHERE     (a.DiffQty >= 0)
GROUP BY b.KittingPartNum, b.BatchID


GO
