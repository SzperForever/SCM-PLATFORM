CREATE VIEW dbo.View_Machine_Material_List
AS
SELECT     TOP (100) PERCENT c.OrderID, a.fsPartNum, a.Number, a.BoardSide AS Step, a.fsSetPos, a.Rev, a.MAText, a.fsPartQty, c.Sets,
                          (SELECT     COUNT(fsPartNum) AS Expr1
                            FROM          dbo.Bas_Machine_Feeder_Report
                            WHERE      (Number = a.Number) AND (fsPartNum = a.fsPartNum) AND (BoardSide <> a.BoardSide)) AS DifRST_M_Cnt, c.Sets * CONVERT(int, 
                      a.fsPartQty) / a.SeqBrdNum AS NeedQty, ISNULL
                          ((SELECT     SUM(Qty) AS Expr1
                              FROM         dbo.Tb_PreparedList AS h
                              WHERE     (PartNo = a.fsPartNum) AND (OrderID = c.OrderID) AND (Model = c.PPLModelName) AND (Step = a.BoardSide) AND (Feeder = a.fsSetPos) 
                                                    AND (FlagGroup = 'SMT')), 0) AS Actualqty,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Tb_PreparedList AS g
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.fsPartNum) AND (Feeder = a.fsSetPos) AND (Step = a.BoardSide)) AS PkgCount, ISNULL
                          ((SELECT     SUM(Qty) AS Expr1
                              FROM         dbo.Tb_PreparedList AS h
                              WHERE     (PartNo = a.fsPartNum) AND (OrderID = c.OrderID) AND (Model = c.PPLModelName) AND (Step = a.BoardSide) AND (Feeder = a.fsSetPos) 
                                                    AND (FlagGroup = 'SMT')), 0) - c.Sets * CONVERT(int, a.fsPartQty) / a.SeqBrdNum AS DiffQty, a.ArrangePos, a.pkgInfoTapeWidth, 
                      a.SeqBrdNum
FROM         dbo.Bas_Machine_Feeder_Report AS a LEFT OUTER JOIN
                      dbo.Tb_Order_Details AS c ON c.PPLModelName = a.Number AND c.BayNum = a.MAText AND c.Rev = a.Rev LEFT OUTER JOIN
                      dbo.Tb_PreparedList AS b ON a.Number = b.Model AND a.fsPartNum = b.PartNo AND b.OrderID = c.OrderID
WHERE     (c.OrderStatus = 'Open') AND (c.FlagGroup = 'SMT')
GROUP BY c.OrderID, a.fsPartNum, a.Number, a.BoardSide, a.fsSetPos, a.Rev, a.MAText, a.fsPartQty, c.Sets, c.OrderID, c.PPLModelName, a.ArrangePos, 
                      a.pkgInfoTapeWidth, a.SeqBrdNum
ORDER BY c.OrderID, a.fsPartNum, a.Number, Step, a.fsSetPos, a.Rev, a.MAText, a.fsPartQty
GO
