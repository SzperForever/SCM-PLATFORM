
CREATE  PROCEDURE [dbo].[SP_Kitting_AddNewSplitOrder]

		--@WorkCell varchar(20),
		@FatherOrderID varchar(13),
		@Kits_Qty FLOAT,
		@BuildPlanTime datetime,
		@ReasonFlag int,
		@ReasonCode nchar(10),
		@SplitReason varchar(1000)
		
		--@Priority varchar(10)
		
AS
	begin		
		declare @OrderID Varchar(13),@KittingPartNum nvarchar(30)
		DECLARE @dt CHAR(6),@CreateBy varchar(15)
		SELECT @dt=dt FROM v_GetDate	
		
		set @KittingPartNum= (Select kittingpartnum 
								from Tb_Kitting_Order_Header 
								where OrderID = @FatherOrderID )
		set @CreateBy = (Select CreateBy  
								from Tb_Kitting_Order_Header 
								where OrderID = @FatherOrderID )
								
		set @orderid = (SELECT 'K'+ @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(orderid),6),0),6) 
						FROM Tb_Kitting_Order_Header  WITH(XLOCK,PAGLOCK) 
						WHERE orderid like 'K' + @dt+'%')
		--print @orderid
		
		INSERT INTO [dbo].[Tb_Kitting_Order_Header]
           ([OrderID]
           ,[OrderStatus]
           ,[KittingPartNum]
           ,[BuildPlanTime]
           ,[Kits_Qty]
           ,[CreateBy]
           ,[CreateTime]
           ,[KittingStatus] 
           ,[Kitting_ReceivedTime]        
           ,[Stocksts]     
           ,[CurrentPlace]
           ,Flag 
           ,[UserDefinedColumn1]
           ,[UserDefinedColumn2]
           ,[OrderNotes])           
			VALUES (@orderid			
				--dbo.f_NextBH(@Model,@Batch)--自定义函数，相同MODEL,相同套数,相同BATCH用同一个orderID.
				,'OPEN'
				,@KittingPartNum
				,@BuildPlanTime
				,@Kits_Qty
				,@CreateBy
				,GETDATE()
				,'NotStarted'
				,GETDATE()
				,'NotStarted'
				,'KIT'
				,@ReasonFlag
				,@FatherOrderID 
				,@ReasonCode
				, '//This is a child order. It splited from order:' + @FatherOrderID + '.Split Reason:' + @SplitReason )		
		
		if @@ERROR <> 0 
		begin
			raiserror ('Unknown error occured while inserting child order. Insert failed.',16,1)
			return
		end
		
		update Tb_Kitting_Order_Header 
		set Kits_Qty = Kits_Qty - @Kits_Qty ,OrderNotes = OrderNotes + '//Please be noted this order has child order(s)'  
		where OrderID = @FatherOrderID 
end

GO
