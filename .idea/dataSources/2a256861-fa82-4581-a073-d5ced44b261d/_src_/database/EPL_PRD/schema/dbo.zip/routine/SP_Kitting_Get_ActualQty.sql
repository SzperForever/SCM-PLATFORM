

CREATE PROCEDURE [dbo].[SP_Kitting_Get_ActualQty] 
	@KittingPartNum varchar(30),
	@ActuaQty float output,
	@DiffQty float output
AS
	begin
	
		SET @ActuaQty = 0
		set @DiffQty = 0
		SET @ActuaQty = (select dbo.f_Kitting_getactualqty(@KittingPartNum))
		SET @DiffQty = (Select DiffQty 
						from View_Kitting_OverallStatus
						where [KittingPartNum] = @KittingPartNum)
	RETURN
     
	end

GO
