CREATE VIEW dbo.V_FG_SR_OrderValue
AS
SELECT        Project, SP_Status, COUNT(DISTINCT SRid) AS OrderCnt, COUNT(DISTINCT PartNum) AS PartCnt, SUM(Amount$) AS Amount
FROM            (SELECT        h.SRid, h.SRno, h.Project, h.Requestor, h.Order_Status, h.SP_Status, h.Status, d.PartNum, d.TotalQty, s.Standard_price, 
                                                    s.Standard_price * d.TotalQty AS Amount$, d.Currency, h.TotalCtnCnt, h.TotalPltCnt, h.PGI_Time
                          FROM            dbo.View_FG_SR_Headers AS h INNER JOIN
                                                    dbo.TB_FG_SR_Details AS d ON h.SRid = d.SRid INNER JOIN
                                                    dbo.BAS_SKU AS s ON d.PartNum = s.Material
                          WHERE        (h.Order_Status = 'Open')) AS t
GROUP BY Project, Order_Status, SP_Status
GO
