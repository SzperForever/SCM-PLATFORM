create TRIGGER [dbo].[OrderCancelAlarms] 
ON  [dbo].[Tb_Order_Details] for UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		declare @OrderSts varchar(10),@PullStatus varchar(10), @OrderID varchar(10),@PullListNo varchar(13),@IA varchar(10),@Msg varchar(500),@FlagGroup varchar(10),@Mailadd varchar(50),@WorkCell varchar(20)
		select @OrderSts=OrderStatus,@PullStatus = PullStatus,@OrderID=OrderID,@PullListNo=PULLLISTNO,@IA = CreateBy ,@FlagGroup = Flaggroup,@workcell = Workcell from inserted
		set @Mailadd = (Select top 1 MailAddress from bas_user where username = @IA) + ';Hanson_zhang@jabil.com'
		if update(orderstatus)
			BEGIN 
			--RAISERROR ('Transaction cannot be processed.orderstatus cannot be modified.', 10, 1)			
				
				select @Msg= 'OrderID:' + @OrderID + 'PullListNo:' + @PullListNo + ' was Canceled !'
				
				IF @ORDERSTS='Cancel'
					begin
					--同步UPDATE PULLSTATUS = ‘CANCEL’ after OrderID canceled.
						update dbo.Tb_Order_Details 
						set PullStatus = 'Cancel' ,OrderNotes = Ordernotes + ',' + @msg
						WHERE OrderID = @Orderid and FlagGroup = @FlagGroup
					end				
			end
		--if update(PullStatus)
		--	begin
		--		if @PullStatus = 'Cancel' and @FlagGroup = 'SMT' and UPPER(right(@workcell,3)) = '-AI' 
		--			begin
		--				set @Msg= 'AI-OrderID:' + @OrderID + ',PullListNo:' + @PullListNo + ',FlagGroup: ' + @FlagGroup + ' 被成功标记为【取消】状态，由于目前AI料单存在不正常取消的BUG,请注意如果是异常取消，请马上通知HANSON或是DAILS获得帮助。'
		--				exec dbo.sp_SendingAlert @Mailadd,'AI Pull Order cancel Notification' ,@Msg
		--				--RAISERROR ('PullStatus is updated as [Cancel].Please be noted. 如AI料单被异常取消，请马上通知HANSON。此动作已经邮件通知到下单人和HANSON', 16, 1)
		--				return
		--			end
		--	end
		IF UPDATE (Model)
			begin			
				 Declare @PLVBomModelname nchar(80),
						 @Model nchar(80),
						 @rowcount1 int,@rowcount2 int,
						 @Rev nchar(20),
						 @MAText varchar(50),			 
						 @OrderType varchar(20)
						 
				 set @WorkCell = (Select workcell from inserted)
				 set @Model = (Select Model from inserted)	 
				 set @OrderID = (select orderid from inserted)
				 set @FlagGroup = (Select FlagGroup from inserted)
				 set @OrderType = (select OrderType from inserted)
			     
				 if @WorkCell = 'Cisco' and @OrderType = 'AutoPull' and @FlagGroup = 'SMT'
					begin
						set @rowcount1 = (Select count(PLVBomModelname) from bas_bomlink where sapbommodelname = @model)

						if @rowcount1 =0 
							begin
								rollback tran
								RAISERROR ('No records return from the bas_bomlink for this model.', 16, 1)
							end
						else begin
							set @PLVBomModelname = (Select PLVBomModelname from bas_bomlink where sapbommodelname = @model)
							set @rowcount2 = (Select count(*) from bas_ppl where Number = @PLVBomModelname)
							if @rowcount2 =0 
								begin
									rollback tran
									RAISERROR ('No records return from the BAS_PPL for this model.', 16, 1)
								end
							ELSE
								BEGIN								
									set @rev = (Select top 1 Revision from bas_ppl where number = @PLVBomModelname)
									set @MAText = (select top 1 [MAText] from bas_ppl where number = @plvbommodelname)
									Update tb_order_details 
									set
										PPLModelName = @PLVBomModelname
										--,baynum = @MAText
										--,Rev =  @rev
									where Orderid = @OrderID 
								END
						end
					end
			end
end
GO
