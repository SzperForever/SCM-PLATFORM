CREATE VIEW dbo.View_Shipping_PCBA_BulkBIN
AS
SELECT     TOP (100) PERCENT a.Material, a.Sloc, b.Mtrl_Grp, a.S, a.Batch, a.StorageBin, a.Typ, a.[Available stock]
FROM         dbo.TB_SAP_INV_WH AS a LEFT OUTER JOIN
                      dbo.TB_SAP_INV_FINAL AS b ON a.Material = b.Material
GROUP BY a.Material, a.Sloc, b.Mtrl_Grp, a.S, a.Batch, a.StorageBin, a.Typ, a.[Available stock]
HAVING      (a.Typ = N'FGI') AND (a.Sloc = N'0300')
GO
