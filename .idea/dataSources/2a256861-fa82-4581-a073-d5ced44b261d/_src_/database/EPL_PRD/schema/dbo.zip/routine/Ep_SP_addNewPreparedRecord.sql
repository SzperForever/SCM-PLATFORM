CREATE PROCEDURE [dbo].[Ep_SP_addNewPreparedRecord]

	 @OrderID nchar(16)
	,@PartNo nvarchar(20)
	,@Qty numeric(18, 2)
	,@GRN nvarchar(18)
	,@PreparedBy nchar(10)
	,@Remark nchar(20)
	,@PreparedID nvarchar(15)
	,@WorkCell nvarchar(50)
	,@BayNum nchar(10)
	,@Sloc nchar(4)
	,@Model nvarchar(max)
	,@Sets int
	,@FlagGroup nchar(10)
	,@SLEDInfo nvarchar(200) = ''		
AS
begin
	INSERT INTO [dbo].[Tb_PreparedList]
			   ([OrderID]
			   ,[PartNo]
			   ,[Qty]
			   ,[GRN]
			   ,[ScanTime]
			   ,[PreparedBy]
			   ,[Side]
			   ,[Remark]
			   ,[PreparedID]
			   ,[WorkCell]
			   ,[BayNum]
			   ,[Sloc]
			   ,[Model]
			   ,[Sets]
			   ,[CheckFlag]
			   ,[FlagGroup]
			   ,[RuleFlag]
			   ,[SLEDInfo])
		 VALUES
			(@OrderID,@PartNo,@Qty,@GRN,GETDATE(),@PreparedBy,'',@Remark,@PreparedID,@WorkCell,@BayNum,@Sloc,@Model,@Sets,'N',@FlagGroup,'AddIn',@SLEDInfo)
 end
GO
