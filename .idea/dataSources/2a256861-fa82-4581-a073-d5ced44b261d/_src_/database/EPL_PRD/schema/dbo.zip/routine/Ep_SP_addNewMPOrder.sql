
CREATE  PROCEDURE [dbo].[Ep_SP_addNewMPOrder]
		@WorkCell varchar(20),
		@PartCount int,
		@PullListNo varchar(13),
		@BuildPlanTime SMALLdatetime,
		@CreateBy varchar(10),			
		@Baynum varchar(10),
		@Sloc varchar(4),
		@Remark varchar(20)
AS
	DECLARE @MSG VARCHAR(200)
	if (select Count(pulllistno) from Tb_Order_Details where PullListNo = @PullListNo and PullStatus = 'Open' and FlagGroup = 'MP' and OrderType = 'ManualPull') >0 
		begin
			SET @MSG = 'PullList ' + @PullListNo + ' already exsit,insert failed.'
			raiserror(@MSG,16,1)	
		end
	else begin	
	
		declare @OrderID Varchar(12)
		DECLARE @dt CHAR(6)
		declare @Rcount int
		
			SELECT @dt=dt FROM v_GetDate		
			set @orderid = (SELECT 'M' + @dt+RIGHT(100001+ISNULL(RIGHT(MAX(orderid),5),0),5) 
									FROM tb_order_details WITH(XLOCK,PAGLOCK) 
									WHERE orderid like '%M' + @dt+'%' and flaggroup = 'MP')
		declare @StoreArea varchar(4)				
		set @StoreArea = substring(@PullListNo,9,4)
		IF @StoreArea not in ('0100','0300','0500','0600') 
			begin
				SET @MSG = 'Pull list is valid for [0100,0300,0500,0600] only!'
				raiserror(@MSG,16,1)
			end 
		else begin
			INSERT INTO [dbo].[Tb_Order_Details] 
					([OrderID]
					,[OrderType]
					,[OrderStatus]
					,[WorkCell]
					,[BayNum]
					,[StoreArea]
					,[PullListNo]
					,[PullStatus]
					,[PartAmount]
					,[BuildPlanTime]
					,[CreateBy]
					,[CreateTime]
					,[StockSts]
					,[LVHMrequestTime]
					,[LVHMsts]
					,[FlagGroup]
					,[CurrentPlace]
					,[Sloc]
					,[OrderNotes]
					,[Remark])  
				VALUES (@orderid			
					,'ManualPull'
					,'Open'
					,@WorkCell
					,@BayNum
					,@StoreArea
					,@PullListNo
					,'Open'
					,@PartCount 
					,@BuildPlanTime
					,@CreateBy
					,GETDATE()
					,'NotStarted'
					,DATEADD(hh,-1 ,@buildplantime)
					,'NotAccepted'
					,'MP'
					,'StockRoom'
					,@Sloc
					,@Remark 
					,@Remark )	
				
			end
	end
GO
