CREATE VIEW dbo.View_PCBAAgingDayPerModel
AS
SELECT     TOP (100) PERCENT Model,
                          (SELECT     COUNT(DISTINCT SN) AS Expr1
                            FROM          dbo.PRO_PCBA_Tracking
                            WHERE      (DATEDIFF(day, AddTime, GETDATE()) < 7) AND (Model = a.Model)) AS LT7D,
                          (SELECT     COUNT(DISTINCT SN) AS Expr1
                            FROM          dbo.PRO_PCBA_Tracking AS PRO_PCBA_Tracking_3
                            WHERE      (DATEDIFF(day, AddTime, GETDATE()) >= 7) AND (DATEDIFF(day, AddTime, GETDATE()) < 14) AND (Model = a.Model)) AS LT14DO7D,
                          (SELECT     COUNT(DISTINCT SN) AS Expr1
                            FROM          dbo.PRO_PCBA_Tracking AS PRO_PCBA_Tracking_2
                            WHERE      (DATEDIFF(day, AddTime, GETDATE()) >= 7) AND (DATEDIFF(day, AddTime, GETDATE()) < 14) AND (Model = a.Model)) AS LT30DO14D,
                          (SELECT     COUNT(DISTINCT SN) AS Expr1
                            FROM          dbo.PRO_PCBA_Tracking AS PRO_PCBA_Tracking_1
                            WHERE      (DATEDIFF(day, AddTime, GETDATE()) >= 7) AND (DATEDIFF(day, AddTime, GETDATE()) < 14) AND (Model = a.Model)) AS O30D
FROM         dbo.PRO_PCBA_Tracking AS a
WHERE     (WorkCell = 'Cisco')
GROUP BY Model
ORDER BY Model
GO
