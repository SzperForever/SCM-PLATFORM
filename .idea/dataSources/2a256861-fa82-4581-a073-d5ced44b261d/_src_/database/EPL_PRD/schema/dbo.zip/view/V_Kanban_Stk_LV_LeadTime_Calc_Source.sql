CREATE VIEW dbo.V_Kanban_Stk_LV_LeadTime_Calc_Source
AS
SELECT        CONVERT(VARCHAR(6), CreateTime, 6) AS ShortDate_CreateTime, CONVERT(date, BuildPlanTime) AS LongDate_CreateTime, OrderID, PullListNo, BuildPlanTime, 
                         DATEADD(hour, - 6, BuildPlanTime) AS Feeder_RequestTime, LVHMrequestTime, DATEADD(hour, - 6, LVHMrequestTime) AS Stk_RequestTime, StockReceivedTime, 
                         StockCompleteTime, LVHMReceivedTime, LVHMcompleteTime, DATEDIFF(minute, StockReceivedTime, LVHMrequestTime) AS Stk_LeadTime_Request, 
                         DATEDIFF(minute, LVHMReceivedTime, DATEADD(hour, 6, BuildPlanTime)) AS lV_LeadTime_Request, DATEDIFF(minute, StockReceivedTime, StockCompleteTime) 
                         AS Stk_Lead_Time_Actual, DATEDIFF(minute, LVHMReceivedTime, LVHMcompleteTime) AS LV_Lead_Time_Actual, (CASE WHEN datediff(minute, StockReceivedTime, 
                         StockCompleteTime) > datediff(minute, StockReceivedTime, [LVHMrequestTime]) THEN 1 ELSE 0 END) AS IsStkDelay, (CASE WHEN datediff(minute, 
                         LVHMReceivedTime, LVHMcompleteTime) > datediff(minute, LVHMReceivedTime, dateadd(hour, 6, BuildPlanTime)) THEN 1 ELSE 0 END) AS IsLVDelay
FROM            dbo.Tb_Order_Details
WHERE        (FlagGroup = 'SMT') AND (OrderStatus = 'Close') AND (PullStatus = 'Close') AND (StockReceivedTime IS NOT NULL)
GROUP BY OrderID, PullListNo, BuildPlanTime, CreateTime, StockReceivedTime, StockCompleteTime, LVHMReceivedTime, LVHMcompleteTime, LVHMrequestTime
GO
