CREATE VIEW dbo.V_Order_SAPBOM
AS
SELECT     OrderID, WorkCell, Model, Rev, BayNum, CurrentPlace, CreateBy, Component
FROM         (SELECT DISTINCT A2.OrderID, A2.WorkCell, A2.Model, A2.Rev, A2.BayNum, A2.CurrentPlace, N.Component, A2.CreateBy
                       FROM          dbo.Tb_Order_Details AS A2 INNER JOIN
                                              dbo.Bas_SAPbom AS N ON A2.Model = N.[Assembly Name]
                       WHERE      (A2.OrderStatus = 'Open') AND (A2.FlagGroup = 'SMT')) AS T1
GO
