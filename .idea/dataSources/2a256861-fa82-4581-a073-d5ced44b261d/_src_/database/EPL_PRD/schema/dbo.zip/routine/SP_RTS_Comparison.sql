
--exec SP_RTS_Comparison '170828S037','ZRT'

CREATE PROCEDURE [dbo].[SP_RTS_Comparison]
	@RTSid nvarchar(16),
	@SourceTyp nchar(3)
AS
BEGIN
	SET NOCOUNT ON;

	if not exists(select 0 from tb_rts where rtsno = @RTSid) 
		begin
			raiserror ('This RTS ID does not exist.',16,1)
			return
		end

	IF OBJECT_ID('tmp_RTS', 'U') IS NOT NULL   DROP TABLE dbo.tmp_RTS;

	CREATE TABLE [dbo].tmp_RTS(
		[RTSNO] [varchar](15) NOT NULL,
		[ScanDate] [date] NULL,
		[WorkCell] [nvarchar](30) NULL,
		[StoreLocation] [nvarchar](10) NULL,
		[ScanPartNo] [nvarchar](30) NULL,
		[ScanQty] [numeric](18, 0) NULL,
		[PartNo] [nvarchar](50) NULL,
		[Qty] [numeric](18, 0) NULL,
		[GRNno] [nvarchar](18) NOT NULL,
		[CountedBy] [nvarchar](10) NULL,
		[CountedName] [nvarchar](30) NULL,
		[ScannedBy] [nvarchar](30) NULL,
		[ScanTime] [smalldatetime] NULL,
		[CountTime] [smalldatetime] NULL,
		[IAanalyzingTime] [smalldatetime] NULL,
		[IAname] [nvarchar](30) NULL,
		[InputTime] [smalldatetime] NULL,
		[InputBy] [nvarchar](30) NULL,
		[Remark] [varchar](max) NULL,
		[MAEditTime] [smalldatetime] NULL,
		[MAremark] [ntext] NULL,
		[ID] [bigint] IDENTITY(1,1) NOT NULL,
	 CONSTRAINT [PK_Tmp_RTS] PRIMARY KEY CLUSTERED 
	(
		[RTSNO] ASC,
		[GRNno] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

	insert into tmp_RTS
			([RTSNO]
           ,[ScanDate]
           ,[WorkCell]
           ,[StoreLocation]
           ,[ScanPartNo]
           ,[ScanQty]	
           ,[PartNo]
           ,[Qty]
           ,[GRNno])
	select   [RTSNO]
			   ,[ScanDate]
			   ,[WorkCell]
			   ,[StoreLocation]
			   ,[ScanPartNo]
			   ,[ScanQty]
			   ,[PartNo]
			   ,[Qty]
			   ,[GRNno]
	from tb_rts
	where RTSNO = @RTSid

	if @SourceTyp= 'MA'
	BEGIN
			SELECT  [RTSNO],[RTSID],[ScanPartNo],[Material],[PkgCnt],[EP_SubTotal],[SAP_SubTotal],[DiffQty] 
			FROM 
						(SELECT        c.RTSNO, b.RTSID, c.ScanPartNo, b.Material, COUNT(c.GRNno) AS PkgCnt, b.Standard_Price, ISNULL
                             ((SELECT        SUM(CONVERT(int, ScanQty)) AS EP_TotalRTSQty
                                 FROM          tmp_RTS
                                 WHERE        (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS EP_SubTotal, ISNULL
                             ((SELECT        SUM(Qty) AS Expr1
                                 FROM            dbo.Temp_RTS_SAPData
                                 WHERE        (Material = b.Material) AND (RTSID = b.RTSID)), 0) AS SAP_SubTotal, ISNULL
                             ((SELECT        SUM(Qty) AS Expr1
                                 FROM            dbo.Temp_RTS_SAPData AS Temp_RTS_SAPData_1
                                 WHERE        (Material = b.Material) AND (RTSID = b.RTSID)), 0) - ISNULL
                             ((SELECT        SUM(CONVERT(int, ScanQty)) AS EP_TotalRTSQty
                                 FROM           dbo.tmp_RTS AS Tb_RTS_1
                                 WHERE        (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS DiffQty
						FROM            dbo.Temp_RTS_SAPData AS b WITH (nolock) FULL OUTER JOIN
												dbo.tmp_RTS AS c WITH (nolock) ON b.Material = c.ScanPartNo AND b.RTSID = c.RTSNO
						where b.rtsid = @rtsid 
						GROUP BY c.RTSNO, b.RTSID, c.ScanPartNo, b.Material, b.Standard_Price

						union all

						SELECT        c.RTSNO, b.RTSID, c.ScanPartNo, b.Material, COUNT(c.GRNno) AS PkgCnt, b.Standard_Price, ISNULL
                             ((SELECT        SUM(CONVERT(int, ScanQty)) AS EP_TotalRTSQty
                                 FROM           dbo.tmp_RTS
                                 WHERE        (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS EP_SubTotal, ISNULL
                             ((SELECT        SUM(Qty) AS Expr1
                                 FROM            dbo.Temp_RTS_SAPData
                                 WHERE        (Material = b.Material) AND (RTSID = b.RTSID)), 0) AS SAP_SubTotal, ISNULL
                             ((SELECT        SUM(Qty) AS Expr1
                                 FROM            dbo.Temp_RTS_SAPData AS Temp_RTS_SAPData_1
                                 WHERE        (Material = b.Material) AND (RTSID = b.RTSID)), 0) - ISNULL
                             ((SELECT        SUM(CONVERT(int, ScanQty)) AS EP_TotalRTSQty
                                 FROM           dbo.tmp_RTS AS Tb_RTS_1
                                 WHERE        (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS DiffQty
						FROM            dbo.Temp_RTS_SAPData AS b WITH (nolock) FULL OUTER JOIN
												dbo.tmp_RTS AS c WITH (nolock) ON b.Material = c.ScanPartNo AND b.RTSID = c.RTSNO
						where c.RTSNO = @rtsid 
						GROUP BY c.RTSNO, b.RTSID, c.ScanPartNo, b.Material, b.Standard_Price) AS V
			group by [RTSNO],[RTSID],[ScanPartNo],[Material],[PkgCnt],[EP_SubTotal],[SAP_SubTotal],diffqty 
			order by abs(diffqty) desc
		return
	END

	if @SourceTyp= 'STK'
	BEGIN
					SELECT  [RTSNO],[RTSID],[ScanPartNo],[Material],[PkgCnt],[EP_SubTotal],[SAP_SubTotal],[DiffQty] 
			FROM 
						(SELECT        c.RTSNO, b.RTSID, c.ScanPartNo, b.Material,
													 (SELECT        COUNT(GRNno) AS Expr1
													   FROM           tmp_RTS WITH (nolock)
													   WHERE        (RTSNO = c.RTSNO) AND (ScanPartNo = c.ScanPartNo)) AS PkgCnt, ISNULL
													 ((SELECT        SUM(ScanQty) AS EP_TotalRTSQty
														 FROM           tmp_RTS AS Tb_RTS_2 WITH (nolock)
														 WHERE        (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS EP_SubTotal, ISNULL
													 ((SELECT        SUM(Qty) AS Expr1
														 FROM            dbo.Temp_RTS_SAPData WITH (nolock)
														 WHERE        (Material = b.Material) AND (RTSID = b.RTSID)), 0) AS SAP_SubTotal, ISNULL
													 ((SELECT        SUM(Qty) AS Expr1
														 FROM            dbo.Temp_RTS_SAPData AS Temp_RTS_SAPData_1 WITH (nolock)
														 WHERE        (Material = b.Material) AND (RTSID = b.RTSID)), 0) - ISNULL
													 ((SELECT        SUM(ScanQty) AS EP_TotalRTSQty
														 FROM           tmp_RTS AS Tb_RTS_1 WITH (nolock)
														 WHERE        (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS DiffQty
						FROM            dbo.Temp_RTS_SAPData AS b WITH (nolock) FULL OUTER JOIN
												dbo.tmp_RTS AS c WITH (nolock) ON b.Material = c.ScanPartNo AND b.RTSID = c.RTSNO
						WHERE B.RTSID = @RTSid
						GROUP BY c.RTSNO, b.RTSID, c.ScanPartNo, b.Material 

						union all

						SELECT        c.RTSNO, b.RTSID, c.ScanPartNo, b.Material,
													 (SELECT        COUNT(GRNno) AS Expr1
													   FROM           tmp_RTS WITH (nolock)
													   WHERE        (RTSNO = c.RTSNO) AND (ScanPartNo = c.ScanPartNo)) AS PkgCnt, ISNULL
													 ((SELECT        SUM(ScanQty) AS EP_TotalRTSQty
														 FROM           tmp_RTS AS Tb_RTS_2 WITH (nolock)
														 WHERE        (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS EP_SubTotal, ISNULL
													 ((SELECT        SUM(Qty) AS Expr1
														 FROM            dbo.Temp_RTS_SAPData WITH (nolock)
														 WHERE        (Material = b.Material) AND (RTSID = b.RTSID)), 0) AS SAP_SubTotal, ISNULL
													 ((SELECT        SUM(Qty) AS Expr1
														 FROM            dbo.Temp_RTS_SAPData AS Temp_RTS_SAPData_1 WITH (nolock)
														 WHERE        (Material = b.Material) AND (RTSID = b.RTSID)), 0) - ISNULL
													 ((SELECT        SUM(ScanQty) AS EP_TotalRTSQty
														 FROM           tmp_RTS AS Tb_RTS_1 WITH (nolock)
														 WHERE        (ScanPartNo = c.ScanPartNo) AND (RTSNO = c.RTSNO)), 0) AS DiffQty
						FROM            dbo.Temp_RTS_SAPData AS b WITH (nolock) FULL OUTER JOIN
												tmp_RTS AS c WITH (nolock) ON b.Material = c.ScanPartNo AND b.RTSID = c.RTSNO
						WHERE c.rtsno = @RTSid
						GROUP BY c.RTSNO, b.RTSID, c.ScanPartNo, b.Material ) AS V
			group by [RTSNO],[RTSID],[ScanPartNo],[Material],[PkgCnt],[EP_SubTotal],[SAP_SubTotal],diffqty 
			order by abs(diffqty) desc

		return
	END

end
GO
