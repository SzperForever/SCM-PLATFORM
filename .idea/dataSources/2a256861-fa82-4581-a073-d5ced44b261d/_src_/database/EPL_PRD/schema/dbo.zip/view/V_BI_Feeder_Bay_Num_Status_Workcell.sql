CREATE VIEW dbo.V_BI_Feeder_Bay_Num_Status_Workcell
AS
SELECT DISTINCT Workcell
FROM            dbo.V_BI_Feeder_BayNum_Status
GO
