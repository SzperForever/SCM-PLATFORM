-- =============================================
-- Author:		<Hanson>
-- Create date: <2015-4-27>
-- Description:	<Start PGI,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_FG_ScanSM]
	-- Add the parameters for the stored procedure here
	@SRid int
	,@TruckNo nchar(20)
	,@LbID nchar(30)
	,@ScanBy nchar(10)
	,@ScanFinished integer output

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @SRStatus nchar(3),@ErrMsg varchar(200),@OrderStatus nchar(3),@SPStatus nchar(3),@RowCnt int
    -- Insert statements for procedure here
	set @ScanFinished  = 0 
	set @RowCnt = (Select count(*) from [dbo].[TB_FG_SR_Details] where SRid = @SRid)
	if @rowcnt = 0 begin
		set @ErrMsg = 'No Shipping request items found. (请至少添加一个SR行，再尝试进行此操作。)'
		raiserror (@ErrMsg,16,1)
		return
	end
	IF LEN(@TruckNo) < 6 BEGIN
		set @ErrMsg = 'Truck No is not valid. (车牌号不合法!)'
		raiserror (@ErrMsg,16,1)
		return
	END
	IF LEN(@lbid) < 10 BEGIN
		set @ErrMsg = 'Shipping mark label is not valid. (唛头条码不合法!)'
		raiserror (@ErrMsg,16,1)
		return
	END
	set @OrderStatus = (Select SR_OrderStatus  from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
	if @OrderStatus <> '200' begin
		set @ErrMsg = 'Process denied since SR Order status is not open. (由于SR订单状态未开启，拒绝进行下一步操作。)'
		raiserror (@ErrMsg,16,1)
		return
	end
	set @SRStatus = (Select SR_Status from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
	if @SRStatus <> '901' begin
		set @ErrMsg = 'SR is not activated. (该SR订单状态未被激活。)'
		raiserror (@ErrMsg,16,1)
		return
	end
	
	set @SPStatus = (Select [SR_SP_Status] from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
	if @SPStatus not in('908','909') begin
		set @ErrMsg = 'Invalid shipping status. (该SR只有当前处于待装车或装车时才可以进行此操作。)'
		raiserror (@ErrMsg,16,1)
		return
	end

	 set @RowCnt = (Select count(*) from [dbo].[View_FG_SM_Details] where srid = @SRid and lbid = @lbid and ScanFlag = 0)
	 if @RowCnt = 0 
		begin
			set @ErrMsg = 'Invalid shipping mark. (无效的唛头。)'
			raiserror (@ErrMsg,16,1)
			return
		end

		update [TB_FG_SR_Header]
			set [SR_SP_Status] = '909',ScanBy = @ScanBy,Truck_No = @TruckNo
			where SRid = @SRid  

		if @@ERROR = 0 begin
			update [dbo].[TB_FG_SM_Details]
			set scanflag = 1,ScanBy = @ScanBy,scantime =getdate()
			where SRid = @SRid  and lbid = convert(int,substring(@lbid,11,len(rtrim(@Lbid))-10)) 
		end

		set @RowCnt = (Select count(*) from [dbo].[TB_FG_SM_Details] where srid = @SRid and ScanFlag = 0)
		--if @RowCnt = 0  begin
		--	update [TB_FG_SR_Header]
		--	set [SR_SP_Status] = '910',[SR_OrderStatus] = '201' , Load_Truck_Time = getdate(),Actual_Pick_Time = getdate(),closetime = getdate()
		--	where SRid = @SRid  

		--	select @ScanFinished = 1	
		--end
		if @RowCnt = 0  begin
			update [TB_FG_SR_Header]
			set [SR_SP_Status] = '911', Load_Truck_Time = getdate(),Actual_Pick_Time = getdate()
			where SRid = @SRid  

			select @ScanFinished = 1	
		end

END


--select convert(int,substring('150429000001-1',14,len(rtrim('150429000001-1'))-13))

--CodeGroup	Code	Chinese_DESC	English_DESC	CodeGroup_Desc
--57	9         	900       	创建订单	SRNotActivated	SR_Status
--58	9         	901       	激活订单	SRActivated	SR_Status
--59	9         	902       	未创建拣货单	MPNotCreated	SR_SP_Status
--60	9         	903       	拣货单创建	MPCreated	SR_SP_Status
--61	9         	904       	拣货中	MPPicking	SR_SP_Status
--62	9         	905       	打印唛头中	PrintShippingMark	SR_SP_Status
--63	9         	906       	等待PGI中	PGI NotStarted	SR_SP_Status
--64	9         	907       	扣PGI中	PGI InProgress	SR_SP_Status
--65	9         	908       	待装车	TruckNotLoaded	SR_SP_Status
--66	9         	909       	发货中	TruckLoading	SR_SP_Status
--67	9         	910       	已发货	ShippedOut	SR_SP_Status

--200  open
--201  closed
--202  cancel
--203  hold
--204  activated
GO
