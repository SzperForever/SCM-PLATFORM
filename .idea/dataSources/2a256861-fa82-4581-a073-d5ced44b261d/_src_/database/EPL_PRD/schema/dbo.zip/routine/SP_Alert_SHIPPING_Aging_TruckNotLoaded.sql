-- =============================================
-- Author:		DALIS
-- Create date: 2017-1-12
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Alert_SHIPPING_Aging_TruckNotLoaded]
	
AS
BEGIN

	SET NOCOUNT ON;

	Declare @tableHTML  NVARCHAR(MAX) 
			,@Msg nvarchar(max)
			,@RecList nvarchar(max)
			,@CCList nvarchar(max)
			,@CCto nvarchar(max)
			,@BlindCopyList nvarchar(max)
			,@MailSubj nvarchar(200)
			,@RowCnt int				
			,@ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@Rcnt int
			,@AlertName nvarchar(100)
			,@PlannerMailAddress nvarchar(max)

	
	set @AlertName = 'SHIPPING_Aging_TruckNotLoaded'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	set @Rcnt = 0
	set @Rcnt =(select COUNT(0)
				FROM [dbo].TB_FG_SR_Header
				where  SR_OrderStatus='200' and SR_SP_Status='908')	
				
	if @Rcnt = 0 or @@ERROR <> 0
		begin

			return
		end	
		
		if @Rcnt >0 		
			 begin			
				DECLARE Mycursor cursor 
				Read_only FOR 
				Select MailAddress
				from [EPL_SEC].[dbo].[COM_Member]
				where UserID in 
					(select distinct ActivateBy from dbo.TB_FG_SR_Header
					where  SR_OrderStatus='200' and SR_SP_Status='908') 
					and (len(rtrim(isnull(mailaddress,''))) > 0) 
				
				set @RecList = @RecAddressList 

				set @MailSubj = (Select Subject  from Cfg_DBmail where AlertName = @AlertName)
				set @BlindCopyList=(Select Blind_recipients from Cfg_DBmail where AlertName = @AlertName)
				
				--打开游标Mycursor
				OPEN Mycursor; 
				FETCH NEXT FROM Mycursor
					INTO @PlannerMailAddress 	
				WHILE (@@FETCH_STATUS = 0) --       0-FETCH statement was successful.		
					BEGIN
						select @RecList = @RecList + ';'+ isnull(@PlannerMailAddress,'') + ';'				

						FETCH NEXT  FROM Mycursor 
						INTO @PlannerMailAddress			
					END		
				--关闭游标
				CLOSE Mycursor
				DEALLOCATE Mycursor		
				
				--print @RecList
				
				--开始定义和发邮件

				
				SET @tableHTML =
					N'<H1>SHIPPING_Aging_TruckNotLoaded</H1>' +
					N'<table border="1">' +
					N'<tr><th>[Project]</th><th>[SRQTY]</th></tr>' +
	


					CAST ( ( SELECT  
									td =  [Project],'',									
									td =  COUNT([Project]) ,''									
							FROM [dbo].[View_FG_SR_Headers]
							where  Order_Status='Open' and SP_Status='TruckNotLoaded'
							GROUP BY [Project]
							order by [Project]	
							  FOR XML PATH('tr'), TYPE 
					) AS NVARCHAR(MAX) ) +







	
				


					N'<table border="1">' +
					N'<tr><th>[SRid]</th><th>[SRno]</th><th>[Order_Status]</th><th>[SP_Status]</th><th>I/E-WH</th>' +
					N'<th>[TradeTerms]</th><th>[Project]</th><th>[CreateBy]</th>' +
					N'<th>[PGI_Time]</th><th>AgingDAY</th><th>[TotalCtnCnt]</th><th>[TotalPltCnt]</th></tr>' +




					CAST ( ( SELECT  td = [SRid],'',
									td =  [SRno],'',
									td =  [Order_Status],'',
									td =  [SP_Status],'',
									td =  [Flag],'',
									td =  [TradeTerms],'',
									td =  [Project],'',
									td =  [CreateBy],'',
									td =  [PGI_Time],'',
									td =  DATEDIFF(DAY,[PGI_Time],GETDATE()) ,'',
									td =  [TotalCtnCnt],'', 
									td =  [TotalPltCnt],''
							FROM [dbo].[View_FG_SR_Headers]
							where  Order_Status='Open' and SP_Status='TruckNotLoaded'
							order by [CreateBy]	
							  FOR XML PATH('tr'), TYPE 
					) AS NVARCHAR(MAX) ) +
					N'</table>'  +    
					'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';
					
	

					EXEC msdb.dbo.sp_send_dbmail 
					@profile_name ='EpullSqlMail',
					@recipients = @RecList,
					@copy_recipients =@CopyAddressList ,
					--@Blind_Copy_recipients = @BlindCopyList ,
					@subject = @mailsubj,
					@body = @tableHTML,
					@body_format = 'HTML' ;
			    
				end

END
GO
