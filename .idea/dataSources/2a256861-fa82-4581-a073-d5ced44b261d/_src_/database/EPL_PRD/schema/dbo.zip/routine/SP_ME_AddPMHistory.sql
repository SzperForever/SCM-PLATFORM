CREATE PROCEDURE [dbo].[SP_ME_AddPMHistory]
			@FeederID nchar(10)
           ,@PMDate date
           ,@PMBy nchar(10)
           ,@PMTime SMALLDATETIME
           ,@PMNotes nchar(50)
           ,@NextPMDate date
           ,@RepairDate date
           ,@RepariNotes nchar(50)
           ,@RepairedBy nchar(10)
           ,@RepairTime SMALLDATETIME
           ,@Remark nchar(100)
AS
BEGIN
	SET NOCOUNT ON;
INSERT INTO [dbo].[ME_Feeder_History]
           ([FeederID]
           ,[PMDate]
           ,[PMBy]
           ,[PMTime]
           ,[PMNotes]
           ,[NextPMDate]
           ,[RepairDate]
           ,[RepariNotes]
           ,[RepairedBy]
           ,[RepairTime]
           ,[Remark])
     VALUES
           (@FeederID
           ,@PMDate
           ,@PMBy
           ,@PMTime
           ,@PMNotes
           ,@NextPMDate 
           ,@RepairDate 
           ,@RepariNotes 
           ,@RepairedBy 
           ,@RepairTime 
           ,@Remark)
END
GO
