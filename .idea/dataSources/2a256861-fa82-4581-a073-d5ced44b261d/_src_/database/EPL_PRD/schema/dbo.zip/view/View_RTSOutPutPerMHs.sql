CREATE VIEW dbo.View_RTSOutPutPerMHs
AS
SELECT     TOP (100) PERCENT ScanDate, RTRIM(CountedName) AS ScannedBy, COUNT(ScanPartNo) AS sumcount
FROM         dbo.Tb_RTS
WHERE     (CountedBy <> '999999')
GROUP BY ScanDate, CountedName
ORDER BY ScanDate, sumcount DESC
GO
