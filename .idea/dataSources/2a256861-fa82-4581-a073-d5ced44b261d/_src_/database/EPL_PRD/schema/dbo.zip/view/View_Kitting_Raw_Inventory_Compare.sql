
CREATE VIEW [dbo].[View_Kitting_Raw_Inventory_Compare]
AS
SELECT     TOP (100) PERCENT a.Selective, a.OrderID, b.[Material Group] AS WorkCell, a.KittingPartNum, a.Kits_Qty, b.[Qty Per], b.Component AS RawPartNum, 
                      b.[Qty Per] * a.Kits_Qty AS RawPartNeedQty,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) + ISNULL(SUM(Unrestr_Cnsgt), 0) + ISNULL(SUM(In_Qual_Insp), 0) + ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_Total
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1
                            WHERE      (Material = b.Component) AND (Sloc IN ('0100', '0300', '0500'))) AS Current_Stock, c.DocIndex, c.KittingType,
                          (SELECT     ISNULL(SUM(Unrestricted), 0) + ISNULL(SUM(Unrestr_Cnsgt), 0) + ISNULL(SUM(In_Qual_Insp), 0) + ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_Total
                            FROM          dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1
                            WHERE      (Material = b.Component) AND (Sloc IN ('0100', '0300', '0500'))) - b.[Qty Per] * a.Kits_Qty AS DiffQty
FROM         dbo.Tb_Kitting_Order_Header AS a  with (nolock) INNER JOIN
                      dbo.Bas_SAPbom AS b  with (nolock) ON a.KittingPartNum = b.[Assembly Name] LEFT OUTER JOIN
                      dbo.Bas_Kitting_Doc AS c  with (nolock) ON a.KittingPartNum = c.KittingPartNum
WHERE     (a.OrderStatus = 'Open')
ORDER BY a.OrderID

GO
