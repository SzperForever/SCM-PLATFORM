CREATE TRIGGER [dbo].[Tri_UpdateBinStsWhenDelete]   ON  [dbo].[Sup_TempStoreIn]
   AFTER delete
AS 
--if @@rowcount > 1
--begin
--	set @empid = (select top 1 addwho from deleted)

--end
--else 

BEGIN
		SET NOCOUNT ON;
		declare @Binloc varchar(6),
				@empID varchar(10),
				@PartNum varchar(20),
				@Qty int,
				@GRN varchar(18),
				@TransferID varchar(15),
				
				@RowCount int			
				set @binloc = (select distinct binloc from deleted)
				set @empid = (select distinct addwho from deleted)
				set @RowCount = (select count(binloc) from sup_inventory where binloc = @Binloc)			
				If @RowCount> 0 
					begin
						update bas_sup_binloc set binsts = 'HV',resuser = '' where binloc = @Binloc
					end			
				ELSE
					begin
						update bas_sup_binloc set binsts = 'EP',resuser = '' where binloc = @Binloc
					end		
END
GO
