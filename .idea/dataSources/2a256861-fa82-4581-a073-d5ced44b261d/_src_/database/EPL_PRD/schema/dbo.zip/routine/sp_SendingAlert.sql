CREATE PROCEDURE [dbo].[sp_SendingAlert]
	-- Add the parameters for the stored procedure here
	@MailAddress varchar(255),
	@AlertSubject varchar(500),
	@AlertText varchar(1000)		
AS
BEGIN

	SET NOCOUNT ON;
		EXEC msdb.dbo.sp_send_dbmail 
		@profile_name ='EpullSqlMail',
		@recipients = @MailAddress,
		@subject = @AlertSubject,
		@body = @AlertText
END
GO
