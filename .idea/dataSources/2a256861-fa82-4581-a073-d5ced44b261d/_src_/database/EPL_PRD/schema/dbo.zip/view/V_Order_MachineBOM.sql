CREATE VIEW dbo.V_Order_MachineBOM
AS
SELECT     OrderID, WorkCell, PPLModelName, Rev, BayNum, CurrentPlace, fsPartNum, pkgInfoTapeWidth, CreateBy
FROM         (SELECT DISTINCT a1.OrderID, a1.WorkCell, a1.PPLModelName, a1.Rev, a1.BayNum, a1.CurrentPlace, m.fsPartNum, m.pkgInfoTapeWidth, a1.CreateBy
                       FROM          dbo.Tb_Order_Details AS a1 INNER JOIN
                                              dbo.Bas_Machine_Feeder_Report AS m ON a1.Rev = m.Rev AND a1.BayNum = m.MAText AND a1.PPLModelName = m.Number
                       WHERE      (a1.OrderStatus = 'Open') AND (a1.FlagGroup = 'SMT')) AS T2
GO
