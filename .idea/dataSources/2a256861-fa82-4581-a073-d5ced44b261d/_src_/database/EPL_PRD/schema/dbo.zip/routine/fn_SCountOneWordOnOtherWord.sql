
CREATE  function [dbo].[fn_SCountOneWordOnOtherWord]
(
    @Word NVARCHAR(200),
    @WordAll NVARCHAR(2000)
)
RETURNS CHAR(4)
AS
BEGIN
    RETURN  len(replace(@WordAll,@Word,@Word+'_'))-len(@WordAll)
END
GO
