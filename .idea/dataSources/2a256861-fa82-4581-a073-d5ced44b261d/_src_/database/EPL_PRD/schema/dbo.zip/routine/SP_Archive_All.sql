-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-11-15>
-- Description:	<Remove all items to history db>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Archive_All]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	exec dbo.SP_Archive_3PL201 
	--prinT '1 OK'
	exec dbo.SP_Archive_BF_Scan 
	--prinT '2 OK'
	exec dbo.SP_Archive_OrderDetail 
	--prinT '3 OK'
	exec dbo.SP_Archive_PreparedList 
	--PRINT '4 OK'
	exec dbo.SP_Archive_RCV_InboundTracking 
	--PRINT '5 OK'
	exec dbo.SP_Archive_RMA 
	--PRINT '6 OK'
	exec dbo.SP_Archive_RTS 
	--PRINT '7 OK'
	exec dbo.SP_Archive_SR 
	--PRINT '8 OK'
	--exec dbo.SP_Archive_Sup_PullListHistory 
	--PRINT '9 OK'
	exec dbo.SP_Archive_Sup_Transaction 
	--PRINT '10 OK'
	exec dbo.SP_Archive_TB_RCV_TroubleShelf 
	--PRINT '11 OK'

END

GO
