
CREATE PROCEDURE [dbo].[sp_LV_Check_SMT_Safe_Inventory]
		@Material varchar(20),
		@OrderID nvarchar(20),		
		@RemoveQty float,	
		@Step nvarchar(5),
		@Feeder nvarchar(10),	
		@ErrCode int output
AS
BEGIN
	SET NOCOUNT ON;	
		Declare @Rcnt int,
				@AvailableInventory float,
				@Errmsg nvarchar(200)
		
		set @ErrCode = 0 
		set @Rcnt =(select COUNT(*)
            from dbo.View_Machine_Material_List a join Tb_Order_Details b on a.OrderID = b.OrderID and b.OrderStatus = 'Open'
            where A.OrderID = @OrderID AND a.fsPartNum = @Material and a.Step = @step and a.fsSetPos = @Feeder  and a.DiffQty >=0 )
        IF @Rcnt > 0 
			BEGIN
				set @AvailableInventory =(
					select distinct ABS(a.Diffqty)
					from dbo.View_Machine_Material_List a join Tb_Order_Details b on a.OrderID = b.OrderID and b.OrderStatus = 'Open'
					where A.OrderID = @OrderID AND a.fsPartNum = @Material and a.Step = @step and a.fsSetPos = @Feeder and a.DiffQty >=0 )
				IF @RemoveQty > @AvailableInventory 
					BEGIN
						set @ErrCode = 1
						set	@Errmsg ='The Qty you are trying to split :' + str(@removeqty) + ' is more than the Available Inventory of current order. The Available Inventory of the Order:' +  @OrderID + ' is' + STR(@AvailableInventory)
						raiserror(@ErrMsg,16,1)
					END
					
			END
		else if @Rcnt = 0 
			BEGIN
				set @ErrCode = 2
				set	@Errmsg ='No Available Inventory in this Order.'
				raiserror(@ErrMsg,16,1)
			END
		
END

GO
