
CREATE  PROCEDURE [dbo].[SP_Sup_addNewMFGCalls]

		@StationID varchar(30),
		@Project varchar(30),
		@Model varchar(50),	
		@Kits_Qty int,
		@RaisedBy varchar(20),
		@PathID varchar(30)
				
AS
	begin		
		declare @ProcessID Varchar(12)
		DECLARE @dt CHAR(6)
		declare @Rcount int
		SELECT @dt=dt FROM v_GetDate	
			
		set @ProcessID = (SELECT @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(ProcessID),6),0),6) 
						FROM TB_Calls  WITH(XLOCK,PAGLOCK) 
						WHERE ProcessID like @dt+'%')
			
		INSERT INTO [TB_Calls]
           ([ProcessID]
           ,[StationID]
           ,[Project]
           ,[Model]
           ,[Sets]
           ,[ProcessStatus]
           ,[RaisedBy]
           ,[RaiseTime]
           ,[PathID])
          values (
          @ProcessID
          ,@StationID
          ,@Project
          ,@Model
          ,@Kits_Qty
          ,'Open'
          ,@RaisedBy
          ,GETDATE()
          ,@pathid)
end
GO
