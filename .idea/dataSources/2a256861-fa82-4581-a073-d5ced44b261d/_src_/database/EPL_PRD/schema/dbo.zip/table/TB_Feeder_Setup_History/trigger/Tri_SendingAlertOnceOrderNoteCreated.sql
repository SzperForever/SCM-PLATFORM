-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2013-07-08>
-- Description:	<Sending alert message once a order note been updated.>
-- =============================================
CREATE TRIGGER Tri_SendingAlertOnceOrderNoteCreated
   ON  dbo.TB_Feeder_Setup_History
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @OrderNotes varchar(500),@OrderID Varchar(12),@BodyText varchar(500)
	set @OrderNotes = (Select top 1 OrderNotes from inserted)
	set @OrderID = (Select top 1 OrderID from inserted)
	set @BodyText = 'OrderID:' + @OrderID + ',' + @OrderNotes
	if update(ordernotes)
		begin
			Exec sp_SendingAlert 'Xu_yan@jabil.com','Alert Message from epull server',@BodyText
		end
		
END
GO
