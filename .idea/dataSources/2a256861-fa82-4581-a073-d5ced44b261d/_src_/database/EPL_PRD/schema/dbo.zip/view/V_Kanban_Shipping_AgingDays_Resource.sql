CREATE VIEW dbo.V_Kanban_Shipping_AgingDays_Resource
AS
SELECT        a.Material, a.Typ, a.[GR Date], b.Matlgroup, a.StorageBin, a.[Available stock1], DATEDIFF(day, a.[GR Date], GETDATE()) AS Agingday, (CASE WHEN DATEDIFF(day, 
                         a.[GR Date], GETDATE()) <= 7 THEN 'LessThan1Week' WHEN DATEDIFF(day, a.[GR Date], GETDATE()) BETWEEN 8 AND 
                         30 THEN 'LessThan1Month_GreaterThan1Week' WHEN DATEDIFF(day, a.[GR Date], GETDATE()) BETWEEN 31 AND 
                         90 THEN 'LessThan3Month_GreaterThan1Month' WHEN DATEDIFF(day, a.[GR Date], GETDATE()) > 90 THEN 'GreaterThan3months' END) AS PeriodType
FROM            dbo.TB_SAP_INV_WH AS a INNER JOIN
                         dbo.BAS_SKU AS b ON a.Material = b.Material
WHERE        (a.Typ = 'fgi')
GO
