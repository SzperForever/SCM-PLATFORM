CREATE VIEW dbo.View_FG_PKL_Details
AS
SELECT        dbo.View_FG_SR_Headers.SRno, dbo.TB_FG_PKL_Details.LineID AS Item, dbo.TB_FG_PKL_Details.DocName, RTRIM(dbo.TB_FG_PKL_Details.FilePath) 
                         AS FilePath, dbo.View_Users.UserName AS AddBy, dbo.TB_FG_PKL_Details.AddTime, dbo.View_FG_SR_Headers.PGI_Time, dbo.View_FG_SR_Headers.SRid, 
                         dbo.TB_FG_PKL_Details.Docid
FROM            dbo.TB_FG_PKL_Details INNER JOIN
                         dbo.View_FG_SR_Headers ON dbo.TB_FG_PKL_Details.SRid = dbo.View_FG_SR_Headers.SRid INNER JOIN
                         dbo.View_Users ON dbo.TB_FG_PKL_Details.AddBy = dbo.View_Users.UserID
GO
