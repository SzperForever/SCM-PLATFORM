CREATE VIEW dbo.V_Kanban_RTS_Count_Source
AS
SELECT     TOP (100) PERCENT DocYear, ShortDate_RTS, LongDate_RTS, ScanDay_DayNo, ScanDay_WkNo, ScanDay_MonthNo, COUNT(0) AS QTY
FROM         (SELECT     RTSNO, GRNno, ScanTime, DATEPART(year, ScanTime) AS DocYear, CONVERT(VARCHAR(6), ScanTime, 6) AS ShortDate_RTS, CONVERT(date, ScanTime) AS LongDate_RTS, 
                                              DATEPART(DAY, ScanTime) AS ScanDay_DayNo, DATEPART(WEEK, ScanTime) AS ScanDay_WkNo, DATEPART(Month, ScanTime) AS ScanDay_MonthNo
                       FROM          dbo.Tb_RTS) AS t
WHERE     (CONVERT(date, ScanTime) BETWEEN DATEADD(dd, - 15, GETDATE()) AND GETDATE() - 1)
GROUP BY DocYear, ShortDate_RTS, LongDate_RTS, ScanDay_DayNo, ScanDay_WkNo, ScanDay_MonthNo
ORDER BY DocYear, ShortDate_RTS
GO
