CREATE TRIGGER [dbo].[Tri_UpdateOrderStatus_whenInsert]
   ON  [dbo].[Tb_PreparedList]
   AFTER INSERT,update
AS 
BEGIN

	SET NOCOUNT ON;
	declare @OrderID varchar(12),
			@CheckFlag varchar(1),
			@OrderPlace varchar(10),
			--@ActiveRecords int,
			@FlagGroup nchar(10),
			@PartNo nchar(20),
			@Model nchar(50),
			@Errmsg nchar(100),
			@RowCount int,
			@BomRowCount int,
			@FinishStatus varchar(15),
			--@MAtext varchar(12),
			--@Revision varchar(4),			
			@Ruleflag varchar(10)
	set @OrderID = (select top 1  orderid from inserted)	
	set @OrderPlace = (select top 1 currentplace from tb_order_details where orderid = @OrderID and orderstatus = 'Open')
	set @CheckFlag = (select top 1 checkflag from inserted)
	set @FlagGroup = (Select top 1 Flaggroup from inserted)	
	set @Ruleflag=(Select top 1 Ruleflag from inserted)
				
	if update(CheckFlag) begin		
		if @CheckFlag = 'Y' and @OrderPlace  in('Online') and @FlagGroup = 'SMT' begin		
			update tb_order_details 
			set currentplace = 'RTS',Returntime = getdate(),productionleadtime = (getdate()-sendlinetime)
			where orderid = @OrderID and orderstatus = 'Open' and FlagGroup = 'SMT' 
			
			return --如果只是做盘前扫描，到这里直接退出。
		END				
	end
		if @flaggroup = 'SMT' and @Ruleflag not in('Upload')
			BEGIN	
				exec SP_Pull_UpdateFinishRateByOrder @orderid,@flaggroup,''
				return
			end
		Else if @flaggroup = 'MI'  
			BEGIN	
				--set @ActiveRecords = (select count(currentplace) from tb_order_details where orderid = @OrderID and orderstatus = 'Open')	
				set @Partno = (Select partno from inserted)
				set @Model = (Select model from inserted)
				set @RowCount = (Select count(partnum) from bas_bom where model = @model and partnum = @partno)
				--set @BomRowCount = (Select count(partnum) from bas_bom where model = @model)	
				
				if @RowCount =0
					begin
						rollback tran
						set	@Errmsg = 'The Part you are trying to addin is not contained in the Bomlist of this model.' + @partno + @model + str(@BomRowCount)
						raiserror(@ErrMsg,16,1)
					end
				else begin			
					exec SP_Pull_UpdateFinishRateByOrder @orderid,@flaggroup,@Model
					return	
						--set @FinishStatus = (
						--	(SELECT  ltrim(str(COUNT(distinct PartNum))) 
						--	FROM  dbo.View_MI_KittingStatus AS b 
						--	WHERE(b.DiffQty >= 0) and (b.model = @model) 
						--		AND (b.OrderID = @OrderID))
						--		+ '/' +  ltrim(str(@BomRowCount)))
								
						--	if (SELECT  ltrim(str(COUNT(distinct PartNum)))  FROM  dbo.View_MI_KittingStatus AS b WHERE(b.DiffQty >= 0) and (b.model = @model) 
						--		AND (b.OrderID = @OrderID)) =  ltrim(str(@BomRowCount))
						--		begin
						--			update tb_order_details 
						--			set FinishRate = @finishstatus,ConditionalFormat = 'Completed'
						--			where orderid = @orderid					
						--		end
						--	else begin
						--		update tb_order_details 
						--		set FinishRate = @finishstatus,ConditionalFormat = 'InProgress'
						--		where orderid = @orderid 
						--end
						
						
					end
			end
	--END
end
GO
