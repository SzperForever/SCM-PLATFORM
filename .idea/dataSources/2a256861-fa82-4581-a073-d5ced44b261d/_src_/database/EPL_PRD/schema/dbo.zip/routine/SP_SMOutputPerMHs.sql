CREATE PROCEDURE [dbo].[SP_SMOutputPerMHs]
	@DateFrom smalldatetime,
	@DateTo smalldatetime,
	@MHname varchar(10)
AS
BEGIN
	SET NOCOUNT ON;
	if @MHname = ''
		begin
			SELECT    RegDate, RTRIM(UserName) as MHname, [StoreIn(101)] = 
						(Select COUNT(*) from dbo.Sup_Transaction 
						where RegDate =a.regdate AND UserName = a.UserName and Movement = '101'  and TransactionTime between @DateFrom and @DateTo ),
						[StoreOut(311)]= 
						(Select COUNT(*) from dbo.Sup_Transaction 
						where RegDate =a.regdate AND UserName = a.UserName and Movement = '311'  and TransactionTime between @DateFrom and @DateTo),
						ZRT = 
						(Select COUNT(*) from dbo.Sup_Transaction 
						where RegDate =a.regdate AND UserName = a.UserName and Movement = 'ZRT'  and TransactionTime between @DateFrom and @DateTo)
			FROM      dbo.Sup_Transaction a
			WHERE     TransactionTime between @DateFrom and @DateTo
			GROUP BY RegDate, UserName
			ORDER BY RegDate asc 
		end
	if LEN(@mhname) > 0
		begin
			SELECT    RegDate, RTRIM(UserName) as MHname, [StoreIn(101)] = 
						(Select COUNT(*) from dbo.Sup_Transaction 
						where RegDate =a.regdate
						and UserName = @MHname and Movement = '101' and TransactionTime between @DateFrom and @DateTo),
						[StoreOut(311)] = 
						(Select COUNT(*) from dbo.Sup_Transaction 
						where RegDate =a.regdate
						and UserName = @MHname and Movement = '311' and TransactionTime between @DateFrom and @DateTo ),
						ZRT = 
						(Select COUNT(*) from dbo.Sup_Transaction 
						where RegDate =a.regdate
						and UserName = @MHname and Movement = 'ZRT' and TransactionTime between @DateFrom and @DateTo)
			FROM      dbo.Sup_Transaction a
			WHERE     TransactionTime between @DateFrom and @DateTo and UserName = @MHname
			GROUP BY RegDate, UserName
			ORDER BY RegDate asc 			
		end
	
end
GO
