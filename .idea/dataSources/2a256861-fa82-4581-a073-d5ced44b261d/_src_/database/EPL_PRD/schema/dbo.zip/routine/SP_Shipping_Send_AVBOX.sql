-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-1-9,>
-- Description:	<Send a batch order list to supplier team,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Shipping_Send_AVBOX]  
	-- Add the parameters for the stored procedure here
		@Mtrl_Grp varchar(30)
	   ,@AlertName nvarchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
		
  	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	set @Rcnt = 0
	set @Rcnt =(Select count(0) from View_Kitting_MissingKittingType)
	
	if @Rcnt = 0 or @@ERROR <> 0 begin
		return
	end
	
	
	set @Rcnt =(SELECT COUNT(0) from [View_Shipping_MergeBox] WHERE Mtrl_Grp IN (@Mtrl_Grp) )	
	if @Rcnt = 0 or @@ERROR <> 0 begin
		print 'No records return from the view.'
		return
	end
	
	SET @tableHTML = 
		N'<font color=#FF0000><H1> Dear Planner：</H1></font>' +
		N'<font color=#FF0000><H1>Below is partial box item list of 0300 location. You shall inform MFG to do merge for normal shipment before you raise SR to Shipping.</H1></font>' +
		N'<font color=#FF0000><H1> Pls be noticed that ONLY 0100 location is available inventory for SR. Shipping will reject all SR if 0100 location inventory is not enough.</H1></font>' +
		N'<font color=#FF0000><H1>看到邮件后及请通知产线速到成品仓库将下面0300散箱合并成整数箱!仓库将根据0100库存检查SR，0300并箱必须在0100SR提交申请之前完成。0100库存不足SR全部退回。</H1></font>' +
		N'<font color=#FF0000><H1>0300退库每天安排一次于夜班进行！！！</H1></font>' +
		
		
	    N'<H3>Shipping Merge Box Materialcnt </H3>' +
		N'<table border="1">' +
		N'<tr><th>Mtrl_Grp</th><th>MaterialCnt</th></tr>' +
		CAST ( ( SELECT td = Mtrl_Grp,'',
						td = convert(int,COUNT([Material])), ''
				  from [View_Shipping_MergeBox] 
				  --WHERE    Mtrl_Grp = 'SCHNEIDER'
				  WHERE    Mtrl_Grp IN (@Mtrl_Grp)
				  group by [Mtrl_Grp]				 
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		
		
		N'<H3>Shipping FG Partial Box list (To be merged)</H3>' +
		N'<table border="1">' +
		N'<tr><th>Mtrl_Grp</th><th>Material</th><th>Available stock</th><th>Std_Qty</th><th>BoxCnt</th></tr>' +
		CAST ( ( SELECT td = Mtrl_Grp,       '',
						td = Material, '',
						td =  convert(int,[Available stock]), ''	,
						td =  convert(int,STD_QTY), '',
						td =  convert(int,BOXcout), ''		
				  from [View_Shipping_MergeBox] with (nolock) 
				  WHERE    Mtrl_Grp IN (@Mtrl_Grp)
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		
	
		N'<H3>Shipping Merge Box Available Part List BIN </H3>' +
		N'<table border="1">' +
		N'<tr><th>Mtrl_Grp</th><th>Material</th><th>StorageBin</th><th>Available stock]</th></th>'+
		CAST ( ( SELECT  td = A.Mtrl_Grp, '',
						 td = A.Material, '',
						 td = B.StorageBin, '',
						 td =  convert(int,B.[Available stock]),''
						 --td = B.Typ ,''
			      FROM        dbo.View_Shipping_MergeBox AS A 
								LEFT OUTER JOIN
								dbo.View_Shipping_PCBA_BulkBIN AS B ON A.Material = B.Material
			     WHERE    A.Mtrl_Grp IN (@Mtrl_Grp)
                  ORDER BY  A.Material
            	  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		
		
		N'<font color=#FF0000>Do not reply to this mail since it is an automatical notification message.</font>';
       EXEC msdb.dbo.sp_send_dbmail 
	--@profile_name ='EpullSqlMail',
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;
END
GO
