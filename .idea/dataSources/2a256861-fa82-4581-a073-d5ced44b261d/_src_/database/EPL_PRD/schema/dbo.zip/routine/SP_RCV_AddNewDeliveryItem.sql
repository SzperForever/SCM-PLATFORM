-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-2-26>
-- Description:	<Add New RCV Delivery Item.>
-- =============================================
CREATE PROCEDURE [dbo].[SP_RCV_AddNewDeliveryItem]
	-- Add the parameters for the stored procedure here
			--@RegDate date
	@DeliveryNote nvarchar(25)
	,@Forwarder nvarchar(20)
	,@Qty int
	,@Unit nchar(10)
	,@Location varchar(10)
	,@GoodsFrom varchar(10)
	,@ReceivedBy varchar(10)
	,@HostName varchar(10)
	,@AddWho varchar(10)
	,@Remark varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @DocNo varchar(12)
			,@dt CHAR(6)
			,@Rcount int
	
	SELECT @dt=dt FROM v_GetDate		
	select @Rcount = (select COUNT(*) 
					  from TB_RCV_InboundTracking  
					  where DeliveryNote = @DeliveryNote and qty =@Qty)

	if @Rcount = 0
		begin
			set @DocNo =(SELECT @dt+RIGHT(1000001+ISNULL(RIGHT(MAX(DocNo),6),0),6) 
								  FROM TB_RCV_InboundTracking WITH(XLOCK,PAGLOCK) 
								  WHERE DocNo like @dt+'%')
		end   
	else begin
		raiserror('You are trying to insert an item which already exsit in epull system.Please double confirm.',16,1)	
	end  
           
	INSERT INTO [dbo].[TB_RCV_InboundTracking]
           ([DocNo]
           ,[ItemStatus]
           ,[DeliveryNote]
           ,[Forwarder]
           ,[Qty]
		   ,[Unit]
           ,[Location]
           ,[GoodsFrom]
           ,[ReceivedBy]
           ,[ReceivedTime]
           ,[HostName]
           ,[AddWho]
           ,[AddTime]
           ,[Remark])
     VALUES  (@DocNo
			,'Open'
			,@DeliveryNote
			,@Forwarder
			,@Qty
			,@Unit
			,@Location 
			,@GoodsFrom 
			,@ReceivedBy
			,GETDATE()
			,@HostName
			,@AddWho 
			,GETDATE()
			,@Remark)       
END
GO
