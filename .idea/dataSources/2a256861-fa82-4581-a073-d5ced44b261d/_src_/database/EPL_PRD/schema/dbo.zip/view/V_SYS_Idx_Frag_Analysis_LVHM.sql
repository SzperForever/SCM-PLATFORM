CREATE VIEW dbo.V_SYS_Idx_Frag_Analysis_LVHM
AS
SELECT        TOP (100) PERCENT object_id, TableName, index_id, IdxName, avg_fragmentation_in_percent
FROM            dbo.V_SYS_Idx_Frag_Analysis_All
WHERE        (avg_fragmentation_in_percent > 15) AND (object_id IN (996914623, 780581869, 1244583522, 1793441463, 253959981, 914154352, 1767729400, 2039014345, 
                         1527012521, 1575012692, 1433108196, 354100302, 807725980, 2151103, 1614680850, 943394480))
ORDER BY avg_fragmentation_in_percent DESC
GO
