create  TRIGGER [dbo].[TriCheckRule] ON  dbo.Sup_TempPullList
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	declare @InventoryQty int,
			@InsertQty int,
			@InsertSku varchar(20),
			@Errmsg varchar(150)
			
		set @InsertSku = (select PartNum from inserted)
		set @InsertQty =(select qty from inserted)
		set @InventoryQty = (select AvailableQty from dbo.Sup_Inventory where material = @InsertSku)
		if @InventoryQty is null 
			begin
				rollback tran
				set @Errmsg = '无可用库存！'
				raiserror(@ErrMsg,16,1)	
			end
		if @InsertQty > @InventoryQty
			begin
				rollback tran
				set @Errmsg = '可用库存不足，不允许写入。可用库存：' + rtrim(str(@InventoryQty)) + ',缺:' + rtrim(str(@InsertQty-@InventoryQty))
				raiserror(@ErrMsg,16,1)		
			end 	
END
GO
