

CREATE  PROCEDURE [dbo].[SP_KIT_AddNew_Raw_Item]
		@OrderID varchar(13),
		@PartNo varchar(25),
		@Qty float,
		@GRN varchar(18),	
		@AddBy varchar(15),
		@ReturnCode varchar(200)	 = ''	output
AS	
	begin

		declare @KittingPartNum VARCHAR(40),@OrderStatus varchar(10),@OrderProgress varchar(20)
		Declare @Rcnt int,@DiffQty float,@ActualQty float,@KitsQty float
		
		SELECT @KittingPartNum = [KittingPartNum]
					,@OrderStatus = [OrderStatus]
					,@OrderProgress = ProgressCode
					,@KitsQty = Kits_Qty
					,@ActualQty =(Select sum(Qnty) from TB_KIT_RAW_HISTORY where orderid = @OrderID and RawPartNum = @PartNo)
					,@DiffQty = @KitsQty - (Select sum(Qnty) from TB_KIT_RAW_HISTORY where orderid = @OrderID and RawPartNum = @PartNo)
		from TB_KIT_ORDER_HEADER
		where orderid = @OrderID

		if @OrderStatus <> 'OPEN' 
			begin
				set @ReturnCode = 'Error:001,Invalid order status. You are not allowed to append items while order status does not show open.'
				RAISERROR (@ReturnCode, 16, 1)
				return
			end

		if @OrderProgress <>303
			begin
				set @ReturnCode = 'Error:001,Invalid order progress. You are not allowed to append items at this time.'
				RAISERROR (@ReturnCode, 16, 1)
				return
			end

		if not exists (select 0 from Bas_SAPbom where [Assembly Name] = @KittingPartNum and Component = @PartNo )
			begin
				set @ReturnCode = 'Error:100,Invalid raw part number. It does not exist in KIT BOM tree.'
				RAISERROR (@ReturnCode, 16, 1)
				return
			end

		SET @Rcnt = (Select count(0) from TB_KIT_RAW_HISTORY where OrderID = @OrderID)

		INSERT INTO [dbo].[TB_KIT_RAW_HISTORY]
           ([OrderID]
           ,[RawPartNum]
           ,[GRN]
           ,[Qnty]
		   ,[LineID]
           ,[AddWho]
           ,[AddTime])
     VALUES
			(@OrderID
			,@PartNo
			,@GRN
			,@Qty
			,@Rcnt+1
			,@AddBy
			,getdate())
		
		if @@ROWCOUNT  = 0 begin
				set @ReturnCode = 'Error:888, Insert failed.'
				RAISERROR (@ReturnCode, 16, 1)
				return
		end

		set @ReturnCode = '000. Raw part item appended.'
		
		SELECT @KittingPartNum = [KittingPartNum]
					,@OrderStatus = [OrderStatus]
					,@OrderProgress = ProgressCode
					,@KitsQty = DemandQty
					,@ActualQty = ActualQty
					,@DiffQty =DiffQty
		from V_KIT_RAW_Calc
		where orderid = @OrderID

		if @DiffQty >= 0
			begin
				set @ReturnCode = '000. Raw part fulfilled.'
				Update TB_KIT_ORDER_HEADER
				set ProgressCode = 304
				where OrderID = @OrderID
			end
		
		return
					
end


GO
