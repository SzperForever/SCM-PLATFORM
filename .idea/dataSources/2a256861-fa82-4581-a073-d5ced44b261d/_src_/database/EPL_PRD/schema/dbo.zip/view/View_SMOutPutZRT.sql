CREATE VIEW dbo.View_SMOutPutZRT
AS
SELECT     TOP (100) PERCENT RegDate, COUNT(Movement) AS ZRT
FROM         dbo.Sup_Transaction
WHERE     (Movement = 'ZRT')
GROUP BY RegDate
ORDER BY RegDate
GO
