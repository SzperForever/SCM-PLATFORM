

CREATE proc [dbo].[SP_Machine_Feeder_ArrangeOrder] 
	@Number nvarchar(50),
	@MAText nchar(12),
	@Rev nchar(10),
	@BoardSide nchar(10)
	--@JobRevision nchar(10)
AS BEGIN
	Declare  @SlotPitch int,@LineID INT
			,@ArrangeTrolley int
			,@ArrangePos nchar(10)
			,@ArrangeOrder 	int
			,@ArrangeLayer int
			,@LogFileName varchar(1000)
			,@LstSlotPitch int  --上一个SLOTPITCH
    --set @LogFileName = @ResultPath + '\ResultLog.txt'
	set @ArrangeTrolley =1
	SET @ArrangeLayer = 1
	set @ArrangeOrder =0
	SET @LineID = 0
	
	Declare ArgOdr_Cursor cursor scroll dynamic for                        --游标处理循环写入
	select Number,MAText,Rev,BoardSide,SlotPitch
	from  Bas_Machine_Feeder_Report
	where Number =@Number and MAText = @MAText and Rev=@Rev and BoardSide =@BoardSide and pkgInfoPkgType <> 'Tray'
	Order by convert(int,dbo.GetStrPara(fssetpos,1,'-')) asc,convert(int,dbo.GetStrPara(fssetpos,2,'-')) asc
	
	for update-- 定义游标可读写
		
		open ArgOdr_Cursor                   
		fetch next from ArgOdr_Cursor  into @Number,@MAText,@Rev,@BoardSide,@SlotPitch
		while(@@fetch_status=0)		
		BEGIN
			SET @ArrangeOrder =@ArrangeOrder+1+@SlotPitch 
			SET @LineID= @LineID +1
			SET @LstSlotPitch = @SlotPitch 
			
            IF @ArrangeOrder > 43 
				begin
					IF @ArrangeLayer =2  
						begin
							set @ArrangeTrolley = @ArrangeTrolley +1 --如果两层已经放满，则开始摆到下一车。
							set @ArrangeLayer = 0   --下一车继续从第一层开始摆
						end
					IF @SlotPitch <> 0
						BEGIN
							 SET @ArrangeOrder =1+@SlotPitch 
						END
					ELSE BEGIN
						SET @ArrangeOrder = 1 --满足第一个TROLLEY后，进入下一车，序号从1计算 					
					END
					set @ArrangeLayer = @ArrangeLayer +1
				end
            
			update dbo.Bas_Machine_Feeder_Report
			set LineID = @LineID, ArrangePos =  LTRIM(STR(@ArrangeTrolley)) + '-' + LTRIM(STR(@ArrangeLayer)) + ':' + ltrim(STR(@ArrangeOrder))
			WHERE
				CURRENT OF ArgOdr_Cursor;	
			
			IF @LstSlotPitch <> 0 	SET @ArrangeOrder =@ArrangeOrder+@LstSlotPitch 
			
			fetch next from ArgOdr_Cursor into @MAText,@Number,@Rev,@BoardSide,@SlotPitch	
			
						
		end		
	CLOSE ArgOdr_Cursor	
	DEALLOCATE ArgOdr_Cursor
	
	if @@ERROR <>  0 begin
		raiserror ('Unknow error occured.',16,1)
		return
	end
END

GO
