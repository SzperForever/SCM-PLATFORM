CREATE VIEW dbo.V_BI_Kanban_RTS_Count_Source
AS
SELECT     a.DocYear, a.ShortDate_RTS, a.LongDate_RTS, a.ScanDay_DayNo, a.ScanDay_MonthNo, a.ScanDay_WkNo, a.QTY, b.PlanQty, a.QTY / b.PlanQty AS Efficiency
FROM         dbo.V_Kanban_RTS_Count_Source AS a INNER JOIN
                      dbo.Tb_Kanban_RTS_PlanData AS b ON a.LongDate_RTS = b.logDay
GO
