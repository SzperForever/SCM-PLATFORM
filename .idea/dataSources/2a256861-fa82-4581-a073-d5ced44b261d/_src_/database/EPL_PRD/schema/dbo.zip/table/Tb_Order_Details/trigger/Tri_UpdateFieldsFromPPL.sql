-- =============================================
-- Author:		<Hanson>
-- Create date: <2012-08-08>
-- Description:	<Update PLVMODELNAME From BAS_PPL once a new SMT Order inserted>
-- =============================================
CREATE TRIGGER [dbo].[Tri_UpdateFieldsFromPPL]
   ON  [dbo].[Tb_Order_Details]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;		            		
	Declare @PLVBomModelname nchar(80),
		 @Model nchar(80),
		 @rowcount1 int,@rowcount2 int,@rowcount3 int,
		 @Rev nchar(20),
		 @MAText varchar(50),
		 @OrderID Varchar(20),
		 @BuildPlanTime smalldatetime,
		 @WorkCell varchar(20),
		 @FlagGroup varchar(10),
		 @OrderType varchar(20),
		 @msg varchar(250),
		 @AP_Flag nchar(1)
		 
	set @WorkCell = (Select workcell from inserted)
	set @Model = (Select Model from inserted)	 
	set @OrderID = (select orderid from inserted)
	set @FlagGroup = (Select FlagGroup from inserted)
	set @OrderType = (select OrderType from inserted)
	set @AP_Flag = (Select AP_Flag from inserted)
	set @Rev =(Select Rev from inserted)
	set @MAText = (Select BayNum from inserted)
	set @BuildPlanTime = (select BuildPlanTime from inserted)
	
		      --All Autopull order need check PLV BOM first except AI pulls .
		      --New rule:AP_FLAG will be updated as '1' if a new SMT Order created. no matter it is belong to internal or exernal warehouse.
    
	--如果需要定时停止服务，则启用如下代码：
    declare @DatePeriod smalldatetime
    set @DatePeriod = getdate()
	--if @DatePeriod < '2016-09-05 20:00:00' 
	--or  @DatePeriod > '2016-09-16 00:00:00'
	--goto normal

--如果需要手动停止服务，则启用如下代码：

	if @BuildPlanTime between '2017-09-13 6:29:00' and '2017-09-16 0:00:00' goto normal	
    if @DatePeriod between '2017-09-03 17:00:00' and '2017-09-11 00:00:00' 
			and  @FlagGroup NOT IN('MP','Pkg')
    
	begin		
		rollback tran
		set @msg = 'You are not allowed to upload build plan during this period. 
		ePull is out of service during (2017-09-01 00:00:00--2017-09-11 00:00:00)
		EPull  （BuildPlanTime > 2017-09-13 0:00:00  )does not stop during the service.
		Any unclear please contact with Dai lisong-65141.'-- due to PI preparation is inprogress.'
		RAISERROR (@msg, 16, 1)
		return
     end

normal:     
	 if @AP_Flag = 1 and @FlagGroup = 'SMT' and UPPER(right(@workcell,3)) <> '-AI' 
		begin
			
			if @MAText is null or @Rev is null or @Model is null
				begin
					rollback tran
					set @msg = 'Model,Baynum and Rev is not allow nulls.'
					RAISERROR (@msg, 16, 1)
					return
				end
			set @rowcount1 = (Select count(PLVBomModelname) from bas_bomlink where sapbommodelname = @model)
			
			if @rowcount1 =0 
				begin
					rollback tran
					set @msg = 'No records return from the Bom Link Profile for this SAP model:' + @Model + ',You may go check the Bom Link profile.'
					RAISERROR (@msg, 16, 1)
					return
				end				
					
			If Upper(RIGHT(rtrim(@workcell),3))<> '-AI'  --and UPPER(RTRIM(@MAText)) <> 'BAY 2B'
				begin
					set @PLVBomModelname = (Select PLVBomModelname from bas_bomlink where sapbommodelname = @model)
					--PRINT @PLVBomModelname
					set @rowcount3 = (Select count(*) from bas_machine_feeder_report where Number = @PLVBomModelname and MAText = @MAText and Rev = @Rev)
					if @rowcount3 =0 
						begin
							rollback tran
							set @msg = 'No records return from the [BAS_Machine_feeder_report] for this information: Model(' + RTRIM(@PLVBomModelname) + '),MAText:( ' + RTRIM(@matext) + '),Rev:('+ RTRIM(@Rev) + ').Check with MachineBom is needed.'
							RAISERROR (@msg, 16, 1)
							return
						end
					ELSE BEGIN								
							Update tb_order_details 
								set PPLModelName = @PLVBomModelname
								where orderid = @OrderID and model = @model
						end
				end
		end			
end
GO
