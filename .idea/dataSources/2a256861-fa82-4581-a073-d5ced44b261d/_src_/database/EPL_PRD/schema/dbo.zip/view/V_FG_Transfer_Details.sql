CREATE VIEW dbo.V_FG_Transfer_Details
AS
SELECT     TOP (100) PERCENT a.RegDate, a.Movement, b.Matlgroup, a.DocNo, a.PartNo, a.Description, a.Qty, a.SerialNumber, a.Sloc, a.AddWho, a.empID, 
                      a.RPTFlag
FROM         dbo.TB_BFscan AS a LEFT OUTER JOIN
                      dbo.BAS_SKU AS b ON a.PartNo = b.Material
WHERE     (b.Plant <> 'cn07') AND (a.AddTime < GETDATE())
GROUP BY a.RegDate, a.Movement, b.Matlgroup, a.DocNo, a.PartNo, a.Description, a.AddWho, a.empID, a.Qty, a.SerialNumber, a.Sloc, a.RPTFlag
ORDER BY a.RegDate, a.PartNo
GO
