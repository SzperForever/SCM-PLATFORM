CREATE function [dbo].[f_second_Time] (@second int)  
returns varchar(16)  
as  
BEGIN  
/* 根据传入的秒数返回秒数所对应的时间,格式为:x天 xx:xx:xx
如果超过24小时则显示有天，其余时分秒保证显示为2位数字，
例如 1天 00:00:00
Create by Woody
使用: select dbo.[f_second_Time](214580)  
注意:可查询的最大秒数为35999999,即9999时59分59秒,  
这与返回中cast(@Hours as varchar(4))有关,如果需要更大的精度  
可以在返回时改成如cast(@Hours as varchar(8))  
*/  
declare @Secs int  
declare @Mins int  
declare @Hours int  
declare @Days int  
declare @result_d varchar(5)  
declare @result_h varchar(4)  
declare @result_m varchar(4)  
declare @result_s varchar(4)  
set @Secs=@second%60 --秒  
set @Mins=(@second-(@second%60))/60  
set @Hours=(@Mins-(@Mins%60))/60  
set @Mins=@Mins-@Hours*60 ---'分钟  
set @Days=(@Hours-(@Hours%24))/24 ---'日  
set @Hours=@Hours-@Days*24 ---'小时  
/*天*/
if @Days > 0  
 begin
  set @result_d= cast(@Days as varchar(6)) +'Days + '
  end
else
 set @result_d= ''
/*小时*/
if len(@Hours) = 1
 begin  
  set @result_h ='0'+ cast(@Hours as varchar(4)) +':'
 end  
else  
 begin
  set @result_h = cast(@Hours as varchar(4)) +':'
  end
/*分*/
if len(@Mins) = 1
 begin  
  set @result_m ='0'+ cast(@Mins as varchar(4)) +':'
 end  
else  
 begin
  set @result_m = cast(@Mins as varchar(4)) +':'
  end
/*秒*/
if len(@Secs) = 1
 begin  
  set @result_s ='0'+ cast(@Secs as varchar(4))
 end  
else  
 begin
  set @result_s = cast(@Secs as varchar(4))  
  end
/*返回天 时:分:秒*/
return @result_d + @result_h + @result_m + @result_s
END
GO
