/*查看表的索引情况*/
CREATE VIEW dbo.V_SYS_Idx_Frag_Analysis_All
AS
SELECT        TOP (100) PERCENT t.object_id, t.name AS TableName, i.index_id, i.name AS IdxName, s.avg_fragmentation_in_percent
FROM            sys.tables AS t INNER JOIN
                         sys.indexes AS i ON i.object_id = t.object_id INNER JOIN
                         sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('EPL_PRD'), NULL, NULL, 'limited') AS s ON s.object_id = i.object_id AND s.index_id = i.index_id
WHERE        (i.index_id > 0)
ORDER BY s.avg_fragmentation_in_percent DESC
GO
