-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-2-15>
-- Description:	<Verify The DonNo of Backflash history>
-- =============================================
CREATE PROCEDURE sp_VerifyBFDocNo
	-- Add the parameters for the stored procedure here
	@Docno varchar(20),
	@Result int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	declare @rCnt int
	select @rCnt = (select COUNT(*) from dbo.TB_BFscan where DocNo = @docno)
	if @rCnt = 0 
		begin
			set @Result = 1
		end
	if @rCnt > 0 
		begin
			set @Result = 0
		end		
END
GO
