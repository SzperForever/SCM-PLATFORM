-- =============================================
-- Author:		Hanson Zhang
-- Create date: <2014-10-30>
-- Description:	<Sending an alert mail to supplier that once new available stock detected.>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_ShortageAlert_Launch]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Insert statements for procedure here
    --Declare @AfterDiffQty float
 --   truncate table tb_kitting_rawpart_inv_compare
	Declare @Rcnt int
			,@Msg nvarchar(max)
			,@TableHtml nvarchar(max)
			,@IAMailAdd varchar(200)
			,@MailSubj nvarchar(200)
			
	Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(max)
					
	set @Rcnt = (Select COUNT(0) from View_Kitting_RawShortage_CheckAvlbStock  with (nolock) where AvailableStock = 'Y' )
	if @Rcnt = 0 begin
		Return --When no available stock detected then quit.
	end
	
	
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = 'KittingShortageAlert') 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = 'KittingShortageAlert') 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName = 'KittingShortageAlert')
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = 'KittingShortageAlert')
	set @BlindCopyList=(Select Blind_recipients from Cfg_DBmail where AlertName = 'KittingShortageAlert')
	
	select @Msg = 'To Supplier,' + CHAR(10) +
				  'Please be noticed below raw parts have new stock available. Please take action if needed.'       
	
	SET @TableHtml = @Msg +
		N'<H1>New Stock Available For Raw Parts </H1>' +
		N'<table border="1">' +
		N'<tr><th>RawPartNum</th><th>Qty_Per</th><th>Demand_Before</th><th>InvTotal_Before</th><th>DiffQty_Before</th><th>Shortage_After</th><th>TotalInv_After</th><th>DiffQty_After</th><th>AvailableStock</th><th>LastRecordTime</th><th>RefreshTime</th></tr>' +
		CAST ( ( SELECT td =[RawPartNum],       '',
						td= cast([Qty Per] as varchar),'',
						td =cast([Demand_Before] as varchar), '',
						td =cast([InvTotal_Before] as varchar), '',
						td= cast([DiffQty_Before] as varchar),'', 				
						td= cast([Shortage_After] as varchar),'',
						td= cast([TotalInv_After] as varchar),'',
						td= cast([DiffQty_After] as varchar),'',
						td= [AvailableStock],'',
						td= [AddTime],'',
						td =[RefreshTime],''
				  from View_Kitting_RawShortage_CheckAvlbStock with (nolock) 
				  where AvailableStock = 'Y'	
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		'Do not reply to this mail since it is an automatical notification message.';
		
	
	EXEC msdb.dbo.sp_send_dbmail 
	--@profile_name ='EpullSqlMail',
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @BlindCopyList ,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;
	

			  
END


GO
