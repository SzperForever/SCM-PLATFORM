-- =============================================
-- Author:		<Hanson >
-- Create date: <2014-10-21,>
-- Description:	<Batch Close Kitting Orders base on scanned sheet,,>
-- Command example:exec [SP_Kitting_Close_Order_By_KittingPartNum] '2061612$','HANSON',''
-- =============================================
CREATE  PROCEDURE [dbo].[SP_Kitting_Close_Order_By_KittingPartNum]
	-- Add the parameters for the stored procedure here
		@KittingPartNum varchar(30),
		@CloseBy varchar(15),
		@ReturnCode varchar(200) output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;  
    
Declare  @Rcnt int,@ActualQty float,@DiffQty float,@ExcessQty float,@TotalKitsQty float
		,@OrderID VARCHAR(13),@LstOrderID varchar(13)
		,@BuildPlanTime datetime
		,@Kits_Qty float
		,@LogText varchar(200)
set @Rcnt =(Select COUNT(distinct orderid) from View_Kitting_Order_Headers with (nolock) where KittingPartNum = @KittingPartNum and OrderStatus = 'OPEN')


--temp talbe
	declare @TmpActualQty table
	(	
		ID				int identity(1,1) primary key,
		KittingPartNum	varchar(30) not null,
		ActualQty		float not null,
		PkgCnt			int not null
	)

	insert into @TmpActualQty (KittingPartNum,ActualQty,PkgCnt)
	SELECT DISTINCT KittingPartNum, ISNULL(SUM(Qty), 0) AS ActualQty, ISNULL(COUNT(DISTINCT GRN), 0) AS PkgCnt
	FROM         dbo.View_Kitting_PreparedList AS h with (nolock)
	WHERE     ((BatchID + KittingPartNum + GRN) IN
							  (SELECT     BatchID + PartNo + GRN AS Expr1
								FROM          dbo.View_Kitting_BatchDetails with (nolock)
								WHERE      (OrderStatus = 'OPEN')))
	GROUP BY KittingPartNum

	SET @ActualQty = (Select ActualQty  from @TmpActualQty where KittingPartNum = @KittingPartNum )

IF @ActualQty =0 
	begin
		set @ReturnCode = '001.Actual qty is 0 so an abortion is proceed.' 
		print @ReturnCode
		RETURN
	end


If exists (Select * from tempdb.dbo.sysobjects Where name='##ep_tmp_Kitting_OrderList' and  Xtype='U') drop table [##ep_tmp_Kitting_OrderList]

--创建临时表用以存储该物料的订单列表
CREATE TABLE [dbo].##ep_tmp_Kitting_OrderList (
	[Orderid] VARCHAR(13) NOT NULL,
	[Buildplantime] Datetime NOT NULL,
	[KittingPartNum] VARCHAR(30) NOT NULL,
	[Kits_Qty] [nchar](10) NULL,
	[Idx] int Identity(1,1) not null
) ON [PRIMARY]

-- 将此物料的订单列表插入临时表，并按需求时间升序排序
	insert into ##ep_tmp_Kitting_OrderList (orderid,buildplantime,kittingpartnum,kits_qty )
	select orderid,buildplantime,kittingpartnum,kits_qty 
					from view_kitting_order_headers  with (nolock)
					where orderstatus = 'OPEN' and kittingpartnum = @kittingpartnum 
					order by buildplantime asc 
	set @Rcnt = @@ROWCOUNT 
	
	Declare @I int
	set @I= 0 
	SET @TotalKitsQty =0 
	while @I < @Rcnt 
		begin
			set @I= @I +1
			Select @OrderID = orderid,@Kits_Qty=Kits_Qty,@TotalKitsQty = Kits_Qty +@TotalKitsQty  from ##ep_tmp_Kitting_OrderList where Idx = @I 
			
			set @ExcessQty = @ActualQty - @TotalKitsQty 
			
			if @ExcessQty < 0 
				begin
					if @I = 1 set @ReturnCode = '991.PartNum: ' + @KittingPartNum + ' first order doesnot meet.'
					goto JumpOut
				end
			
			if @ExcessQty = 0 
				begin
					set @ReturnCode = '992.No Excess Qty.'
					set @LogText = '/Order closed since it is full kited.'
					update Tb_Kitting_Order_Header 
							set OrderStatus = 'CLOSED',ClosedBy = @CloseBy ,ClosedTime =GETDATE(),OrderNotes  = OrderNotes + @LogText
							where OrderID = @OrderID 					
					
					--重置已出库数量
					exec SP_Kitting_ResetActualQty @kittingpartnum	
					if @@ERROR <> 0 set @ReturnCode = '888. Error occured while reseting the actual qty. Please check!'
					--此时不需要移到下一条记录因为不会有多余数量了。								
					goto JumpOut
				end

			if @ExcessQty > 0
				begin
					set @LstOrderID = @OrderID -- 为上一个订单赋值
					set @ReturnCode = '993.Excess Qty is detected.'
					set @LogText = '/ full kited but still has excess qty:' + STR(@ExcessQty)
					update Tb_Kitting_Order_Header 
							set OrderStatus = 'CLOSED',ClosedBy = @CloseBy ,ClosedTime =GETDATE(),OrderNotes  = OrderNotes + @LogText
							where OrderID = @LstOrderID 					
					
					-- 这里进行扣除运算事务
					
					if exists (Select orderid from ##ep_tmp_Kitting_OrderList where Idx = @I+1 )
						begin
							
							Select @OrderID=orderid,@Kits_Qty = Kits_Qty from ##ep_tmp_Kitting_OrderList where Idx = @I+1 
							
							if @Kits_Qty > @ExcessQty  -- 剩余数量小于下一个订单需求数量，在下一个订单的需求数量进行扣除
								begin
									set @LogText = '/Old Request Qty:' + str(@kits_qty) + ',Remaining：' + str(@excessqty) + '.Kits Qty will be updated as:' +  str(@Kits_Qty -@ExcessQty)
									update Tb_Kitting_Order_Header 
									set Kits_Qty = Kits_Qty -@ExcessQty ,OrderNotes = OrderNotes + @LogText
									where OrderID = @OrderID 
									goto ActionEnd
								end
							if @Kits_Qty = @ExcessQty -- 剩余数量刚好等于下一个订单需求数量，关闭这个订单将退出
								begin
									set @LogText = '/Old Request Qty:' + str(@kits_qty) + ' is equal to excess qty of last order so it will be closed in the same time.'
									update Tb_Kitting_Order_Header 
									set OrderStatus = 'ClOSED',ClosedBy = @CloseBy ,ClosedTime =GETDATE(),OrderNotes  = OrderNotes + @LogText
									where OrderID = @OrderID 
									goto ActionEnd
								end
							if @Kits_Qty < @ExcessQty 	-- 剩余数量大于下一个订单需求数量，关闭这个订单并移到下一个订单
								begin
									set @LogText = '/Old Request Qty:' + str(@kits_qty) + ',Remaining：' + str(@excessqty) + '.'
									update Tb_Kitting_Order_Header 
									set OrderStatus = 'ClOSED',ClosedBy = @CloseBy ,ClosedTime =GETDATE(),OrderNotes  = OrderNotes + @LogText
									where OrderID = @OrderID 
								end											
						end
					else
						begin
							set @ReturnCode = '002.There are no more orders wating to be proceed. '
							goto jumpout
						end
				end
		end	
		
ActionEnd:
		--重置已出库数量
	exec SP_Kitting_ResetActualQty @kittingpartnum		
	
	if @@ERROR <> 0 
		begin
			set @ReturnCode = '888. Error occured while reseting the actual qty. Please check!'
		end
	else begin
			set @ReturnCode = '000. Operation proceed.'
	end
	
	print @ReturnCode
	If exists (Select * from tempdb.dbo.sysobjects Where name='##ep_tmp_Kitting_OrderList' and  Xtype='U') drop table [##ep_tmp_Kitting_OrderList]
	Return

JumpOut:				
	If exists (Select * from tempdb.dbo.sysobjects Where name='##ep_tmp_Kitting_OrderList' and  Xtype='U') drop table [##ep_tmp_Kitting_OrderList]

	print @ReturnCode
	Return
					
end

GO
