
CREATE  PROCEDURE [dbo].[Ep_SP_addNewRTSItem]
		@RTSno nvarchar(12),
		@WorkCell varchar(20),
		@Sloc nvarchar(4),
		@ScanPartNum varchar(25),
		@ScanQty numeric(18, 0),
		@QtyBefore numeric(18, 0),
		@GRN nvarchar(18),
		@CountedBy nvarchar(20),
		@CountedName nvarchar(20),
		@ScannedBy nvarchar(20),
		@MAremark nvarchar(200) ='',
		@IsMSDPart nvarchar(12)= 'N'
AS
	begin
				INSERT INTO [dbo].[Tb_RTS]
					   ([RTSNO]
					   ,[WorkCell]
					   ,[StoreLocation]
					   ,[ScanPartNo]
					   ,[ScanQty]
					   ,[Qty]
					   ,[GRNno]
					   ,[CountedBy]
					   ,[CountedName]
					   ,[ScannedBy]
					   ,[ScanTime]
					   ,[MAremark]
					   ,[InputBy])
				VALUES
						(@RTSno,
						@WorkCell,
						@Sloc,
						@ScanPartNum ,
						@ScanQty,
						@QtyBefore, 
						@GRN,
						@CountedBy,
						@CountedName,
						@ScannedBy,
						GETDATE()
						,@MAremark
						,@IsMSDPart )	

	end
GO
