/* AND (DATEPART(year, AddTime) = DATEPART(year, GETDATE()))*/
CREATE VIEW dbo.V_Kanban_Rec_ArriveRate_Source
AS
SELECT        DATEPART(year, AddTime) AS DocYear, DocNo, CONVERT(VARCHAR(6), AddTime, 6) AS ShortDate_Rec, CONVERT(date, AddTime) AS LongDate_Rec, 
                         DATEDIFF(HOUR, AddTime, ClosedTime) AS Diff_h, DATEDIFF(Day, AddTime, ClosedTime) AS Diff_d, DATEDIFF(Day, AddTime, GETDATE()) AS Diff_d_tillNow, 
                         DATEPART(WEEK, ClosedTime) AS ClosedDay_WkNo, DATEPART(WEEK, GETDATE()) AS Now_WkNo, DATEPART(Month, ClosedTime) AS ClosedDay_MonthNo, 
                         (CASE WHEN datediff(HOUR, AddTime, ClosedTime) < 12 THEN 'Ls12' WHEN datediff(HOUR, AddTime, ClosedTime) < 24 AND datediff(HOUR, AddTime, ClosedTime) 
                         > 12 THEN 'Ls24Gt12' WHEN datediff(HOUR, AddTime, ClosedTime) < 48 AND datediff(HOUR, AddTime, ClosedTime) > 24 THEN 'Ls48Gt24' WHEN datediff(HOUR, 
                         AddTime, ClosedTime) > 48 THEN 'Gt48' END) AS PeriodType
FROM            dbo.TB_RCV_InboundTracking
WHERE        (ItemStatus = 'Closed')
GO
