CREATE VIEW dbo.View_SMT_KittingStatus
AS
SELECT     TOP (100) PERCENT c.OrderID, c.WorkCell, c.Model, c.BayNum, c.Sloc, c.CreateBy, a.Component, a.[Qty Per], c.Sets, c.OrderStatus, c.Sets * a.[Qty Per] AS NeedQty,
                          (SELECT     ISNULL(SUM(Qty), 0) AS Actualqty
                            FROM          dbo.Tb_PreparedList AS h WITH (nolock)
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Component) AND (FlagGroup = 'SMT')) AS Actualqty,
                          (SELECT     ISNULL(SUM(Qty), 0) AS Expr1
                            FROM          dbo.Tb_PreparedList AS h WITH (nolock)
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Component) AND (FlagGroup = 'SMT')) - c.Sets * a.[Qty Per] AS DiffQty,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Tb_PreparedList AS g WITH (nolock)
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Component)) AS PkgCount, c.FinishRate
FROM         dbo.Bas_SAPbom AS a WITH (nolock) FULL OUTER JOIN
                      dbo.Tb_Order_Details AS c WITH (nolock) ON c.Model = a.[Assembly Name] FULL OUTER JOIN
                      dbo.Tb_PreparedList AS b WITH (nolock) ON a.[Assembly Name] = c.Model AND a.Component = b.PartNo AND b.OrderID = c.OrderID AND c.FlagGroup = 'SMT'
WHERE     (c.OrderStatus <> 'Cance') AND (c.FlagGroup = 'SMT') AND (c.OrderID IS NOT NULL) AND (c.OrderStatus = 'Open')
GROUP BY c.OrderID, c.WorkCell, c.Model, c.BayNum, c.Sloc, c.CreateBy, a.Component, a.[Qty Per], c.Sets, c.FinishRate, c.OrderStatus
ORDER BY a.Component
GO
