CREATE TRIGGER [dbo].[Tri_Update_Inventory] on [dbo].[Sup_Transaction]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON 
		begin					
			declare @TBinLoc varchar(6),
					@sku varchar(20),
					@Tqty numeric(18, 7),
					@StgType varchar(2),
					@Movement varchar(3),
					@MoveQty int,
					@MaterialGroup varchar(20),
					@ModifyTime Datetime,
					@ModifyBy varchar(20),
					@LastMovement nchar(3),
					@MtrlDescription varchar(150),
					@BinStgType varchar(2),
					@PartCountInsert int,
					@BinPartCount int,
					@BinMaxPartCount int,					
					@BinCountStgType int,										
					@ErrMsg varchar(max),
					@TransferID varchar(15),
					@Inventory numeric(18, 7),@SingleRemoveQty numeric(18, 7),
					@MapCount int,
					@empID varchar(10),
					@ReferenceNo varchar(13),
					@Sloc varchar(4)
					,@msg varchar(200)
					
					set @TBinLoc=(select top 1 TBinloc from inserted)
					set @sku=(select top 1 sku from inserted)
					set @Tqty=(select top 1 Tqty from inserted)
					set @StgType=(select top 1 TStgType from inserted)
					set @MaterialGroup=(select top 1 rtrim(MaterialGroup) from inserted)
					set @Movement =(select top 1 RTRIM(movement) from inserted)
					set @MoveQty=(select top 1 FQty from inserted)
					set @ModifyTime = (select top 1 TransactionTime from inserted)
					set @ModifyBy = (select top 1 USERNAME from inserted)
					set @LastMovement = (select top 1 movement from inserted)
					set @MtrlDescription = (select top 1 MtrlDescription from inserted)
					set @TransferID = (select top 1 TransferID from inserted)
					set @empid = (select top 1 addwho from inserted)
					set @ReferenceNo = (select top 1 ReferenceNo from inserted)
					
				if @Movement = '101' or @Movement = 'ZRT' 
					begin
						if @MoveQty > 0
							begin
								update sup_inventory set AvailableQty = AvailableQty + @Tqty,lastmovement = @lastmovement,LastModifyBy =@ModifyBy,LastModifyTime=@ModifyTime 
								where Material = @sku and BinLoc = @TBinLoc								
							end
						if @MoveQty = 0
							begin
								insert into sup_inventory (MaterialGroup,BinLoc,Material,MtrlDescription,AvailableQty,StoreType,LastModifyBy,LastModifyTime,LastMovement) 
								values(@MaterialGroup,@TBinLoc,@sku,@MtrlDescription,@Tqty,@StgType,@ModifyBy,@ModifyTime,@LastMovement)
							end					

						update bas_sup_binloc set binsts = 'HV' where binloc = @TBinLoc
					end
				if @Movement = '311' 
					begin
						set @SingleRemoveQty = (select tqty from inserted)
						set @MapCount=(select count(*) from sup_skumap where material = @SKU)
						set @Inventory =(select AvailableQty from sup_inventory where material = @sku and binloc =@Tbinloc)
						set @Sloc = (Select Sloc from inserted)
			
						--更新配料历史表的配料FLAG
						update dbo.SUP_PullListHistory set pickflag = 1 where DocNo = @ReferenceNo and PartNum = @sku				
					
						if @SingleRemoveQty > @inventory
								begin
									rollback tran
									set @Errmsg = ltrim(str(@SingleRemoveQty)) + ',' + ltrim(str(@inventory)) + '库存不足，无法进行出库交易。此次操作失败。'
									raiserror(@ErrMsg,16,1)								
								end									
						ELSE 
							BEGIN
								--更新这个物料在超市线上库存表为原有线上库存加上311出库的数量。
								update dbo.Sup_OnlineInventory set Unrestricted = Unrestricted + @SingleRemoveQty,MaintainedBy = @empID,MaintainTime = getdate(),Remark = 'Online Inventory Updated'
								where SLoc =@sloc and Material = @Sku and [Matl grp] = 'Cisco'
																			
								if @SingleRemoveQty < @inventory
									begin
										--更新这个料的库存等于原来的库存减去311出库的数量。			
										update sup_inventory set AvailableQty = AvailableQty - @SingleRemoveQty,lastmovement = @lastmovement,LastModifyBy =@ModifyBy,LastModifyTime=@ModifyTime 
										where sup_inventory.Material = @sku and sup_inventory.BinLoc = @TBinLoc																
										--储位状态为HV,说明该储位上尚有物料。
										update bas_sup_binloc set binsts = 'HV' where binloc = @TBinLoc
									end
								if @SingleRemoveQty = @inventory							
									begin																	
										--删除这个料的库存
										DELETE FROM sup_inventory
										where sup_inventory.Material = @sku and sup_inventory.BinLoc = @TBinLoc								
										--恢复储位状态为EP,即空储位							
										update bas_sup_binloc set binsts = 'EP' where binloc = @TBinLoc	
									END
							END
					end
				if @Movement = '999'					
					if @tqty = 0 
						begin
								DELETE FROM sup_inventory
								where sup_inventory.Material = @sku and sup_inventory.BinLoc = @TBinLoc	
						end
					else begin
								update sup_inventory set lastmovement = @lastmovement,LastModifyBy =@ModifyBy,LastModifyTime=@ModifyTime 
								where sup_inventory.Material = @sku and sup_inventory.BinLoc = @TBinLoc																
								update bas_sup_binloc set binsts = 'HV' where binloc = @TBinLoc						
					end	
				if @movement = '' or @movement is null
					begin
						rollback tran
						set @Errmsg = '读取交易类型失败，触发器不能正常工作，库存不能正常更新。此次操作被回滚。'
						raiserror(@ErrMsg,16,1)							
					end								
		end
END
GO
