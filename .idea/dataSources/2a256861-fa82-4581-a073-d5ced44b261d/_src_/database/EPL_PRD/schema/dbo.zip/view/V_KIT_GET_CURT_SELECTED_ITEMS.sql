
CREATE VIEW [dbo].[V_KIT_GET_CURT_SELECTED_ITEMS]
AS
SELECT        TOP (100) PERCENT a.Selective, a.OrderID, a.BuildPlanTime, b.[Material Group] AS WorkCell, a.KittingPartNum, a.Kits_Qty, b.[Qty Per], 
                         b.Component AS RawPartNum, b.[Qty Per] * a.Kits_Qty AS RawPartNeedQty,
                             (SELECT        ISNULL(SUM(Unrestricted), 0) + ISNULL(SUM(Unrestr_Cnsgt), 0) + ISNULL(SUM(In_Qual_Insp), 0) + ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_Total
                               FROM            dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1
                               WHERE        (Material = b.Component) AND (Sloc IN ('0100', '0300', '0500'))) AS Current_Stock, c.DocIndex, c.ProcessingType,
                             (SELECT        ISNULL(SUM(Unrestricted), 0) + ISNULL(SUM(Unrestr_Cnsgt), 0) + ISNULL(SUM(In_Qual_Insp), 0) + ISNULL(SUM(Cnsgt_Qual_In), 0) AS Inv_Total
                               FROM            dbo.TB_SAP_INV_FINAL AS TB_SAP_INV_FINAL_1
                               WHERE        (Material = b.Component) AND (Sloc IN ('0100', '0300', '0500'))) - b.[Qty Per] * a.Kits_Qty AS DiffQty, a.ProgressCode, a.PullListNo
FROM            dbo.TB_KIT_ORDER_HEADER AS a WITH (nolock) INNER JOIN
                         dbo.Bas_SAPbom AS b WITH (nolock) ON a.KittingPartNum = b.[Assembly Name] LEFT OUTER JOIN
                         dbo.TB_KIT_DOC AS c WITH (nolock) ON a.KittingPartNum = c.KittingPartNum
WHERE        (a.OrderStatus = 'Open')
ORDER BY a.OrderID

GO
