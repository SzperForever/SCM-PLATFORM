-- =============================================
-- Author:		HANSON
-- Create date: 2014-11-4
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SP_Alert_SMT_MFG_AgingOver24Hrs

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   

 

Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
		
	set @AlertName = 'SMTAgingSlocOver24hrsMFG'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	set @Rcnt = 0
	set @Rcnt =(select COUNT(distinct PullListNo) 
			from Tb_Order_Details 
			where DATEDIFF(Minute,sendlinetime, GETDATE())> 1440 and OrderStatus = 'Open' and CurrentPlace = 'Online')
	if @Rcnt > 0
	
	if @Rcnt = 0 or @@ERROR <> 0 begin
		return
	end


	SET @tableHTML =
		N'<H1>Aging Sloc Alarming Service </H1>' +
		N'<table border="1">' +
		N'<tr><th>Workcell</th><th>OrderID</th><th>Model</th><th>Sets</th><th>BayNum</th><th>sloc</th><th>PullListNo</th><th>BuildPlanTime</th>' +
		N'<th>SendLineTime</th><th>OverTime</th><th>Owner</th><th>AgingReason</th></tr>' +
		CAST ( ( SELECT td = Workcell,       '',
						td = OrderID, '',
						td = Model, '',
						td = Sets, '',
						td = BayNum, '',
						td = sloc, '',
						td = PullListNo, '',
						td = BuildPlanTime, '',
						td = SendLineTime, '',
						td = DATEDIFF(hh,sendlinetime, GETDATE()), '',
						td = CreateBy, '',
						td = Agingreason, ''						
				  from Tb_Order_Details 
				  where DATEDIFF(Minute,sendlinetime, GETDATE())> 1440 
						and OrderStatus = 'Open' and CurrentPlace = 'Online' and FlagGroup = 'SMT'                 
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';

	
	 EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;
	


END
GO
