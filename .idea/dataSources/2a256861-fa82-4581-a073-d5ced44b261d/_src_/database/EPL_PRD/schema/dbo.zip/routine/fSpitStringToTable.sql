
-- Author:  苟安廷
-- Create date: 2008-1-19
-- Description: 将一个字符串拆分到表中
--select * from fSpitStringToTable(';123;223m;323;',';')
-- =============================================
Create FUNCTION [dbo].[fSpitStringToTable] 
(
 @List nvarchar(4000), --被拆分的字符串
 @SplitChar char   --用于分割的字符
)
RETURNS @Result table (ChildStr nvarchar(4000),OrderSN int )
AS
BEGIN
 --声明用于存放拆分的子串和剩下的字符串
 declare @ChildStr nvarchar(4000)
 set @ChildStr=''

 --去掉前导的分隔符
 while Charindex(@SplitChar,@List,0)=1
  set @List=right(@List,len(@List)-1)
 --去掉后面的分隔符
 while right(@List,1)=@SplitChar
  set @List=left(@List,len(@List)-1)

 declare @nIndex int
 declare @Order int--次序
 set @Order=1
 while len(@List)>0
 begin
  set @nIndex=Charindex(@SplitChar,@List,0)
  if @nIndex>0
  begin
   set @ChildStr=left(@List,@nIndex-1)
   set @List=right(@List,len(@List)-@nIndex)
  end
  else
  begin
   set @ChildStr=@List
   set @List=''
  end
  if len(@ChildStr)>0
  begin
   insert into @Result(ChildStr,OrderSN) values(@ChildStr,@Order)
   set @Order=@Order+1
  end
 end

 return

END
GO
