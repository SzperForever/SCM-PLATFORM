-- =============================================
-- Author:		Hanson
-- Create date: 2015.8.11
-- Description:	Add a PKG item
-- =============================================
CREATE PROCEDURE [dbo].[SP_FG_AddNewPKGDetails]
	-- Add the parameters for the stored procedure here

	 @SRid bigint
	,@SMid bigint = 0
	,@PartNum nchar(30)
	,@Qty float
	,@BoxID nchar(25)
	,@AddBy nchar(13)
	,@LbID nchar(20) = '' output
	,@RemPkgCnt int output
	,@RemQty float output
	,@FullKit bit = 0 output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	Declare @SRStatus nchar(3)
			,@OrderStatus nchar(3)
			,@ErrMsg varchar(300)
			,@Rcnt int
			,@SPStatus nchar(3)
			,@LineID int
			,@PKGid int
			,@OrderQty int
			,@DoneQty int
			,@IsMutiPkgType bit
			,@PkgTypeCnt int
			,@EstimatePkgCnt int
			,@IsPlt bit
			,@GW float
			,@NW float
			,@Height float
			,@Length float
			,@Width float
	set @LineID = (Select count(*) from [dbo].[TB_FG_PKG_Details] where [SRid] = @SRid ) + 1
	set @EstimatePkgCnt = (Select isnull(EstimatePkgCnt,0) from [dbo].[TB_FG_SR_Header] where [SRid] = @SRid )
	set @IsPlt = (Select isnull(IsPlt,1) from [dbo].[TB_FG_SR_Header] where [SRid] = @SRid )
	set @OrderQty = (Select sum(isnull([TotalQty],0)) from [TB_FG_SR_Details] where  [SRid] = @SRid and [PartNum] = @PartNum )
	set @DoneQty = (Select sum(isnull([Qty],0)) from [TB_FG_PKG_Details] where  [SRid] = @SRid and [PartNum] = @PartNum )
	
	if @EstimatePkgCnt = 0 begin
			set @ErrMsg = 'EstimatePkgCnt error. （预估包装数量非法。）'
			raiserror (@ErrMsg,16,1)
			return
	end
	set @OrderStatus = (Select SR_OrderStatus  from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
		if @OrderStatus <> '200' begin
			set @ErrMsg = 'Process denied since SR Order status is not [Open]. （由于SR订单状态未开启，拒绝进行下一步操作。）'
			raiserror (@ErrMsg,16,1)
			return
		end

	set @SRStatus = (Select [SR_Status] from [dbo].[TB_FG_SR_Header] where [SRid] = @SRid)
	if @SRStatus <> '901' begin
		set @ErrMsg = 'Process denied since this SR is not activated. （由于SR订单状态未被激活，拒绝进行下一步操作。）'
		raiserror (@ErrMsg,16,1)
		return
	end

	set @SPStatus = (Select [SR_SP_Status] from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
	if @SPStatus not IN ('904','905') begin
		set @ErrMsg = 'Invalid SR Stauts which SP Status is not [MPPicking]. (该SR订单状态为非打印唛头时不允许进行此操作。)'
		raiserror (@ErrMsg,16,1)
		return
	end

	if @DoneQty > @OrderQty begin
		set @ErrMsg = 'Pack qty larger than order qty is not allowed.（实际备货数量不可以大于订单要求数量！）'
		raiserror (@ErrMsg,16,1)
		return
	end

	if not exists(Select [PartNum] from [TB_FG_SR_Details] where  [SRid] = @SRid and [PartNum] = @PartNum) 
		begin
			set @ErrMsg = 'This good:' + @PartNum + ' is not exist in this order（此产品在此SR订单中不存在！）'
			raiserror (@ErrMsg,16,1)
			return
		end

	set @Rcnt = (Select count(*) from [dbo].[TB_FG_PKG_Details] where [SRid] = @SRid )
	if @Rcnt = 0 
		begin
			set @PKGid = 1
		end
		else begin
			if @IsPlt = 1   set @PKGid = @SMid 
			if @SMid  = 0 --判断为箱出货时
				begin
					set @PKGid = (Select max(PKGid) from [dbo].[TB_FG_PKG_Details] where [SRid] = @SRid ) + 1
					if @PKGid > @EstimatePkgCnt begin
						set @ErrMsg = 'Acutal package count met maxmum estimate number.（实际包装数量大于预估数量！）'
						raiserror (@ErrMsg,16,1)
						return
					end
				end 						
		end	

		set @RemQty = (Select [Difference] from [dbo].[View_FG_SR_Details_Status] where SRid = @SRid AND [PartNum] = @PartNum  )
		if @Qty > ABS(@RemQty) begin
			set @ErrMsg = 'The qty you attemp to add in is larger than remains qty which is not allowed.（扫描数量大于订单剩余数量是不允许的！）'
			raiserror (@ErrMsg,16,1)
			return
		end		

		if @IsPlt = 0 BEGIN
			if @EstimatePkgCnt-@PKGid = 0 begin
				if @Qty <> ABS(@RemQty) begin
					set @ErrMsg = 'The qty you attemp to add into the last package is not full fill with remain qty which is not allowed.（最后一个包装数量无法满足订单剩余数量，请检查。）'
					raiserror (@ErrMsg,16,1)
					return
				end
			end
		END

	INSERT INTO [dbo].[TB_FG_PKG_Details]
           ([SRid]
           ,[PKGid]
           ,[LineID]
           ,[PartNum]
           ,[Qty]
		   ,[BoxID]
           ,[AddBy]
           ,[AddTime])
     VALUES
           (@SRid
		   ,@PKGid  
		   ,@LineID
		   ,@PartNum 
		   ,@Qty
		   ,@BoxID 
		   ,@AddBy 
		   ,Getdate())


	if @@ERROR = 0 begin
		Set @LbID = (Select PKGid  from [TB_FG_PKG_Details] where BoxID = @BoxID and SRid = @SRid  )
		set @RemPkgCnt = @EstimatePkgCnt - @PKGid
		if @IsPlt = 0
			begin
				--if not exists (Select * from [dbo].[BAS_FG_BOX] where [FG_PartNum] = @PartNum ) 
				--	begin
				--		set @ErrMsg = 'Carton size information not found.（缺少包装箱尺寸信息！）'
				--		raiserror (@ErrMsg,16,1)
				--		return
				--	end
				--else begin
					Select @GW=0,@NW =0,@Height=0,@Length = 0,@Width =0
					--from [dbo].[BAS_FG_BOX] 
					--where [FG_PartNum] = @PartNum 
				--end

			INSERT INTO [dbo].[TB_FG_SM_Details]
			   ([SRid]
			   ,[lbid]
			   ,[CreateBy]
			   ,[CreateTime]
			   ,[Length]
			   ,[Width]
			   ,[Height]
			   ,[GrossWeight]
			   ,[NetWeight]
			   ,[PrintFlag]
			   ,[ScanFlag]
			   ,[SMType])
			VALUES
			   (@SRid 
			   ,@PKGid
			   ,@AddBy
			   ,Getdate()
			   ,@Length
			   ,@Width 
			   ,@Height
			   ,@GW
			   ,@NW
			   ,0
			   ,0
			   ,@IsPlt)
			end
	end

	SET @FullKit = 0
	set @Rcnt = (Select count(*) from [dbo].[View_FG_SR_Details_Status] where SRid = @SRid AND [Difference] < 0  )
	IF @Rcnt = 0 BEGIN	
			SET @FullKit = 1
			if @RemPkgCnt> 0 begin
					set @ErrMsg = 'There is still remains package to be scanned into but this order is already full kitted.（订单已经满足但仍然有剩余的包装未使用，请重新定义包装数量！）'
					raiserror (@ErrMsg,16,1)
					return
			end		
				
			select @rcnt = (select count(*) from dbo.TB_FG_SM_Details where srid = @SRid and PrintFlag = 0)
			if @rcnt = 0 AND @IsPlt = 1
				begin
					--判断数量全额满足，标签已打印，且为栈板出货模式时（栈板出货模式，包装在选栈板时已经维护包装信息，故没有再作判断），
					--这三个条件全部满足，自动转至下一阶段。				
					exec SP_FG_StartPGI @SRid			
				END		
		END
	else begin
			SET @FullKit = 0
	end
END


--CodeGroup	Code	Chinese_DESC	English_DESC	CodeGroup_Desc
--57	9         	900       	创建订单	SRNotActivated	SR_Status
--58	9         	901       	激活订单	SRActivated	SR_Status
--59	9         	902       	未创建拣货单	MPNotCreated	SR_SP_Status
--60	9         	903       	拣货单创建	MPCreated	SR_SP_Status
--61	9         	904       	拣货中	MPPicking	SR_SP_Status
--62	9         	905       	打印唛头中	PrintShippingMark	SR_SP_Status
--63	9         	906       	打包中	Packing	SR_SP_Status
--64	9         	907       	扣PGI中	PGI InProgress	SR_SP_Status
--65	9         	908       	待装车	TruckNotLoaded	SR_SP_Status
--66	9         	909       	发货中	TruckLoading	SR_SP_Status
--67	9         	910       	已发货	ShippedOut	SR_SP_Status

--200  open
--201  closed
--202  cancel
--203  hold
--204  activated
GO
