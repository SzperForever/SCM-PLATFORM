
CREATE PROCEDURE [dbo].[SP_RTSOutputPerMHs]
	@DateFrom smalldatetime,
	@DateTo smalldatetime,
	@MHname varchar(10)
AS
BEGIN
	SET NOCOUNT ON;
	if @MHname = ''
		begin
			SELECT    ScanDate, RTRIM(CountedName) AS ScannedBy, COUNT(ScanPartNo) AS sumcount
			FROM         dbo.Tb_RTS
			WHERE     (CountedBy <> '999999') and ScanTime between @DateFrom and @DateTo 
			GROUP BY ScanDate, CountedName
			ORDER BY ScanDate, sumcount DESC
		end
	if LEN(@mhname) > 0
		begin
			SELECT    ScanDate, RTRIM(CountedName) AS ScannedBy, COUNT(ScanPartNo) AS sumcount
			FROM         dbo.Tb_RTS
			WHERE     (CountedBy <> '999999') and ScanTime between @DateFrom and @DateTo and CountedName = @MHname 
			GROUP BY ScanDate, CountedName
			ORDER BY ScanDate asc 		
		end
end
GO
