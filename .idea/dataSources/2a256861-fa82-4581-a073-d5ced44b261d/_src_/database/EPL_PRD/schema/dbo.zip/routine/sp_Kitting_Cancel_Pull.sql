

CREATE PROCEDURE [dbo].[sp_Kitting_Cancel_Pull]
	@OrderID nvarchar(13)
AS
BEGIN
	SET NOCOUNT ON;
	Declare @PullSts nchar(10)	
		set @PullSts =( select Stocksts from Tb_Kitting_Order_Header where OrderID = @OrderID and OrderStatus  <> 'CANCEL')

		if @PullSts <> 'NotStarted'
			begin
				raiserror('Invalid Pull Status.This pulll list might be in progress. Cancel failed.',16,1)	
				return
			end
		else begin
			update Tb_Kitting_Order_Header  set OrderStatus  = 'CANCEL' WHERE OrderID = @OrderID 
		end
		
END


GO
