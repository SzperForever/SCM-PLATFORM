-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Tri_BoxID_Check_Insert]
   ON  [dbo].[TB_FG_PKG_Details]
   AFTER insert,update
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	if @@rowcount > 1 return
	
	Declare @BoxID nchar(30),@Errmsg VARCHAR(100)
	select @BoxID = BoxID FROM INSERTED
	if left(ltrim(@BoxID),6) in ('PALLET') AND len(rtrim(ltrim(@BoxID))) <> 10 goto RejectInsert
	if left(ltrim(@BoxID),1) not in ('S','J','B','0','T','R') or len(rtrim(ltrim(@BoxID))) < 7 goto RejectInsert
	if (left(ltrim(@BoxID),1)= '0' and len(rtrim(ltrim(@BoxID))) < 7) goto RejectInsert
	if (left(ltrim(@BoxID),1) = 'S' AND len(rtrim(ltrim(@BoxID)))<> 7 AND LEFT(LTRIM(@BoxID),2) not in ('SJ', 'SS'))
		BEGIN
			RejectInsert:
				set @Errmsg = 'BoxID(SeriaNumber):' + @BoxID + ' is not valid. Please retry.'
				raiserror(@ErrMsg,16,1)
				rollback tran
				return
		END		

END
GO
