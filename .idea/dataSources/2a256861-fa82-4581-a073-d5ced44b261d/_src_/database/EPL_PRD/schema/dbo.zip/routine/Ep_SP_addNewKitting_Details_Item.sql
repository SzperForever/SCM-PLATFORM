CREATE  PROCEDURE [dbo].[Ep_SP_addNewKitting_Details_Item]
		@OrderID varchar(12),
		@PartNo varchar(20),
		@Qty numeric(18, 2),
		@GRN varchar(18),
		@DmdType nchar(15),		
		@AddBy varchar(15)		
AS	
	begin
		Declare @Stocksts nvarchar(20)
		Declare @KittingStatus nvarchar(20)	
		Declare @Stock_ReceivedTime smalldatetime
		Declare @Stock_completeTime smalldatetime
		Declare @Kitting_ReceivedTime smalldatetime
		Declare @Kitting_CompleteTime smalldatetime
		Declare	@CreateTime smalldatetime
		
		select @Stocksts = (Select Stocksts from  dbo.Tb_Kitting_Order_Header where OrderID = @OrderID)
		select @KittingStatus = (Select KittingStatus from  dbo.Tb_Kitting_Order_Header where OrderID = @OrderID)
		select @Stock_ReceivedTime = (Select Stock_ReceivedTime from  dbo.Tb_Kitting_Order_Header where OrderID = @OrderID)		
		select @Kitting_ReceivedTime = (Select Kitting_ReceivedTime from  dbo.Tb_Kitting_Order_Header where OrderID = @OrderID)
		select @CreateTime = (Select CreateTime from  dbo.Tb_Kitting_Order_Header where OrderID = @OrderID)
		
		if rtrim(@DmdType) = 'RAW' begin
			IF @Stocksts = 'NotStarted'
				BEGIN
					UPDATE Tb_Kitting_Order_Header 
					SET 
						Stocksts = 'Completed'
						,Stock_completeTime = GETDATE() 
						,Kitting_ReceivedTime = GETDATE()
						,Stock_LeadTime = (select dbo.f_second_Time(datediff(ss,@Stock_ReceivedTime,GETDATE())))
						,CurrentPlace = 'KIT'
					where OrderID = @OrderID 
				END
		end
		if rtrim(@DmdType) = 'KIT' begin
			--IF @KittingStatus = 'NotStarted'
				--BEGIN
					UPDATE Tb_Kitting_Order_Header 
					SET KittingStatus = 'InProgress'
						,Kitting_CompleteTime = GETDATE() 
						,Kitting_LeadTime =(select dbo.f_second_Time(datediff(ss,@Kitting_ReceivedTime,GETDATE())))
						,PullLeadTime=(select dbo.f_second_Time(datediff(ss,@CreateTime,GETDATE())))						
					where OrderID = @OrderID 
				--END		
		end
		if rtrim(@DmdType) = '' begin		
			raiserror('Invalid Demand Type.',16,1)			
			RETURN
		end
		INSERT INTO [dbo].[Tb_Kitting_Order_Details]
           ([OrderID]
           ,[PartNo]
           ,[Qty]
           ,[GRN]
           ,[DmdType]
           ,[AddTime]
           ,[AddBy])
			VALUES (@OrderID			
					,@PartNo
					,@Qty
					,@GRN
					,@DmdType
					,GETDATE()
					,@AddBy )
					
end
GO
