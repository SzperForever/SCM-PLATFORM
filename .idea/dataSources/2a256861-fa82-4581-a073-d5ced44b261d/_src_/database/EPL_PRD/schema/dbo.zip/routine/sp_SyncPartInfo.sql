-- =============================================
-- Author:		<Hanson_Zhang>
-- Create date: <2012-2-15>
-- Description:	<Synconazition of PartInfo between Epull and SAP,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_SyncPartInfo]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here

	Truncate Table bas_sku
	--delete from Bas_PartInfo where Site = 'CN07'
	insert into bas_sku(
		 [Plant]
		,[Material]
	    ,[MRPCn]
        ,[PGr]
		,[Material_description]
		,[Standard_price]
		,[Matlgroup]
		,[Field10]
		,[per]
		,[Part_Type] 
		,[ABC_Type] 
		,[Min]
        ,[Max]
        ,[Total_OH]
        ,[Total_OO]
		,[AddTime]
		,[AddWho]) 		
		select 
			 [Site]
			,[Part_Number]
			,[MRP_Controller]
			,[Buyer_Code]
			,[Description]
			,[Std Cost]
			,Material_Grp
			,'USD'
			,1
			,[Part_Type]
			,[ABC_Type]
			,[Min]
			,[Max]
			,[Total_OH]
			,[Total_OO]
			,GETDATE()
			,'sys' 
		from [Bas_PartInfo]  
		where Part_Number <> 'NS832819X1-R'
end
GO
