-- =============================================
-- Author:		<Hanson>
-- Create date: <2015-5-15>
-- Description:	<Close SR order,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_FG_SR_Close]
	-- Add the parameters for the stored procedure here
	@SRid int,
	@ActionBy nchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @SRStatus nchar(3),@ErrMsg varchar(200),@OrderStatus nchar(3),@RowCnt int
    -- Insert statements for procedure here

	set @RowCnt = (Select count(*)  from [dbo].[TB_FG_SR_Header] where SRid = @SRid and CreateBy = @ActionBy )
	if @rowcnt = 0 begin
		set @ErrMsg = 'You are not the valid user granted to do so.（非创建者本人禁止关闭此订单。）'
		raiserror (@ErrMsg,16,1)
		return
	end
	set @OrderStatus = (Select SR_OrderStatus  from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
	if @OrderStatus <> '200' begin
		set @ErrMsg = 'Process denied since SR Order status is not open. （无法关闭一个已经取消了的或是关闭了的订单。）'
		raiserror (@ErrMsg,16,1)
		return
	end
	set @SRStatus = (Select SR_SP_Status from [dbo].[TB_FG_SR_Header] WHERE [SRid] = @SRid)
	if @SRStatus <> '911' begin
		set @ErrMsg = 'Process denied since SR still not shipped out. （由于SR订单状态未出车和维护运单信息，不允许关闭。）'
		Update [TB_FG_SR_Header] set AWB = null where   [SRid] = @SRid
		raiserror (@ErrMsg,16,1)
		return
	end

		update [TB_FG_SR_Header]
			--set SR_OrderStatus  = '201',closetime = getdate(),OrderNotes = OrderNotes + '/cancelled by :' + @ActionBy 
			set [SR_SP_Status] = '910',[SR_OrderStatus] = '201' ,closetime = getdate()
			where SRid = @SRid	

END



--CodeGroup	Code	Chinese_DESC	English_DESC	CodeGroup_Desc
--57	9         	900       	创建订单	SRNotActivated	SR_Status
--58	9         	901       	激活订单	SRActivated	SR_Status
--59	9         	902       	未创建拣货单	MPNotCreated	SR_SP_Status
--60	9         	903       	拣货单创建	MPCreated	SR_SP_Status
--61	9         	904       	拣货中	MPPicking	SR_SP_Status
--62	9         	905       	打印唛头中	PrintShippingMark	SR_SP_Status
--63	9         	906       	等待PGI中	PGI NotStarted	SR_SP_Status
--64	9         	907       	扣PGI中	PGI InProgress	SR_SP_Status
--65	9         	908       	待装车	TruckNotLoaded	SR_SP_Status
--66	9         	909       	发货中	TruckLoading	SR_SP_Status
--67	9         	910       	已发货	ShippedOut	SR_SP_Status
--910 维护运单
--200  open
--201  closed
--202  cancel
--203  hold
--204  activated
GO
