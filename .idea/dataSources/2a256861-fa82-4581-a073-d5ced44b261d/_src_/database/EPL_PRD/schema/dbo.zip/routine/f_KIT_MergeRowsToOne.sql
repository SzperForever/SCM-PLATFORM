  CREATE function [dbo].[f_KIT_MergeRowsToOne](@RIPE_PN nchar(40))
returns varchar(8000)
as
begin
  declare @str varchar(8000)
  set @str = ''
  select @str = @str + ',' +  cast(RTRIM(Component) as varchar) from Bas_SAPbom where [Assembly Name] = @RIPE_PN
  set @str = right(@str , len(@str) - 1)
  return(@str)
End
  GO
