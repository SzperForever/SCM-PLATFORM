-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-1-9,>
-- Description:	<Send a batch order list to supplier team,,>
-- =============================================
CREATE PROCEDURE  [dbo].[SP_ALERT_RMA_INV_COMPARE] 

	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
	Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@tableHTML2 nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@Rcnt2 int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)	
			

		
	set @AlertName = 'RMA_INV_COMPARE_Report'	
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	
	
	
	set @Rcnt = (SELECT count(0) FROM   V_RMA_MFG_SAP_vs_EPL   
				  Where   [Mtrl_Grp] IS NULL)
	
	set @Rcnt2 = (SELECT count(0)  FROM   V_RMA_MFG_SAP_vs_EPL   
				  Where  [DiffQty]<> 0 and [Mtrl_Grp] <> 'SCHNEIDER' )
				  
    set @tableHTML2 = ''		
	SET @tableHTML = 
		N'<font color=#FF0000><H1> Dear IA：</H1></font>' +
		N'<font color=#FF0000><H1> The RMA comparison report as follows(SAP vs E-pull) and check all of the variance items, thanks!</H1></font>' +
				N'<font color=#FF0000><H1> </H1></font>' +	
		
		N'<font color=#FF0000><H1>下面是EPULL有库存的差异</H1></font>' +
		
	    --N'<H3>RMA_INV_COMPARE</H3>' +
		N'<table border="1">' +
		N'<tr><th>Mtrl_Grp</th><th>S_PN</th><th>E_PN</th><th>S_QTY</th><th>E_QTY</th><th>DiffQty</th></tr>' +
		CAST ( ( SELECT   td = ISNULL(Mtrl_Grp,0) ,'',		
						  td = ISNULL(S_PN,0),'',
						  td = ISNULL(E_PN,0),'',
						  td =convert(int, S_QTY),'',
						  td =convert(int, E_QTY),'',
						  td =convert(int, DiffQty),''
				  FROM   V_RMA_MFG_SAP_vs_EPL   
				  Where   [Mtrl_Grp] IS NULL
				  ORDER BY Mtrl_Grp,S_PN,E_PN              
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
N'</table>'  
		
set @tableHTML2 =  
		N'<font color=#FF0000><H1> 下面是SAP有库存的差异</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>Mtrl_Grp</th><th>S_PN</th><th>E_PN</th><th>S_QTY</th><th>E_QTY</th><th>DiffQty</th></tr>' +
		CAST ( ( SELECT   td = ISNULL(Mtrl_Grp,0) ,'',		
						  td = ISNULL(S_PN,0),'',
						  td = ISNULL(E_PN,0),'',
						  td =convert(int, S_QTY),'',
						  td =convert(int, E_QTY),'',
						  td =convert(int, DiffQty),''
				  FROM   V_RMA_MFG_SAP_vs_EPL   
				  Where  [DiffQty]<> 0 and [Mtrl_Grp] <> 'SCHNEIDER'
				  ORDER BY Mtrl_Grp,S_PN,E_PN              
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		
		
	   N'<font color=#FF0000>Do not reply to this mail since it is an automatical notification message.</font>';
	if @Rcnt =0 and @Rcnt2 =0  return

	if @Rcnt > 0 and @Rcnt2 = 0 return
		set @tableHTML=@tableHTML
	end	
	if @Rcnt = 0 and @Rcnt2 > 0 begin
		set @tableHTML= @tableHTML2
	end	
	if @Rcnt > 0 and @Rcnt2 > 0  begin
		set @tableHTML=@tableHTML+ @tableHTML2
    end

       EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;
--END
GO
