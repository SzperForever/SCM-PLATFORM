-- =============================================
-- Author:		<Hanson>
-- Create date: <2014-12-4>
-- Description:	<Get Overall Status by kitting pn>
-- Example Cmd: SP_GetOverallStatus_By_KittingPN '2061617$4'
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_GetOverallStatus_By_KittingPN] 
	-- Add the parameters for the stored procedure here
	@KittingPartNum varchar(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	declare @TmpActualQty table
	(	
		ID				int identity(1,1) primary key,
		KittingPartNum	varchar(30) not null,
		ActualQty		float not null,
		PkgCnt			int not null
	)

	insert into @TmpActualQty (KittingPartNum,ActualQty,PkgCnt)
	SELECT DISTINCT KittingPartNum, ISNULL(SUM(Qty), 0) AS ActualQty, ISNULL(COUNT(DISTINCT GRN), 0) AS PkgCnt
	FROM         dbo.View_Kitting_PreparedList AS h with (nolock) 
	WHERE     ((BatchID + KittingPartNum + GRN) IN
							  (SELECT     BatchID + PartNo + GRN AS Expr1
								FROM          dbo.View_Kitting_BatchDetails with (nolock) 
								WHERE      (OrderStatus = 'OPEN')))
	GROUP BY KittingPartNum
	

    -- Insert statements for procedure here
	declare @TmpKittingOverall table
	(	
		ID				int identity(1,1) primary key,
		WorkCell	varchar(30) not null,
		KittingPartNum VARCHAR(30) NOT NULL,
		OrderCnt	INT NOT NULL,
		PkgCnt		INT NOT NULL,
		DemandQty	FLOAT NOT NULL,
		ActualQty	FLOAT NOT NULL,
		KitsRate	VARCHAR(10) NOT NULL,
		DiffQty		FLOAT NOT NULL
	)

	insert into @TmpKittingOverall (WorkCell,KittingPartNum,OrderCnt,PkgCnt,DemandQty,ActualQty,KitsRate,DiffQty)
	
	SELECT     TOP (100) PERCENT a.WorkCell, a.KittingPartNum, COUNT(DISTINCT a.OrderID) AS OrderCnt, ISNULL(b.PkgCnt, 0) AS PkgCnt, 
                      ISNULL(SUM(a.Kits_Qty), 0) AS DemandQty, ISNULL(b.ActualQty, 0) AS ActualQty, CAST(ROUND(ABS(ISNULL(b.ActualQty, 
                      0)) / ISNULL(SUM(a.Kits_Qty), 0), 3) * 100 AS varchar(9)) + '%' AS KitsRate, ISNULL(b.ActualQty, 0) - ISNULL(SUM(a.Kits_Qty), 0) AS DiffQty
	FROM         dbo.View_Kitting_Order_Headers AS a  with (nolock) LEFT OUTER JOIN
						  @TmpActualQty AS b   ON b.KittingPartNum = a.KittingPartNum
	WHERE     (a.OrderStatus = 'OPEN')
	GROUP BY a.WorkCell, a.KittingPartNum, a.[Part Description], b.PkgCnt, b.ActualQty 
	ORDER BY ActualQty DESC

	Select KittingPartNum,WorkCell,OrderCnt,PkgCnt,DemandQty,ActualQty,KitsRate,DiffQty 
	from 	@TmpKittingOverall
	where KittingPartNum = @KittingPartNum 

END
GO
