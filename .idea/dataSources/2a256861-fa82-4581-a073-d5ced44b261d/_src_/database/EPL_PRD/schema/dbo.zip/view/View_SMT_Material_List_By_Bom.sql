CREATE VIEW dbo.View_SMT_Material_List_By_Bom
AS
SELECT     TOP (100) PERCENT c.OrderID, a.Material, a.Number, a.RouteStepText AS Step, a.Feeder, a.Revision, a.MAText, a.CRDCount, c.Sets,
                          (SELECT     COUNT(Material) AS Expr1
                            FROM          dbo.BAS_PPL
                            WHERE      (Number = a.Number) AND (Material = a.Material) AND (RouteStepText <> a.RouteStepText)) AS DifRST_M_Cnt, 
                      c.Sets * a.CRDCount AS NeedQty, ISNULL
                          ((SELECT     SUM(Qty) AS Expr1
                              FROM         dbo.Tb_PreparedList AS h
                              WHERE     (PartNo = a.Material) AND (OrderID = c.OrderID) AND (Model = c.PPLModelName) AND (Step = a.RouteStepText) AND (Feeder = a.Feeder) 
                                                    AND (FlagGroup = 'SMT')), 0) AS Actualqty,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Tb_PreparedList AS g
                            WHERE      (OrderID = c.OrderID) AND (PartNo = a.Material) AND (Feeder = a.Feeder) AND (Step = a.RouteStepText)) AS PkgCount, ISNULL
                          ((SELECT     SUM(Qty) AS Expr1
                              FROM         dbo.Tb_PreparedList AS h
                              WHERE     (PartNo = a.Material) AND (OrderID = c.OrderID) AND (Model = c.PPLModelName) AND (Step = a.RouteStepText) AND (Feeder = a.Feeder) 
                                                    AND (FlagGroup = 'SMT')), 0) - c.Sets * a.CRDCount AS DiffQty
FROM         dbo.BAS_PPL AS a LEFT OUTER JOIN
                      dbo.Tb_Order_Details AS c ON c.PPLModelName = a.Number AND c.BayNum = a.MAText AND c.Rev = a.Revision LEFT OUTER JOIN
                      dbo.Tb_PreparedList AS b ON a.Number = b.Model AND a.Material = b.PartNo AND b.OrderID = c.OrderID
WHERE     (c.OrderStatus = 'Open') AND (c.FlagGroup = 'SMT')
GROUP BY c.OrderID, a.Material, a.Number, a.RouteStepText, a.Feeder, a.Revision, a.MAText, a.CRDCount, c.Sets, c.OrderID, c.PPLModelName
ORDER BY c.OrderID, a.Material, a.Number, Step, a.Feeder, a.Revision, a.MAText, a.CRDCount
GO
