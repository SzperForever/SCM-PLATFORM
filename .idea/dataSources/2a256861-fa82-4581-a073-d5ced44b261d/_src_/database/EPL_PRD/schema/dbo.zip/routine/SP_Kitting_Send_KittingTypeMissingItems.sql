-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-10-28,>
-- Description:	<Send a batch order list to supplier team,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_Send_KittingTypeMissingItems] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
		
	set @AlertName = 'KittingAlertMissKittingType'
    -- Insert statements for procedure here
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	--Steed_gu@jabil.com;qiudi_wang@jabil.com;zhu_jifeng@jabil.com
	set @Rcnt = 0
	set @Rcnt =(Select count(0) from View_Kitting_MissingKittingType)
	
	if @Rcnt = 0 or @@ERROR <> 0 begin
		return
	end
	
	select @Msg = 'To Supplier,' + CHAR(10) +
				  'Please be noticed that below items are missing kitting type. Please maintain them if possible.' 
			 
	
	SET @tableHTML = @Msg +
		N'<H1>Kitting Part List with Missing Kitting Type </H1>' +
		N'<table border="1">' +
		N'<tr><th>KittingPartNum</th><th>KittingType</th><th>IA</th></tr>' +
		CAST ( ( SELECT td = KittingPartNum,       '',
						td = KittingType, '',
						td = IA, ''			
				  from View_Kitting_MissingKittingType with (nolock) 
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		'Do not reply to this mail since it is an automatical notification message.';
    
    EXEC msdb.dbo.sp_send_dbmail 
	--@profile_name ='EpullSqlMail',
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;
END
GO
