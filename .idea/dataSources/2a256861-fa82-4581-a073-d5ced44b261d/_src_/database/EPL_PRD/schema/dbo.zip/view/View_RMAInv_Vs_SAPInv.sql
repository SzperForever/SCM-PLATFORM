CREATE VIEW dbo.View_RMAInv_Vs_SAPInv
AS
SELECT     a.SLoc, a.Material AS SAPPartNo, b.[SAP Part No] AS RMAPartNo, a.[Material description], a.[Matl grp], ISNULL(a.[Stand Price], 0.00) AS Stand_Price, 
                      SUM(ISNULL(a.Unrestricted, 0)) AS SAPqty, COUNT(b.Serialnumber) AS RMAQty, COUNT(b.Serialnumber) - SUM(ISNULL(a.Unrestricted, 0)) 
                      AS VarianceQty, (COUNT(b.Serialnumber) - SUM(ISNULL(a.Unrestricted, 0))) * ISNULL(a.[Stand Price], 0.00) AS VarianceValue
FROM         dbo.tmp_Sap_Inventory AS a FULL OUTER JOIN
                      dbo.tb_RMA_Tracking AS b ON b.[SAP Part No] = a.Material
GROUP BY a.SLoc, a.Material, b.[SAP Part No], a.[Material description], a.[Matl grp], a.[Stand Price]
GO
