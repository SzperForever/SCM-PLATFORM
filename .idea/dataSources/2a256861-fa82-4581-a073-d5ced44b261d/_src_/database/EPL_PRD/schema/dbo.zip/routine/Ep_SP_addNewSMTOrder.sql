
CREATE  PROCEDURE [dbo].[Ep_SP_addNewSMTOrder]
		@OrderID varchar(12),
		@WorkCell varchar(20),
		@Model varchar(100),
		@Side varchar(4),
		@Rev varchar(20),
		--@PartCount int,
		@PullListNo varchar(13),
		@BuildPlanTime SMALLdatetime,
		@CreateBy varchar(50),			
		@Sets varchar(20),
		@Baynum varchar(10),
		@Sloc varchar(4),
		@KTEName varchar(20),
		@Remark varchar(255),
		@Priority varchar(10)
		
AS
	DECLARE @MSG VARCHAR(200)
	if (select Count(pulllistno) from Tb_Order_Details where PullListNo = @PullListNo and PullStatus = 'Open' and model = @model and FlagGroup = 'SMT') >0 
		begin
			SET @MSG = 'SMT PullList：' + @PullListNo + ' is already exsit,insert failed.'
			raiserror(@MSG,16,1)	
		end
	else begin	
	
		DECLARE @dt Varchar(6)
		declare @Rcount int,@Lvrequesttime smalldatetime
		declare @StoreArea varchar(4)
		
		declare @MinLT int
		
		if UPPER(@WorkCell) = 'CISCO' BEGIN
			SET @MinLT = 16
			END
		ELSE BEGIN
			SET @MinLT = 12
		END
		
		IF upper(RIGHT(rtrim(@workcell),3))= '-AI' AND upper(rtrim(@workcell)) <>'SCHNEIDER-AI' BEGIN
			SELECT @dt=dt FROM v_GetDate	
			
			select @Rcount = (select COUNT(*) 
							from Tb_Order_Details 
							where (upper(RIGHT(rtrim(workcell),3))= '-AI') and FlagGroup = 'SMT' and left(PullListNo,8) = left(@PullListNo,8) and OrderStatus = 'Open')
							--where (WorkCell = 'NETAPP' or upper(RIGHT(rtrim(workcell),3))= '-AI') and model = @Model  and FlagGroup = 'SMT' and left(PullListNo,8) = left(@PullListNo,8) and OrderStatus = 'Open')
							
			
			if @Rcount = 0 
				begin 
					set @orderid = (SELECT @dt+RIGHT(10001+ISNULL(RIGHT(MAX(orderid),4),0),4) --这里比MI去掉2位是为了防止和MI料单混淆，怕取消或是关闭错误。
									FROM tb_order_details WITH(XLOCK,PAGLOCK) 
									WHERE orderid like @dt+'%' and FlagGroup = 'SMT' AND (upper(RIGHT(rtrim(workcell),3))= '-AI') AND upper(rtrim(workcell)) <>'SCHNEIDER-AI')
					--raiserror(@dt,16,1)	
				end
			else begin
					set @orderid =(select distinct orderid from Tb_Order_Details where WORKCELL = @WORKCELL and FlagGroup = 'SMT' and left(PullListNo,8) = left(@PullListNo,8) and OrderStatus = 'Open')
					--set @orderid =(select distinct orderid from Tb_Order_Details where WORKCELL = @WORKCELL AND model = @Model and FlagGroup = 'SMT' and left(PullListNo,8) = left(@PullListNo,8) and OrderStatus = 'Open')
				end
			end
		
		set @StoreArea = substring(@PullListNo,9,4)
		
		if @StoreArea = '0100' or @StoreArea = '0300' or @StoreArea = '0600' or @StoreArea = '0800' begin
			INSERT INTO [dbo].[Tb_Order_Details] 
				([OrderID]
				,[OrderType]
				,[OrderStatus]
				,[WorkCell]
				,[Model]
				,[Side]
				,[Rev]
				,[BayNum]
				,[StoreArea]
				,[PullListNo]
				,[PullStatus]
				,[PartAmount]
				,[Sets]
				,[BuildPlanTime]
				,[Sloc]
				,[CreateBy]
				,[CreateTime]
				,[StockSts]
				,[LVHMrequestTime]
				,[LVHMsts]
				,[KTE]
				,[OrderNotes] 
				,[FlagGroup]
				,[CurrentPlace]
				,[Priority]
				,[ConditionalFormat]
				,[AP_Flag]
				,[KTEName])  
			VALUES (@orderid			
				--dbo.f_NextBH(@Model,@Batch)--自定义函数，相同MODEL,相同套数,相同BATCH用同一个orderID.
				,'AutoPull'
				,'Open'
				,@WorkCell
				,@Model
				,@Side
				,@rev
				,@BayNum
				,@StoreArea
				,@PullListNo
				,'Open'
				,dbo.F_GetSMTPartCount(@Model)--自定义函数，用于获取该MODEL下的物料数量
				,@Sets
				,@BuildPlanTime
				,@Sloc
				,@CreateBy
				,GETDATE()
				,'NotStarted'
				,DATEADD(hh,-@MinLT ,@buildplantime)
				,'NotReceived'
				,'N'
				,@Remark
				,'SMT'
				,'StockRoom'
				,@Priority
				,'NotStarted'
				,'1'
				,@KTEName)	
			end
		else if @StoreArea = '0500' and UPPER(@WorkCell) = 'SCHNEIDER' begin
			INSERT INTO [dbo].[Tb_Order_Details] 
				([OrderID]
				,[OrderType]
				,[OrderStatus]
				,[WorkCell]
				,[Model]
				,[Side]
				,[Rev]
				,[BayNum]
				,[StoreArea]
				,[PullListNo]
				,[PullStatus]
				,[PartAmount]
				,[Sets]
				,[BuildPlanTime]
				,[Sloc]
				,[CreateBy]
				,[CreateTime]
				,[StockSts]
				,[LVHMrequestTime]
				,[LVHMsts]
				,[KTE]
				,[OrderNotes]
				,[FlagGroup]
				,[CurrentPlace]
				,[Priority]
				,[ConditionalFormat]
				,[AP_Flag]
				,[KTEName])  
			VALUES (@orderid			
				,'AutoPull'
				,'Open'
				,@WorkCell
				,@Model
				,@Side
				,@rev
				,@BayNum
				,@StoreArea
				,@PullListNo
				,'Open'
				,dbo.F_GetSMTPartCount(@Model)--自定义函数，用于获取该MODEL下的物料数量
				,@Sets
				,@BuildPlanTime
				,@Sloc
				,@CreateBy
				,GETDATE()
				,'NotStarted'
				,DATEADD(hh,-10 ,@buildplantime)
				,'NotReceived'
				,'N'
				,@Remark
				,'SMT'
				,'StockRoom'
				,@Priority
				,'NotStarted'
				,'1'
				,@KTEName)	
			end

		else if @StoreArea = '0500' and UPPER(@WorkCell) <> 'SCHNEIDER'  begin
			INSERT INTO [dbo].[Tb_Order_Details] 
				([OrderID]
				,[OrderType]
				,[OrderStatus]
				,[WorkCell]
				,[Model]
				,[Side]
				,[Rev]
				,[BayNum]
				,[StoreArea]
				,[PullListNo]
				,[PullStatus]
				,[PartAmount]
				,[Sets]
				,[BuildPlanTime]
				,[Sloc]
				,[CreateBy]
				,[CreateTime]
				,[StockSts]
				,[LVHMrequestTime]
				,[LVHMsts]
				,[KTE]
				,[OrderNotes]
				,[FlagGroup]
				,[CurrentPlace]
				,[Priority]
				,[ConditionalFormat]
				,[AP_Flag]
				,[KTEName])  
			VALUES (@orderid			
				,'AutoPull'
				,'Open'
				,@WorkCell
				,@Model
				,@Side
				,@rev
				,@BayNum
				,@StoreArea
				,@PullListNo
				,'Open'
				,dbo.F_GetSMTPartCount(@Model)--自定义函数，用于获取该MODEL下的物料数量
				,@Sets
				,@BuildPlanTime
				,@Sloc
				,@CreateBy
				,GETDATE()
				,'NotStarted'
				,DATEADD(hh,-6 ,@buildplantime)
				,'NotReceived'
				,'N'
				,@Remark
				,'SMT'
				,'StockRoom'
				,@Priority
				,'NotStarted'
				,'1'
				,@KTEName)	
			end			
		--else if @StoreArea = '0300' or @StoreArea = '0600' begin 
		--		INSERT INTO [EpullDB].[dbo].[Tb_Order_Details] 
		--		([OrderID]
		--		,[OrderType]
		--		,[OrderStatus]
		--		,[WorkCell]
		--		,[Model]
		--		,[Side]
		--		,[Rev]
		--		,[BayNum]
		--		,[StoreArea]
		--		,[PullListNo]
		--		,[PullStatus]
		--		,[PartAmount]
		--		,[Sets]
		--		,[BuildPlanTime]
		--		,[Sloc]
		--		,[CreateBy]
		--		,[CreateTime]
		--		,[StockSts]
		--		,[LVHMrequestTime]
		--		,[LVHMsts]
		--		,[KTE]
		--		,[Remark]
		--		,[FlagGroup]
		--		,[CurrentPlace]
		--		,[Priority]
		--		,[ConditionalFormat]
		--		,[AP_Flag])  
		--	VALUES (@orderid			
		--		--dbo.f_NextBH(@Model,@Batch)--自定义函数，相同MODEL,相同套数,相同BATCH用同一个orderID.
		--		,'TransferOrder'
		--		,'Open'
		--		,@WorkCell
		--		,@Model
		--		,@Side
		--		,@rev
		--		,@BayNum
		--		,@StoreArea
		--		,@PullListNo
		--		,'Open'
		--		,dbo.F_GetSMTPartCount(@Model)--自定义函数，用于获取该MODEL下的物料数量
		--		,@Sets
		--		,@BuildPlanTime
		--		,@Sloc
		--		,@CreateBy
		--		,GETDATE()
		--		,'NotStarted'
		--		,DATEADD(hh,-6,@buildplantime)
		--		,'NotReceived'
		--		,'Y'
		--		,@Remark
		--		,'SMT'
		--		,'3PL'
		--		,@Priority
		--		,'NotStarted'
		--		,'1')		
		--	end 
		else begin
			raiserror('Invaild StoreArea please double check!',16,1)	
		end				
end
GO
