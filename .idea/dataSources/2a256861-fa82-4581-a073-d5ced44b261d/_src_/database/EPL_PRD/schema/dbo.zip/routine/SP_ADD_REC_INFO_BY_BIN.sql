CREATE  PROCEDURE [dbo].[SP_ADD_REC_INFO_BY_BIN]
	@Loc_ID varchar(12) = 'New',
	@Info nchar(200),
	@AddBy nchar(10),
	@Remark varchar(50),
	@ReturnID varchar(12) OUTPUT
           
AS
begin
	SET NOCOUNT ON;	
	DECLARE @dt CHAR(6)
	
	-- Add the T-SQL statements to compute the return value here
	
	SELECT @dt=dt FROM v_GetDate	
	if @Loc_ID = 'New'
		BEGIN
			set @Loc_ID = (SELECT 'R' + @dt+RIGHT(100001+ISNULL(RIGHT(MAX(LocID),5),0),5) 
					FROM [TB_REC_PRE_LOG] WITH(XLOCK,PAGLOCK) 
					WHERE LocID like '%R' + @dt+'%')
			set @ReturnID = @Loc_ID
		END
		
					
	INSERT INTO [EPL_PRD].[dbo].[TB_REC_PRE_LOG]
           (LocID
           ,[Info]
           ,[AddBy]
           ,[Remark])
     VALUES(@Loc_ID,@info,@AddBy,@Remark)
     
end
GO
