CREATE VIEW dbo.View_FG_SM_Details
AS
SELECT        h.SRid, h.SRno, RTRIM(h.SRno) + '-' + RTRIM(LTRIM(STR(d.Lbid))) AS Lbid, RTRIM(h.ForwarderName) AS Forwarder, d.SMtype, (CASE WHEN d .length = 0 OR
                         d .width = 0 OR
                         d .height = 0 OR
                         d .GrossWeight = 0 OR
                         d .NetWeight = 0 THEN 0 ELSE 1 END) AS HasSizeInfo, d.Length, d.Width, d.Height, d.GrossWeight, d.NetWeight, d.ScanFlag, d.ScanBy, d.ScanTime, 
                         (CASE WHEN d .PrintFlag = 1 THEN 'Y' ELSE 'N' END) AS PrintFlag, d.PrintTime, u.UserName AS CreateBy, d.CreateTime, h.ShipToAddress, d.Lbid AS Line_id, 
                         COUNT(p.BoxID) AS PkgCnt, h.EstimatePkgCnt, d.Lbid AS Idx, h.CreateBy AS Planner, u.Contacts, h.Project
FROM            dbo.TB_FG_SM_Details AS d LEFT OUTER JOIN
                         dbo.TB_FG_PKG_Details AS p ON d.Lbid = p.PKGid AND d.SRid = p.SRid LEFT OUTER JOIN
                         dbo.View_FG_SR_Headers AS h ON d.SRid = h.SRid INNER JOIN
                         dbo.View_Users AS u ON d.CreateBy = u.UserID
GROUP BY h.SRid, h.SRno, RTRIM(h.SRno) + '-' + RTRIM(LTRIM(STR(d.Lbid))), RTRIM(h.ForwarderName), d.SMtype, d.Length, d.Width, d.Height, d.GrossWeight, d.NetWeight, 
                         d.ScanFlag, d.ScanBy, d.ScanTime, (CASE WHEN d .PrintFlag = 1 THEN 'Y' ELSE 'N' END), d.PrintTime, u.UserName, d.CreateTime, h.ShipToAddress, d.Lbid, 
                         h.EstimatePkgCnt, h.CreateBy, u.Contacts, h.Project
GO
