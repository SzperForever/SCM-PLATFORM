
create FUNCTION [dbo].[f_Kitting_GetActualQty](@KittingPartNum varchar(30))
RETURNS float
AS
BEGIN
    RETURN(
        Select ActualQty from View_Kitting_OverallStatus
        where [KittingPartNum] = @KittingPartNum)
END

GO
