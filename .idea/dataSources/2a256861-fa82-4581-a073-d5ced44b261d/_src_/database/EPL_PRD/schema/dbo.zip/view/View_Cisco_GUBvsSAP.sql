
CREATE VIEW [dbo].[View_Cisco_GUBvsSAP]
AS
SELECT     TOP (100) PERCENT b.Material, b.[Stand Price], SUM(b.[Unrestr# cnsgt]) AS SAPtotalQty, SUM(a.[OnHand Qty]) AS GHubTotalQty, 
                      SUM(b.[Unrestr# cnsgt]) - SUM(a.[OnHand Qty]) AS TotalVariance, (SUM(b.[Unrestr# cnsgt]) - SUM(a.[OnHand Qty])) 
                      * b.[Stand Price] AS TotalVairanceValue,
                          (SELECT     SUM(Unrestricted) + SUM([Unrestr# cnsgt]) AS Expr1
                            FROM          dbo.Z_SAP_INV AS c
                            WHERE      (Material = b.Material) AND (SLoc = '01SH' OR
                                                   SLoc = '01CC')) AS SAP_01SH,
                          (SELECT     SUM(AvlQty) AS Expr1
                            FROM          dbo.Z_Gub_Inv AS d
                            WHERE      (SKU = b.Material)) AS GhubAvailableQty,
                          (SELECT     SUM(Unrestricted) + SUM([Unrestr# cnsgt]) AS Expr1
                            FROM          dbo.Z_SAP_INV AS c
                            WHERE      (Material = b.Material) AND (SLoc = '01SH' OR
                                                   SLoc = '01CC')) -
                          (SELECT     SUM(AvlQty) AS Expr1
                            FROM          dbo.Z_Gub_Inv AS d
                            WHERE      (SKU = b.Material)) AS Vairance01SH, ISNULL
                          ((SELECT     SUM(Unrestricted) + SUM([Unrestr# cnsgt]) AS Expr1
                              FROM         dbo.Z_SAP_INV AS g
                              WHERE     (Material = b.Material) AND (SLoc = '01TR')), 0) AS SAP_01TR,
                          (SELECT     SUM(AllocQty) AS Expr1
                            FROM          dbo.Z_Gub_Inv AS h
                            WHERE      (SKU = b.Material)) AS GHubAllocatedQty, ISNULL
                          ((SELECT     SUM(Unrestricted) + SUM([Unrestr# cnsgt]) AS Expr1
                              FROM         dbo.Z_SAP_INV AS g
                              WHERE     (Material = b.Material) AND (SLoc = '01TR')), 0) - ISNULL
                          ((SELECT     SUM(AllocQty) AS Expr1
                              FROM         dbo.Z_Gub_Inv AS h
                              WHERE     (SKU = b.Material)), 0) AS Variance01TRQty, ISNULL
                          ((SELECT     SUM(Unrestricted) + SUM([Unrestr# cnsgt]) AS Expr1
                              FROM         dbo.Z_SAP_INV AS e
                              WHERE     (Material = b.Material) AND (SLoc = '01CP' OR
                                                    SLoc = '01HP' OR
                                                    SLoc = '01MP')), 0) AS SAPBlockQty, ISNULL
                          ((SELECT     SUM(OnHldQty) AS Expr1
                              FROM         dbo.Z_Gub_Inv AS f
                              WHERE     (SKU = b.Material)), 0) AS GhubHoldQty, ISNULL
                          ((SELECT     SUM(Unrestricted) + SUM([Unrestr# cnsgt]) AS Expr1
                              FROM         dbo.Z_SAP_INV AS e
                              WHERE     (Material = b.Material) AND (SLoc = '01CP' OR
                                                    SLoc = '01HP' OR
                                                    SLoc = '01MP')), 0) - ISNULL
                          ((SELECT     SUM(OnHldQty) AS Expr1
                              FROM         dbo.Z_Gub_Inv AS f
                              WHERE     (SKU = b.Material)), 0) AS VairanceBlockQty
FROM         (SELECT     SKU, SUM(AvlQty) AS [Available Qty], SUM(OnHndQty) AS [OnHand Qty], SUM(AllocQty) AS [Allocated Qty], SUM(PickQty) AS [Picked Qty], 
                                              SUM(OnHldQty) AS [OnHold Qty], SUM(InTrstQty) AS [Intransit Qty]
                       FROM          dbo.Z_Gub_Inv
                       GROUP BY SKU) AS a INNER JOIN
                          (SELECT     Material, [Stand Price], SUM(Unrestricted) AS Unrestricted, SUM([Unrestr# cnsgt]) AS [Unrestr# cnsgt], SUM([Stock in tfr]) AS [Stock in tfr], 
                                                   SUM([In qual# insp#]) AS [In qual# insp#], SUM([Cnsgt qual# insp#]) AS [Cnsgt qual# insp#], SUM(Blocked) AS Blocked, 
                                                   SUM([Blocked cnsgt stk]) AS [Blocked cnsgt stk]
                            FROM          dbo.Z_SAP_INV
                            GROUP BY Material, [Stand Price]) AS b ON b.Material = a.SKU
GROUP BY b.Material, b.[Stand Price]
ORDER BY b.Material

GO
