-- =============================================
-- Author:		<Hanson>
-- Create date: <2012-04-12>
-- Description:	<Update SAPPartNo once NewAssembly updated.>
-- =============================================
CREATE TRIGGER [dbo].[Tri_Update]
   ON  dbo.tb_RMA_Tracking
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		declare @Serialnumber nvarchar(100),@RMAno nvarchar(11),@newassembly nvarchar(30),@SAPpartNo nvarchar(25)
		DECLARE @SubSapPartNo nvarchar(20),@ReplacedSN nvarchar(100),@ID Decimal(18,0),@Status nvarchar(10)
		
	if @@ROWCOUNT = 1 begin
		set @Status =(select [Status] From Inserted)
		set @Serialnumber = (select Serialnumber from inserted)
		set @RMAno =(select [RMA Number] from inserted)
		set @newassembly =(select newassembly from inserted)
		set @SAPpartNo = (select [SAP Part No] from inserted)
		
		if update ([newassembly])
			begin						
				update tb_RMA_Tracking
				set [SAP Part No] = rtrim(newassembly) + right(rtrim([SAP Part No]),len(rtrim([SAP Part No])) - len(rtrim(newassembly)))
				where Serialnumber  = @Serialnumber  AND [RMA Number]  = @RMANO 
				--WHERE ID=@ID
			end
		if update([Serialnumber])
				begin
					update tb_RMA_Tracking
					set ReplacedSN =  @Serialnumber,Remark='Planner Updated SN. Go see ReplacedSN to find the orignal SN.' 
					where Serialnumber  = @Serialnumber
				end			
		--if update ([Status])
		--	if @Status ='Closed' or @Status ='Cancel' BEGIN	
		--			insert into EpullDB_History.dbo.tb_RMA_Tracking
		--			([Status]
		--			,[Progress]
		--			,[Site From]
		--			,[MRB Number]
		--			,[Family]
		--			,[Serialnumber]
		--			,[RMA Number]
		--			,[SAP Part No]
		--			,[Assembly]
		--			,[NewAssembly]
		--			,[GRN]
		--			,[ItemOption]
		--			,[Rework Category]
		--			,[Failure Category]
		--			,[Failure]
		--			,[MRBOption]
		--			,[AddTime]
		--			,[AddWho]
		--			,[EditTime]
		--			,[EditWho]
		--			,[DateReceived]
		--			,[ReceivedBy]
		--			,[MFGReceivedDate]
		--			,[MFGReceivedBy]
		--			,[Rework Date]
		--			,[Reworked By]
		--			,[IAConfirmedBy]
		--			,[IAConfirmedTime]
		--			,[IAConfirmedResult]
		--			,[MRBReceivedDate]
		--			,[MRBReceivedBy]
		--			,[MRBedDate]
		--			,[MRBedBy]
		--			,[ShippingReceivedDate]
		--			,[ShippingReceivedBy]
		--			,[DateShipped]
		--			,[ShippedBy]
		--			,[ClosedTime]
		--			,[ClosedBy]
		--			,[CancelTime]
		--			,[CancelBy]
		--			,[Flag]
		--			,[Remark]
		--			,[LogSAP]
		--			,[HAWB]
		--			,[CurrentArea]
		--			,[WorkCell]
		--			,[ReplacedSN]
		--			,[SNNullFlag]
		--			,[Qty]
		--			,[BoxID] )
		--			select [Status]
		--				,[Progress]
		--				,[Site From]
		--				,[MRB Number]
		--				,[Family]
		--				,[Serialnumber]
		--				,[RMA Number]
		--				,[SAP Part No]
		--				,[Assembly]
		--				,[NewAssembly]
		--				,[GRN]
		--				,[ItemOption]
		--				,[Rework Category]
		--				,[Failure Category]
		--				,[Failure]
		--				,[MRBOption]
		--				,[AddTime]
		--				,[AddWho]
		--				,[EditTime]
		--				,[EditWho]
		--				,[DateReceived]
		--				,[ReceivedBy]
		--				,[MFGReceivedDate]
		--				,[MFGReceivedBy]
		--				,[Rework Date]
		--				,[Reworked By]
		--				,[IAConfirmedBy]
		--				,[IAConfirmedTime]
		--				,[IAConfirmedResult]
		--				,[MRBReceivedDate]
		--				,[MRBReceivedBy]
		--				,[MRBedDate]
		--				,[MRBedBy]
		--				,[ShippingReceivedDate]
		--				,[ShippingReceivedBy]
		--				,[DateShipped]
		--				,[ShippedBy]
		--				,[ClosedTime]
		--				,[ClosedBy]
		--				,[CancelTime]
		--				,[CancelBy]
		--				,[Flag]
		--				,[Remark]
		--				,[LogSAP]
		--				,[HAWB]
		--				,[CurrentArea]
		--				,[WorkCell]
		--				,[ReplacedSN]
		--				,[SNNullFlag]
		--				,[Qty]
		--				,[BoxID] 
		--		from tb_RMA_Tracking 
		--		where Serialnumber  = @Serialnumber
					
		--		Delete from tb_rma_tracking
		--		where Serialnumber  = @Serialnumber
		--	end
		end
END
GO
