-- =============================================
-- Author:		HANSON
-- Create date: 2014-11-4
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SP_Alert_RTS_IA_AgingOver24hrs

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   

 Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@Msg nvarchar(300)
			,@Rcnt int
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
		
	set @AlertName = 'RTSAgingSlocOver24hrsUnclosed'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	set @Rcnt = 0
	set @Rcnt =(select count(DISTINCT a.rtsno)from Tb_RTS as a join Tb_Order_Details as b on a.rtsno = b.orderid 
						where datediff(hour,(a.ScanTime),getdate()) > 24 and b.OrderStatus = 'Open' and b.CurrentPlace ='IA')
	if @Rcnt > 0
	
	if @Rcnt = 0 or @@ERROR <> 0 begin
		return
	end

	SET @tableHTML =
		N'<H1>Aging Sloc Alarming Service(Waiting For IA close) </H1>' +
		N'<table border="1">' +
		N'<tr><th>WorkCell</th><th>OrderID</th><th>RTStime</th><th>Sloc</th><th>Model</th><th>Sets</th><th>BAYNUM</th><th>SendLineTime</th>' +
		N'<th>BuildPlanTime</th><th>CreateBy</th><th>AgingReason</th></tr>' +
		CAST ( ( SELECT td = b.WorkCell,       '',
						td = a.RTSNO, '',
						td = max(a.ScanTime), '',
						td = b.Sloc, '',
						td = b.Model, '',
						td = b.Sets, '',
						td = b.BayNum , '',
						td = b.SendLineTime, '',
						td = b.BuildPlanTime, '',
						td = b.CreateBy, '',
                                                                                                td = b.AgingReason,''
				  from Tb_RTS as a join Tb_Order_Details as b on a.rtsno = b.orderid 
					where datediff(hour,(a.ScanTime),getdate()) > 24 and b.OrderStatus = 'Open' and b.CurrentPlace ='IA'
					group by b.WorkCell,a.RTSNO,b.Sloc,b.Model,b.Sets,b.BAYNUM,b.SendLineTime,b.BuildPlanTime,b.CreateBy,b.AgingReason          
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' +    
		'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';

	EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;


END
GO
