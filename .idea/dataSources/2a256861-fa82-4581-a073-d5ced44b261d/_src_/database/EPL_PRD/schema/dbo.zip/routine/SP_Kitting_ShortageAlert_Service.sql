-- =============================================
-- Author:		Hanson Zhang
-- Create date: <2014-10-30>
-- Description:	<Sync rawparts inventory data to compare with final inventory data thus can make a shortage alert comeout,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Kitting_ShortageAlert_Service]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Insert statements for procedure here
    --Declare @AfterDiffQty float
    
		truncate table tb_kitting_rawpart_inv_compare
		
	INSERT INTO [dbo].[Tb_Kitting_RawPart_Inv_Compare]
           ([RawPartNum]
           ,[Qty Per]
           ,RawPartDemand_Before
           ,RawPartsDiffQty_Before
           ,RawPartInvTotal_Before
           ,[AddTime]
           ,[UpdateTime])
           
		SELECT [RawPartNum]
			  ,[Qty Per]
			  ,Shortage 
			  ,DiffQty 
			  ,Inv_Total 
			  ,GETDATE()
			  ,null
		  FROM [dbo].[View_Kitting_RawPart_Inv] with (nolock) 
		  where DiffQty < 0
		  
		  
		
			  
END
GO
