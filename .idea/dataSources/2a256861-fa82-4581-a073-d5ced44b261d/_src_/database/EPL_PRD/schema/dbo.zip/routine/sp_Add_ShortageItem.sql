-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2012-2-28>
-- Description:	<Add Shortage Item>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Add_ShortageItem]
	-- Add the parameters for the stored procedure here
	@OrderID nvarchar(12),
	@Side nvarchar(4),
	@PartNum nvarchar(20),
	@Qty float,
	@ReasonText varchar(200),
	@AddWho nvarchar(10),
	@HostName varchar(10),
	@Remark nvarchar(100),
	@Owner 	varchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[TB_ShortageList]
			   ([OrderID]
			   ,[Side]
			   ,[PartNum]
			   ,[Qty]
			   ,[ReasonText]
			   ,[ItemStatus]
			   ,[AddWho]
			   ,[AddTime]
			   ,[HostName]
			   ,[Remark]
			   ,[Owner])
	VALUES(@OrderID
			,@Side
			,@PartNum
			,@Qty
			,@ReasonText
			,'Open'
			,@AddWho
			,GETDATE()
			,@HostName
			,@Remark
			,@Owner)	
END
GO
