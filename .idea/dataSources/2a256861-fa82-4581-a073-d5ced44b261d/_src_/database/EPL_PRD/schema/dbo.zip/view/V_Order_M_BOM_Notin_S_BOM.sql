CREATE VIEW dbo.V_Order_M_BOM_Notin_S_BOM
AS
SELECT     a.OrderID, a.WorkCell, a.PPLModelName AS MachineBOM, b.Model AS SAPBOM, a.Rev, a.BayNum, a.CurrentPlace, a.fsPartNum, a.pkgInfoTapeWidth, 
                      a.CreateBy
FROM         dbo.V_Order_MachineBOM AS a LEFT OUTER JOIN
                      dbo.V_Order_SAPBOM AS b ON a.OrderID = b.OrderID AND a.fsPartNum = b.Component
WHERE     (b.Component IS NULL)
GO
