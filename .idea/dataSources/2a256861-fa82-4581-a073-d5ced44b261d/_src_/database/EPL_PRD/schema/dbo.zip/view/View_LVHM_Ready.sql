CREATE VIEW dbo.View_LVHM_Ready
AS
SELECT     WorkCell, COUNT(DISTINCT Sloc) AS Ready
FROM         dbo.Tb_Order_Details
WHERE     (OrderStatus = 'Open') AND (BuildPlanTime < GETDATE()) AND (CurrentPlace <> 'IA') AND (CurrentPlace <> 'RTS') AND (CurrentPlace <> 'Online') AND 
                      (LVHMsts <> 'NotReceived') AND (LVHMsts <> 'Received')
GROUP BY WorkCell
GO
