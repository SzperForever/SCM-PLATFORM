-- =============================================
-- Author:		DAILS
-- Create date: 2018-04-18
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_SAP_VA_GRN_Dropped material report]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	


   Declare  @ProfileName nchar(20)
			,@RecAddresslist nvarchar(500)
			,@CopyAddressList nvarchar(500)
			,@BlindCopyList nvarchar(500)
			,@tableHTML nvarchar(max)
			,@tableHTML2 nvarchar(max)
			,@tableHTML3 nvarchar(max)		
			,@Msg nvarchar(300)
			,@Rcnt int
			,@Rcnt2 int
			
			,@MailSubj nvarchar(200)
			,@AlertName nvarchar(100)
			
	set @AlertName = 'Dropped material report'
	set @RecAddressList = (Select recipients  from Cfg_DBmail where AlertName = @AlertName) 
	set @CopyAddressList= (Select CopyList  from Cfg_DBmail where AlertName = @AlertName) 
	set @ProfileName = (select profile_name from Cfg_DBmail where AlertName =@AlertName)
	set @MailSubj = (select Subject  from Cfg_DBmail where AlertName = @AlertName)
	set @BlindCopyList = (select Blind_recipients   from Cfg_DBmail where AlertName = @AlertName)
	
	
	set @Rcnt = (SELECT count(0)
										FROM[SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
										WHERE [Active]='1' and [SLoc]='n001')
	
	set @Rcnt2 = (SELECT count(0)
										FROM[SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
										WHERE [Active]='1' and [SLoc]='n001')
    set @tableHTML2 = ''
	SET @tableHTML =
	
		N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
     	--N'<font color=#FF0000><H1> [MaterialGroup</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[MaterialGroup]</th><th>GRN_QTY</th></tr>' +
		CAST ( (SELECT 
                       td =  [MaterialGroup]  ,'',    
                       td =  convert(int,COUNT(grn)) ,''
  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1' and [SLoc]='n001'
  group by [MaterialGroup]
  order by [MaterialGroup]
				  FOR XML PATH('tr'), TYPE 
		        ) AS NVARCHAR(MAX) ) +
N'</table>'


	SET @tableHTML2 =

		N'<a href="http://shasmeiis01:8001">GRN Tracebility System</a>' +
		N'<font color=#FF0000><H1>IA: 下面是每天生产产生的脱离料盘的的物料,请速速联系工程师解决，避免停产。谢谢</H1></font>' +
		N'<table border="1">' +
		N'<tr><th>[SLoc]</th><th>[MaterialGroup]</th><th>[Material]</th><th>GRN</th><th>G_QTY</th><th>[CreatedDate]</th><th>Aging_DAY</th></tr>' +
		
	CAST ( (	SELECT 
		  td = [SLoc],'',
		  td = [MaterialGroup],'',		  
          td = [Material],'',
          td = [GRN],'',
          td = convert(int,[Quantity]) ,'',
          td = [CreatedDate],'',	
          td = Aging_DAY,''
		
FROM(
SELECT [Plant]
      ,[SLoc]
      ,[Material]
      ,[MaterialGroup]      
      ,[GRN]
      ,[Quantity]
      ,[UnitPrice]
      ,[UnitPrice]*[Quantity] AS TotalPrice
      ,[CreatedDate] 
      ,DATEDIFF(DAY,[CreatedDate],GETDATE()) Aging_DAY 
  FROM [SHASMESQL01].[Warehouse].[dbo].[WH_GRNTracebility]
  WHERE [Active]='1' and [SLoc]='n001'
           )AS A
		
				FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>'+
    
		'Please do not reply to this email.This is a system generated email and the email account is not actively monitored.If you have any questions about this data please contact epull administrator.';
 if @Rcnt =0 and @Rcnt2 =0  return

	if @Rcnt > 0 and @Rcnt2 = 0 return
		set @tableHTML=@tableHTML
	end	
	if @Rcnt = 0 and @Rcnt2 > 0 begin
		set @tableHTML= @tableHTML2
	end	
	if @Rcnt > 0 and @Rcnt2 > 0  begin
		set @tableHTML=@tableHTML+ @tableHTML2
	--end
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,	
	@recipients = @RecAddressList,
	@copy_recipients=@CopyAddressList,
	@blind_copy_recipients = @blindcopylist,
	@subject = @MailSubj,
	@body = @tableHTML,
    @body_format = 'HTML' ;

END

GO
