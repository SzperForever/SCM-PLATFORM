CREATE VIEW dbo.View_SMhrsOutput
AS
SELECT     COUNT(MOVEMENT) AS sumcount, '06:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a 
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '05:00:00:000' AND '06:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '07:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '06:00:00:000' AND '07:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '08:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '07:00:00:000' AND '08:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '09:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '08:00:00:000' AND '09:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '10:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '09:00:00:000' AND '10:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '11:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '10:00:00:000' AND '11:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '12:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '11:00:00:000' AND '12:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '13:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '12:00:00:000' AND '13:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '14:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '13:00:00:000' AND '14:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '15:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '14:00:00:000' AND '15:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '16:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '15:00:00:000' AND '16:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '17:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '16:00:00:000' AND '17:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '18:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '17:00:00:000' AND '18:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '19:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '18:00:00:000' AND '19:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '20:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '19:00:00:000' AND '20:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '21:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '20:00:00:000' AND '21:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '22:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '21:00:00:000' AND '22:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '23:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '22:00:00:000' AND '23:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '0:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '23:00:00:000' AND '24:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '01:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '00:00:00:000' AND '01:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '02:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '01:00:00:000' AND '02:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '03:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '03:00:00:000' AND '04:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '04:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '04:00:00:000' AND '05:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)UNION
SELECT     COUNT(MOVEMENT) AS sumcount, '05:00' AS times, CONVERT(date, TransactionTime, 120) AS dates
FROM         dbo.Sup_Transaction a
WHERE     CONVERT(varchar(12), TransactionTime, 114) BETWEEN '05:00:00:000' AND '06:00:00:000'
GROUP BY CONVERT(date, TransactionTime, 120)
GO
