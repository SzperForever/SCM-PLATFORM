CREATE VIEW dbo.View_SMOutput311
AS
SELECT     TOP (100) PERCENT RegDate, COUNT(Movement) AS StoreOut
FROM         dbo.Sup_Transaction
WHERE     (Movement = '311')
GROUP BY RegDate
ORDER BY RegDate
GO
