-- =============================================
-- Author:		<Hanson Zhang>
-- Create date: <2014-10-29>
-- Description:	<Send message or alert to supplier with a customized text,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_KIT_SendingMsg]
	-- Add the parameters for the stored procedure here
	@SubjectText varchar(255),
	@BodyText varchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

     
	Declare  @Msg nvarchar(max)
			,@RecAddressList NVARCHAR(MAX) 
			,@copy_recipients NVARCHAR(MAX) 
			,@ProfileName nchar(20)
			
	select @Msg =   @BodyText
	select @RecAddressList = (select recipients from Cfg_DBmail where AlertName = 'KittingOrder')
	select @copy_recipients =(select copylist from Cfg_DBmail where AlertName = 'KittingOrder')
	select @ProfileName  = (select profile_name from Cfg_DBmail where AlertName = 'KittingOrder')
	
    EXEC msdb.dbo.sp_send_dbmail 
	@profile_name =@ProfileName,
	@recipients = @RecAddressList,
	@copy_recipients=@copy_recipients,
	@subject = @SubjectText,
	@body = @Msg,
    @body_format = 'HTML' ;
END
GO
