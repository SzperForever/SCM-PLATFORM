create TRIGGER [dbo].[Tri_SyncInventoryWhenDelete]
   ON  dbo.Sup_Inventory
   AFTER delete
AS 
if @@rowcount = 1
BEGIN
	SET NOCOUNT ON;

	declare @Inventory numeric(18, 7),
			@sku varchar(20)
			
	set @sku = (select material from deleted)
	set @Inventory = (select AvailableQty from deleted)
	update Sup_SKuMap set inventory = 0 where Material = @sku

END
GO
