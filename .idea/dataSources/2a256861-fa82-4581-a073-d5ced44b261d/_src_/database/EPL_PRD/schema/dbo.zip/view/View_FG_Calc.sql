CREATE VIEW dbo.View_FG_Calc
AS
SELECT     h.SRid, h.SRno, COUNT(DISTINCT mp.MPno) AS MPCnt, SUM(ISNULL(sm.GrossWeight, 0)) AS TotalGrossWeight, SUM(ISNULL(sm.NetWeight, 0)) AS TotalNetWeight, 
                      ISNULL(h.EstimatePkgCnt, 0) AS EstimatePkgCnt,
                          (SELECT     COUNT(DISTINCT Docid) AS Expr1
                            FROM          dbo.TB_FG_PKL_Details AS p
                            WHERE      (SRid = h.SRid)) AS DocCnt
FROM         dbo.TB_FG_SR_Header AS h LEFT OUTER JOIN
                      dbo.TB_FG_MP_Details AS mp ON mp.SRid = h.SRid LEFT OUTER JOIN
                      dbo.TB_FG_SM_Details AS sm ON sm.SRid = h.SRid
GROUP BY h.SRid, h.SRno, h.EstimatePkgCnt
GO
