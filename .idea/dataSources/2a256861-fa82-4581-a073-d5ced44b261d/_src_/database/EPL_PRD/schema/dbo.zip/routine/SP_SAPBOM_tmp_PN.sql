


Create procedure [dbo].[SP_SAPBOM_tmp_PN]

as begin

if exists (Select * from tempdb.dbo.sysobjects Where name='##tmp_SAP_VS_PN' and  Xtype='U') drop table [##tmp_SAP_VS_PN]

CREATE TABLE ##tmp_SAP_VS_PN(
	[PN] Nvarchar(30) NOT NULL,
	[Qty] float NOT NULL)
	

ALTER TABLE ##tmp_SAP_VS_PN ALTER COLUMN [PN] Nvarchar(30) COLLATE Chinese_PRC_CI_AS 

	--ALTER TABLE ##eP_tmp_KR ALTER COLUMN [QtyPer] varchar(20)COLLATE Chinese_PRC_CI_AS 
	--ALTER TABLE ##eP_tmp_KR ALTER COLUMN [WorkCell] [nchar](25)COLLATE Chinese_PRC_CI_AS 
	--

--Cannot resolve the collation conflict between "Chinese_PRC_CI_AS" and "SQL_Latin1_General_CP1_CI_AS" in the equal to operation.

end

GO
